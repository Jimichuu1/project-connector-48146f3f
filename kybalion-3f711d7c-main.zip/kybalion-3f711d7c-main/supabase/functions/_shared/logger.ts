/**
 * Structured Logging Utility for Edge Functions
 * Provides consistent log format for debugging and monitoring
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  level: LogLevel;
  message: string;
  context?: string;
  data?: Record<string, unknown>;
  timestamp: string;
  requestId?: string;
}

/**
 * Creates a structured logger for edge functions
 */
export function createLogger(context: string, requestId?: string) {
  const log = (level: LogLevel, message: string, data?: Record<string, unknown>) => {
    const entry: LogEntry = {
      level,
      message,
      context,
      data,
      timestamp: new Date().toISOString(),
      requestId,
    };

    // Format: [CONTEXT] [LEVEL] message {data}
    const prefix = `[${context}]`;
    const dataStr = data ? ` ${JSON.stringify(data)}` : '';

    const logFn =
      level === 'error'
        ? console.error
        : level === 'warn'
        ? console.warn
        : level === 'debug'
        ? console.debug
        : console.log;

    logFn(`${prefix} ${message}${dataStr}`);
  };

  return {
    debug: (message: string, data?: Record<string, unknown>) => log('debug', message, data),
    info: (message: string, data?: Record<string, unknown>) => log('info', message, data),
    warn: (message: string, data?: Record<string, unknown>) => log('warn', message, data),
    error: (message: string, data?: Record<string, unknown>) => log('error', message, data),
  };
}

/**
 * Generates a unique request ID
 */
export function generateRequestId(): string {
  return crypto.randomUUID();
}

/**
 * Extracts error message safely
 */
export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  if (typeof error === 'string') {
    return error;
  }
  if (error && typeof error === 'object' && 'message' in error) {
    return String((error as { message: unknown }).message);
  }
  return 'An unknown error occurred';
}

/**
 * Logs the start of a request
 */
export function logRequestStart(
  logger: ReturnType<typeof createLogger>,
  method: string,
  path: string,
  clientIp: string
): void {
  logger.info('Request received', { method, path, clientIp });
}

/**
 * Logs the end of a request
 */
export function logRequestEnd(
  logger: ReturnType<typeof createLogger>,
  status: number,
  durationMs: number
): void {
  logger.info('Request completed', { status, durationMs });
}
