// Shared authorization helper for bulk operation edge functions.
// Validates the caller's role and resolves the tenant id the operation must run against.
//
// - Throws if the caller is unauthenticated, missing a role, below the required role,
//   or attempting a cross-tenant operation as a non-SUPER_ADMIN.
// - Returns { userId, role, tenantId } where tenantId is what should be passed to
//   the RPC as p_tenant_id.

import { SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';

export type BulkRole = 'SUPER_ADMIN' | 'TENANT_OWNER' | 'MANAGER';

export interface BulkAuthContext {
  userId: string;
  role: BulkRole | string;
  tenantId: string;
}

export class BulkAuthError extends Error {
  status: number;
  constructor(message: string, status = 401) {
    super(message);
    this.status = status;
  }
}

/**
 * Verify the caller has one of the allowed roles and resolve the tenant id.
 * For SUPER_ADMIN, requestedTenantId must be supplied (cross-tenant ops allowed).
 * For everyone else, requestedTenantId is ignored and the caller's own admin_id is used.
 */
export async function authorizeBulkRequest(
  supabaseAdmin: SupabaseClient,
  userId: string,
  allowedRoles: BulkRole[],
  requestedTenantId?: string | null,
): Promise<BulkAuthContext> {
  if (!userId) throw new BulkAuthError('Unauthorized', 401);

  const { data: roleRow, error: roleErr } = await supabaseAdmin
    .from('user_roles')
    .select('role')
    .eq('user_id', userId)
    .maybeSingle();

  if (roleErr) throw new BulkAuthError('Failed to verify role', 500);
  const role = roleRow?.role as string | undefined;
  if (!role || !allowedRoles.includes(role as BulkRole)) {
    throw new BulkAuthError('Insufficient privileges', 403);
  }

  let tenantId: string | null = null;

  if (role === 'SUPER_ADMIN') {
    if (!requestedTenantId) {
      throw new BulkAuthError('tenantId is required for SUPER_ADMIN', 400);
    }
    tenantId = requestedTenantId;
  } else if (role === 'TENANT_OWNER') {
    tenantId = userId;
  } else {
    const { data: profile, error: profErr } = await supabaseAdmin
      .from('profiles')
      .select('admin_id')
      .eq('id', userId)
      .maybeSingle();
    if (profErr) throw new BulkAuthError('Failed to resolve tenant', 500);
    tenantId = profile?.admin_id ?? null;
  }

  if (!tenantId) throw new BulkAuthError('Caller has no tenant', 403);

  // Non-super-admins must not pass a different tenant id than their own.
  if (role !== 'SUPER_ADMIN' && requestedTenantId && requestedTenantId !== tenantId) {
    throw new BulkAuthError('Cross-tenant operation not permitted', 403);
  }

  return { userId, role, tenantId };
}
