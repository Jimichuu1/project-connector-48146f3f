/**
 * CORS and Response Utilities for Edge Functions
 * Provides secure, consistent CORS headers and response helpers
 */

// Allowed origins for the CRM application
const ALLOWED_ORIGINS = [
  'https://lahchwagkhwypecmjojj.supabase.co',
  'http://localhost:5173',
  'http://localhost:8080',
];

// Patterns to match dynamic subdomains
const ALLOWED_PATTERNS = [
  /^https:\/\/[a-z0-9-]+\.lovableproject\.com$/,
  /^https:\/\/[a-z0-9-]+\.lovable\.app$/,
  /^https:\/\/[a-z0-9-]+\.gptengineer\.app$/,
  /^https:\/\/lovableproject\.com$/,
  /^https:\/\/lovable\.app$/,
];

/**
 * Check if origin is allowed
 */
function isOriginAllowed(origin: string): boolean {
  // Check exact matches first
  if (ALLOWED_ORIGINS.includes(origin)) {
    return true;
  }
  
  // Check pattern matches for dynamic subdomains
  return ALLOWED_PATTERNS.some(pattern => pattern.test(origin));
}

/**
 * Get CORS headers for a given origin
 */
export function getCorsHeaders(origin: string | null): Record<string, string> {
  const isAllowed = origin && isOriginAllowed(origin);
  const allowedOrigin = isAllowed ? origin : '*';

  return {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Max-Age': '86400',
  };
}

/**
 * Security headers for all responses
 */
export const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
};

/**
 * Handle CORS preflight request
 */
export function handleCorsPreFlight(corsHeaders: Record<string, string>): Response {
  return new Response(null, {
    status: 204,
    headers: corsHeaders,
  });
}

/**
 * Combine CORS headers with security headers
 */
export function getAllHeaders(
  corsHeaders: Record<string, string>,
  contentType = 'application/json'
): Record<string, string> {
  return {
    ...corsHeaders,
    ...SECURITY_HEADERS,
    'Content-Type': contentType,
  };
}

/**
 * Create error response with proper headers
 */
export function createErrorResponse(
  message: string,
  status: number,
  corsHeaders: Record<string, string>,
  details?: Record<string, unknown>
): Response {
  return new Response(
    JSON.stringify({
      success: false,
      error: message,
      status,
      timestamp: new Date().toISOString(),
      ...details,
    }),
    {
      status,
      headers: getAllHeaders(corsHeaders),
    }
  );
}

/**
 * Create success response with proper headers
 */
export function createSuccessResponse(
  data: unknown,
  corsHeaders: Record<string, string>,
  status = 200
): Response {
  const responseData = typeof data === 'object' && data !== null
    ? { success: true, ...data }
    : { success: true, data };

  return new Response(
    JSON.stringify(responseData),
    {
      status,
      headers: getAllHeaders(corsHeaders),
    }
  );
}

/**
 * Create accepted response for async operations
 */
export function createAcceptedResponse(
  message: string,
  count: number,
  corsHeaders: Record<string, string>
): Response {
  return new Response(
    JSON.stringify({
      success: true,
      status: 'processing',
      message,
      count,
      timestamp: new Date().toISOString(),
    }),
    {
      status: 202,
      headers: getAllHeaders(corsHeaders),
    }
  );
}
