/**
 * Rate Limiting Utilities for Edge Functions
 * Provides IP-based rate limiting with configurable windows
 */

import { getAllHeaders } from './cors.ts';

/**
 * Rate limit configuration
 */
export interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
  keyPrefix?: string;
}

/**
 * Rate limit check result
 */
export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
  retryAfter?: number;
}

// In-memory store for rate limiting
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();

/**
 * Check rate limit for a given key
 */
export function checkRateLimit(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now();
  const storeKey = config.keyPrefix ? `${config.keyPrefix}:${key}` : key;
  const entry = rateLimitStore.get(storeKey);

  if (!entry || now >= entry.resetAt) {
    rateLimitStore.set(storeKey, { count: 1, resetAt: now + config.windowMs });
    return {
      allowed: true,
      remaining: config.maxRequests - 1,
      resetAt: now + config.windowMs,
    };
  }

  if (entry.count >= config.maxRequests) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: entry.resetAt,
      retryAfter: Math.ceil((entry.resetAt - now) / 1000),
    };
  }

  entry.count++;
  return {
    allowed: true,
    remaining: config.maxRequests - entry.count,
    resetAt: entry.resetAt,
  };
}

/**
 * Get rate limit headers for response
 */
export function getRateLimitHeaders(result: RateLimitResult, config: RateLimitConfig): Record<string, string> {
  const headers: Record<string, string> = {
    'X-RateLimit-Limit': String(config.maxRequests),
    'X-RateLimit-Remaining': String(result.remaining),
    'X-RateLimit-Reset': String(result.resetAt),
  };

  if (result.retryAfter) {
    headers['Retry-After'] = String(result.retryAfter);
  }

  return headers;
}

/**
 * Predefined rate limit configurations
 */
export const RATE_LIMIT_CONFIGS = {
  // Standard API endpoints
  standard: {
    windowMs: 60 * 1000,
    maxRequests: 60,
    keyPrefix: 'standard',
  } as RateLimitConfig,

  // Authentication endpoints (stricter)
  auth: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 10,
    keyPrefix: 'auth',
  } as RateLimitConfig,

  // Email endpoints
  email: {
    windowMs: 60 * 1000,
    maxRequests: 20,
    keyPrefix: 'email',
  } as RateLimitConfig,

  // Call/CCC endpoints
  calls: {
    windowMs: 60 * 1000,
    maxRequests: 30,
    keyPrefix: 'calls',
  } as RateLimitConfig,

  // Bulk operations
  bulk: {
    windowMs: 60 * 1000,
    maxRequests: 10,
    keyPrefix: 'bulk',
  } as RateLimitConfig,

  // Webhook endpoints (more permissive)
  webhook: {
    windowMs: 60 * 1000,
    maxRequests: 100,
    keyPrefix: 'webhook',
  } as RateLimitConfig,

  // User management
  userManagement: {
    windowMs: 60 * 1000,
    maxRequests: 20,
    keyPrefix: 'user-mgmt',
  } as RateLimitConfig,
};

/**
 * Get client IP from request
 */
export function getClientIp(req: Request): string {
  return (
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-real-ip') ||
    req.headers.get('cf-connecting-ip') ||
    'unknown'
  );
}

/**
 * Rate limit middleware - returns error response if rate limited, null otherwise
 */
export function rateLimitMiddleware(
  req: Request,
  config: RateLimitConfig,
  corsHeaders: Record<string, string>
): { response: Response | null; result: RateLimitResult } {
  const clientIp = getClientIp(req);
  const result = checkRateLimit(clientIp, config);

  if (!result.allowed) {
    const response = new Response(
      JSON.stringify({
        success: false,
        error: 'Too many requests',
        message: `Rate limit exceeded. Please try again in ${result.retryAfter} seconds.`,
        retryAfter: result.retryAfter,
      }),
      {
        status: 429,
        headers: {
          ...getAllHeaders(corsHeaders),
          ...getRateLimitHeaders(result, config),
        },
      }
    );
    return { response, result };
  }

  return { response: null, result };
}

/**
 * Cleanup expired entries (call periodically)
 */
export function cleanupExpiredEntries(): void {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (now >= entry.resetAt) {
      rateLimitStore.delete(key);
    }
  }
}
