/**
 * Authentication Utilities for Edge Functions
 * Provides consistent auth verification across all functions
 */

import { createClient, SupabaseClient, User } from 'https://esm.sh/@supabase/supabase-js@2';
import { createErrorResponse } from './cors.ts';

export type UserRole = 'SUPER_ADMIN' | 'TENANT_OWNER' | 'ADMIN' | 'MANAGER' | 'SUPER_AGENT' | 'AGENT';

export interface AuthResult {
  user: User | null;
  error: Response | null;
  supabaseUser: SupabaseClient;
  supabaseAdmin: SupabaseClient;
}

export interface RoleCheckResult {
  hasRole: boolean;
  role: UserRole | null;
  error: Response | null;
}

/**
 * Create Supabase clients for edge function
 */
export function createSupabaseClients(authHeader: string | null): {
  supabaseUser: SupabaseClient;
  supabaseAdmin: SupabaseClient;
} {
  const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
  const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? '';
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

  const supabaseUser = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: authHeader ? { Authorization: authHeader } : {} },
  });

  const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  return { supabaseUser, supabaseAdmin };
}

/**
 * Verify user authentication
 */
export async function verifyAuth(
  req: Request,
  corsHeaders: Record<string, string>
): Promise<AuthResult> {
  const authHeader = req.headers.get('Authorization');

  if (!authHeader) {
    return {
      user: null,
      error: createErrorResponse('Missing authorization header', 401, corsHeaders),
      supabaseUser: null as unknown as SupabaseClient,
      supabaseAdmin: null as unknown as SupabaseClient,
    };
  }

  const { supabaseUser, supabaseAdmin } = createSupabaseClients(authHeader);

  const {
    data: { user },
    error: authError,
  } = await supabaseUser.auth.getUser();

  if (authError || !user) {
    return {
      user: null,
      error: createErrorResponse('Unauthorized', 401, corsHeaders),
      supabaseUser,
      supabaseAdmin,
    };
  }

  return {
    user,
    error: null,
    supabaseUser,
    supabaseAdmin,
  };
}

/**
 * Check if user has required role
 */
export async function checkUserRole(
  supabaseAdmin: SupabaseClient,
  userId: string,
  allowedRoles: UserRole[],
  corsHeaders: Record<string, string>
): Promise<RoleCheckResult> {
  const { data: roles, error: roleError } = await supabaseAdmin
    .from('user_roles')
    .select('role')
    .eq('user_id', userId);

  if (roleError || !roles || roles.length === 0) {
    return {
      hasRole: false,
      role: null,
      error: createErrorResponse('Could not verify permissions', 403, corsHeaders),
    };
  }

  const userRole = roles[0]?.role as UserRole;
  const hasRole = allowedRoles.includes(userRole);

  if (!hasRole) {
    return {
      hasRole: false,
      role: userRole,
      error: createErrorResponse('Insufficient permissions', 403, corsHeaders),
    };
  }

  return {
    hasRole: true,
    role: userRole,
    error: null,
  };
}

/**
 * Get user's tenant ID (admin_id)
 */
export async function getUserTenantId(
  supabaseAdmin: SupabaseClient,
  userId: string
): Promise<string | null> {
  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('admin_id')
    .eq('id', userId)
    .single();

  return profile?.admin_id || userId;
}

/**
 * Full auth verification with role check
 */
export async function verifyAuthWithRole(
  req: Request,
  allowedRoles: UserRole[],
  corsHeaders: Record<string, string>
): Promise<{
  user: User | null;
  role: UserRole | null;
  tenantId: string | null;
  error: Response | null;
  supabaseAdmin: SupabaseClient;
}> {
  const authResult = await verifyAuth(req, corsHeaders);

  if (authResult.error) {
    return {
      user: null,
      role: null,
      tenantId: null,
      error: authResult.error,
      supabaseAdmin: authResult.supabaseAdmin,
    };
  }

  const roleResult = await checkUserRole(
    authResult.supabaseAdmin,
    authResult.user!.id,
    allowedRoles,
    corsHeaders
  );

  if (roleResult.error) {
    return {
      user: authResult.user,
      role: null,
      tenantId: null,
      error: roleResult.error,
      supabaseAdmin: authResult.supabaseAdmin,
    };
  }

  const tenantId = await getUserTenantId(authResult.supabaseAdmin, authResult.user!.id);

  return {
    user: authResult.user,
    role: roleResult.role,
    tenantId,
    error: null,
    supabaseAdmin: authResult.supabaseAdmin,
  };
}
