import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getCorsHeaders, handleCorsPreFlight, createSuccessResponse, createErrorResponse } from '../_shared/cors.ts';
import { createLogger, generateRequestId, getErrorMessage } from '../_shared/logger.ts';
import { rateLimitMiddleware, RATE_LIMIT_CONFIGS } from '../_shared/rate-limiter.ts';

Deno.serve(async (req) => {
  const requestId = generateRequestId();
  const logger = createLogger('create-sample-users', requestId);
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') return handleCorsPreFlight(corsHeaders);

  const { response: rateLimitResponse } = rateLimitMiddleware(req, RATE_LIMIT_CONFIGS.auth, corsHeaders);
  if (rateLimitResponse) return rateLimitResponse;

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return createErrorResponse('Missing authorization header', 401, corsHeaders);

    const token = authHeader.replace('Bearer ', '');
    const supabaseAdmin = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '', { auth: { autoRefreshToken: false, persistSession: false } });

    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    if (userError || !user) return createErrorResponse('Unauthorized', 401, corsHeaders);

    const { data: roles } = await supabaseAdmin.from('user_roles').select('role').eq('user_id', user.id).in('role', ['SUPER_ADMIN', 'TENANT_OWNER']);
    if (!roles || roles.length === 0) return createErrorResponse('Access denied. Super Admin or Tenant Owner role required.', 403, corsHeaders);

    logger.info('Creating sample users', { requestedBy: user.email });

    const sampleUsers = [
      { email: 'agent1@forexcrm.com', password: 'Agent123!@#', full_name: 'John Smith', role: 'AGENT' },
      { email: 'agent2@forexcrm.com', password: 'Agent123!@#', full_name: 'Sarah Johnson', role: 'AGENT' },
      { email: 'superagent1@forexcrm.com', password: 'SuperAgent123!@#', full_name: 'Emily Williams', role: 'SUPER_AGENT' },
    ];

    const createdUsers = [];
    for (const userData of sampleUsers) {
      const { data: existingUser } = await supabaseAdmin.auth.admin.listUsers();
      if (existingUser?.users.some((u) => u.email === userData.email)) continue;

      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({ email: userData.email, password: userData.password, email_confirm: true, user_metadata: { full_name: userData.full_name } });
      if (authError || !authData.user) continue;

      await supabaseAdmin.from('user_roles').insert({ user_id: authData.user.id, role: userData.role });
      createdUsers.push({ email: userData.email, full_name: userData.full_name, role: userData.role });
    }

    logger.info('Sample users created', { count: createdUsers.length });
    return createSuccessResponse({ message: `Created ${createdUsers.length} users successfully`, users: createdUsers }, corsHeaders);
  } catch (error) {
    const errorMessage = getErrorMessage(error);
    logger.error('Error creating sample users', { error: errorMessage });
    return createErrorResponse(errorMessage, 500, corsHeaders);
  }
});
