import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getCorsHeaders, handleCorsPreFlight, createSuccessResponse, getAllHeaders } from '../_shared/cors.ts';
import { createLogger, generateRequestId } from '../_shared/logger.ts';

const VERSION = '1.0.0';
const startTime = Date.now();

Deno.serve(async (req) => {
  const requestId = generateRequestId();
  const logger = createLogger('health-check', requestId);
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') return handleCorsPreFlight(corsHeaders);

  const url = new URL(req.url);
  const path = url.pathname.split('/').pop();

  if (path === 'live' || req.method === 'HEAD') {
    return new Response('OK', { status: 200, headers: { ...corsHeaders, 'Content-Type': 'text/plain' } });
  }

  const supabase = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_ANON_KEY') ?? '');

  const checkDatabase = async () => {
    const start = Date.now();
    try {
      const { error } = await supabase.from('profiles').select('id').limit(1);
      return { status: error ? 'fail' : 'pass', latency_ms: Date.now() - start, message: error?.message };
    } catch (e) { return { status: 'fail', latency_ms: Date.now() - start, message: e instanceof Error ? e.message : 'Unknown' }; }
  };

  const checkAuth = async () => {
    const start = Date.now();
    try {
      const { error } = await supabase.auth.getSession();
      return { status: error ? 'fail' : 'pass', latency_ms: Date.now() - start, message: error?.message };
    } catch (e) { return { status: 'fail', latency_ms: Date.now() - start, message: e instanceof Error ? e.message : 'Unknown' }; }
  };

  if (path === 'ready') {
    const dbCheck = await checkDatabase();
    const isReady = dbCheck.status === 'pass';
    return new Response(JSON.stringify({ ready: isReady, checks: { database: dbCheck } }), { status: isReady ? 200 : 503, headers: getAllHeaders(corsHeaders) });
  }

  const [dbCheck, authCheck] = await Promise.all([checkDatabase(), checkAuth()]);
  const overallStatus = dbCheck.status === 'pass' && authCheck.status === 'pass' ? 'healthy' : 'unhealthy';

  logger.info('Health check completed', { status: overallStatus });
  return new Response(JSON.stringify({ status: overallStatus, timestamp: new Date().toISOString(), version: VERSION, uptime: Math.floor((Date.now() - startTime) / 1000), checks: { database: dbCheck, auth: authCheck } }, null, 2), { status: overallStatus === 'healthy' ? 200 : 503, headers: getAllHeaders(corsHeaders) });
});
