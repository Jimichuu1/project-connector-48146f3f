import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getCorsHeaders, handleCorsPreFlight, createSuccessResponse, createErrorResponse } from '../_shared/cors.ts';
import { createLogger, generateRequestId, getErrorMessage } from '../_shared/logger.ts';

Deno.serve(async (req) => {
  const requestId = generateRequestId();
  const logger = createLogger('security-monitor', requestId);
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') return handleCorsPreFlight(corsHeaders);

  try {
    const supabaseClient = createClient(Deno.env.get('SUPABASE_URL') ?? '', Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '');
    const now = new Date();
    const fifteenMinutesAgo = new Date(now.getTime() - 15 * 60 * 1000);
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);

    logger.info('Running security monitoring checks');

    // Check for failed login attempts
    const { data: failedLogins } = await supabaseClient.from('auth_attempts').select('ip_address, user_email').eq('success', false).gte('created_at', fifteenMinutesAgo.toISOString());

    if (failedLogins) {
      const ipCounts = new Map<string, { count: number; emails: Set<string> }>();
      for (const attempt of failedLogins) {
        if (!ipCounts.has(attempt.ip_address)) ipCounts.set(attempt.ip_address, { count: 0, emails: new Set() });
        const entry = ipCounts.get(attempt.ip_address)!;
        entry.count++;
        if (attempt.user_email) entry.emails.add(attempt.user_email);
      }

      for (const [ip, data] of ipCounts) {
        if (data.count >= 5) {
          const { data: adminRoles } = await supabaseClient.from('user_roles').select('user_id').in('role', ['SUPER_ADMIN', 'TENANT_OWNER']);
          if (adminRoles) {
            for (const admin of adminRoles) {
              await supabaseClient.from('notifications').insert({ user_id: admin.user_id, type: 'TICKET_CREATED', message: `Security Alert: ${data.count} failed login attempts from IP ${ip}`, related_entity_type: 'security_alert', related_entity_id: ip });
            }
          }
          logger.warn('Suspicious failed logins detected', { ip, count: data.count });
        }
      }
    }

    // Check unusual access patterns
    const { data: recentSessions } = await supabaseClient.from('user_sessions').select('ip_address, user_id').eq('is_active', true).gte('created_at', oneHourAgo.toISOString());

    if (recentSessions) {
      const sessionsByIp = new Map<string, Set<string>>();
      for (const session of recentSessions) {
        if (!session.ip_address) continue;
        if (!sessionsByIp.has(session.ip_address)) sessionsByIp.set(session.ip_address, new Set());
        sessionsByIp.get(session.ip_address)!.add(session.user_id);
      }

      for (const [ip, userIds] of sessionsByIp) {
        if (userIds.size >= 3) {
          const { data: adminRoles } = await supabaseClient.from('user_roles').select('user_id').in('role', ['SUPER_ADMIN', 'TENANT_OWNER']);
          if (adminRoles) {
            for (const admin of adminRoles) {
              await supabaseClient.from('notifications').insert({ user_id: admin.user_id, type: 'TICKET_CREATED', message: `Security Alert: ${userIds.size} users from IP ${ip}`, related_entity_type: 'security_alert', related_entity_id: ip });
            }
          }
          logger.warn('Unusual access pattern', { ip, userCount: userIds.size });
        }
      }
    }

    logger.info('Security monitoring completed');
    return createSuccessResponse({ message: 'Security monitoring completed' }, corsHeaders);
  } catch (error) {
    const errorMessage = getErrorMessage(error);
    logger.error('Security monitoring error', { error: errorMessage });
    return createErrorResponse(errorMessage, 500, corsHeaders);
  }
});
