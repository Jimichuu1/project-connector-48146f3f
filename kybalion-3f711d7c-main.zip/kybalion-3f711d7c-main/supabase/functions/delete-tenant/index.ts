import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getCorsHeaders, handleCorsPreFlight, createErrorResponse, createSuccessResponse } from "../_shared/cors.ts";
import { createLogger, generateRequestId } from "../_shared/logger.ts";

Deno.serve(async (req) => {
  const requestId = generateRequestId();
  const logger = createLogger("delete-tenant", requestId);
  const origin = req.headers.get("origin");
  const corsHeaders = getCorsHeaders(origin);

  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return handleCorsPreFlight(corsHeaders);
  }

  try {
    // Get authorization header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return createErrorResponse("Missing authorization header", 401, corsHeaders);
    }

    // Initialize Supabase admin client
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Verify the caller's JWT and get their user ID
    const token = authHeader.replace("Bearer ", "");
    const { data: { user: caller }, error: authError } = await supabaseAdmin.auth.getUser(token);

    if (authError || !caller) {
      logger.error("Authentication failed", { error: authError?.message });
      return createErrorResponse("Invalid authentication token", 401, corsHeaders);
    }

    // Check if caller is SUPER_ADMIN
    const { data: callerRoles, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", caller.id);

    if (roleError) {
      logger.error("Failed to check caller role", { error: roleError.message });
      return createErrorResponse("Failed to verify permissions", 500, corsHeaders);
    }

    const isSuperAdmin = callerRoles?.some((r) => r.role === "SUPER_ADMIN");
    if (!isSuperAdmin) {
      logger.warn("Non-super admin attempted to delete tenant", { callerId: caller.id });
      return createErrorResponse("Only super admins can delete tenants", 403, corsHeaders);
    }

    // Parse request body
    const { tenantId, deleteUsers } = await req.json();

    if (!tenantId) {
      return createErrorResponse("Tenant ID is required", 400, corsHeaders);
    }

    logger.info("Deleting tenant", { tenantId, deleteUsers });

    // Verify the tenant exists and is a TENANT_OWNER
    const { data: tenantRole, error: tenantRoleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", tenantId)
      .eq("role", "TENANT_OWNER")
      .single();

    if (tenantRoleError || !tenantRole) {
      return createErrorResponse("Tenant not found or is not a valid tenant", 404, corsHeaders);
    }

    // If deleteUsers is true, get all users under this tenant and delete them
    if (deleteUsers) {
      // Get users by admin_id (primary way users are linked to tenant)
      const { data: usersByAdmin, error: adminError } = await supabaseAdmin
        .from("profiles")
        .select("id")
        .eq("admin_id", tenantId)
        .neq("id", tenantId); // Don't include the tenant itself

      // Also get users by created_by (fallback)
      const { data: usersByCreator, error: creatorError } = await supabaseAdmin
        .from("profiles")
        .select("id")
        .eq("created_by", tenantId)
        .neq("id", tenantId);

      if (adminError || creatorError) {
        logger.error("Failed to fetch tenant users", { 
          adminError: adminError?.message, 
          creatorError: creatorError?.message 
        });
        return createErrorResponse("Failed to fetch tenant users", 500, corsHeaders);
      }

      // Combine and dedupe user IDs
      const allUserIds = new Set<string>();
      (usersByAdmin || []).forEach(u => allUserIds.add(u.id));
      (usersByCreator || []).forEach(u => allUserIds.add(u.id));

      logger.info("Found users to delete", { count: allUserIds.size, userIds: Array.from(allUserIds) });

      // Delete user_roles first for each user
      for (const userId of allUserIds) {
        const { error: roleDelError } = await supabaseAdmin
          .from("user_roles")
          .delete()
          .eq("user_id", userId);
        
        if (roleDelError) {
          logger.warn("Failed to delete user roles", { userId, error: roleDelError.message });
        }
      }

      // Delete each user from auth (this will cascade to profiles due to FK)
      let deletedCount = 0;
      for (const userId of allUserIds) {
        const { error: deleteUserError } = await supabaseAdmin.auth.admin.deleteUser(userId);
        if (deleteUserError) {
          logger.warn("Failed to delete user", { userId, error: deleteUserError.message });
        } else {
          deletedCount++;
        }
      }

      logger.info("Deleted tenant users", { found: allUserIds.size, deleted: deletedCount });
    }

    // Delete all tenant data (the order matters for FK constraints)
    const tablesToClean = [
      // Activities and logs
      { table: "lead_activities", column: "admin_id" },
      { table: "client_activities", column: "admin_id" },
      { table: "audit_logs", column: "admin_id" },
      
      // Comments
      { table: "lead_comments", column: null, subquery: { table: "leads", column: "admin_id" } },
      { table: "client_comments", column: null, subquery: { table: "clients", column: "admin_id" } },
      
      // Tasks
      { table: "lead_tasks", column: null, subquery: { table: "leads", column: "admin_id" } },
      { table: "client_tasks", column: null, subquery: { table: "clients", column: "admin_id" } },
      
      // Groups and memberships
      { table: "lead_group_members", column: null, subquery: { table: "lead_groups", column: "admin_id" } },
      { table: "lead_groups", column: "admin_id" },
      { table: "client_group_members", column: null, subquery: { table: "client_groups", column: "admin_id" } },
      { table: "client_groups", column: "admin_id" },
      
      // KYC and documents
      { table: "documents", column: "admin_id" },
      { table: "kyc_records", column: "admin_id" },
      
      // Deposits and withdrawals
      { table: "deposits", column: "admin_id" },
      { table: "client_withdrawals", column: null, subquery: { table: "clients", column: "admin_id" } },
      
      // Notifications and reminders
      { table: "notifications", column: "admin_id" },
      { table: "reminders", column: "admin_id" },
      
      // Attendance
      { table: "attendance", column: "admin_id" },
      
      // Settings
      { table: "admin_settings", column: "admin_id" },
      { table: "commission_tier_settings", column: "admin_id" },
      
      // IP whitelist
      { table: "ip_whitelist", column: "admin_id" },
      
      // Main entities (order matters - clients after leads due to converted_from_lead_id)
      { table: "clients", column: "admin_id" },
      { table: "leads", column: "admin_id" },
    ];

    for (const { table, column, subquery } of tablesToClean) {
      try {
        if (column) {
          // Direct delete by admin_id
          const { error } = await supabaseAdmin
            .from(table)
            .delete()
            .eq(column, tenantId);
          
          if (error) {
            logger.warn(`Failed to clean ${table}`, { error: error.message });
          }
        } else if (subquery) {
          // Need to get IDs first, then delete
          const { data: parentIds } = await supabaseAdmin
            .from(subquery.table)
            .select("id")
            .eq(subquery.column, tenantId);
          
          if (parentIds && parentIds.length > 0) {
            const ids = parentIds.map(p => p.id);
            const parentColumn = subquery.table === "leads" ? "lead_id" : "client_id";
            
            const { error } = await supabaseAdmin
              .from(table)
              .delete()
              .in(parentColumn, ids);
            
            if (error) {
              logger.warn(`Failed to clean ${table}`, { error: error.message });
            }
          }
        }
      } catch (err) {
        logger.warn(`Error cleaning ${table}`, { error: String(err) });
      }
    }

    // Delete the tenant's user role
    const { error: roleDeleteError } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", tenantId);

    if (roleDeleteError) {
      logger.warn("Failed to delete tenant role", { error: roleDeleteError.message });
    }

    // Finally, delete the tenant user from auth (this will cascade to profile)
    const { error: deleteTenantError } = await supabaseAdmin.auth.admin.deleteUser(tenantId);

    if (deleteTenantError) {
      logger.error("Failed to delete tenant user", { error: deleteTenantError.message });
      return createErrorResponse("Failed to delete tenant user account", 500, corsHeaders);
    }

    logger.info("Tenant deleted successfully", { tenantId });

    return createSuccessResponse({ message: "Tenant deleted successfully" }, corsHeaders);
  } catch (error) {
    logger.error("Unexpected error", { error: String(error) });
    return createErrorResponse("An unexpected error occurred", 500, corsHeaders);
  }
});
