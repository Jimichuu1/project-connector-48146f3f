// Partner API proxy: TO/SA in Kybalion can call the external partner site's
// endpoints without ever exposing the API key to the browser.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.50.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const PARTNER_API_KEY = normalizeApiKey(Deno.env.get("PARTNER_API_KEY") ?? "");
const PARTNER_API_BASE_URL =
  (Deno.env.get("PARTNER_API_BASE_URL") ?? "https://tvlhwgwftujrecxkmixj.supabase.co/functions/v1")
    .replace(/\/+$/, "");

function normalizeApiKey(value: string): string {
  return value
    .trim()
    .replace(/^x-api-key\s*:\s*/i, "")
    .replace(/^authorization\s*:\s*bearer\s+/i, "")
    .replace(/^bearer\s+/i, "")
    .replace(/^['"]|['"]$/g, "")
    .trim();
}

type EndpointKey =
  | "create-user"
  | "create-transaction"
  | "create-user-with-deposit"
  | "ping";

const ENDPOINT_MAP: Record<Exclude<EndpointKey, "ping">, string> = {
  "create-user": "/api-create-user",
  "create-transaction": "/api-create-transaction",
  "create-user-with-deposit": "/api-create-user-with-deposit",
};

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function redact(payload: unknown): unknown {
  if (!payload || typeof payload !== "object") return payload;
  if (Array.isArray(payload)) return payload.map(redact);
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(payload as Record<string, unknown>)) {
    if (k.toLowerCase() === "password" || k.toLowerCase() === "api_key" || k.toLowerCase() === "x-api-key") {
      out[k] = "••••";
    } else if (v && typeof v === "object") {
      out[k] = redact(v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

function validatePayload(endpoint: EndpointKey, payload: any): string | null {
  const isStr = (v: unknown) => typeof v === "string" && v.trim().length > 0;
  const isNum = (v: unknown) => typeof v === "number" && Number.isFinite(v);

  if (endpoint === "ping") return null;

  if (endpoint === "create-user" || endpoint === "create-user-with-deposit") {
    if (!isStr(payload?.email)) return "email is required";
    if (!isStr(payload?.password)) return "password is required";
  }

  if (endpoint === "create-transaction") {
    if (!isStr(payload?.user_id) && !isStr(payload?.user_email)) {
      return "user_id or user_email is required";
    }
    if (!isStr(payload?.type)) return "type is required";
    if (!isStr(payload?.token)) return "token is required";
    if (!isNum(payload?.amount)) return "amount must be a number";
    // usd_value optional — partner calculates it
    if (!isStr(payload?.status)) return "status is required";
  }

  if (endpoint === "create-user-with-deposit") {
    const dep = payload?.deposit;
    if (!dep || typeof dep !== "object") return "deposit object is required";
    if (!isStr(dep.token)) return "deposit.token is required";
    if (!isNum(dep.amount)) return "deposit.amount must be a number";
    if (!isStr(dep.status)) return "deposit.status is required";
  }

  if (endpoint === "create-transaction") {
    // usd_value optional — partner calculates it
  }

  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  // Auth
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return json(401, { error: "Unauthorized" });

  const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
  });
  const token = authHeader.replace("Bearer ", "");
  const { data: claimsData, error: claimsErr } = await userClient.auth.getClaims(token);
  if (claimsErr || !claimsData?.claims?.sub) return json(401, { error: "Unauthorized" });
  const userId = claimsData.claims.sub as string;

  // Service role client for role check + audit log
  const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

  const { data: roleRows } = await admin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId);
  const roles = (roleRows ?? []).map((r: any) => r.role);
  const isSuperAdmin = roles.includes("SUPER_ADMIN");
  const isTenantOwner = roles.includes("TENANT_OWNER");
  // All authenticated users (any role) may invoke partner endpoints.

  // Effective tenant
  let adminId: string | null = null;
  if (isTenantOwner) {
    adminId = userId;
  } else if (isSuperAdmin) {
    adminId = null;
  } else {
    const { data: prof } = await admin.from("profiles").select("admin_id").eq("id", userId).maybeSingle();
    adminId = prof?.admin_id ?? null;
  }

  // Body
  let body: any;
  try {
    body = await req.json();
  } catch {
    return json(400, { error: "Invalid JSON" });
  }

  const endpoint = body?.endpoint as EndpointKey | undefined;
  const payload = body?.payload ?? {};
  if (!endpoint || !["create-user", "create-transaction", "create-user-with-deposit", "ping"].includes(endpoint)) {
    return json(400, { error: "Invalid endpoint" });
  }

  const validationError = validatePayload(endpoint, payload);
  if (validationError) return json(400, { error: validationError });

  if (!PARTNER_API_KEY) {
    return json(500, { error: "PARTNER_API_KEY is not configured" });
  }

  // Ping = HEAD/GET to base URL
  if (endpoint === "ping") {
    try {
      const res = await fetch(PARTNER_API_BASE_URL, {
        method: "GET",
        headers: { "x-api-key": PARTNER_API_KEY },
      });
      const text = await res.text();
      return json(200, {
        ok: true,
        reachable: true,
        partner_status: res.status,
        partner_base_url: PARTNER_API_BASE_URL,
        sample: text.slice(0, 200),
      });
    } catch (e) {
      return json(200, { ok: false, reachable: false, error: String(e) });
    }
  }

  // Forward
  const url = `${PARTNER_API_BASE_URL}${ENDPOINT_MAP[endpoint]}`;
  let partnerStatus = 0;
  let partnerBody: any = null;
  let networkError: string | null = null;
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": PARTNER_API_KEY,
      },
      body: JSON.stringify(payload),
    });
    partnerStatus = res.status;
    const text = await res.text();
    try {
      partnerBody = text ? JSON.parse(text) : null;
    } catch {
      partnerBody = { raw: text };
    }
  } catch (e) {
    networkError = String(e);
  }

  // Audit log (best-effort)
  try {
    await admin.from("partner_api_call_log").insert({
      caller_user_id: userId,
      admin_id: adminId,
      endpoint,
      request_payload: redact(payload) as any,
      response_status: networkError ? null : partnerStatus,
      response_body: networkError ? { error: networkError } : partnerBody,
    });
  } catch (e) {
    console.error("audit log insert failed", e);
  }

  if (networkError) return json(502, { error: "Network error", detail: networkError });

  return json(partnerStatus, partnerBody ?? {});
});
