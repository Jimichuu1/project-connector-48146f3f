import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getCorsHeaders, handleCorsPreFlight, createErrorResponse, createSuccessResponse } from '../_shared/cors.ts';
import { createLogger, generateRequestId, getErrorMessage } from '../_shared/logger.ts';
import { rateLimitMiddleware, RATE_LIMIT_CONFIGS } from '../_shared/rate-limiter.ts';

Deno.serve(async (req) => {
  const requestId = generateRequestId();
  const logger = createLogger('manage-user-password', requestId);
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') {
    return handleCorsPreFlight(corsHeaders);
  }

  // Rate limiting
  const { response: rateLimitResponse } = rateLimitMiddleware(req, RATE_LIMIT_CONFIGS.auth, corsHeaders);
  if (rateLimitResponse) {
    logger.warn('Rate limit exceeded');
    return rateLimitResponse;
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      logger.warn('Missing authorization header');
      return createErrorResponse('Missing authorization header', 401, corsHeaders);
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !user) {
      logger.warn('Unauthorized', { error: userError?.message });
      return createErrorResponse('Unauthorized', 401, corsHeaders);
    }

    // Check user role
    const { data: roles } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .in('role', ['SUPER_ADMIN', 'TENANT_OWNER', 'MANAGER']);

    if (!roles || roles.length === 0) {
      logger.warn('Insufficient permissions', { userId: user.id });
      return createErrorResponse('Insufficient permissions', 403, corsHeaders);
    }
    
    const currentUserRole = roles[0]?.role;
    const { action, userId, newPassword, excludeAdmins, force } = await req.json();

    logger.info('Processing action', { action, userId, requestedBy: user.id });

    // DELETE USER
    if (action === 'delete-user') {
      if (!userId) {
        return createErrorResponse('Missing userId', 400, corsHeaders);
      }

      // Check target user's role
      const { data: targetRoleData } = await supabaseAdmin
        .from('user_roles')
        .select('role')
        .eq('user_id', userId)
        .single();

      const targetRole = targetRoleData?.role;

      // SUPER_ADMIN can only be deleted by another SUPER_ADMIN
      if (targetRole === 'SUPER_ADMIN' && currentUserRole !== 'SUPER_ADMIN') {
        logger.warn('Cannot delete SUPER_ADMIN', { targetRole, currentUserRole });
        return createErrorResponse('Only SUPER_ADMIN can delete another SUPER_ADMIN', 403, corsHeaders);
      }

      // Check assigned clients/leads
      const { count: assignedClientsCount } = await supabaseAdmin
        .from('clients')
        .select('id', { count: 'exact', head: true })
        .eq('assigned_to', userId);

      const { count: assignedLeadsCount } = await supabaseAdmin
        .from('leads')
        .select('id', { count: 'exact', head: true })
        .eq('assigned_to', userId);

      const totalAssignments = (assignedClientsCount ?? 0) + (assignedLeadsCount ?? 0);

      // Request confirmation if has assignments
      if (totalAssignments > 0 && !force) {
        return createSuccessResponse({
          needsConfirmation: true,
          assignedClientsCount: assignedClientsCount ?? 0,
          assignedLeadsCount: assignedLeadsCount ?? 0
        }, corsHeaders);
      }

      // Always unassign clients and leads (they must become unassigned)
      if (totalAssignments > 0) {
        const { error: clientsUnassignError } = await supabaseAdmin
          .from('clients')
          .update({ assigned_to: null })
          .eq('assigned_to', userId);

        const { error: leadsUnassignError } = await supabaseAdmin
          .from('leads')
          .update({ assigned_to: null })
          .eq('assigned_to', userId);

        if (clientsUnassignError || leadsUnassignError) {
          logger.warn('Error unassigning clients/leads', {
            clientsError: clientsUnassignError?.message,
            leadsError: leadsUnassignError?.message
          });
        }

        logger.info('Unassigned clients and leads', { userId, assignedClientsCount, assignedLeadsCount });
      }

      // Detect hard-delete intent (legacy `force` flag still triggers full removal)
      const hardDelete = force === 'hard' || force === true;

      if (hardDelete) {
        // HARD DELETE — wipes profile and auth user (legacy behaviour, loses history)
        await supabaseAdmin.from('user_roles').delete().eq('user_id', userId);
        await supabaseAdmin.from('user_permissions').delete().eq('user_id', userId);
        await supabaseAdmin.from('ip_whitelist').delete().eq('user_id', userId);
        await supabaseAdmin.from('user_sessions').delete().eq('user_id', userId);

        const { error: profileError } = await supabaseAdmin
          .from('profiles')
          .delete()
          .eq('id', userId);

        if (profileError) {
          logger.error('Failed to delete profile', { error: profileError.message, userId });
          return createErrorResponse(`Failed to delete user profile: ${profileError.message}`, 500, corsHeaders);
        }

        const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(userId);
        if (deleteError) {
          logger.warn('Auth delete failed (profile already removed)', { error: deleteError.message });
        }

        logger.info('User hard-deleted', { userId });
        return createSuccessResponse({ message: 'User permanently deleted' }, corsHeaders);
      }

      // SOFT DELETE — preserves profile/history so past salary records remain valid
      // Remove role/permissions/whitelist/sessions so user cannot do anything if reactivated
      await supabaseAdmin.from('user_roles').delete().eq('user_id', userId);
      await supabaseAdmin.from('user_permissions').delete().eq('user_id', userId);
      await supabaseAdmin.from('ip_whitelist').delete().eq('user_id', userId);
      await supabaseAdmin.from('user_sessions').delete().eq('user_id', userId);

      const { error: softErr } = await supabaseAdmin
        .from('profiles')
        .update({ deleted_at: new Date().toISOString() })
        .eq('id', userId);

      if (softErr) {
        logger.error('Failed to soft-delete profile', { error: softErr.message, userId });
        return createErrorResponse(`Failed to soft-delete user: ${softErr.message}`, 500, corsHeaders);
      }

      // Ban auth user so they can't log in (effectively disables the account)
      const { error: banErr } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        ban_duration: '876000h', // ~100 years
      });
      if (banErr) {
        logger.warn('Failed to ban auth user', { error: banErr.message, userId });
      }

      logger.info('User soft-deleted (history preserved)', { userId });
      return createSuccessResponse({ message: 'User deleted successfully' }, corsHeaders);
    }

    // UPDATE PASSWORD
    if (action === 'update-password') {
      if (!userId || !newPassword) {
        return createErrorResponse('Missing userId or newPassword', 400, corsHeaders);
      }

      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, { password: newPassword });
      if (error) {
        logger.error('Password update error', { error: error.message });
        return createErrorResponse(error.message, 400, corsHeaders);
      }

      logger.info('Password updated', { userId });
      return createSuccessResponse({ message: 'Password updated successfully' }, corsHeaders);
    }

    // BULK UPDATE PASSWORD
    if (action === 'bulk-update-password') {
      if (!newPassword) {
        return createErrorResponse('Missing newPassword', 400, corsHeaders);
      }

      const { data: { users: allUsers } } = await supabaseAdmin.auth.admin.listUsers();
      let usersToUpdate = allUsers || [];

      if (excludeAdmins) {
        const { data: adminRoles } = await supabaseAdmin
          .from('user_roles')
          .select('user_id')
          .in('role', ['SUPER_ADMIN', 'TENANT_OWNER']);

        const adminUserIds = new Set((adminRoles || []).map(r => r.user_id));
        usersToUpdate = usersToUpdate.filter(u => !adminUserIds.has(u.id));
      }

      const results = [];
      for (const u of usersToUpdate) {
        const { error } = await supabaseAdmin.auth.admin.updateUserById(u.id, { password: newPassword });
        results.push({ userId: u.id, success: !error, error: error?.message });
      }

      const updated = results.filter(r => r.success).length;
      const failed = results.filter(r => !r.success).length;

      logger.info('Bulk password update complete', { updated, failed });

      return createSuccessResponse({ 
        message: `Updated ${updated} passwords`,
        updated,
        failed
      }, corsHeaders);
    }

    return createErrorResponse('Invalid action', 400, corsHeaders);

  } catch (error) {
    const errorMessage = getErrorMessage(error);
    logger.error('Unexpected error', { error: errorMessage });
    return createErrorResponse(errorMessage, 500, corsHeaders);
  }
});
