import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getCorsHeaders, handleCorsPreFlight, createErrorResponse, createSuccessResponse, SECURITY_HEADERS, getAllHeaders } from '../_shared/cors.ts';
import { createLogger, generateRequestId, getErrorMessage } from '../_shared/logger.ts';
import { rateLimitMiddleware, RATE_LIMIT_CONFIGS } from '../_shared/rate-limiter.ts';

Deno.serve(async (req) => {
  const requestId = generateRequestId();
  const logger = createLogger('create-user', requestId);
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === 'OPTIONS') {
    return handleCorsPreFlight(corsHeaders);
  }

  // Rate limiting
  const { response: rateLimitResponse, result: rateLimitResult } = rateLimitMiddleware(req, RATE_LIMIT_CONFIGS.auth, corsHeaders);
  if (rateLimitResponse) {
    logger.warn('Rate limit exceeded');
    return rateLimitResponse;
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !serviceRoleKey) {
      logger.error('Missing environment variables');
      return createErrorResponse('Server configuration error', 500, corsHeaders);
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false }
    });

    // Verify authorization
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      logger.warn('No authorization header');
      return createErrorResponse('No authorization header', 401, corsHeaders);
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    
    if (userError || !user) {
      logger.warn('Auth error', { error: userError?.message });
      return createErrorResponse('Unauthorized', 401, corsHeaders);
    }

    logger.info('Authenticated user', { userId: user.id });

    // Check user role
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (roleError) {
      logger.error('Role lookup error', { error: roleError.message });
      return createErrorResponse('Could not verify permissions', 403, corsHeaders);
    }

    const allowedRoles = ['SUPER_ADMIN', 'TENANT_OWNER', 'ADMIN', 'MANAGER'];
    if (!allowedRoles.includes(roleData?.role || '')) {
      logger.warn('Insufficient permissions', { role: roleData?.role });
      return createErrorResponse('Insufficient permissions', 403, corsHeaders);
    }

    logger.info('User role verified', { role: roleData.role });

    // Get the creator's admin_id (tenant) to assign to new user
    const { data: creatorProfile } = await supabaseAdmin
      .from('profiles')
      .select('admin_id')
      .eq('id', user.id)
      .single();

    // Determine the admin_id for the new user
    let newUserAdminId: string | null = null;
    if (roleData.role === 'TENANT_OWNER') {
      newUserAdminId = user.id;
    } else if (roleData.role !== 'SUPER_ADMIN') {
      newUserAdminId = creatorProfile?.admin_id || null;
    }

    logger.debug('New user admin_id determined', { adminId: newUserAdminId });

    // Parse request
    const body = await req.json();
    const { username, password, fullName, role, whitelistedIps, isCloser } = body;

    logger.info('Creating user', { username, fullName, role });

    if (!username || !password || !fullName || !role) {
      return createErrorResponse('Missing required fields: username, password, fullName, role', 400, corsHeaders);
    }

    const creatorRole = roleData.role;

    // Role hierarchy validation
    if (role === 'SUPER_ADMIN') {
      return createErrorResponse('SUPER_ADMIN role cannot be created', 403, corsHeaders);
    }
    
    if (role === 'TENANT_OWNER' && creatorRole !== 'SUPER_ADMIN') {
      return createErrorResponse('Only SUPER_ADMIN can create TENANT_OWNER users', 403, corsHeaders);
    }
    
    if (role === 'ADMIN' && creatorRole !== 'SUPER_ADMIN') {
      return createErrorResponse('Only SUPER_ADMIN can create ADMIN users', 403, corsHeaders);
    }
    
    if (role === 'MANAGER' && !['SUPER_ADMIN', 'ADMIN', 'TENANT_OWNER'].includes(creatorRole)) {
      return createErrorResponse('Only SUPER_ADMIN, ADMIN, or TENANT_OWNER can create MANAGER users', 403, corsHeaders);
    }
    
    if (creatorRole === 'MANAGER' && !['SUPER_AGENT', 'AGENT'].includes(role)) {
      return createErrorResponse('MANAGER can only create SUPER_AGENT or AGENT users', 403, corsHeaders);
    }

    // Create user
    const tempEmail = `${username}@crm.internal`;

    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: tempEmail,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName, username },
    });

    if (authError) {
      logger.error('Auth create error', { error: authError.message });
      return createErrorResponse(authError.message, 400, corsHeaders);
    }

    if (!authData.user) {
      return createErrorResponse('User creation failed', 500, corsHeaders);
    }

    logger.info('User created', { newUserId: authData.user.id });

    // Update profile with admin_id for tenant isolation
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .update({ 
        username, 
        full_name: fullName,
        created_by: user.id,
        admin_id: newUserAdminId,
        is_closer: role === 'AGENT' ? Boolean(isCloser) : false,
      })
      .eq('id', authData.user.id);

    if (profileError) {
      logger.warn('Profile update error', { error: profileError.message });
    }

    // Set role
    await supabaseAdmin.from('user_roles').delete().eq('user_id', authData.user.id);
    
    const { error: roleInsertError } = await supabaseAdmin
      .from('user_roles')
      .insert({ user_id: authData.user.id, role });

    if (roleInsertError) {
      logger.warn('Role insert error', { error: roleInsertError.message });
    }

    // Add IP whitelist
    if (whitelistedIps?.trim()) {
      const ips = whitelistedIps.split(',').map((ip: string) => ip.trim()).filter(Boolean);
      if (ips.length > 0) {
        await supabaseAdmin.from('ip_whitelist').insert(
          ips.map((ip: string) => ({
            user_id: authData.user.id,
            ip_address: ip,
            created_by: user.id,
          }))
        );
      }
    }

    // Generate display email (kybalioncrm.io domain) for audit/reference only
    const sanitizedName = fullName
      .toLowerCase()
      .replace(/\s+/g, '.')
      .replace(/[^a-z0-9.]/g, '');
    const generatedEmail = `${sanitizedName}@kybalioncrm.io`;

    // Audit log
    await supabaseAdmin.from('audit_logs').insert({
      user_id: user.id,
      action_type: 'user_created',
      entity_type: 'user',
      entity_id: authData.user.id,
      details: { username, full_name: fullName, role, generated_email: generatedEmail },
    });

    logger.info('User creation complete', { newUserId: authData.user.id });

    return createSuccessResponse({ 
      user: {
        id: authData.user.id,
        email: tempEmail,
        username,
        fullName,
        role,
      }
    }, corsHeaders);

  } catch (error) {
    const errorMessage = getErrorMessage(error);
    logger.error('Unexpected error', { error: errorMessage });
    return createErrorResponse(errorMessage, 500, corsHeaders);
  }
});
