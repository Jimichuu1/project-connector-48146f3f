import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SOURCE_NAME = 'Santos Mauro';

// ---------- Google auth ----------
async function getAccessToken(saJson: any): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claims = {
    iss: saJson.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets.readonly',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
  };
  const enc = (o: any) =>
    btoa(JSON.stringify(o)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const unsigned = `${enc(header)}.${enc(claims)}`;
  const pem = saJson.private_key.replace(/\\n/g, '\n');
  const pkcs8 = pem.replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '').replace(/\s+/g, '');
  const binary = Uint8Array.from(atob(pkcs8), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    'pkcs8', binary, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign'],
  );
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(unsigned));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const jwt = `${unsigned}.${sigB64}`;
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });
  const t = await r.json();
  if (!t.access_token) throw new Error(`Token error: ${JSON.stringify(t)}`);
  return t.access_token;
}

// ---------- Helpers ----------
function cleanPhone(raw: string): string {
  if (!raw) return '';
  return raw.replace(/^p:/, '').trim();
}
function normalizePhone(raw: string): string {
  return cleanPhone(raw).replace(/[^\d]/g, '');
}
// Phone prefix → country lookup (mirrors src/lib/phoneCountryCode.ts)
const phoneCodeToCountry: Record<string, string> = {
  '1242':'Bahamas','1246':'Barbados','1264':'Anguilla','1268':'Antigua and Barbuda',
  '1284':'British Virgin Islands','1340':'US Virgin Islands','1345':'Cayman Islands',
  '1441':'Bermuda','1473':'Grenada','1649':'Turks and Caicos','1664':'Montserrat',
  '1670':'Northern Mariana Islands','1671':'Guam','1684':'American Samoa','1721':'Sint Maarten',
  '1758':'Saint Lucia','1767':'Dominica','1784':'Saint Vincent and the Grenadines',
  '1787':'Puerto Rico','1809':'Dominican Republic','1829':'Dominican Republic',
  '1849':'Dominican Republic','1868':'Trinidad and Tobago','1869':'Saint Kitts and Nevis',
  '1876':'Jamaica','1939':'Puerto Rico',
  '212':'Morocco','213':'Algeria','216':'Tunisia','218':'Libya','220':'Gambia','221':'Senegal',
  '222':'Mauritania','223':'Mali','224':'Guinea','225':'Ivory Coast','226':'Burkina Faso',
  '227':'Niger','228':'Togo','229':'Benin','230':'Mauritius','231':'Liberia','232':'Sierra Leone',
  '233':'Ghana','234':'Nigeria','235':'Chad','236':'Central African Republic','237':'Cameroon',
  '238':'Cape Verde','239':'Sao Tome and Principe','240':'Equatorial Guinea','241':'Gabon',
  '242':'Republic of the Congo','243':'Democratic Republic of the Congo','244':'Angola',
  '245':'Guinea-Bissau','246':'British Indian Ocean Territory','247':'Ascension Island',
  '248':'Seychelles','249':'Sudan','250':'Rwanda','251':'Ethiopia','252':'Somalia',
  '253':'Djibouti','254':'Kenya','255':'Tanzania','256':'Uganda','257':'Burundi',
  '258':'Mozambique','260':'Zambia','261':'Madagascar','262':'Reunion','263':'Zimbabwe',
  '264':'Namibia','265':'Malawi','266':'Lesotho','267':'Botswana','268':'Eswatini',
  '269':'Comoros','290':'Saint Helena','291':'Eritrea','297':'Aruba','298':'Faroe Islands',
  '299':'Greenland','350':'Gibraltar','351':'Portugal','352':'Luxembourg','353':'Ireland',
  '354':'Iceland','355':'Albania','356':'Malta','357':'Cyprus','358':'Finland','359':'Bulgaria',
  '370':'Lithuania','371':'Latvia','372':'Estonia','373':'Moldova','374':'Armenia',
  '375':'Belarus','376':'Andorra','377':'Monaco','378':'San Marino','380':'Ukraine',
  '381':'Serbia','382':'Montenegro','383':'Kosovo','385':'Croatia','386':'Slovenia',
  '387':'Bosnia and Herzegovina','389':'North Macedonia','420':'Czech Republic','421':'Slovakia',
  '423':'Liechtenstein','500':'Falkland Islands','501':'Belize','502':'Guatemala',
  '503':'El Salvador','504':'Honduras','505':'Nicaragua','506':'Costa Rica','507':'Panama',
  '508':'Saint Pierre and Miquelon','509':'Haiti','590':'Guadeloupe','591':'Bolivia',
  '592':'Guyana','593':'Ecuador','594':'French Guiana','595':'Paraguay','596':'Martinique',
  '597':'Suriname','598':'Uruguay','599':'Curacao','670':'East Timor','672':'Norfolk Island',
  '673':'Brunei','674':'Nauru','675':'Papua New Guinea','676':'Tonga','677':'Solomon Islands',
  '678':'Vanuatu','679':'Fiji','680':'Palau','681':'Wallis and Futuna','682':'Cook Islands',
  '683':'Niue','685':'Samoa','686':'Kiribati','687':'New Caledonia','688':'Tuvalu',
  '689':'French Polynesia','690':'Tokelau','691':'Micronesia','692':'Marshall Islands',
  '850':'North Korea','852':'Hong Kong','853':'Macau','855':'Cambodia','856':'Laos',
  '880':'Bangladesh','886':'Taiwan','960':'Maldives','961':'Lebanon','962':'Jordan',
  '963':'Syria','964':'Iraq','965':'Kuwait','966':'Saudi Arabia','967':'Yemen','968':'Oman',
  '970':'Palestine','971':'United Arab Emirates','972':'Israel','973':'Bahrain','974':'Qatar',
  '975':'Bhutan','976':'Mongolia','977':'Nepal','992':'Tajikistan','993':'Turkmenistan',
  '994':'Azerbaijan','995':'Georgia','996':'Kyrgyzstan','998':'Uzbekistan',
  '20':'Egypt','27':'South Africa','30':'Greece','31':'Netherlands','32':'Belgium','33':'France',
  '34':'Spain','36':'Hungary','39':'Italy','40':'Romania','41':'Switzerland','43':'Austria',
  '44':'United Kingdom','45':'Denmark','46':'Sweden','47':'Norway','48':'Poland','49':'Germany',
  '51':'Peru','52':'Mexico','53':'Cuba','54':'Argentina','55':'Brazil','56':'Chile',
  '57':'Colombia','58':'Venezuela','60':'Malaysia','61':'Australia','62':'Indonesia',
  '63':'Philippines','64':'New Zealand','65':'Singapore','66':'Thailand','81':'Japan',
  '82':'South Korea','84':'Vietnam','86':'China','90':'Turkey','91':'India','92':'Pakistan',
  '93':'Afghanistan','94':'Sri Lanka','95':'Myanmar','98':'Iran',
  '1':'Canada','7':'Russia',
};

function countryFromPhone(raw: string): string | null {
  if (!raw) return null;
  let digits = String(raw).replace(/[^\d+]/g, '');
  if (digits.startsWith('+')) digits = digits.slice(1);
  if (!digits) return null;
  // Memory rule: any +1 number defaults to Canada (NANP overrides handled by 4-digit lookup below first)
  for (const len of [4, 3, 2, 1]) {
    if (digits.length >= len) {
      const prefix = digits.slice(0, len);
      if (phoneCodeToCountry[prefix]) return phoneCodeToCountry[prefix];
    }
  }
  if (digits.startsWith('1')) return 'Canada';
  return null;
}
function parseAmount(raw: string | null | undefined): number | string | null {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();
  if (!s) return null;
  const n = Number(s.replace(/[^\d.\-]/g, ''));
  return Number.isFinite(n) && n > 0 ? n : s;
}
function buildMetadata(rec: Record<string, string>) {
  const scamType = rec['type_of_scam'] || null;
  const lostAmountRaw = rec[`amount_you've_lost`] || rec['amount_you_ve_lost'] || null;
  const timeFrame = rec['when_scam_occurred'] || null;
  const story = rec[`tell_us_short_story_about_your_case_(optional)`] ||
                rec['tell_us_short_story_about_your_case'] || null;
  return {
    // Canonical keys consumed by Live Submission KYC panel and convert RPC
    scam_type: scamType,
    lost_amount: parseAmount(lostAmountRaw),
    time_frame: timeFrame,
    description: story,
    // Extras
    transfer_method: rec['transfer_method'] || null,
    campaign: rec['campaign_name'] || null,
    ad: rec['ad_name'] || null,
    form: rec['form_name'] || null,
    platform: rec['platform'] || null,
    sheet_created_time: rec['created_time'] || null,
    sheet_row_id: rec['id'] || null,
    imported_from: 'google_sheet',
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
  const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const SHEET_ID = Deno.env.get('SANTOS_SHEET_ID');
  const TENANT_INPUT = Deno.env.get('SANTOS_TENANT_ID');
  const SA_RAW = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_JSON');

  try {
    if (!SHEET_ID) throw new Error('SANTOS_SHEET_ID not set');
    if (!TENANT_INPUT) throw new Error('SANTOS_TENANT_ID not set');
    if (!SA_RAW) throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON not set');

    const supabase = createClient(SUPABASE_URL, SERVICE_KEY);

    // Resolve tenant: accept UUID or tenant name (full_name / username)
    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    let resolvedTenantId = TENANT_INPUT;
    if (!UUID_RE.test(TENANT_INPUT)) {
      const tokens = TENANT_INPUT.split(/\s+/).filter(t => t.length >= 3);
      const orClause = tokens.length > 0
        ? tokens.flatMap(t => [`full_name.ilike.%${t}%`, `username.ilike.%${t}%`]).join(',')
        : `full_name.ilike.%${TENANT_INPUT}%,username.ilike.%${TENANT_INPUT}%`;
      const { data: prof } = await supabase
        .from('profiles').select('id, full_name, username').or(orClause).limit(20);
      if (!prof || prof.length === 0) {
        throw new Error(`SANTOS_TENANT_ID "${TENANT_INPUT}" not found as UUID or tenant name`);
      }
      const ids = prof.map(p => p.id);
      const { data: owners } = await supabase
        .from('user_roles').select('user_id').in('user_id', ids).eq('role', 'TENANT_OWNER');
      const ownerIds = new Set((owners || []).map(o => o.user_id));
      const owner = prof.find(p => ownerIds.has(p.id));
      if (!owner) throw new Error(`No TENANT_OWNER profile matches "${TENANT_INPUT}". Candidates: ${prof.map(p=>p.full_name).join(', ')}`);
      resolvedTenantId = owner.id;
    }
    const sa = JSON.parse(SA_RAW);
    const token = await getAccessToken(sa);

    // 1. Read sheet
    const meta = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}?fields=sheets.properties`,
      { headers: { Authorization: `Bearer ${token}` } },
    ).then(r => r.json());
    const firstSheet = meta.sheets?.[0]?.properties?.title ?? 'Sheet1';

    const valRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(firstSheet)}!A1:Z100000`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    const valJson = await valRes.json();
    if (!valRes.ok) throw new Error(`Sheets API: ${JSON.stringify(valJson)}`);

    const rows: string[][] = valJson.values || [];
    if (rows.length < 2) {
      return new Response(JSON.stringify({ ok: true, message: 'no data rows' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    const headers = rows[0].map(h => h.trim());
    const dataRows = rows.slice(1);

    // 2. Find or create the "Santos Mauro" live form source for this tenant
    let { data: existingKey } = await supabase
      .from('live_form_api_keys')
      .select('id')
      .eq('admin_id', resolvedTenantId)
      .eq('name', SOURCE_NAME)
      .maybeSingle();

    let apiKeyId = existingKey?.id;
    if (!apiKeyId) {
      // create a placeholder key (not exposed; only used for source labelling)
      const randomBytes = new Uint8Array(32);
      crypto.getRandomValues(randomBytes);
      const keyHash = Array.from(randomBytes).map(b => b.toString(16).padStart(2, '0')).join('');
      const { data: newKey, error: keyErr } = await supabase
        .from('live_form_api_keys')
        .insert({
          admin_id: resolvedTenantId,
          name: SOURCE_NAME,
          key_hash: keyHash,
          key_prefix: 'santos',
          default_source: 'PAID_ADS',
          is_active: true,
          created_by: resolvedTenantId,
        })
        .select('id')
        .single();
      if (keyErr) throw new Error(`create source: ${keyErr.message}`);
      apiKeyId = newKey.id;
    }

    // 3. Get already-imported sheet row IDs for this tenant
    const sheetRowIds = dataRows.map(r => {
      const rec: Record<string, string> = {};
      headers.forEach((h, i) => rec[h] = r[i] || '');
      return rec['id'];
    }).filter(Boolean);

    const { data: alreadyImported } = await supabase
      .from('santos_sheet_imports')
      .select('sheet_row_id')
      .eq('admin_id', resolvedTenantId)
      .in('sheet_row_id', sheetRowIds);
    const importedSet = new Set((alreadyImported || []).map(r => r.sheet_row_id));

    // 4. Process new rows only
    let inserted = 0, duplicates = 0, skipped = 0;
    const importLog: any[] = [];

    for (const row of dataRows) {
      const rec: Record<string, string> = {};
      headers.forEach((h, i) => rec[h] = (row[i] || '').toString().trim());

      const sheetRowId = rec['id'];
      if (!sheetRowId) { skipped++; continue; }
      if (importedSet.has(sheetRowId)) continue; // already processed

      const fullName = rec['full_name'] || 'Unknown';
      const rawPhone = rec['phone'] || '';
      const cleanedPhone = cleanPhone(rawPhone);
      const phoneNorm = normalizePhone(rawPhone);
      const email = rec['email'] || null;
      const sheetCountry = (rec['country'] || '').trim();
      const country = sheetCountry || countryFromPhone(rawPhone);

      // Require a real phone number — skip empty, "p:", "p:+", or no-digit values
      if (!phoneNorm) {
        importLog.push({
          admin_id: resolvedTenantId, sheet_row_id: sheetRowId, status: 'skipped',
          reason: 'missing or invalid phone', full_name: fullName, phone: cleanedPhone, email,
        });
        skipped++;
        continue;
      }

      // Dedup: check phone against existing leads AND submissions for this tenant
      let isDup = false;
      let dupLeadId: string | null = null;
      if (phoneNorm) {
        const { data: dupLead } = await supabase
          .from('leads')
          .select('id')
          .eq('admin_id', resolvedTenantId)
          .eq('phone', cleanedPhone)
          .maybeSingle();
        if (dupLead) { isDup = true; dupLeadId = dupLead.id; }

        if (!isDup) {
          const { data: dupSub } = await supabase
            .from('live_traffic_submissions')
            .select('id')
            .eq('admin_id', resolvedTenantId)
            .eq('phone_normalized', phoneNorm)
            .limit(1)
            .maybeSingle();
          if (dupSub) isDup = true;
        }
      }

      if (isDup) {
        importLog.push({
          admin_id: resolvedTenantId, sheet_row_id: sheetRowId, status: 'duplicate',
          reason: 'phone already exists in tenant', full_name: fullName,
          phone: cleanedPhone, email,
        });
        duplicates++;
        continue;
      }

      // Insert as live traffic submission
      const { data: sub, error: subErr } = await supabase
        .from('live_traffic_submissions')
        .insert({
          admin_id: resolvedTenantId,
          api_key_id: apiKeyId,
          name: fullName,
          email: email,
          phone: cleanedPhone || null,
          phone_normalized: phoneNorm || null,
          country: country,
          metadata: buildMetadata(rec),
          source_url: 'google_sheet:santos_mauro',
          is_duplicate: false,
          duplicate_of_lead_id: dupLeadId,
          status: 'new',
        })
        .select('id')
        .single();

      if (subErr) {
        importLog.push({
          admin_id: resolvedTenantId, sheet_row_id: sheetRowId, status: 'error',
          reason: subErr.message, full_name: fullName, phone: cleanedPhone, email,
        });
        skipped++;
        continue;
      }

      importLog.push({
        admin_id: resolvedTenantId, sheet_row_id: sheetRowId, status: 'inserted',
        submission_id: sub.id, full_name: fullName, phone: cleanedPhone, email,
      });
      inserted++;
    }

    // Bulk write the import log
    if (importLog.length > 0) {
      // upsert in chunks of 500
      for (let i = 0; i < importLog.length; i += 500) {
        await supabase.from('santos_sheet_imports')
          .upsert(importLog.slice(i, i + 500), {
            onConflict: 'admin_id,sheet_row_id', ignoreDuplicates: true,
          });
      }
    }

    return new Response(
      JSON.stringify({
        ok: true,
        total_rows: dataRows.length,
        new_rows: importLog.length,
        inserted,
        duplicates,
        skipped,
        source: SOURCE_NAME,
        api_key_id: apiKeyId,
      }, null, 2),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
