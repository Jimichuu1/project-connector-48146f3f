import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Countries to block (ISO 3166-1 alpha-2 codes)
const BLOCKED_COUNTRIES = ['GE']; // Georgia

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get client IP from headers
    const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
      || req.headers.get('x-real-ip')
      || req.headers.get('cf-connecting-ip')
      || 'unknown';

    // ── 1. GEO BLOCK CHECK ──
    const isPrivateIp = clientIp === 'unknown' ||
      clientIp === '127.0.0.1' ||
      clientIp.startsWith('192.168.') ||
      clientIp.startsWith('10.') ||
      clientIp.startsWith('172.');

    let geoBlocked = false;
    let countryName: string | null = null;
    let countryCode: string | null = null;

    if (!isPrivateIp) {
      try {
        const geoResponse = await fetch(
          `http://ip-api.com/json/${clientIp}?fields=status,country,countryCode`,
        );
        if (geoResponse.ok) {
          const geoData = await geoResponse.json();
          if (geoData.status === 'success') {
            countryCode = geoData.countryCode;
            countryName = geoData.country;
            geoBlocked = BLOCKED_COUNTRIES.includes(geoData.countryCode);
          }
        }
      } catch {
        // Geo API failure — continue to IP whitelist check
      }
    }

    if (geoBlocked) {
      return new Response(
        JSON.stringify({ allowed: false, country: countryName, countryCode, reason: 'geo_blocked' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // Skip IP whitelist for private/unknown IPs (local dev)
    if (isPrivateIp) {
      return new Response(
        JSON.stringify({ allowed: true, country: null, ip: clientIp }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // ── 2. GLOBAL IP WHITELIST CHECK ──
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if there are ANY whitelist entries in the system
    const { count: totalWhitelistCount, error: countError } = await supabase
      .from('ip_whitelist')
      .select('id', { count: 'exact', head: true })
      .eq('is_active', true);

    if (countError) {
      // FAIL-OPEN on transient DB errors — return allowed with error flag
      return new Response(
        JSON.stringify({ allowed: true, reason: 'internal_error', error: 'transient' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 },
      );
    }

    if (totalWhitelistCount === 0) {
      // No whitelist configured — allow access (initial setup)
      return new Response(
        JSON.stringify({ allowed: true, country: countryName, countryCode, ip: clientIp }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // Whitelist is configured — check if THIS IP is in any user's whitelist
    const { data: matchingIps, error: ipError } = await supabase
      .from('ip_whitelist')
      .select('id')
      .eq('ip_address', clientIp)
      .eq('is_active', true)
      .limit(1);

    if (ipError) {
      // FAIL-OPEN on transient DB errors
      return new Response(
        JSON.stringify({ allowed: true, reason: 'internal_error', error: 'transient' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 },
      );
    }

    if (!matchingIps || matchingIps.length === 0) {
      // IP not in ANY whitelist — definitive block
      return new Response(
        JSON.stringify({
          allowed: false,
          country: countryName,
          countryCode,
          reason: 'ip_not_whitelisted',
          ip: clientIp,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    // ── 3. USER-SPECIFIC IP CHECK (for authenticated users) ──
    const authHeader = req.headers.get('authorization');
    if (authHeader) {
      try {
        const token = authHeader.replace('Bearer ', '');
        const { data: { user }, error: userError } = await supabase.auth.getUser(token);

        if (user && !userError) {
          const { data: isWhitelisted, error: rpcError } = await supabase.rpc(
            'check_ip_whitelist',
            { p_user_id: user.id, p_ip_address: clientIp },
          );

          if (rpcError) {
            // FAIL-OPEN on transient RPC errors
            return new Response(
              JSON.stringify({ allowed: true, reason: 'internal_error', error: 'transient' }),
              { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 },
            );
          }

          if (isWhitelisted === false) {
            return new Response(
              JSON.stringify({
                allowed: false,
                country: countryName,
                countryCode,
                reason: 'ip_not_whitelisted',
                ip: clientIp,
              }),
              { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
            );
          }
        }
      } catch {
        // FAIL-OPEN for auth errors
        return new Response(
          JSON.stringify({ allowed: true, reason: 'internal_error', error: 'transient' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 },
        );
      }
    }

    // ── 4. ALL CLEAR ──
    return new Response(
      JSON.stringify({ allowed: true, country: countryName, countryCode, ip: clientIp }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );

  } catch (error) {
    // FAIL-OPEN on unexpected errors
    return new Response(
      JSON.stringify({ allowed: true, reason: 'internal_error', error: 'transient' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 },
    );
  }
});
