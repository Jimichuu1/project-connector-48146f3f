// Public endpoint: external landing pages POST a form submission here.
// Auth via x-api-key header. Always inserts into live_traffic_submissions.
// Never inserts into leads or attaches to a group — that happens via the
// Live Traffic page (move_live_submission RPC) by the Tenant Owner.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-api-key",
  "Access-Control-Max-Age": "86400",
};

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

// Simple in-memory rate limiter per api key (best-effort; resets on cold start)
const rateBucket = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = 30;
const RATE_WINDOW_MS = 10_000;
function rateLimited(keyId: string): boolean {
  const now = Date.now();
  const b = rateBucket.get(keyId);
  if (!b || b.resetAt < now) {
    rateBucket.set(keyId, { count: 1, resetAt: now + RATE_WINDOW_MS });
    return false;
  }
  b.count++;
  return b.count > RATE_LIMIT;
}

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function normalizePhone(phone: string | null | undefined): string {
  if (!phone) return "";
  return phone.replace(/\D/g, "");
}

function inferCountryFromPhone(phone: string, country?: string | null): string | null {
  if (country && country.trim().length > 0) return country;
  const digits = normalizePhone(phone);
  if (digits.startsWith("1") && digits.length === 11) return "Canada";
  return null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json(405, { ok: false, error: "Method not allowed" });

  try {
    const apiKey = req.headers.get("x-api-key");
    if (!apiKey || apiKey.length < 16) {
      return json(401, { ok: false, error: "Missing or invalid x-api-key header" });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const keyHash = await sha256Hex(apiKey);
    const { data: keyRow, error: keyErr } = await supabase
      .rpc("verify_live_form_api_key", { p_key_hash: keyHash })
      .maybeSingle();

    if (keyErr) {
      console.error("verify_live_form_api_key error:", keyErr);
      return json(500, { ok: false, error: "Auth check failed" });
    }
    if (!keyRow) return json(401, { ok: false, error: "Invalid API key" });

    if (rateLimited(keyRow.api_key_id)) {
      return json(429, { ok: false, error: "Rate limit exceeded" });
    }

    let body: Record<string, unknown> = {};
    try {
      body = await req.json();
    } catch {
      return json(400, { ok: false, error: "Invalid JSON body" });
    }

    const name = typeof body.name === "string" ? body.name.trim() : "";
    if (!name || name.length > 200) {
      return json(400, { ok: false, error: "name (Full name) is required (max 200 chars)" });
    }

    const email = typeof body.email === "string" ? body.email.trim().slice(0, 255) : "";
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return json(400, { ok: false, error: "email is required and must be valid" });
    }

    const phone = typeof body.phone === "string" ? body.phone.trim().slice(0, 50) : "";
    if (!phone) {
      return json(400, { ok: false, error: "phone is required" });
    }

    const scamType = typeof body.scam_type === "string" ? body.scam_type.trim().slice(0, 200) : "";
    if (!scamType) {
      return json(400, { ok: false, error: "scam_type (Type of scam) is required" });
    }

    const lostAmountRaw = body.lost_amount;
    const lostAmount =
      typeof lostAmountRaw === "number"
        ? lostAmountRaw
        : typeof lostAmountRaw === "string" && lostAmountRaw.trim().length > 0
          ? Number(lostAmountRaw.replace(/[^\d.\-]/g, ""))
          : NaN;
    if (!Number.isFinite(lostAmount) || lostAmount < 0) {
      return json(400, { ok: false, error: "lost_amount (Lost amount) is required and must be a number" });
    }

    const timeFrame = typeof body.time_frame === "string" ? body.time_frame.trim().slice(0, 200) : "";
    if (!timeFrame) {
      return json(400, { ok: false, error: "time_frame (Time frame) is required" });
    }

    const description = typeof body.description === "string" ? body.description.trim().slice(0, 5000) : "";
    const wordCount = description ? description.split(/\s+/).filter(Boolean).length : 0;
    if (wordCount < 20) {
      return json(400, {
        ok: false,
        error: `description must be at least 20 words (got ${wordCount})`,
      });
    }

    const countryRaw = typeof body.country === "string" ? body.country.trim().slice(0, 100) : null;
    const sourceUrl =
      typeof body.source_url === "string" ? body.source_url.slice(0, 500) : null;
    const extraMetadata =
      body.metadata && typeof body.metadata === "object" && !Array.isArray(body.metadata)
        ? (body.metadata as Record<string, unknown>)
        : {};
    const metadata = {
      ...extraMetadata,
      scam_type: scamType,
      lost_amount: lostAmount,
      time_frame: timeFrame,
      description,
    };

    const phoneNormalized = normalizePhone(phone);
    const country = inferCountryFromPhone(phone || "", countryRaw);

    // Duplicate detection against existing leads in this tenant
    let isDuplicate = false;
    let duplicateOfLeadId: string | null = null;
    if (phoneNormalized.length > 0) {
      const { data: dup } = await supabase
        .from("leads")
        .select("id, phone")
        .eq("admin_id", keyRow.admin_id)
        .not("phone", "is", null);
      if (dup) {
        const match = dup.find((l: { phone: string | null }) =>
          (l.phone || "").replace(/\D/g, "") === phoneNormalized
        );
        if (match) {
          isDuplicate = true;
          duplicateOfLeadId = match.id;
        }
      }
    }

    const ipAddress =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      req.headers.get("x-real-ip") ||
      req.headers.get("cf-connecting-ip") ||
      null;
    const userAgent = req.headers.get("user-agent");

    const { data: inserted, error: insertErr } = await supabase
      .from("live_traffic_submissions")
      .insert({
        admin_id: keyRow.admin_id,
        api_key_id: keyRow.api_key_id,
        name,
        email,
        phone,
        country,
        phone_normalized: phoneNormalized || null,
        metadata,
        source_url: sourceUrl,
        ip_address: ipAddress,
        user_agent: userAgent,
        is_duplicate: isDuplicate,
        duplicate_of_lead_id: duplicateOfLeadId,
        status: "new",
      })
      .select("id")
      .single();

    if (insertErr) {
      console.error("insert submission error:", insertErr);
      return json(500, { ok: false, error: "Failed to record submission" });
    }

    // Update key usage stats (best-effort)
    await supabase
      .from("live_form_api_keys")
      .update({
        last_used_at: new Date().toISOString(),
        request_count: ((keyRow as { request_count?: number }).request_count ?? 0) + 1,
      })
      .eq("id", keyRow.api_key_id);

    return json(200, {
      ok: true,
      submission_id: inserted.id,
      is_duplicate: isDuplicate,
    });
  } catch (e) {
    console.error("submit-live-lead fatal:", e);
    return json(500, { ok: false, error: "Internal error" });
  }
});
