const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Build a Google OAuth2 JWT and exchange for an access token
async function getAccessToken(saJson: any): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', typ: 'JWT' };
  const claims = {
    iss: saJson.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets.readonly',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
  };

  const enc = (obj: any) =>
    btoa(JSON.stringify(obj)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

  const unsigned = `${enc(header)}.${enc(claims)}`;

  // Import private key
  const pem = saJson.private_key.replace(/\\n/g, '\n');
  const pkcs8 = pem
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\s+/g, '');
  const binary = Uint8Array.from(atob(pkcs8), (c) => c.charCodeAt(0));

  const key = await crypto.subtle.importKey(
    'pkcs8',
    binary,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign'],
  );

  const sig = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    key,
    new TextEncoder().encode(unsigned),
  );
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

  const jwt = `${unsigned}.${sigB64}`;

  const tokRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });
  const tok = await tokRes.json();
  if (!tok.access_token) throw new Error(`Token error: ${JSON.stringify(tok)}`);
  return tok.access_token;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const sheetId = Deno.env.get('SANTOS_SHEET_ID');
    const saRaw = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_JSON');
    if (!sheetId) throw new Error('SANTOS_SHEET_ID not set');
    if (!saRaw) throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON not set');

    const sa = JSON.parse(saRaw);
    const token = await getAccessToken(sa);

    // Get spreadsheet metadata (sheet names)
    const metaRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}?fields=properties.title,sheets.properties`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    const meta = await metaRes.json();
    if (!metaRes.ok) throw new Error(`Sheets API: ${JSON.stringify(meta)}`);

    const firstSheet = meta.sheets?.[0]?.properties?.title ?? 'Sheet1';

    // Read first 2 rows
    const valRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${encodeURIComponent(firstSheet)}!A1:Z2`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    const vals = await valRes.json();

    return new Response(
      JSON.stringify({
        ok: true,
        spreadsheet: meta.properties?.title,
        service_account: sa.client_email,
        sheets: meta.sheets?.map((s: any) => s.properties?.title),
        firstSheet,
        headers: vals.values?.[0] ?? [],
        sampleRow: vals.values?.[1] ?? [],
      }, null, 2),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ ok: false, error: e instanceof Error ? e.message : String(e) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
