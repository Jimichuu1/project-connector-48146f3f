import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getCorsHeaders, handleCorsPreFlight, createErrorResponse, createAcceptedResponse } from '../_shared/cors.ts';
import { rateLimitMiddleware, RATE_LIMIT_CONFIGS, getClientIp } from '../_shared/rate-limiter.ts';
import { createLogger, getErrorMessage } from '../_shared/logger.ts';
import { authorizeBulkRequest, BulkAuthError } from '../_shared/bulk-auth.ts';

declare const EdgeRuntime: { waitUntil: (promise: Promise<unknown>) => void };

const BATCH_SIZE = 50;
const BATCH_DELAY_MS = 100;

interface BulkDeleteRequest {
  leadIds: string[];
  tenantId?: string;
}

async function processInBackground(leadIds: string[], userId: string, tenantId: string) {
  const logger = createLogger('bulk-delete-leads-bg');
  logger.info('Starting background processing', { count: leadIds.length, tenantId });

  const supabaseAdmin = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  const batches: string[][] = [];
  for (let i = 0; i < leadIds.length; i += BATCH_SIZE) {
    batches.push(leadIds.slice(i, i + BATCH_SIZE));
  }

  let successCount = 0;
  let errorCount = 0;

  for (let i = 0; i < batches.length; i++) {
    const batch = batches[i];
    try {
      const { error } = await supabaseAdmin.rpc('bulk_delete_leads', {
        p_lead_ids: batch,
        p_user_id: userId,
        p_tenant_id: tenantId,
      } as Record<string, unknown>);

      if (error) {
        logger.error('Batch failed', { batch: i + 1, total: batches.length, error: error.message });
        errorCount += batch.length;
      } else {
        successCount += batch.length;
        logger.info('Batch completed', { batch: i + 1, total: batches.length, processed: successCount });
      }
    } catch (err) {
      logger.error('Batch exception', { batch: i + 1, error: getErrorMessage(err) });
      errorCount += batch.length;
    }

    if (i < batches.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, BATCH_DELAY_MS));
    }
  }

  logger.info('Processing completed', { successCount, errorCount });
}

Deno.serve(async (req) => {
  const origin = req.headers.get('Origin');
  const corsHeaders = getCorsHeaders(origin);
  const logger = createLogger('bulk-delete-leads');

  if (req.method === 'OPTIONS') {
    return handleCorsPreFlight(corsHeaders);
  }

  const { response: rateLimitResponse } = rateLimitMiddleware(req, RATE_LIMIT_CONFIGS.bulk, corsHeaders);
  if (rateLimitResponse) {
    logger.warn('Rate limit exceeded', { ip: getClientIp(req) });
    return rateLimitResponse;
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return createErrorResponse('Missing authorization header', 401, corsHeaders);
    }

    const supabaseUser = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseUser.auth.getUser();
    if (authError || !user) {
      return createErrorResponse('Unauthorized', 401, corsHeaders);
    }

    const body: BulkDeleteRequest = await req.json();
    const { leadIds, tenantId } = body;

    if (!leadIds || !Array.isArray(leadIds) || leadIds.length === 0) {
      return createErrorResponse('leadIds must be a non-empty array', 400, corsHeaders);
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    const ctx = await authorizeBulkRequest(
      supabaseAdmin,
      user.id,
      ['SUPER_ADMIN', 'TENANT_OWNER'],
      tenantId,
    );

    logger.info('Request authorized', { count: leadIds.length, userId: user.id, role: ctx.role, tenantId: ctx.tenantId });

    EdgeRuntime.waitUntil(processInBackground(leadIds, user.id, ctx.tenantId));

    return createAcceptedResponse(`Deleting ${leadIds.length} leads in background`, leadIds.length, corsHeaders);
  } catch (error) {
    if (error instanceof BulkAuthError) {
      logger.warn('Authorization failed', { error: error.message });
      return createErrorResponse(error.message, error.status, corsHeaders);
    }
    logger.error('Request failed', { error: getErrorMessage(error) });
    return createErrorResponse(getErrorMessage(error), 500, corsHeaders);
  }
});
