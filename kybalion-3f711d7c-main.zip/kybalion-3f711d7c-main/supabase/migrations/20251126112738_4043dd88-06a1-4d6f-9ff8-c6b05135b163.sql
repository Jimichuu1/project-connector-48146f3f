-- Add DON'T_CALL to lead_status enum
ALTER TYPE lead_status ADD VALUE IF NOT EXISTS 'DON''T_CALL';