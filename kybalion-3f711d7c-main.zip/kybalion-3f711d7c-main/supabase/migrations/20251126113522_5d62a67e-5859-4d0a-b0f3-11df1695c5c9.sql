-- Add transferred_by column to leads table to track who transferred the lead
ALTER TABLE leads ADD COLUMN IF NOT EXISTS transferred_by uuid REFERENCES auth.users(id);

-- Add comment to explain the column
COMMENT ON COLUMN leads.transferred_by IS 'ID of the user who last transferred this lead to another agent';