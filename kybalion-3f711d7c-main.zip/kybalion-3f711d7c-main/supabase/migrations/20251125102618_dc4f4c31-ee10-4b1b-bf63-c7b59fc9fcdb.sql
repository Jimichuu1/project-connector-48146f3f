-- Create enums for client management
CREATE TYPE public.risk_profile AS ENUM ('LOW', 'MEDIUM', 'HIGH');
CREATE TYPE public.kyc_status AS ENUM ('VERIFIED', 'PENDING', 'REJECTED');
CREATE TYPE public.churn_risk AS ENUM ('LOW', 'MEDIUM', 'HIGH');
CREATE TYPE public.pipeline_status AS ENUM ('PROSPECT', 'QUALIFIED', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST');
CREATE TYPE public.withdrawal_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED');

-- Create clients table
CREATE TABLE public.clients (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  country TEXT,
  home_phone TEXT,
  join_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  trading_account TEXT UNIQUE NOT NULL,
  source lead_source NOT NULL DEFAULT 'OTHER',
  balance NUMERIC(15, 2) DEFAULT 0.00,
  equity NUMERIC(15, 2) DEFAULT 0.00,
  margin_level NUMERIC(5, 2) DEFAULT 0.00,
  open_trades INTEGER DEFAULT 0,
  deposits NUMERIC(15, 2) DEFAULT 0.00,
  risk_profile risk_profile NOT NULL DEFAULT 'MEDIUM',
  kyc_status kyc_status NOT NULL DEFAULT 'PENDING',
  churn_risk churn_risk NOT NULL DEFAULT 'LOW',
  satisfaction_score INTEGER DEFAULT 0 CHECK (satisfaction_score >= 0 AND satisfaction_score <= 100),
  assigned_to UUID REFERENCES public.profiles(id),
  pipeline_status pipeline_status NOT NULL DEFAULT 'PROSPECT',
  potential_value NUMERIC(15, 2),
  actual_value NUMERIC(15, 2),
  converted_from_lead_id UUID REFERENCES public.leads(id),
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create withdrawals table
CREATE TABLE public.client_withdrawals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  amount NUMERIC(15, 2) NOT NULL CHECK (amount > 0),
  status withdrawal_status NOT NULL DEFAULT 'PENDING',
  requested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  approved_by UUID REFERENCES public.profiles(id),
  approved_at TIMESTAMP WITH TIME ZONE,
  rejection_reason TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create client activities table
CREATE TABLE public.client_activities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  activity_type TEXT NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create client tasks table
CREATE TABLE public.client_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  assigned_to UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMP WITH TIME ZONE,
  completed BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create client comments table
CREATE TABLE public.client_comments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  comment TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_comments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for clients table
CREATE POLICY "Agents can view their assigned clients"
  ON public.clients FOR SELECT
  USING (assigned_to = auth.uid() OR created_by = auth.uid());

CREATE POLICY "Managers and admins can view all clients"
  ON public.clients FOR SELECT
  USING (has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'));

CREATE POLICY "Super agents with assign permission can view all clients"
  ON public.clients FOR SELECT
  USING (has_role(auth.uid(), 'SUPER_AGENT') AND has_permission(auth.uid(), 'CAN_ASSIGN_ALL'));

CREATE POLICY "Authenticated users can create clients"
  ON public.clients FOR INSERT
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Agents can update their assigned clients"
  ON public.clients FOR UPDATE
  USING (assigned_to = auth.uid() OR created_by = auth.uid());

CREATE POLICY "Managers and admins can update all clients"
  ON public.clients FOR UPDATE
  USING (has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'));

CREATE POLICY "Users with delete permission can delete clients"
  ON public.clients FOR DELETE
  USING (has_permission(auth.uid(), 'CAN_DELETE_LEADS'));

-- RLS Policies for withdrawals
CREATE POLICY "Users can view withdrawals for accessible clients"
  ON public.client_withdrawals FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_withdrawals.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can create withdrawals for accessible clients"
  ON public.client_withdrawals FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_withdrawals.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Admins can update all withdrawals"
  ON public.client_withdrawals FOR UPDATE
  USING (has_role(auth.uid(), 'ADMIN'));

-- RLS Policies for client activities
CREATE POLICY "Users can view activities for accessible clients"
  ON public.client_activities FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_activities.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can create activities for accessible clients"
  ON public.client_activities FOR INSERT
  WITH CHECK (auth.uid() = user_id AND EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_activities.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

-- RLS Policies for client tasks
CREATE POLICY "Users can view tasks for accessible clients"
  ON public.client_tasks FOR SELECT
  USING (assigned_to = auth.uid() OR EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_tasks.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can create tasks for accessible clients"
  ON public.client_tasks FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_tasks.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can update their assigned tasks"
  ON public.client_tasks FOR UPDATE
  USING (assigned_to = auth.uid());

CREATE POLICY "Managers and admins can update all tasks"
  ON public.client_tasks FOR UPDATE
  USING (has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'));

CREATE POLICY "Users can delete their assigned tasks"
  ON public.client_tasks FOR DELETE
  USING (assigned_to = auth.uid());

CREATE POLICY "Managers and admins can delete all tasks"
  ON public.client_tasks FOR DELETE
  USING (has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'));

-- RLS Policies for client comments
CREATE POLICY "Users can view comments for accessible clients"
  ON public.client_comments FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_comments.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can create comments for accessible clients"
  ON public.client_comments FOR INSERT
  WITH CHECK (auth.uid() = user_id AND EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = client_comments.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can delete their own comments"
  ON public.client_comments FOR DELETE
  USING (user_id = auth.uid());

CREATE POLICY "Managers and admins can delete all comments"
  ON public.client_comments FOR DELETE
  USING (has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'));

-- Create indexes for performance
CREATE INDEX idx_clients_assigned_to ON public.clients(assigned_to);
CREATE INDEX idx_clients_created_by ON public.clients(created_by);
CREATE INDEX idx_clients_kyc_status ON public.clients(kyc_status);
CREATE INDEX idx_clients_trading_account ON public.clients(trading_account);
CREATE INDEX idx_client_withdrawals_client_id ON public.client_withdrawals(client_id);
CREATE INDEX idx_client_withdrawals_status ON public.client_withdrawals(status);
CREATE INDEX idx_client_activities_client_id ON public.client_activities(client_id);
CREATE INDEX idx_client_tasks_client_id ON public.client_tasks(client_id);
CREATE INDEX idx_client_comments_client_id ON public.client_comments(client_id);

-- Add triggers for updated_at
CREATE TRIGGER update_clients_updated_at
  BEFORE UPDATE ON public.clients
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_client_withdrawals_updated_at
  BEFORE UPDATE ON public.client_withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

CREATE TRIGGER update_client_tasks_updated_at
  BEFORE UPDATE ON public.client_tasks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();