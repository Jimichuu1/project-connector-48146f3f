-- Create lead_groups table
CREATE TABLE public.lead_groups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create lead_group_members junction table (many-to-many)
CREATE TABLE public.lead_group_members (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  group_id UUID NOT NULL REFERENCES public.lead_groups(id) ON DELETE CASCADE,
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  added_by UUID NOT NULL,
  added_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(group_id, lead_id)
);

-- Enable RLS
ALTER TABLE public.lead_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lead_group_members ENABLE ROW LEVEL SECURITY;

-- RLS Policies for lead_groups
CREATE POLICY "Admins and managers can view all groups"
ON public.lead_groups
FOR SELECT
USING (
  has_role(auth.uid(), 'ADMIN'::app_role) OR 
  has_role(auth.uid(), 'MANAGER'::app_role)
);

CREATE POLICY "Admins can create groups"
ON public.lead_groups
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'ADMIN'::app_role) AND
  auth.uid() = created_by
);

CREATE POLICY "Admins can update groups"
ON public.lead_groups
FOR UPDATE
USING (has_role(auth.uid(), 'ADMIN'::app_role));

CREATE POLICY "Admins can delete groups"
ON public.lead_groups
FOR DELETE
USING (has_role(auth.uid(), 'ADMIN'::app_role));

-- RLS Policies for lead_group_members
CREATE POLICY "Admins and managers can view group members"
ON public.lead_group_members
FOR SELECT
USING (
  has_role(auth.uid(), 'ADMIN'::app_role) OR 
  has_role(auth.uid(), 'MANAGER'::app_role)
);

CREATE POLICY "Admins can add leads to groups"
ON public.lead_group_members
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'ADMIN'::app_role) AND
  auth.uid() = added_by
);

CREATE POLICY "Admins can remove leads from groups"
ON public.lead_group_members
FOR DELETE
USING (has_role(auth.uid(), 'ADMIN'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_lead_groups_updated_at
BEFORE UPDATE ON public.lead_groups
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at();