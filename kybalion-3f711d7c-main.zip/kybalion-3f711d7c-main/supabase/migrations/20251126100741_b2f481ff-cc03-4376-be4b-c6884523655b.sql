-- Create attendance table for tracking agent work hours
CREATE TABLE public.attendance (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  clock_in TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  clock_out TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, date)
);

-- Enable RLS
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;

-- Agents and Super Agents can insert their own attendance
CREATE POLICY "Agents can clock in"
ON public.attendance
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id AND 
  (has_role(auth.uid(), 'AGENT'::app_role) OR has_role(auth.uid(), 'SUPER_AGENT'::app_role))
);

-- Agents and Super Agents can view their own attendance
CREATE POLICY "Agents can view their own attendance"
ON public.attendance
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id AND
  (has_role(auth.uid(), 'AGENT'::app_role) OR has_role(auth.uid(), 'SUPER_AGENT'::app_role))
);

-- Agents and Super Agents can update their own attendance (for clock out)
CREATE POLICY "Agents can clock out"
ON public.attendance
FOR UPDATE
TO authenticated
USING (
  auth.uid() = user_id AND
  (has_role(auth.uid(), 'AGENT'::app_role) OR has_role(auth.uid(), 'SUPER_AGENT'::app_role))
);

-- Admins and Managers can view all attendance
CREATE POLICY "Admins and managers can view all attendance"
ON public.attendance
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'ADMIN'::app_role) OR 
  has_role(auth.uid(), 'MANAGER'::app_role)
);

-- Create trigger for updated_at
CREATE TRIGGER update_attendance_updated_at
BEFORE UPDATE ON public.attendance
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at();

-- Create function to calculate working hours
CREATE OR REPLACE FUNCTION public.calculate_working_hours(
  p_clock_in TIMESTAMP WITH TIME ZONE,
  p_clock_out TIMESTAMP WITH TIME ZONE
)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE
AS $$
BEGIN
  IF p_clock_out IS NULL THEN
    RETURN NULL;
  END IF;
  RETURN EXTRACT(EPOCH FROM (p_clock_out - p_clock_in)) / 3600;
END;
$$;