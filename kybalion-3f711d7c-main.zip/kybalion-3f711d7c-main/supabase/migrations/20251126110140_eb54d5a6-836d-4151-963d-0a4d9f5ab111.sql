-- Add day off fee to general settings
ALTER TABLE public.general_settings
ADD COLUMN day_off_fee numeric NOT NULL DEFAULT 0.00;