-- Create deposits table to track deposit splits between agents and super agents
CREATE TABLE public.deposits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_branch_id UUID NOT NULL REFERENCES public.sale_branches(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  amount NUMERIC NOT NULL,
  agent_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  super_agent_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  agent_percentage INTEGER NOT NULL CHECK (agent_percentage IN (30, 50, 70)),
  super_agent_percentage INTEGER NOT NULL CHECK (super_agent_percentage IN (30, 50, 70)),
  agent_amount NUMERIC NOT NULL,
  super_agent_amount NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID NOT NULL,
  CONSTRAINT valid_percentage_split CHECK (agent_percentage + super_agent_percentage = 100)
);

-- Enable RLS
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;

-- Admins can view all deposits
CREATE POLICY "Admins can view all deposits"
ON public.deposits
FOR SELECT
USING (has_role(auth.uid(), 'ADMIN'::app_role));

-- Managers can view all deposits
CREATE POLICY "Managers can view all deposits"
ON public.deposits
FOR SELECT
USING (has_role(auth.uid(), 'MANAGER'::app_role));

-- Agents and super agents can view their own deposits
CREATE POLICY "Users can view their own deposits"
ON public.deposits
FOR SELECT
USING (auth.uid() = agent_id OR auth.uid() = super_agent_id);

-- Super agents can create deposits
CREATE POLICY "Super agents can create deposits"
ON public.deposits
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'SUPER_AGENT'::app_role) AND 
  auth.uid() = created_by
);

-- Create index for performance
CREATE INDEX idx_deposits_agent_id ON public.deposits(agent_id);
CREATE INDEX idx_deposits_super_agent_id ON public.deposits(super_agent_id);
CREATE INDEX idx_deposits_created_at ON public.deposits(created_at);
CREATE INDEX idx_deposits_client_id ON public.deposits(client_id);