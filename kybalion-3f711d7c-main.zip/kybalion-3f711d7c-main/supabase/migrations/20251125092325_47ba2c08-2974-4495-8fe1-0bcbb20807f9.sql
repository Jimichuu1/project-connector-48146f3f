-- Create enum for lead status
CREATE TYPE public.lead_status AS ENUM (
  'NEW',
  'ACTIVE',
  'CALLBACK',
  'NOT_INTERESTED',
  'READY_TO_TRANSFER',
  'CALLED'
);

-- Create enum for lead source
CREATE TYPE public.lead_source AS ENUM (
  'WEBSITE',
  'REFERRAL',
  'SOCIAL_MEDIA',
  'COLD_CALL',
  'EMAIL_CAMPAIGN',
  'PAID_ADS',
  'WEBINAR',
  'TRADE_SHOW',
  'OTHER'
);

-- Create leads table
CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  country TEXT,
  source lead_source NOT NULL DEFAULT 'OTHER',
  status lead_status NOT NULL DEFAULT 'NEW',
  job_title TEXT,
  company TEXT,
  assigned_to UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  lead_score INTEGER DEFAULT 0 CHECK (lead_score >= 0 AND lead_score <= 100),
  conversion_probability DECIMAL(3,2) DEFAULT 0.00 CHECK (conversion_probability >= 0 AND conversion_probability <= 1),
  deal_value DECIMAL(12,2),
  estimated_close_date DATE,
  best_contact_time TEXT,
  next_best_action TEXT,
  is_transferred BOOLEAN DEFAULT false,
  last_contacted_at TIMESTAMPTZ,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on leads
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Create lead activities table
CREATE TABLE public.lead_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  activity_type TEXT NOT NULL,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on lead_activities
ALTER TABLE public.lead_activities ENABLE ROW LEVEL SECURITY;

-- Create lead tasks table
CREATE TABLE public.lead_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  assigned_to UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  due_date TIMESTAMPTZ,
  completed BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on lead_tasks
ALTER TABLE public.lead_tasks ENABLE ROW LEVEL SECURITY;

-- Create lead comments table
CREATE TABLE public.lead_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  comment TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on lead_comments
ALTER TABLE public.lead_comments ENABLE ROW LEVEL SECURITY;

-- Create indexes for better query performance
CREATE INDEX idx_leads_assigned_to ON public.leads(assigned_to);
CREATE INDEX idx_leads_status ON public.leads(status);
CREATE INDEX idx_leads_created_by ON public.leads(created_by);
CREATE INDEX idx_leads_email ON public.leads(email);
CREATE INDEX idx_lead_activities_lead_id ON public.lead_activities(lead_id);
CREATE INDEX idx_lead_tasks_lead_id ON public.lead_tasks(lead_id);
CREATE INDEX idx_lead_comments_lead_id ON public.lead_comments(lead_id);

-- Create trigger for leads updated_at
CREATE TRIGGER update_leads_updated_at
  BEFORE UPDATE ON public.leads
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- Create trigger for lead_tasks updated_at
CREATE TRIGGER update_lead_tasks_updated_at
  BEFORE UPDATE ON public.lead_tasks
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- RLS Policies for leads

-- Agents can view their own leads
CREATE POLICY "Agents can view their assigned leads"
  ON public.leads
  FOR SELECT
  USING (
    assigned_to = auth.uid() OR 
    created_by = auth.uid()
  );

-- Agents can view leads they created that are unassigned
CREATE POLICY "Agents can view unassigned leads they created"
  ON public.leads
  FOR SELECT
  USING (created_by = auth.uid() AND assigned_to IS NULL);

-- Managers and admins can view all leads
CREATE POLICY "Managers and admins can view all leads"
  ON public.leads
  FOR SELECT
  USING (
    public.has_role(auth.uid(), 'ADMIN') OR 
    public.has_role(auth.uid(), 'MANAGER')
  );

-- Super agents with CAN_ASSIGN_ALL can view all leads
CREATE POLICY "Super agents with assign permission can view all leads"
  ON public.leads
  FOR SELECT
  USING (
    public.has_role(auth.uid(), 'SUPER_AGENT') AND
    public.has_permission(auth.uid(), 'CAN_ASSIGN_ALL')
  );

-- Any authenticated user can create leads
CREATE POLICY "Authenticated users can create leads"
  ON public.leads
  FOR INSERT
  WITH CHECK (auth.uid() = created_by);

-- Agents can update their assigned leads
CREATE POLICY "Agents can update their assigned leads"
  ON public.leads
  FOR UPDATE
  USING (assigned_to = auth.uid() OR created_by = auth.uid());

-- Managers and admins can update all leads
CREATE POLICY "Managers and admins can update all leads"
  ON public.leads
  FOR UPDATE
  USING (
    public.has_role(auth.uid(), 'ADMIN') OR 
    public.has_role(auth.uid(), 'MANAGER')
  );

-- Only users with CAN_DELETE_LEADS permission can delete
CREATE POLICY "Users with delete permission can delete leads"
  ON public.leads
  FOR DELETE
  USING (public.has_permission(auth.uid(), 'CAN_DELETE_LEADS'));

-- RLS Policies for lead_activities

-- Users can view activities for leads they have access to
CREATE POLICY "Users can view activities for accessible leads"
  ON public.lead_activities
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.leads
      WHERE leads.id = lead_activities.lead_id
      AND (
        leads.assigned_to = auth.uid() OR
        leads.created_by = auth.uid() OR
        public.has_role(auth.uid(), 'ADMIN') OR
        public.has_role(auth.uid(), 'MANAGER')
      )
    )
  );

-- Users can create activities for leads they have access to
CREATE POLICY "Users can create activities for accessible leads"
  ON public.lead_activities
  FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM public.leads
      WHERE leads.id = lead_activities.lead_id
      AND (
        leads.assigned_to = auth.uid() OR
        leads.created_by = auth.uid() OR
        public.has_role(auth.uid(), 'ADMIN') OR
        public.has_role(auth.uid(), 'MANAGER')
      )
    )
  );

-- RLS Policies for lead_tasks

-- Users can view tasks for leads they have access to
CREATE POLICY "Users can view tasks for accessible leads"
  ON public.lead_tasks
  FOR SELECT
  USING (
    assigned_to = auth.uid() OR
    EXISTS (
      SELECT 1 FROM public.leads
      WHERE leads.id = lead_tasks.lead_id
      AND (
        leads.assigned_to = auth.uid() OR
        leads.created_by = auth.uid() OR
        public.has_role(auth.uid(), 'ADMIN') OR
        public.has_role(auth.uid(), 'MANAGER')
      )
    )
  );

-- Users can create tasks for leads they have access to
CREATE POLICY "Users can create tasks for accessible leads"
  ON public.lead_tasks
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.leads
      WHERE leads.id = lead_tasks.lead_id
      AND (
        leads.assigned_to = auth.uid() OR
        leads.created_by = auth.uid() OR
        public.has_role(auth.uid(), 'ADMIN') OR
        public.has_role(auth.uid(), 'MANAGER')
      )
    )
  );

-- Users can update tasks assigned to them
CREATE POLICY "Users can update their assigned tasks"
  ON public.lead_tasks
  FOR UPDATE
  USING (assigned_to = auth.uid());

-- Managers and admins can update all tasks
CREATE POLICY "Managers and admins can update all tasks"
  ON public.lead_tasks
  FOR UPDATE
  USING (
    public.has_role(auth.uid(), 'ADMIN') OR 
    public.has_role(auth.uid(), 'MANAGER')
  );

-- Users can delete tasks assigned to them
CREATE POLICY "Users can delete their assigned tasks"
  ON public.lead_tasks
  FOR DELETE
  USING (assigned_to = auth.uid());

-- Managers and admins can delete all tasks
CREATE POLICY "Managers and admins can delete all tasks"
  ON public.lead_tasks
  FOR DELETE
  USING (
    public.has_role(auth.uid(), 'ADMIN') OR 
    public.has_role(auth.uid(), 'MANAGER')
  );

-- RLS Policies for lead_comments

-- Users can view comments for leads they have access to
CREATE POLICY "Users can view comments for accessible leads"
  ON public.lead_comments
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.leads
      WHERE leads.id = lead_comments.lead_id
      AND (
        leads.assigned_to = auth.uid() OR
        leads.created_by = auth.uid() OR
        public.has_role(auth.uid(), 'ADMIN') OR
        public.has_role(auth.uid(), 'MANAGER')
      )
    )
  );

-- Users can create comments for leads they have access to
CREATE POLICY "Users can create comments for accessible leads"
  ON public.lead_comments
  FOR INSERT
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM public.leads
      WHERE leads.id = lead_comments.lead_id
      AND (
        leads.assigned_to = auth.uid() OR
        leads.created_by = auth.uid() OR
        public.has_role(auth.uid(), 'ADMIN') OR
        public.has_role(auth.uid(), 'MANAGER')
      )
    )
  );

-- Users can delete their own comments
CREATE POLICY "Users can delete their own comments"
  ON public.lead_comments
  FOR DELETE
  USING (user_id = auth.uid());

-- Managers and admins can delete all comments
CREATE POLICY "Managers and admins can delete all comments"
  ON public.lead_comments
  FOR DELETE
  USING (
    public.has_role(auth.uid(), 'ADMIN') OR 
    public.has_role(auth.uid(), 'MANAGER')
  );