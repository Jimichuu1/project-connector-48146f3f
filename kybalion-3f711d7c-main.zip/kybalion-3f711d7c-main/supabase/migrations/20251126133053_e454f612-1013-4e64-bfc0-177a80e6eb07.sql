-- Add exchanges column to deposits table
ALTER TABLE deposits ADD COLUMN exchanges TEXT[];

-- Add comment for documentation
COMMENT ON COLUMN deposits.exchanges IS 'Array of exchange names used for the deposit';