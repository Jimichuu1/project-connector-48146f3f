
-- Drop the previous policy and create a better one
DROP POLICY IF EXISTS "Users can view profiles of assigned super agents" ON public.profiles;

-- Allow agents to view super agent profiles assigned to their converted clients
CREATE POLICY "Agents can view super agent profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  -- Allow viewing profiles that are super agents assigned to user's clients
  id IN (
    SELECT DISTINCT c.assigned_to 
    FROM clients c
    WHERE c.created_by = auth.uid()
    AND c.assigned_to IS NOT NULL
  )
  OR
  -- Allow viewing profiles of agents who created clients assigned to current user (for super agents)
  id IN (
    SELECT DISTINCT c.created_by
    FROM clients c
    WHERE c.assigned_to = auth.uid()
    AND c.created_by IS NOT NULL
  )
);
