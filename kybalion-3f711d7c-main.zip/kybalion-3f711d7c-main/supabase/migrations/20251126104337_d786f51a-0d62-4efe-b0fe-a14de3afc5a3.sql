-- Create general_settings table for work hours and fees configuration
CREATE TABLE IF NOT EXISTS public.general_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_start_time time NOT NULL DEFAULT '09:00:00',
  work_end_time time NOT NULL DEFAULT '18:00:00',
  late_start_fee numeric NOT NULL DEFAULT 0.00,
  excessive_break_fee numeric NOT NULL DEFAULT 0.00,
  max_break_minutes integer NOT NULL DEFAULT 60,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Add trigger for updated_at
CREATE TRIGGER update_general_settings_updated_at
  BEFORE UPDATE ON public.general_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- Enable RLS
ALTER TABLE public.general_settings ENABLE ROW LEVEL SECURITY;

-- Allow admins to manage settings
CREATE POLICY "Admins can manage general settings"
  ON public.general_settings
  FOR ALL
  USING (has_role(auth.uid(), 'ADMIN'::app_role));

-- Allow all authenticated users to view settings
CREATE POLICY "Users can view general settings"
  ON public.general_settings
  FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Insert default settings
INSERT INTO public.general_settings (work_start_time, work_end_time, late_start_fee, excessive_break_fee, max_break_minutes)
VALUES ('09:00:00', '18:00:00', 10.00, 5.00, 60);

-- Add fee columns to attendance table
ALTER TABLE public.attendance
ADD COLUMN IF NOT EXISTS late_start_fee numeric DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS break_time_fee numeric DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS total_fees numeric DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS is_late boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS break_minutes integer DEFAULT 0;