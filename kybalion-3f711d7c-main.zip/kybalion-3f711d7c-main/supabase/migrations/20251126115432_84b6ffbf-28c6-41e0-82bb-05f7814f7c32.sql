-- Remove WORK_IN_PROCESS from pipeline_stage enum
-- First, update any existing records to UPCOMING_SALE
UPDATE sale_branches 
SET status = 'UPCOMING_SALE' 
WHERE status = 'WORK_IN_PROCESS';

-- Drop the default constraint temporarily
ALTER TABLE sale_branches ALTER COLUMN status DROP DEFAULT;

-- Create new enum without WORK_IN_PROCESS
CREATE TYPE pipeline_stage_new AS ENUM ('UPCOMING_SALE', 'STUCK', 'FLIPPED', 'DEPOSIT');

-- Update the sale_branches table to use the new enum
ALTER TABLE sale_branches 
  ALTER COLUMN status TYPE pipeline_stage_new 
  USING status::text::pipeline_stage_new;

-- Drop the old enum and rename the new one
DROP TYPE pipeline_stage;
ALTER TYPE pipeline_stage_new RENAME TO pipeline_stage;

-- Set new default to UPCOMING_SALE
ALTER TABLE sale_branches ALTER COLUMN status SET DEFAULT 'UPCOMING_SALE'::pipeline_stage;