-- Create IP whitelist table for user access control
CREATE TABLE public.ip_whitelist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ip_address TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, ip_address)
);

-- Enable RLS
ALTER TABLE public.ip_whitelist ENABLE ROW LEVEL SECURITY;

-- Admins can manage all IP whitelist entries
CREATE POLICY "Admins can view all IP whitelist entries"
ON public.ip_whitelist
FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'ADMIN'::app_role));

CREATE POLICY "Admins can insert IP whitelist entries"
ON public.ip_whitelist
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'ADMIN'::app_role) AND
  auth.uid() = created_by
);

CREATE POLICY "Admins can update IP whitelist entries"
ON public.ip_whitelist
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'ADMIN'::app_role));

CREATE POLICY "Admins can delete IP whitelist entries"
ON public.ip_whitelist
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'ADMIN'::app_role));

-- Users can view their own IP whitelist entries
CREATE POLICY "Users can view their own IP whitelist"
ON public.ip_whitelist
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

-- Create trigger for updated_at
CREATE TRIGGER update_ip_whitelist_updated_at
BEFORE UPDATE ON public.ip_whitelist
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at();

-- Create function to check if user's IP is whitelisted
CREATE OR REPLACE FUNCTION public.check_ip_whitelist(
  p_user_id UUID,
  p_ip_address TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if user has any active whitelist entries
  IF NOT EXISTS (
    SELECT 1 FROM ip_whitelist 
    WHERE user_id = p_user_id AND is_active = true
  ) THEN
    -- No IP restrictions for this user
    RETURN true;
  END IF;
  
  -- Check if the specific IP is whitelisted
  RETURN EXISTS (
    SELECT 1 FROM ip_whitelist
    WHERE user_id = p_user_id 
      AND ip_address = p_ip_address 
      AND is_active = true
  );
END;
$$;