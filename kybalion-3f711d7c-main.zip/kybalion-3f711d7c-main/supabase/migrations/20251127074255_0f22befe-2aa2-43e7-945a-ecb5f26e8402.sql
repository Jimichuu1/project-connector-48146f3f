
-- Add policy to allow users to view profiles of super agents assigned to their clients
CREATE POLICY "Users can view profiles of assigned super agents"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  -- Allow viewing super agent profiles if they're assigned to any of user's clients
  EXISTS (
    SELECT 1 FROM clients
    WHERE clients.assigned_to = profiles.id
    AND (clients.created_by = auth.uid() OR clients.assigned_to = auth.uid())
  )
);
