-- Create enum for pipeline stages
CREATE TYPE public.pipeline_stage AS ENUM (
  'WORK_IN_PROCESS',
  'UPCOMING_SALE',
  'STUCK',
  'FLIPPED',
  'DEPOSIT'
);

-- Create sale_branches table
CREATE TABLE public.sale_branches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  status pipeline_stage NOT NULL DEFAULT 'WORK_IN_PROCESS',
  value NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.sale_branches ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view branches for accessible clients"
  ON public.sale_branches FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = sale_branches.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can create branches for accessible clients"
  ON public.sale_branches FOR INSERT
  WITH CHECK (auth.uid() = created_by AND EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = sale_branches.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can update branches for accessible clients"
  ON public.sale_branches FOR UPDATE
  USING (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = sale_branches.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

CREATE POLICY "Users can delete branches for accessible clients"
  ON public.sale_branches FOR DELETE
  USING (EXISTS (
    SELECT 1 FROM clients
    WHERE clients.id = sale_branches.client_id
    AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
         OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
  ));

-- Create indexes
CREATE INDEX idx_sale_branches_client_id ON public.sale_branches(client_id);
CREATE INDEX idx_sale_branches_status ON public.sale_branches(status);
CREATE INDEX idx_sale_branches_created_by ON public.sale_branches(created_by);

-- Add trigger for updated_at
CREATE TRIGGER update_sale_branches_updated_at
  BEFORE UPDATE ON public.sale_branches
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();