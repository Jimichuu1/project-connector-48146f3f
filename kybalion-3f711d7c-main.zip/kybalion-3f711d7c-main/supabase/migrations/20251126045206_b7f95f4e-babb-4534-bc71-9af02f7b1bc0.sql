-- Make bank_name optional to allow separate bank and note records
ALTER TABLE public.kyc_records 
ALTER COLUMN bank_name DROP NOT NULL;