-- Allow admins and managers to create deposits
CREATE POLICY "Admins can create deposits"
ON deposits
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'ADMIN'::app_role) 
  AND auth.uid() = created_by
);

CREATE POLICY "Managers can create deposits"
ON deposits
FOR INSERT
TO authenticated
WITH CHECK (
  has_role(auth.uid(), 'MANAGER'::app_role) 
  AND auth.uid() = created_by
);