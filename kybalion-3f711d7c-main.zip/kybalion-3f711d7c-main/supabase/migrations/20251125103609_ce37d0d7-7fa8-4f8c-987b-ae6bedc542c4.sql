-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('documents', 'documents', false);

-- Create document_type enum
CREATE TYPE public.document_type AS ENUM ('PDF', 'DOCX', 'XLSX', 'IMAGE', 'OTHER');

-- Create documents table
CREATE TABLE public.documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  size BIGINT NOT NULL,
  type document_type NOT NULL,
  file_path TEXT NOT NULL,
  uploaded_by UUID NOT NULL,
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  kyc_record_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT documents_entity_check CHECK (
    (lead_id IS NOT NULL AND client_id IS NULL) OR
    (lead_id IS NULL AND client_id IS NOT NULL)
  )
);

-- Create kyc_records table
CREATE TABLE public.kyc_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lead_id UUID REFERENCES public.leads(id) ON DELETE CASCADE,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE,
  status kyc_status NOT NULL DEFAULT 'PENDING',
  bank_name TEXT NOT NULL,
  notes TEXT,
  verified_date TIMESTAMP WITH TIME ZONE,
  verified_by UUID REFERENCES public.profiles(id),
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT kyc_records_entity_check CHECK (
    (lead_id IS NOT NULL AND client_id IS NULL) OR
    (lead_id IS NULL AND client_id IS NOT NULL)
  )
);

-- Add foreign key for documents to kyc_records
ALTER TABLE public.documents 
  ADD CONSTRAINT documents_kyc_record_id_fkey 
  FOREIGN KEY (kyc_record_id) REFERENCES public.kyc_records(id) ON DELETE CASCADE;

-- Create notification_type enum
CREATE TYPE public.notification_type AS ENUM (
  'NEW_LEAD',
  'WITHDRAWAL_REQUEST',
  'LEAD_ASSIGNED',
  'CLIENT_CONVERTED',
  'TASK_DUE',
  'TICKET_CREATED'
);

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  type notification_type NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT false,
  related_profile_id UUID,
  related_entity_type TEXT,
  related_entity_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.kyc_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- RLS Policies for documents
CREATE POLICY "Users can view documents for accessible entities"
  ON public.documents FOR SELECT
  USING (
    (lead_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM leads
      WHERE leads.id = documents.lead_id
      AND (leads.assigned_to = auth.uid() OR leads.created_by = auth.uid() 
           OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
    )) OR
    (client_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM clients
      WHERE clients.id = documents.client_id
      AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
           OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
    ))
  );

CREATE POLICY "Users can upload documents for accessible entities"
  ON public.documents FOR INSERT
  WITH CHECK (
    auth.uid() = uploaded_by AND (
      (lead_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM leads
        WHERE leads.id = documents.lead_id
        AND (leads.assigned_to = auth.uid() OR leads.created_by = auth.uid() 
             OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
      )) OR
      (client_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM clients
        WHERE clients.id = documents.client_id
        AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
             OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
      ))
    )
  );

CREATE POLICY "Users can delete their own documents"
  ON public.documents FOR DELETE
  USING (uploaded_by = auth.uid());

CREATE POLICY "Admins can delete all documents"
  ON public.documents FOR DELETE
  USING (has_role(auth.uid(), 'ADMIN'));

-- RLS Policies for kyc_records
CREATE POLICY "Users can view KYC records for accessible entities"
  ON public.kyc_records FOR SELECT
  USING (
    (lead_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM leads
      WHERE leads.id = kyc_records.lead_id
      AND (leads.assigned_to = auth.uid() OR leads.created_by = auth.uid() 
           OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
    )) OR
    (client_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM clients
      WHERE clients.id = kyc_records.client_id
      AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
           OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
    ))
  );

CREATE POLICY "Users can create KYC records for accessible entities"
  ON public.kyc_records FOR INSERT
  WITH CHECK (
    auth.uid() = created_by AND (
      (lead_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM leads
        WHERE leads.id = kyc_records.lead_id
        AND (leads.assigned_to = auth.uid() OR leads.created_by = auth.uid() 
             OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
      )) OR
      (client_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM clients
        WHERE clients.id = kyc_records.client_id
        AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
             OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
      ))
    )
  );

CREATE POLICY "Users can update KYC records for accessible entities"
  ON public.kyc_records FOR UPDATE
  USING (
    (lead_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM leads
      WHERE leads.id = kyc_records.lead_id
      AND (leads.assigned_to = auth.uid() OR leads.created_by = auth.uid() 
           OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
    )) OR
    (client_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM clients
      WHERE clients.id = kyc_records.client_id
      AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
           OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
    ))
  );

CREATE POLICY "Admins can delete KYC records"
  ON public.kyc_records FOR DELETE
  USING (has_role(auth.uid(), 'ADMIN'));

-- RLS Policies for notifications
CREATE POLICY "Users can view their own notifications"
  ON public.notifications FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own notifications"
  ON public.notifications FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete their own notifications"
  ON public.notifications FOR DELETE
  USING (user_id = auth.uid());

CREATE POLICY "System can create notifications"
  ON public.notifications FOR INSERT
  WITH CHECK (true);

-- Storage policies for documents bucket
CREATE POLICY "Users can view documents they have access to"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'documents' AND
    EXISTS (
      SELECT 1 FROM public.documents
      WHERE documents.file_path = storage.objects.name
      AND (
        (documents.lead_id IS NOT NULL AND EXISTS (
          SELECT 1 FROM leads
          WHERE leads.id = documents.lead_id
          AND (leads.assigned_to = auth.uid() OR leads.created_by = auth.uid() 
               OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
        )) OR
        (documents.client_id IS NOT NULL AND EXISTS (
          SELECT 1 FROM clients
          WHERE clients.id = documents.client_id
          AND (clients.assigned_to = auth.uid() OR clients.created_by = auth.uid() 
               OR has_role(auth.uid(), 'ADMIN') OR has_role(auth.uid(), 'MANAGER'))
        ))
      )
    )
  );

CREATE POLICY "Authenticated users can upload documents"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'documents' AND
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can delete their uploaded documents"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'documents' AND
    (
      auth.uid()::text = (storage.foldername(name))[1] OR
      has_role(auth.uid(), 'ADMIN')
    )
  );

-- Create indexes
CREATE INDEX idx_documents_lead_id ON public.documents(lead_id);
CREATE INDEX idx_documents_client_id ON public.documents(client_id);
CREATE INDEX idx_documents_kyc_record_id ON public.documents(kyc_record_id);
CREATE INDEX idx_kyc_records_lead_id ON public.kyc_records(lead_id);
CREATE INDEX idx_kyc_records_client_id ON public.kyc_records(client_id);
CREATE INDEX idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX idx_notifications_is_read ON public.notifications(is_read);

-- Add triggers
CREATE TRIGGER update_kyc_records_updated_at
  BEFORE UPDATE ON public.kyc_records
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

-- Enable realtime for notifications
ALTER TABLE public.notifications REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;