-- Remove trading_account column from clients table
ALTER TABLE public.clients DROP COLUMN IF EXISTS trading_account;