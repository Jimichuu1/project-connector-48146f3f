-- Fix search_path for calculate_working_hours function
CREATE OR REPLACE FUNCTION public.calculate_working_hours(
  p_clock_in TIMESTAMP WITH TIME ZONE,
  p_clock_out TIMESTAMP WITH TIME ZONE
)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_clock_out IS NULL THEN
    RETURN NULL;
  END IF;
  RETURN EXTRACT(EPOCH FROM (p_clock_out - p_clock_in)) / 3600;
END;
$$;