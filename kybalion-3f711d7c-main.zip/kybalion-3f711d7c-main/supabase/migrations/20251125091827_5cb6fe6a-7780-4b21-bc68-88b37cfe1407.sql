-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('ADMIN', 'MANAGER', 'SUPER_AGENT', 'AGENT');

-- Create enum for permissions
CREATE TYPE public.app_permission AS ENUM (
  'CAN_VIEW_REPORTS',
  'CAN_VIEW_SETTINGS',
  'CAN_MANAGE_USERS',
  'CAN_DELETE_LEADS',
  'CAN_ASSIGN_ALL',
  'CAN_TRANSFER_LEADS'
);

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create user_roles table (separate from profiles for security)
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create user_permissions table
CREATE TABLE public.user_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  permission app_permission NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, permission)
);

-- Enable RLS on user_permissions
ALTER TABLE public.user_permissions ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check if user has a role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

-- Create security definer function to check if user has a permission
CREATE OR REPLACE FUNCTION public.has_permission(_user_id UUID, _permission app_permission)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_permissions
    WHERE user_id = _user_id AND permission = _permission
  );
$$;

-- Create function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert profile
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  
  -- Assign default role (AGENT) to new users
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'AGENT');
  
  RETURN NEW;
END;
$$;

-- Create trigger for new user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Create trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON public.profiles
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles
  FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Admins and managers can view all profiles"
  ON public.profiles
  FOR SELECT
  USING (
    public.has_role(auth.uid(), 'ADMIN') OR 
    public.has_role(auth.uid(), 'MANAGER')
  );

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
  ON public.user_roles
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users with CAN_MANAGE_USERS can view all roles"
  ON public.user_roles
  FOR SELECT
  USING (public.has_permission(auth.uid(), 'CAN_MANAGE_USERS'));

CREATE POLICY "Users with CAN_MANAGE_USERS can insert roles"
  ON public.user_roles
  FOR INSERT
  WITH CHECK (public.has_permission(auth.uid(), 'CAN_MANAGE_USERS'));

CREATE POLICY "Users with CAN_MANAGE_USERS can update roles"
  ON public.user_roles
  FOR UPDATE
  USING (public.has_permission(auth.uid(), 'CAN_MANAGE_USERS'));

CREATE POLICY "Admins can delete roles"
  ON public.user_roles
  FOR DELETE
  USING (public.has_role(auth.uid(), 'ADMIN'));

-- RLS Policies for user_permissions
CREATE POLICY "Users can view their own permissions"
  ON public.user_permissions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users with CAN_MANAGE_USERS can view all permissions"
  ON public.user_permissions
  FOR SELECT
  USING (public.has_permission(auth.uid(), 'CAN_MANAGE_USERS'));

CREATE POLICY "Users with CAN_MANAGE_USERS can insert permissions"
  ON public.user_permissions
  FOR INSERT
  WITH CHECK (public.has_permission(auth.uid(), 'CAN_MANAGE_USERS'));

CREATE POLICY "Users with CAN_MANAGE_USERS can update permissions"
  ON public.user_permissions
  FOR UPDATE
  USING (public.has_permission(auth.uid(), 'CAN_MANAGE_USERS'));

CREATE POLICY "Admins can delete permissions"
  ON public.user_permissions
  FOR DELETE
  USING (public.has_role(auth.uid(), 'ADMIN'));