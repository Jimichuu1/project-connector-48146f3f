-- Add pending_conversion field to leads table
ALTER TABLE public.leads ADD COLUMN IF NOT EXISTS pending_conversion BOOLEAN DEFAULT false;

-- Add comment to explain the field
COMMENT ON COLUMN public.leads.pending_conversion IS 'True when lead is in conversion queue waiting for admin approval';
