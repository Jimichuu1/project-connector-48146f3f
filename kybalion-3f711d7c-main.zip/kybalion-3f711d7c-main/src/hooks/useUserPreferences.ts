import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface UserPreferences {
  timezone: string;
  group_last_read: Record<string, string>;
}

const DEFAULT_PREFERENCES: UserPreferences = {
  timezone: 'America/New_York',
  group_last_read: {},
};

export function useUserPreferences() {
  const { user } = useAuth();
  const [preferences, setPreferences] = useState<UserPreferences>(DEFAULT_PREFERENCES);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch preferences from database
  const fetchPreferences = useCallback(async () => {
    if (!user?.id) {
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('user_preferences')
        .select('timezone, group_last_read')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching preferences:', error);
        return;
      }

      if (data) {
        setPreferences({
          timezone: data.timezone || DEFAULT_PREFERENCES.timezone,
          group_last_read: (data.group_last_read as Record<string, string>) || {},
        });
      } else {
        // Create default preferences for new users
        await supabase
          .from('user_preferences')
          .insert({
            user_id: user.id,
            timezone: DEFAULT_PREFERENCES.timezone,
            group_last_read: DEFAULT_PREFERENCES.group_last_read,
          });
      }
    } catch (error) {
      console.error('Error in fetchPreferences:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchPreferences();
  }, [fetchPreferences]);

  // Update timezone
  const setTimezone = useCallback(async (timezone: string) => {
    if (!user?.id) return;

    setPreferences(prev => ({ ...prev, timezone }));

    const { error } = await supabase
      .from('user_preferences')
      .upsert({
        user_id: user.id,
        timezone,
      }, { onConflict: 'user_id' });

    if (error) {
      console.error('Error updating timezone:', error);
    }
  }, [user?.id]);

  // Update group last read timestamp
  const markGroupAsRead = useCallback(async (groupKey: string) => {
    if (!user?.id) return;

    const newLastRead = {
      ...preferences.group_last_read,
      [groupKey]: new Date().toISOString(),
    };

    setPreferences(prev => ({ ...prev, group_last_read: newLastRead }));

    const { error } = await supabase
      .from('user_preferences')
      .upsert({
        user_id: user.id,
        group_last_read: newLastRead,
      }, { onConflict: 'user_id' });

    if (error) {
      console.error('Error updating group_last_read:', error);
    }
  }, [user?.id, preferences.group_last_read]);

  return {
    preferences,
    isLoading,
    setTimezone,
    markGroupAsRead,
    refetch: fetchPreferences,
  };
}
