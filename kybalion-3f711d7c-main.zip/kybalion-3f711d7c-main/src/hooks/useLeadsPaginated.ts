/**
 * Server-side paginated version of useLeads hook with optimistic updates
 * Includes debounced realtime and async bulk operations
 */
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Lead, LeadStatus } from "@/types/leads";
import { useToast } from "@/hooks/use-toast";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useTenant } from "@/contexts/TenantContext";
import { Database } from "@/integrations/supabase/types";
import { PaginationParams, calculatePagination, getOffsetAndLimit } from "@/types/pagination";
import { useEffect, useRef, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { isValidUUID } from "@/lib/uuidUtils";
import { getAllPhonePrefixesForCountry } from "@/lib/phoneCountryCode";

// Debounce delay for batching realtime updates - increased for heavy operations
const REALTIME_DEBOUNCE_MS = 1000;
// Maximum pending updates before forcing full invalidation
const MAX_PENDING_UPDATES = 100;

// Optimized column selection - only fetch what's needed
const LEAD_COLUMNS = 'id, name, email, phone, status, assigned_to, country, created_at, updated_at, admin_id, is_transferred, source, position, created_by, balance, equity, conversion_probability, best_contact_time, pending_conversion';

interface LeadFilters {
  status?: LeadStatus;
  statuses?: LeadStatus[];
  sources?: string[];
  assignedTo?: string;
  assignedToList?: string[];
  unassigned?: boolean;
  search?: string;
  groupIds?: string[];
  conversionProbMin?: number;
  conversionProbMax?: number;
  dateFrom?: Date;
  dateTo?: Date;
  countries?: string[];
  teamMemberIds?: string[];
}

export const useLeadsPaginated = (
  filters?: LeadFilters,
  pagination: PaginationParams = { page: 1, pageSize: 50 },
  enabled: boolean = true
) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();
  const { effectiveTenantId } = useTenant();
  const { user } = useAuth();
  const { isAgent, isSuperAgent } = useUserData();
  const { offset, limit } = getOffsetAndLimit(pagination.page, pagination.pageSize);
  
  // For agents/super agents, we add explicit filters to help PostgreSQL optimize
  const isAgentRole = isAgent || isSuperAgent;

  // Only run queries when we have a valid tenant context (or explicitly no tenant for super admin)
  const isTenantReady = effectiveTenantId === null || isValidUUID(effectiveTenantId);
  const shouldEnableQueries = enabled && isTenantReady;

  // Count query for total - use longer stale time to reduce DB load
  const { data: totalCount = 0 } = useQuery({
    queryKey: ['leads-count', filters, effectiveTenantId],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    enabled: shouldEnableQueries,
    queryFn: async () => {
      // If group filter is active, query through lead_group_members
      if (filters?.groupIds && filters.groupIds.length > 0) {
        let query = supabase
          .from('lead_group_members')
          .select('lead_id, leads!inner(id)', { count: 'exact', head: true })
          .in('group_id', filters.groupIds);

        if (isAgentRole && user?.id) {
          query = query.or(`assigned_to.eq.${user.id},created_by.eq.${user.id}`, { foreignTable: 'leads' });
        }

        query = applyFilters(query, { ...filters, groupIds: undefined }, effectiveTenantId, 'leads');

        const { count } = await query;
        return count || 0;
      }

      let query = supabase
        .from('leads')
        .select('*', { count: 'exact', head: true });

      // For agents, add explicit filter to help PostgreSQL use indexes
      if (isAgentRole && user?.id) {
        query = query.or(`assigned_to.eq.${user.id},created_by.eq.${user.id}`);
      }

      query = applyFilters(query, filters, effectiveTenantId);

      const { count } = await query;
      return count || 0;
    },
  });

  // Paginated data query with optimized column selection
  const { data: leads, isLoading, error } = useQuery({
    queryKey: ['leads-paginated', filters, effectiveTenantId, pagination.page, pagination.pageSize],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    enabled: shouldEnableQueries,
    queryFn: async () => {
      // If group filter is active, query through the join table to avoid huge URLs
      // (a large group can have thousands of members; .in('id', [...]) hits URL length limits → 400).
      if (filters?.groupIds && filters.groupIds.length > 0) {
        let query = supabase
          .from('lead_group_members')
          .select(`leads!inner(${LEAD_COLUMNS})`)
          .in('group_id', filters.groupIds)
          .order('updated_at', { foreignTable: 'leads', ascending: false })
          .order('created_at', { foreignTable: 'leads', ascending: false })
          .range(offset, offset + limit - 1);

        if (isAgentRole && user?.id) {
          query = query.or(`assigned_to.eq.${user.id},created_by.eq.${user.id}`, { foreignTable: 'leads' });
        }
        query = applyFilters(query, { ...filters, groupIds: undefined }, effectiveTenantId, 'leads');

        const { data, error } = await query;
        if (error) throw error;

        // Dedupe in case a lead belongs to multiple selected groups
        const seen = new Set<string>();
        const out: Lead[] = [];
        for (const row of (data as any[] | null) ?? []) {
          const lead = row?.leads as Lead | undefined;
          if (lead && !seen.has(lead.id)) {
            seen.add(lead.id);
            out.push(lead);
          }
        }
        return out;
      }

      let query = supabase
        .from('leads')
        .select(LEAD_COLUMNS)
        .order('updated_at', { ascending: false })
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      // For agents, add explicit filter to help PostgreSQL use indexes and short-circuit RLS
      if (isAgentRole && user?.id) {
        query = query.or(`assigned_to.eq.${user.id},created_by.eq.${user.id}`);
      }

      query = applyFilters(query, filters, effectiveTenantId);

      const { data, error } = await query;
      if (error) throw error;
      return (data as unknown) as Lead[];
    },
  });

  // Track pending updates for debouncing and mutation tracking
  const pendingUpdatesRef = useRef<Map<string, Partial<Lead>>>(new Map());
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const recentMutationIdsRef = useRef<Set<string>>(new Set());
  const bulkOperationInProgressRef = useRef(false);

  // Apply pending updates in batch
  const applyPendingUpdates = useCallback(() => {
    // Skip if bulk operation in progress
    if (bulkOperationInProgressRef.current) return;
    
    const updates = pendingUpdatesRef.current;
    if (updates.size === 0) return;

    // If too many pending updates, just invalidate
    if (updates.size > MAX_PENDING_UPDATES) {
      pendingUpdatesRef.current = new Map();
      queryClient.invalidateQueries({ queryKey: ['leads-paginated'] });
      return;
    }

    queryClient.setQueriesData(
      { queryKey: ['leads-paginated'] },
      (oldData: Lead[] | undefined) => {
        if (!oldData) return oldData;
        return oldData.map(lead => {
          const update = updates.get(lead.id);
          return update ? { ...lead, ...update } : lead;
        });
      }
    );

    pendingUpdatesRef.current = new Map();
  }, [queryClient]);

  // Debounced realtime updates - batches multiple updates together
  useEffect(() => {
    // Skip realtime if tenant not ready or bulk operation in progress
    if (!isTenantReady) return;
    
    const hasTenantFilter = isValidUUID(effectiveTenantId);
    const channelName = hasTenantFilter 
      ? `leads-realtime-${effectiveTenantId}` 
      : 'leads-realtime-all';
    
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'leads',
          ...(hasTenantFilter && { filter: `admin_id=eq.${effectiveTenantId}` }),
        },
        (payload) => {
          // Skip all realtime processing during bulk operations
          if (bulkOperationInProgressRef.current) return;
          
          // For updates, collect and debounce
          if (payload.eventType === 'UPDATE' && payload.new) {
            const leadId = payload.new.id as string;
            
            // Skip if this was from our own recent mutation (already applied optimistically)
            if (recentMutationIdsRef.current.has(leadId)) {
              return;
            }
            
            // Add to pending updates
            pendingUpdatesRef.current.set(leadId, payload.new as Partial<Lead>);
            
            // Debounce the batch apply
            if (debounceTimerRef.current) {
              clearTimeout(debounceTimerRef.current);
            }
            debounceTimerRef.current = setTimeout(applyPendingUpdates, REALTIME_DEBOUNCE_MS);
          } else {
            // For inserts/deletes, invalidate after debounce
            if (debounceTimerRef.current) {
              clearTimeout(debounceTimerRef.current);
            }
            debounceTimerRef.current = setTimeout(() => {
              if (!bulkOperationInProgressRef.current) {
                queryClient.invalidateQueries({ queryKey: ['leads-paginated'] });
                queryClient.invalidateQueries({ queryKey: ['leads-count'] });
              }
            }, REALTIME_DEBOUNCE_MS);
          }
        }
      )
      .subscribe();

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      supabase.removeChannel(channel);
    };
  }, [queryClient, effectiveTenantId, applyPendingUpdates, isTenantReady]);

  // Helper to track mutations (prevents processing our own realtime updates)
  // Extended timeout (30s) to handle delayed realtime events during bulk operations
  const trackMutatedIds = useCallback((ids: string[]) => {
    ids.forEach(id => recentMutationIdsRef.current.add(id));
    setTimeout(() => {
      ids.forEach(id => recentMutationIdsRef.current.delete(id));
    }, 30000);
  }, []);

  const paginationMeta = calculatePagination(totalCount, pagination.page, pagination.pageSize);

  // Create lead mutation
  const createLead = useMutation({
    mutationFn: async (leadData: Omit<Lead, 'id' | 'created_at' | 'updated_at' | 'created_by'> & Partial<Pick<Lead, 'assigned_to' | 'last_contacted_at'>>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from('leads')
        .insert([{ 
          ...leadData, 
          created_by: user.id,
          admin_id: effectiveTenantId || null 
        }])
        .select(LEAD_COLUMNS)
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['leads-count'] });
      toast({
        title: "Lead created",
        description: "The lead has been successfully created.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update lead with optimistic updates
  const updateLead = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string } & Partial<Omit<Lead, 'id' | 'created_at' | 'updated_at'>>) => {
      const { data, error } = await supabase
        .from('leads')
        .update(updates)
        .eq('id', id)
        .select(LEAD_COLUMNS)
        .single();

      if (error) throw error;

      // Non-blocking audit log
      logAction({
        actionType: updates.status ? 'lead_status_changed' : updates.assigned_to !== undefined ? 'lead_assigned' : 'lead_updated',
        entityType: 'lead',
        entityId: id,
        details: { updates },
      });

      return data;
    },
    onMutate: async ({ id, ...updates }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['leads-paginated'] });

      // Snapshot previous value
      const previousLeads = queryClient.getQueriesData({ queryKey: ['leads-paginated'] });

      // Optimistically update all matching queries
      queryClient.setQueriesData(
        { queryKey: ['leads-paginated'] },
        (old: Lead[] | undefined) => {
          if (!old) return old;
          return old.map(lead => 
            lead.id === id ? { ...lead, ...updates } : lead
          );
        }
      );

      return { previousLeads };
    },
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousLeads) {
        context.previousLeads.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to update lead",
        description: err.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      // Mark as stale but don't refetch — keeps current positions stable
      // Fresh order loads on next navigation or manual refresh
      queryClient.invalidateQueries({ queryKey: ['leads-paginated'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['leads-count'], refetchType: 'none' });
    },
  });

  // Delete lead mutation
  const deleteLead = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('leads')
        .delete()
        .eq('id', id);

      if (error) throw error;

      logAction({
        actionType: 'lead_deleted',
        entityType: 'lead',
        entityId: id,
      });
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['leads-paginated'] });
      
      const previousLeads = queryClient.getQueriesData({ queryKey: ['leads-paginated'] });
      
      queryClient.setQueriesData(
        { queryKey: ['leads-paginated'] },
        (old: Lead[] | undefined) => old?.filter(lead => lead.id !== id)
      );

      return { previousLeads };
    },
    onError: (err, id, context) => {
      if (context?.previousLeads) {
        context.previousLeads.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to delete lead",
        description: err.message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads-count'] });
      toast({
        title: "Lead deleted",
        description: "The lead has been successfully deleted.",
      });
    },
  });

  // Async bulk assign with Edge Function background processing
  const bulkAssignLeads = useMutation({
    mutationFn: async ({ leadIds, assignedTo }: { leadIds: string[]; assignedTo: string }) => {
      if (!user) throw new Error("Not authenticated");
      if (bulkOperationInProgressRef.current) throw new Error("Another bulk operation is in progress");
      
      bulkOperationInProgressRef.current = true;
      
      try {
        // Use Edge Function for background processing
        const { data, error } = await supabase.functions.invoke('bulk-assign-leads', {
          body: {
            leadIds,
            agentId: assignedTo,
            tenantId: effectiveTenantId,
          },
        });

        if (error) throw error;
        return data;
      } finally {
        bulkOperationInProgressRef.current = false;
      }
    },
    onMutate: async ({ leadIds, assignedTo }) => {
      await queryClient.cancelQueries({ queryKey: ['leads-paginated'] });
      
      const previousLeads = queryClient.getQueriesData({ queryKey: ['leads-paginated'] });
      
      // Track these IDs to skip realtime updates
      trackMutatedIds(leadIds);
      
      // Optimistically update all leads immediately
      queryClient.setQueriesData(
        { queryKey: ['leads-paginated'] },
        (old: Lead[] | undefined) => {
          if (!old) return old;
          return old.map(lead => 
            leadIds.includes(lead.id) 
              ? { ...lead, assigned_to: assignedTo, is_transferred: !!lead.assigned_to }
              : lead
          );
        }
      );

      return { previousLeads };
    },
    onError: (err, variables, context) => {
      if (context?.previousLeads) {
        context.previousLeads.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to assign leads",
        description: err.message,
        variant: "destructive",
      });
    },
    onSuccess: (_, { leadIds }) => {
      toast({
        title: "Processing in background",
        description: `${leadIds.length} leads are being assigned. This may take a moment.`,
      });
    },
  });

  // Bulk delete with Edge Function background processing
  const bulkDeleteLeads = useMutation({
    mutationFn: async (leadIds: string[]) => {
      if (!user) throw new Error("Not authenticated");
      if (bulkOperationInProgressRef.current) throw new Error("Another bulk operation is in progress");
      
      bulkOperationInProgressRef.current = true;
      
      try {
        const { data, error } = await supabase.functions.invoke('bulk-delete-leads', {
          body: { leadIds },
        });

        if (error) throw error;
        return data;
      } finally {
        bulkOperationInProgressRef.current = false;
      }
    },
    onMutate: async (leadIds) => {
      await queryClient.cancelQueries({ queryKey: ['leads-paginated'] });
      
      const previousLeads = queryClient.getQueriesData({ queryKey: ['leads-paginated'] });
      
      // Track these IDs to skip realtime updates
      trackMutatedIds(leadIds);
      
      queryClient.setQueriesData(
        { queryKey: ['leads-paginated'] },
        (old: Lead[] | undefined) => old?.filter(lead => !leadIds.includes(lead.id))
      );

      return { previousLeads };
    },
    onError: (err, leadIds, context) => {
      if (context?.previousLeads) {
        context.previousLeads.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to delete leads",
        description: err.message,
        variant: "destructive",
      });
    },
    onSuccess: (_, leadIds) => {
      // Delay count invalidation to let background processing complete
      // Optimistic update already removed items from UI
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['leads-count'] });
      }, 3000);
      toast({
        title: "Processing in background",
        description: `${leadIds.length} leads are being deleted.`,
      });
    },
  });

  // Bulk update status with Edge Function
  const bulkUpdateLeadStatus = useMutation({
    mutationFn: async ({ leadIds, status }: { leadIds: string[]; status: string }) => {
      if (!user) throw new Error("Not authenticated");
      if (bulkOperationInProgressRef.current) throw new Error("Another bulk operation is in progress");
      
      bulkOperationInProgressRef.current = true;
      
      try {
        const { data, error } = await supabase.functions.invoke('bulk-update-lead-status', {
          body: { leadIds, status },
        });

        if (error) throw error;
        return data;
      } finally {
        bulkOperationInProgressRef.current = false;
      }
    },
    onMutate: async ({ leadIds, status }) => {
      await queryClient.cancelQueries({ queryKey: ['leads-paginated'] });
      
      const previousLeads = queryClient.getQueriesData({ queryKey: ['leads-paginated'] });
      
      // Track to skip realtime updates
      trackMutatedIds(leadIds);
      
      // Optimistic update
      queryClient.setQueriesData(
        { queryKey: ['leads-paginated'] },
        (old: Lead[] | undefined) => {
          if (!old) return old;
          return old.map(lead => 
            leadIds.includes(lead.id) ? { ...lead, status: status as LeadStatus } : lead
          );
        }
      );

      return { previousLeads };
    },
    onError: (err, variables, context) => {
      if (context?.previousLeads) {
        context.previousLeads.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to update lead status",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    },
    onSuccess: (_, { leadIds, status }) => {
      toast({
        title: "Processing in background",
        description: `${leadIds.length} leads updated to ${status.replace(/_/g, ' ')}.`,
      });
    },
  });

  return {
    leads,
    totalCount,
    isLoading,
    error,
    createLead,
    updateLead,
    deleteLead,
    bulkAssignLeads,
    bulkDeleteLeads,
    bulkUpdateLeadStatus,
    pagination: paginationMeta,
  };
};

// Helper function to apply filters
function applyFilters(
  query: any,
  filters: LeadFilters | undefined,
  effectiveTenantId: string | null,
  relationPrefix?: string
) {
  const col = (name: string) => (relationPrefix ? `${relationPrefix}.${name}` : name);

  const applyOr = (filter: string) => {
    return relationPrefix
      ? query.or(filter, { foreignTable: relationPrefix })
      : query.or(filter);
  };

  if (effectiveTenantId) {
    // IMPORTANT: PostgREST OR filters for embedded resources must be applied using foreignTable,
    // not by prefixing columns inside the logic tree.
    query = applyOr(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
  }

  if (filters?.status) {
    query = query.eq(col('status'), filters.status);
  }

  if (filters?.statuses && filters.statuses.length > 0) {
    query = query.in(col('status'), filters.statuses);
  }

  if (filters?.sources && filters.sources.length > 0) {
    const typedSources = filters.sources as Database['public']['Enums']['lead_source'][];
    query = query.in(col('source'), typedSources);
  }

  if (filters?.assignedTo) {
    query = query.eq(col('assigned_to'), filters.assignedTo);
  }

  if (filters?.assignedToList && filters.assignedToList.length > 0) {
    const hasUnassigned = filters.assignedToList.includes('unassigned');
    const userIds = filters.assignedToList.filter((id) => id !== 'unassigned');

    if (hasUnassigned && userIds.length > 0) {
      query = applyOr(`assigned_to.is.null,assigned_to.in.(${userIds.join(',')})`);
    } else if (hasUnassigned) {
      query = query.is(col('assigned_to'), null);
    } else {
      query = query.in(col('assigned_to'), userIds);
    }
  }

  if (
    filters?.unassigned &&
    (!filters.assignedToList || filters.assignedToList.length === 0) &&
    (!filters.teamMemberIds || filters.teamMemberIds.length === 0)
  ) {
    query = query.is(col('assigned_to'), null);
  }

  if (filters?.teamMemberIds && filters.teamMemberIds.length > 0) {
    query = applyOr(`assigned_to.in.(${filters.teamMemberIds.join(',')}),assigned_to.is.null`);
  }

  if (filters?.dateFrom) {
    query = query.gte(col('created_at'), filters.dateFrom.toISOString());
  }
  if (filters?.dateTo) {
    query = query.lte(col('created_at'), filters.dateTo.toISOString());
  }

  if (filters?.countries && filters.countries.length > 0) {
    // Country filter is driven by the phone prefix (source of truth).
    // Build an OR of phone LIKE 'prefix%' for every prefix that maps to the selected countries.
    const prefixes = Array.from(
      new Set(filters.countries.flatMap((c) => getAllPhonePrefixesForCountry(c)))
    );
    if (prefixes.length > 0) {
      const orExpr = prefixes.map((p) => `${col('phone')}.like.${p}%`).join(',');
      query = applyOr(orExpr);
    } else {
      // Selected country has no known prefix — return zero rows rather than ignore the filter
      query = query.eq(col('id'), '00000000-0000-0000-0000-000000000000');
    }
  }

  if (filters?.search) {
    const s = filters.search;
    query = applyOr(
      `name.ilike.%${s}%,email.ilike.%${s}%,phone.ilike.%${s}%,country.ilike.%${s}%`
    );
  }

  return query;
}
