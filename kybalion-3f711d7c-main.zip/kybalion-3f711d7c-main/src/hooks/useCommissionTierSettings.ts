import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { toast } from "sonner";

export interface TierLevel {
  minDeposit: number;
  minTransfers?: number;
  commissionPercent: number;
  baseSalary: number;
}

export interface AgentTierLevel {
  minConversions: number;
  commissionPercent?: number; // kept optional for backward compat parsing
  baseSalary: number;
  singleTransferValue: number;
}

export interface AgentCommissionTierLevel {
  minDeposit: number;
  minTransfers?: number;
  commissionPercent: number;
}

export type AgentCommissionTierBasis = "deposit" | "transfers";
export type ManagerTierBasis = "deposit" | "transfers";

export interface CommissionTierSettings {
  id: string;
  month: string;
  admin_id: string | null;
  agent_tiers: AgentTierLevel[];
  agent_commission_tiers: AgentCommissionTierLevel[];
  agent_commission_tier_basis: AgentCommissionTierBasis;
  agent_base_salary: number;
  agent_base_salary_tiers: AgentTierLevel[];
  // Closer Agent — independent salary configuration for agents flagged as closers.
  closer_agent_tiers: AgentTierLevel[];
  closer_agent_commission_tiers: AgentCommissionTierLevel[];
  closer_agent_commission_tier_basis: AgentCommissionTierBasis;
  closer_agent_base_salary: number;
  closer_agent_base_salary_tiers: AgentTierLevel[];
  super_agent_tiers: TierLevel[];
  super_agent_base_salary: number;
  super_agent_base_salary_tiers: TierLevel[];
  manager_tiers: TierLevel[];
  manager_base_salary: number;
  manager_base_salary_tiers: TierLevel[];
}

export interface ManagerCommissionSettings {
  id: string;
  manager_id: string;
  manager_name: string;
  admin_id: string | null;
  commission_percentage: number;
  base_salary: number;
  base_salary_tiers: TierLevel[];
  tier_basis: ManagerTierBasis;
}

// Default tier structures
const DEFAULT_AGENT_TIERS: AgentTierLevel[] = [
  { minConversions: 0, baseSalary: 800, singleTransferValue: 0 },
  { minConversions: 5, baseSalary: 900, singleTransferValue: 0 },
  { minConversions: 10, baseSalary: 1000, singleTransferValue: 0 },
  { minConversions: 20, baseSalary: 1200, singleTransferValue: 0 },
];

const DEFAULT_AGENT_COMMISSION_TIERS: AgentCommissionTierLevel[] = [
  { minDeposit: 0, commissionPercent: 5 },
  { minDeposit: 10000, commissionPercent: 6 },
  { minDeposit: 25000, commissionPercent: 7 },
  { minDeposit: 50000, commissionPercent: 8 },
];

const DEFAULT_SUPER_AGENT_TIERS: TierLevel[] = [
  { minDeposit: 0, commissionPercent: 8, baseSalary: 1000 },
  { minDeposit: 20000, commissionPercent: 9, baseSalary: 1200 },
  { minDeposit: 50000, commissionPercent: 10, baseSalary: 1500 },
  { minDeposit: 100000, commissionPercent: 12, baseSalary: 2000 },
];

const DEFAULT_MANAGER_TIERS: TierLevel[] = [
  { minDeposit: 0, commissionPercent: 3, baseSalary: 1500 },
  { minDeposit: 50000, commissionPercent: 4, baseSalary: 2000 },
  { minDeposit: 100000, commissionPercent: 5, baseSalary: 2500 },
];

function parseTiers(data: unknown): TierLevel[] {
  if (!data) return [];
  if (Array.isArray(data)) {
    return data.map((tier: Record<string, unknown>) => ({
      minDeposit: Number(tier.minDeposit ?? tier.min_deposit ?? 0),
      minTransfers: tier.minTransfers != null || tier.min_transfers != null
        ? Number(tier.minTransfers ?? tier.min_transfers ?? 0)
        : undefined,
      commissionPercent: Number(tier.commissionPercent ?? tier.commission_percent ?? 0),
      baseSalary: Number(tier.baseSalary ?? tier.base_salary ?? 0),
    }));
  }
  return [];
}

function parseAgentTiers(data: unknown): AgentTierLevel[] {
  if (!data) return [];
  if (Array.isArray(data)) {
    return data.map((tier: Record<string, unknown>) => ({
      minConversions: Number(tier.minConversions ?? tier.min_conversions ?? tier.minDeposit ?? 0),
      commissionPercent: tier.commissionPercent != null || tier.commission_percent != null
        ? Number(tier.commissionPercent ?? tier.commission_percent ?? 0)
        : undefined,
      baseSalary: Number(tier.baseSalary ?? tier.base_salary ?? 0),
      singleTransferValue: Number(tier.singleTransferValue ?? tier.single_transfer_value ?? 0),
    }));
  }
  return [];
}

function parseAgentCommissionTiers(data: unknown): AgentCommissionTierLevel[] {
  if (!data) return [];
  if (Array.isArray(data)) {
    return data.map((tier: Record<string, unknown>) => ({
      minDeposit: Number(tier.minDeposit ?? tier.min_deposit ?? 0),
      minTransfers: tier.minTransfers != null || tier.min_transfers != null
        ? Number(tier.minTransfers ?? tier.min_transfers ?? 0)
        : undefined,
      commissionPercent: Number(tier.commissionPercent ?? tier.commission_percent ?? 0),
    }));
  }
  return [];
}

/**
 * Backward compat: extract commission tiers from old agent_tiers that had commissionPercent baked in.
 * Uses minConversions as a rough proxy for minDeposit (set to 0 for simplicity).
 */
function extractCommissionFromLegacyAgentTiers(agentTiers: AgentTierLevel[]): AgentCommissionTierLevel[] {
  const legacy = agentTiers.filter(t => t.commissionPercent != null && t.commissionPercent! > 0);
  if (legacy.length === 0) return [];
  return legacy.map(t => ({
    minDeposit: 0,
    commissionPercent: t.commissionPercent!,
  }));
}

export function useCommissionTierSettings(month?: string) {
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();
  const effectiveMonth = month || new Date().toISOString().slice(0, 7);

  // Fetch tier settings for the selected month, falling back to most-recent prior row
  const { data: tierSettings, isLoading: isLoadingTiers } = useQuery({
    queryKey: ["commission-tier-settings", effectiveTenantId, effectiveMonth],
    enabled: !!effectiveTenantId,
    queryFn: async () => {
      // Try exact-month match first (frozen historical record)
      const { data: exact, error: exactErr } = await supabase
        .from("commission_tier_settings")
        .select("*")
        .eq("admin_id", effectiveTenantId)
        .eq("month", effectiveMonth)
        .maybeSingle();
      if (exactErr) throw exactErr;

      let data = exact;
      if (!data) {
        // Fallback: most-recent row whose month <= selectedMonth
        const { data: prior, error: priorErr } = await supabase
          .from("commission_tier_settings")
          .select("*")
          .eq("admin_id", effectiveTenantId)
          .lte("month", effectiveMonth)
          .order("month", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (priorErr) throw priorErr;
        data = prior;
      }

      if (!data) {
        return {
          id: "",
          month: effectiveMonth,
          admin_id: effectiveTenantId,
          agent_tiers: DEFAULT_AGENT_TIERS,
          agent_commission_tiers: DEFAULT_AGENT_COMMISSION_TIERS,
          agent_commission_tier_basis: "deposit",
          agent_base_salary: 800,
          agent_base_salary_tiers: DEFAULT_AGENT_TIERS,
          closer_agent_tiers: DEFAULT_AGENT_TIERS,
          closer_agent_commission_tiers: DEFAULT_AGENT_COMMISSION_TIERS,
          closer_agent_commission_tier_basis: "deposit",
          closer_agent_base_salary: 800,
          closer_agent_base_salary_tiers: DEFAULT_AGENT_TIERS,
          super_agent_tiers: DEFAULT_SUPER_AGENT_TIERS,
          super_agent_base_salary: 1000,
          super_agent_base_salary_tiers: DEFAULT_SUPER_AGENT_TIERS,
          manager_tiers: DEFAULT_MANAGER_TIERS,
          manager_base_salary: 1500,
          manager_base_salary_tiers: DEFAULT_MANAGER_TIERS,
        } as CommissionTierSettings;
      }

      const parsedAgentTiers = parseAgentTiers(data.agent_tiers);
      const parsedAgentCommissionTiers = parseAgentCommissionTiers(
        (data as Record<string, unknown>).agent_commission_tiers
      );

      let agentCommissionTiers = parsedAgentCommissionTiers.length > 0
        ? parsedAgentCommissionTiers
        : extractCommissionFromLegacyAgentTiers(parsedAgentTiers);
      if (agentCommissionTiers.length === 0) {
        agentCommissionTiers = DEFAULT_AGENT_COMMISSION_TIERS;
      }

      const rawBasis = (data as Record<string, unknown>).agent_commission_tier_basis;
      const agentCommissionTierBasis: AgentCommissionTierBasis =
        rawBasis === "transfers" ? "transfers" : "deposit";

      // Closer Agent parsing — independent salary configuration.
      const raw = data as Record<string, unknown>;
      const parsedCloserTiers = parseAgentTiers(raw.closer_agent_tiers);
      const parsedCloserBaseTiers = parseAgentTiers(raw.closer_agent_base_salary_tiers);
      const parsedCloserCommissionTiers = parseAgentCommissionTiers(raw.closer_agent_commission_tiers);
      const rawCloserBasis = raw.closer_agent_commission_tier_basis;
      const closerCommissionTierBasis: AgentCommissionTierBasis =
        rawCloserBasis === "transfers" ? "transfers" : "deposit";

      return {
        ...data,
        agent_tiers: parsedAgentTiers.length > 0 ? parsedAgentTiers : DEFAULT_AGENT_TIERS,
        agent_commission_tiers: agentCommissionTiers,
        agent_commission_tier_basis: agentCommissionTierBasis,
        agent_base_salary_tiers: parseAgentTiers(data.agent_base_salary_tiers).length > 0 ? parseAgentTiers(data.agent_base_salary_tiers) : DEFAULT_AGENT_TIERS,
        closer_agent_tiers: parsedCloserTiers.length > 0 ? parsedCloserTiers : DEFAULT_AGENT_TIERS,
        closer_agent_base_salary: Number(raw.closer_agent_base_salary ?? 800),
        closer_agent_base_salary_tiers: parsedCloserBaseTiers.length > 0 ? parsedCloserBaseTiers : DEFAULT_AGENT_TIERS,
        closer_agent_commission_tiers: parsedCloserCommissionTiers.length > 0 ? parsedCloserCommissionTiers : DEFAULT_AGENT_COMMISSION_TIERS,
        closer_agent_commission_tier_basis: closerCommissionTierBasis,
        super_agent_tiers: parseTiers(data.super_agent_tiers).length > 0 ? parseTiers(data.super_agent_tiers) : DEFAULT_SUPER_AGENT_TIERS,
        super_agent_base_salary_tiers: parseTiers(data.super_agent_base_salary_tiers).length > 0 ? parseTiers(data.super_agent_base_salary_tiers) : DEFAULT_SUPER_AGENT_TIERS,
        manager_tiers: parseTiers(data.manager_tiers).length > 0 ? parseTiers(data.manager_tiers) : DEFAULT_MANAGER_TIERS,
        manager_base_salary_tiers: parseTiers(data.manager_base_salary_tiers).length > 0 ? parseTiers(data.manager_base_salary_tiers) : DEFAULT_MANAGER_TIERS,
      } as unknown as CommissionTierSettings;
    },
  });

  // Fetch manager-specific settings for the selected month (with fallback to most-recent prior)
  const { data: managerSettings, isLoading: isLoadingManagers } = useQuery({
    queryKey: ["manager-commission-settings", effectiveTenantId, effectiveMonth],
    enabled: !!effectiveTenantId,
    queryFn: async () => {
      const { data: managers, error: managersError } = await supabase
        .from("profiles")
        .select("id, full_name, username")
        .eq("admin_id", effectiveTenantId);

      if (managersError) throw managersError;

      const managerIds = managers?.map((m) => m.id) || [];
      const { data: roles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("user_id", managerIds)
        .in("role", ["MANAGER", "TEAM_LEADER"]);

      if (rolesError) throw rolesError;

      const managerUserIds = roles?.map((r) => r.user_id) || [];
      const filteredManagers = managers?.filter((m) => managerUserIds.includes(m.id)) || [];

      // Pull all settings for this tenant whose month <= selectedMonth, then keep latest per manager
      const { data: settings, error: settingsError } = await supabase
        .from("manager_commission_settings")
        .select("*")
        .eq("admin_id", effectiveTenantId)
        .lte("month", effectiveMonth)
        .order("month", { ascending: false });

      if (settingsError) throw settingsError;

      const settingsMap = new Map<string, typeof settings[number]>();
      for (const s of settings || []) {
        if (!settingsMap.has(s.manager_id)) settingsMap.set(s.manager_id, s);
      }

      return filteredManagers.map((manager) => {
        const existing = settingsMap.get(manager.id);
        // If the existing row is from a prior month, treat as "no row for this month yet"
        // so saves create a new month-scoped row instead of overwriting history.
        const isExactMonth = existing?.month === effectiveMonth;
        const rawBasis = (existing as { tier_basis?: string } | undefined)?.tier_basis;
        return {
          id: isExactMonth ? existing!.id : "",
          manager_id: manager.id,
          manager_name: manager.full_name || manager.username || "Unknown",
          admin_id: effectiveTenantId,
          commission_percentage: existing?.commission_percentage ?? 3,
          base_salary: existing?.base_salary ?? 1500,
          base_salary_tiers: existing?.base_salary_tiers
            ? parseTiers(existing.base_salary_tiers)
            : DEFAULT_MANAGER_TIERS,
          tier_basis: rawBasis === "transfers" ? "transfers" : "deposit",
        } as ManagerCommissionSettings;
      });
    },
  });

  // Save tier settings mutation (month-scoped: upsert per (admin_id, month))
  const saveTierSettings = useMutation({
    mutationFn: async (settings: Partial<CommissionTierSettings>) => {
      const targetMonth = settings.month || effectiveMonth;
      const payload = {
        month: targetMonth,
        admin_id: effectiveTenantId,
        agent_tiers: JSON.parse(JSON.stringify(settings.agent_tiers)),
        agent_base_salary: settings.agent_base_salary,
        agent_base_salary_tiers: JSON.parse(JSON.stringify(settings.agent_base_salary_tiers)),
        agent_commission_tiers: JSON.parse(JSON.stringify(settings.agent_commission_tiers || [])),
        agent_commission_tier_basis: settings.agent_commission_tier_basis ?? "deposit",
        closer_agent_tiers: JSON.parse(JSON.stringify(settings.closer_agent_tiers ?? [])),
        closer_agent_base_salary: settings.closer_agent_base_salary ?? 800,
        closer_agent_base_salary_tiers: JSON.parse(JSON.stringify(settings.closer_agent_base_salary_tiers ?? [])),
        closer_agent_commission_tiers: JSON.parse(JSON.stringify(settings.closer_agent_commission_tiers ?? [])),
        closer_agent_commission_tier_basis: settings.closer_agent_commission_tier_basis ?? "deposit",
        super_agent_tiers: JSON.parse(JSON.stringify(settings.super_agent_tiers)),
        super_agent_base_salary: settings.super_agent_base_salary,
        super_agent_base_salary_tiers: JSON.parse(JSON.stringify(settings.super_agent_base_salary_tiers)),
        manager_tiers: JSON.parse(JSON.stringify(settings.manager_tiers)),
        manager_base_salary: settings.manager_base_salary,
        manager_base_salary_tiers: JSON.parse(JSON.stringify(settings.manager_base_salary_tiers)),
      };

      // Upsert by (admin_id, month) so editing the rules for May doesn't change April's row.
      const { error } = await supabase
        .from("commission_tier_settings")
        .upsert(payload, { onConflict: "admin_id,month" });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["commission-tier-settings"] });
      queryClient.invalidateQueries({ queryKey: ["salary-data"] });
      toast.success("Tier settings saved successfully");
    },
    onError: (error) => {
      toast.error("Failed to save tier settings: " + error.message);
    },
  });

  // Save manager settings mutation (month-scoped)
  const saveManagerSettings = useMutation({
    mutationFn: async (settings: ManagerCommissionSettings) => {
      const payload = {
        manager_id: settings.manager_id,
        admin_id: effectiveTenantId!,
        month: effectiveMonth,
        commission_percentage: settings.commission_percentage,
        base_salary: settings.base_salary,
        base_salary_tiers: JSON.parse(JSON.stringify(settings.base_salary_tiers)),
        tier_basis: settings.tier_basis ?? "deposit",
      };

      const { error } = await supabase
        .from("manager_commission_settings")
        .upsert(payload, { onConflict: "admin_id,manager_id,month" });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["manager-commission-settings"] });
      queryClient.invalidateQueries({ queryKey: ["salary-data"] });
      toast.success("Manager settings saved successfully");
    },
    onError: (error) => {
      toast.error("Failed to save manager settings: " + error.message);
    },
  });

  return {
    tierSettings,
    managerSettings,
    isLoading: isLoadingTiers || isLoadingManagers,
    saveTierSettings,
    saveManagerSettings,
    DEFAULT_AGENT_TIERS,
    DEFAULT_AGENT_COMMISSION_TIERS,
    DEFAULT_SUPER_AGENT_TIERS,
    DEFAULT_MANAGER_TIERS,
  };
}
