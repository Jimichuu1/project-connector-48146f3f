import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useUserRole } from "@/hooks/useUserRole";
import { useAuth } from "@/contexts/AuthContext";
import { isValidUUID } from "@/lib/uuidUtils";

interface LeadsStats {
  totalLeads: number;
  groupCounts: Record<string, number>;
  pendingConversions: number;
}

/**
 * Centralized hook for all lead count queries.
 * Prevents duplicate COUNT queries across components.
 * Uses long stale time to reduce database load.
 */
export const useLeadsStats = () => {
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  const { isAgent, isSuperAgent } = useUserRole();
  const { user } = useAuth();

  // Agents and Super Agents should only see leads assigned to them
  const shouldFilterByAssignment = isAgent || isSuperAgent;
  
  // Only enable when we have valid context
  const isTenantReady = effectiveTenantId === null || isValidUUID(effectiveTenantId);
  const isEnabled = !!user && isTenantReady;

  // Single unified stats query - fetches all counts in one go
  const { data: stats, isLoading, error } = useQuery<LeadsStats>({
    queryKey: ['leads-stats', effectiveTenantId, user?.id, shouldFilterByAssignment],
    staleTime: 5 * 60 * 1000, // 5 minutes - very long stale time
    gcTime: 10 * 60 * 1000, // 10 minutes cache
    refetchOnWindowFocus: false, // Don't refetch on focus
    refetchOnMount: false, // Don't refetch on every mount
    enabled: isEnabled,
    queryFn: async () => {
      // Get total leads count
      let totalQuery = supabase
        .from('leads')
        .select('*', { count: 'exact', head: true });
      
      // Apply tenant filter
      if (!isSuperAdmin && effectiveTenantId) {
        totalQuery = totalQuery.eq('admin_id', effectiveTenantId);
      } else if (isSuperAdmin && effectiveTenantId) {
        totalQuery = totalQuery.eq('admin_id', effectiveTenantId);
      }

      // Agents and Super Agents only see their assigned leads
      if (shouldFilterByAssignment && user?.id) {
        totalQuery = totalQuery.eq('assigned_to', user.id);
      }
      
      const { count: totalLeads } = await totalQuery;

      // Get pending conversions count
      let pendingQuery = supabase
        .from('leads')
        .select('*', { count: 'exact', head: true })
        .eq('pending_conversion', true);

      if (effectiveTenantId) {
        pendingQuery = pendingQuery.eq('admin_id', effectiveTenantId);
      }

      const { count: pendingConversions } = await pendingQuery;

      // Get group counts - only if there are groups
      let groupsQuery = supabase
        .from('lead_groups')
        .select('id');
      
      // Only filter by admin_id if we have one (for non-super-admin users)
      if (effectiveTenantId) {
        groupsQuery = groupsQuery.eq('admin_id', effectiveTenantId);
      }
      
      const { data: groups } = await groupsQuery;
      let groupCounts: Record<string, number> = {};
      
      if (groups && groups.length > 0) {
        const groupIds = groups.map(g => g.id);
        
        if (shouldFilterByAssignment && user?.id) {
          // For agents, count only their assigned leads per group using proper COUNT
          const groupCountPromises = groupIds.map(async (groupId) => {
            const { count } = await supabase
              .from('lead_group_members')
              .select('*, leads!inner(id)', { count: 'exact', head: true })
              .eq('group_id', groupId)
              .eq('leads.assigned_to', user.id);
            
            return { groupId, count: count || 0 };
          });

          const groupCountResults = await Promise.all(groupCountPromises);
          groupCountResults.forEach(({ groupId, count }) => {
            groupCounts[groupId] = count;
          });
        } else {
          // For managers/admins, count all leads in groups using proper COUNT
          const groupCountPromises = groupIds.map(async (groupId) => {
            const { count } = await supabase
              .from('lead_group_members')
              .select('*', { count: 'exact', head: true })
              .eq('group_id', groupId);
            
            return { groupId, count: count || 0 };
          });

          const groupCountResults = await Promise.all(groupCountPromises);
          groupCountResults.forEach(({ groupId, count }) => {
            groupCounts[groupId] = count;
          });
        }
      }

      return {
        totalLeads: totalLeads || 0,
        groupCounts,
        pendingConversions: pendingConversions || 0,
      };
    },
  });

  return {
    totalLeads: stats?.totalLeads || 0,
    groupCounts: stats?.groupCounts || {},
    pendingConversions: stats?.pendingConversions || 0,
    isLoading,
    error,
  };
};
