import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Client, PipelineStatus } from "@/types/clients";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useRef, useCallback } from "react";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useTenant } from "@/contexts/TenantContext";
import { isValidUUID } from "@/lib/uuidUtils";

// Debounce delay for batching realtime updates
const REALTIME_DEBOUNCE_MS = 1000;
// Maximum pending updates before forcing full invalidation
const MAX_PENDING_UPDATES = 100;

export const useClients = (filters?: {
  assignedTo?: string;
  search?: string;
  teamMemberIds?: string[];
  enabled?: boolean;
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();
  const { effectiveTenantId } = useTenant();

  // Track pending updates for debouncing
  const pendingUpdatesRef = useRef<Map<string, Partial<Client>>>(new Map());
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const recentMutationIdsRef = useRef<Set<string>>(new Set());

  // Only run queries when we have a valid tenant context
  const isTenantReady = effectiveTenantId === null || isValidUUID(effectiveTenantId);

  // Apply pending updates in batch
  const applyPendingUpdates = useCallback(() => {
    const updates = pendingUpdatesRef.current;
    if (updates.size === 0) return;

    // If too many pending updates, just invalidate
    if (updates.size > MAX_PENDING_UPDATES) {
      pendingUpdatesRef.current = new Map();
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      return;
    }

    queryClient.setQueriesData(
      { queryKey: ['clients'] },
      (oldData: Client[] | undefined) => {
        if (!oldData) return oldData;
        return oldData.map(client => {
          const update = updates.get(client.id);
          return update ? { ...client, ...update } : client;
        });
      }
    );

    pendingUpdatesRef.current = new Map();
  }, [queryClient]);

  // Helper to track mutations - extended timeout for bulk operations
  const trackMutatedIds = useCallback((ids: string[]) => {
    ids.forEach(id => recentMutationIdsRef.current.add(id));
    // Extended timeout to handle delayed realtime events during bulk operations
    setTimeout(() => {
      ids.forEach(id => recentMutationIdsRef.current.delete(id));
    }, 30000);
  }, []);

  const { data: clients, isLoading, error } = useQuery({
    queryKey: ['clients', filters, effectiveTenantId],
    staleTime: 30000,
    enabled: filters?.enabled !== false && isTenantReady,
    queryFn: async () => {
      let query = supabase
        .from('clients_secure' as any)
        .select('*')
        .order('updated_at', { ascending: false });

      if (isValidUUID(effectiveTenantId)) {
        query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
      }

      if (filters?.assignedTo) {
        query = query.eq('assigned_to', filters.assignedTo);
      }

      if (filters?.teamMemberIds && filters.teamMemberIds.length > 0) {
        query = query.or(`assigned_to.in.(${filters.teamMemberIds.join(',')}),assigned_to.is.null`);
      }

      if (filters?.search) {
        query = query.or(
          `name.ilike.%${filters.search}%,email.ilike.%${filters.search}%,country.ilike.%${filters.search}%`
        );
      }

      const { data, error } = await query;

      if (error) throw error;
      return (data as unknown) as Client[];
    },
  });

  // Note: Realtime handled by useClientsPaginated to avoid duplicate channels

  const createClient = useMutation({
    mutationFn: async (clientData: Omit<Client, 'id' | 'created_at' | 'updated_at' | 'created_by'> & Partial<Pick<Client, 'assigned_to'>>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from('clients')
        .insert([{ 
          ...clientData, 
          created_by: user.id,
          admin_id: effectiveTenantId || null 
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['clients-count'] });
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast({
        title: "Client created",
        description: "The client has been successfully created.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to create client",
        description: message,
        variant: "destructive",
      });
    },
  });

  const updateClient = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string } & Partial<Omit<Client, 'id' | 'created_at' | 'updated_at'>>) => {
      const { data: oldClient } = await supabase
        .from('clients')
        .select('*')
        .eq('id', id)
        .single();

      const { data, error } = await supabase
        .from('clients')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      const changes: Record<string, { old: unknown; new: unknown }> = {};
      if (oldClient) {
        Object.keys(updates).forEach(key => {
          if (oldClient[key as keyof typeof oldClient] !== updates[key as keyof typeof updates]) {
            changes[key] = {
              old: oldClient[key as keyof typeof oldClient],
              new: updates[key as keyof typeof updates],
            };
          }
        });
      }

      let actionType = 'client_updated';
      if (updates.status && oldClient?.status !== updates.status) {
        actionType = 'client_status_changed';
      } else if (updates.assigned_to && oldClient?.assigned_to !== updates.assigned_to) {
        actionType = 'client_assigned';
      }

      await logAction({
        actionType,
        entityType: 'client',
        entityId: id,
        details: {
          client_name: data.name,
          changes,
          old_status: oldClient?.status,
          new_status: updates.status,
          old_assigned_to: oldClient?.assigned_to,
          new_assigned_to: updates.assigned_to,
        },
      });

      return data;
    },
    onMutate: async ({ id, ...updates }) => {
      await queryClient.cancelQueries({ queryKey: ['clients'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients'] });
      
      trackMutatedIds([id]);
      
      queryClient.setQueriesData(
        { queryKey: ['clients'] },
        (old: Client[] | undefined) => {
          if (!old) return old;
          return old.map(client => 
            client.id === id ? { ...client, ...updates } : client
          );
        }
      );

      return { previousClients };
    },
    onError: (error: unknown, variables, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to update client",
        description: message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({
        title: "Client updated",
        description: "The client has been successfully updated.",
      });
    },
  });

  const deleteClient = useMutation({
    mutationFn: async (id: string) => {
      const { data: client } = await supabase
        .from('clients')
        .select('*')
        .eq('id', id)
        .single();

      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', id);

      if (error) throw error;

      if (client) {
        await logAction({
          actionType: 'client_deleted',
          entityType: 'client',
          entityId: id,
          details: {
            deleted_client: {
              name: client.name,
              email: client.email,
              status: client.status,
            },
          },
        });
      }
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['clients'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients'] });
      
      queryClient.setQueriesData(
        { queryKey: ['clients'] },
        (old: Client[] | undefined) => old?.filter(client => client.id !== id)
      );

      return { previousClients };
    },
    onError: (error: unknown, id, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to delete client",
        description: message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({
        title: "Client deleted",
        description: "The client has been successfully deleted.",
      });
    },
  });

  const convertLeadToClient = useMutation({
    mutationFn: async ({ 
      leadId, 
      balance = 0,
      equity = 0,
      riskProfile = 'MEDIUM',
      superAgentId
    }: { 
      leadId: string; 
      balance?: number;
      equity?: number;
      riskProfile?: 'LOW' | 'MEDIUM' | 'HIGH';
      superAgentId?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data: lead, error: leadError } = await supabase
        .from('leads')
        .select('*')
        .eq('id', leadId)
        .single();

      if (leadError) throw leadError;

      // Determine the super agent: use provided superAgentId, or fall back to lead.assigned_to
      const conversionSuperAgentId = superAgentId || lead.assigned_to || null;

      const { data: client, error: clientError } = await supabase
        .from('clients')
        .insert([{
          name: lead.name,
          email: lead.email,
          country: lead.country,
          home_phone: lead.phone,
          source: lead.source,
          balance,
          equity,
          risk_profile: riskProfile,
          satisfaction_score: 0,
          actual_value: 0,
          assigned_to: lead.assigned_to,
          pipeline_status: 'WORK_IN_PROCESS' as PipelineStatus,
          converted_from_lead_id: leadId,
          conversion_super_agent_id: conversionSuperAgentId,
          created_by: user.id,
          admin_id: effectiveTenantId || null,
        }])
        .select()
        .single();

      if (clientError) throw clientError;

      // Log the conversion_confirmed event for historical tracking
      await logAction({
        actionType: 'conversion_confirmed',
        entityType: 'client',
        entityId: client.id,
        details: {
          client_name: client.name,
          client_email: client.email,
          original_lead_id: leadId,
          assigned_super_agent: conversionSuperAgentId,
          transferring_agent: lead.assigned_to,
          balance,
          equity,
        },
      });

      const { data: leadActivities } = await supabase
        .from('lead_activities')
        .select('*')
        .eq('lead_id', leadId);

      if (leadActivities && leadActivities.length > 0) {
        await supabase
          .from('client_activities')
          .insert(
            leadActivities.map(activity => ({
              client_id: client.id,
              user_id: activity.user_id,
              activity_type: activity.activity_type,
              description: activity.description,
              created_at: activity.created_at,
            }))
          );
      }

      const { data: leadTasks } = await supabase
        .from('lead_tasks')
        .select('*')
        .eq('lead_id', leadId);

      if (leadTasks && leadTasks.length > 0) {
        await supabase
          .from('client_tasks')
          .insert(
            leadTasks.map(task => ({
              client_id: client.id,
              assigned_to: task.assigned_to,
              title: task.title,
              description: task.description,
              due_date: task.due_date,
              completed: task.completed,
              created_at: task.created_at,
              updated_at: task.updated_at,
            }))
          );
      }

      const { data: leadComments } = await supabase
        .from('lead_comments')
        .select('*')
        .eq('lead_id', leadId);

      if (leadComments && leadComments.length > 0) {
        await supabase
          .from('client_comments')
          .insert(
            leadComments.map(comment => ({
              client_id: client.id,
              user_id: comment.user_id,
              comment: comment.comment,
              created_at: comment.created_at,
            }))
          );
      }

      await supabase
        .from('documents')
        .update({ client_id: client.id, lead_id: null })
        .eq('lead_id', leadId);

      await supabase
        .from('kyc_records')
        .update({ client_id: client.id, lead_id: null })
        .eq('lead_id', leadId);

      const { error: deleteError } = await supabase
        .from('leads')
        .delete()
        .eq('id', leadId);

      if (deleteError) throw deleteError;

      if (lead.assigned_to) {
        await supabase
          .from('notifications')
          .insert([{
            user_id: lead.assigned_to,
            type: 'CLIENT_CONVERTED',
            message: `Lead ${lead.name} has been converted to a client`,
            related_entity_id: client.id,
            related_entity_type: 'client',
          }]);
      }

      return client;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['clients-count'] });
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      queryClient.invalidateQueries({ queryKey: ['leads-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['leads-count-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Lead converted",
        description: "The lead has been successfully converted to a client.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to convert lead",
        description: message,
        variant: "destructive",
      });
    },
  });

  return {
    clients,
    isLoading,
    error,
    createClient,
    updateClient,
    deleteClient,
    convertLeadToClient,
  };
};
