import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Lead, LeadStatus, LeadSource } from "@/types/leads";
import { useToast } from "@/hooks/use-toast";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useTenant } from "@/contexts/TenantContext";
import { Database } from "@/integrations/supabase/types";
import { getAllPhonePrefixesForCountry } from "@/lib/phoneCountryCode";

export const useLeads = (filters?: {
  status?: LeadStatus;
  statuses?: LeadStatus[];
  sources?: string[];
  assignedTo?: string;
  assignedToList?: string[];
  unassigned?: boolean;
  search?: string;
  groupId?: string;
  conversionProbMin?: number;
  conversionProbMax?: number;
  dateFrom?: Date;
  dateTo?: Date;
  countries?: string[];
  // Filter by team member IDs (for managers)
  teamMemberIds?: string[];
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();
  const { effectiveTenantId } = useTenant();

  // Separate count query to get actual total (bypasses the 1000 row limit)
  const { data: totalCount } = useQuery({
    queryKey: ['leads-count', filters, effectiveTenantId],
    staleTime: 2 * 60 * 1000, // 2 minutes - reduced polling
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    queryFn: async () => {
      // For group filtering, count through the join
      if (filters?.groupId) {
        let query = supabase
          .from('lead_group_members')
          .select('lead_id, leads!inner(*)', { count: 'exact', head: true })
          .eq('group_id', filters.groupId);

        // Apply tenant filter
        if (effectiveTenantId) {
          query = query.or(`leads.admin_id.eq.${effectiveTenantId},leads.created_by.eq.${effectiveTenantId}`);
        }

        const { count } = await query;
        return count || 0;
      }

      // Build count query with same filters
      let query = supabase
        .from('leads_secure')
        .select('*', { count: 'exact', head: true });

      if (effectiveTenantId) {
        query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
      }

      if (filters?.status) {
        query = query.eq('status', filters.status);
      }

      if (filters?.statuses && filters.statuses.length > 0) {
        query = query.in('status', filters.statuses);
      }

      if (filters?.sources && filters.sources.length > 0) {
        const typedSources = filters.sources as Database['public']['Enums']['lead_source'][];
        query = query.in('source', typedSources);
      }

      if (filters?.assignedTo) {
        query = query.eq('assigned_to', filters.assignedTo);
      }

      if (filters?.assignedToList && filters.assignedToList.length > 0) {
        const hasUnassigned = filters.assignedToList.includes('unassigned');
        const userIds = filters.assignedToList.filter(id => id !== 'unassigned');
        
        if (hasUnassigned && userIds.length > 0) {
          query = query.or(`assigned_to.is.null,assigned_to.in.(${userIds.join(',')})`);
        } else if (hasUnassigned) {
          query = query.is('assigned_to', null);
        } else {
          query = query.in('assigned_to', userIds);
        }
      }

      if (filters?.unassigned && (!filters.assignedToList || filters.assignedToList.length === 0)) {
        query = query.is('assigned_to', null);
      }

      if (filters?.dateFrom) {
        query = query.gte('created_at', filters.dateFrom.toISOString());
      }
      if (filters?.dateTo) {
        query = query.lte('created_at', filters.dateTo.toISOString());
      }

      if (filters?.countries && filters.countries.length > 0) {
        const prefixes = Array.from(
          new Set(filters.countries.flatMap((c) => getAllPhonePrefixesForCountry(c)))
        );
        if (prefixes.length > 0) {
          query = query.or(prefixes.map((p) => `phone.like.${p}%`).join(','));
        } else {
          query = query.eq('id', '00000000-0000-0000-0000-000000000000');
        }
      }

      if (filters?.search) {
        query = query.or(
          `name.ilike.%${filters.search}%,email.ilike.%${filters.search}%,phone.ilike.%${filters.search}%,country.ilike.%${filters.search}%`
        );
      }

      const { count } = await query;
      return count || 0;
    },
  });

  const { data: leads, isLoading, error } = useQuery({
    queryKey: ['leads', filters, effectiveTenantId],
    staleTime: 2 * 60 * 1000, // 2 minutes - reduced polling
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    queryFn: async () => {
      // If filtering by group, use a different approach to avoid URL length limits
      if (filters?.groupId) {
        // Get leads through a join - fetch group members with lead data
        const { data: members, error: membersError } = await supabase
          .from('lead_group_members')
          .select('lead_id, leads(*)')
          .eq('group_id', filters.groupId);

        if (membersError) throw membersError;

        // Extract lead data from the join result
        let groupLeads = (members
          ?.map(m => m.leads)
          .filter(Boolean) || []) as unknown as Lead[];

        // Apply tenant filter
        if (effectiveTenantId) {
          groupLeads = groupLeads.filter(
            lead => lead.admin_id === effectiveTenantId || lead.created_by === effectiveTenantId
          );
        }

        // Apply additional filters client-side for group leads
        if (filters?.statuses && filters.statuses.length > 0) {
          groupLeads = groupLeads.filter(lead => filters.statuses!.includes(lead.status as LeadStatus));
        }
        if (filters?.sources && filters.sources.length > 0) {
          groupLeads = groupLeads.filter(lead => filters.sources!.includes(lead.source));
        }
        if (filters?.search) {
          const searchLower = filters.search.toLowerCase();
          groupLeads = groupLeads.filter(lead => 
            lead.name?.toLowerCase().includes(searchLower) ||
            lead.email?.toLowerCase().includes(searchLower) ||
            lead.phone?.toLowerCase().includes(searchLower) ||
            lead.country?.toLowerCase().includes(searchLower)
          );
        }
        if (filters?.countries && filters.countries.length > 0) {
          const prefixes = Array.from(
            new Set(filters.countries.flatMap((c) => getAllPhonePrefixesForCountry(c)))
          );
          groupLeads = groupLeads.filter((lead) => {
            const digits = (lead.phone || '').replace(/\D/g, '');
            return prefixes.some((p) => digits.startsWith(p));
          });
        }
        if (filters?.assignedToList && filters.assignedToList.length > 0) {
          const hasUnassigned = filters.assignedToList.includes('unassigned');
          const userIds = filters.assignedToList.filter(id => id !== 'unassigned');
          groupLeads = groupLeads.filter(lead => {
            if (hasUnassigned && !lead.assigned_to) return true;
            if (userIds.length > 0 && lead.assigned_to && userIds.includes(lead.assigned_to)) return true;
            return false;
          });
        }

        // Sort by updated_at (last modified first)
        groupLeads.sort((a, b) => {
          return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
        });

        return groupLeads;
      }

      // Query from leads_secure view for proper email/phone masking
      // Limit to 500 records to prevent timeout issues
      let query = supabase
        .from('leads_secure')
        .select('*')
        .order('updated_at', { ascending: false })
        .limit(500);

      // Filter by tenant if one is active (TENANT_OWNER sees own, SUPER_ADMIN sees selected or all)
      // For TENANT_OWNER, also show records they created_by (for legacy data without admin_id)
      if (effectiveTenantId) {
        query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
      }

      // Single status filter (legacy)
      if (filters?.status) {
        query = query.eq('status', filters.status);
      }

      // Multiple statuses filter
      if (filters?.statuses && filters.statuses.length > 0) {
        query = query.in('status', filters.statuses);
      }

      // Multiple sources filter
      if (filters?.sources && filters.sources.length > 0) {
        const typedSources = filters.sources as Database['public']['Enums']['lead_source'][];
        query = query.in('source', typedSources);
      }

      // Single assignedTo filter (legacy)
      if (filters?.assignedTo) {
        query = query.eq('assigned_to', filters.assignedTo);
      }

      // Multiple assigned to filter (handle 'unassigned' special value)
      if (filters?.assignedToList && filters.assignedToList.length > 0) {
        const hasUnassigned = filters.assignedToList.includes('unassigned');
        const userIds = filters.assignedToList.filter(id => id !== 'unassigned');
        
        if (hasUnassigned && userIds.length > 0) {
          // Filter for unassigned OR specific users
          query = query.or(`assigned_to.is.null,assigned_to.in.(${userIds.join(',')})`);
        } else if (hasUnassigned) {
          // Only unassigned
          query = query.is('assigned_to', null);
        } else {
          // Only specific users
          query = query.in('assigned_to', userIds);
        }
      }

      // Standalone unassigned filter (from old filter interface)
      if (filters?.unassigned && (!filters.assignedToList || filters.assignedToList.length === 0)) {
        query = query.is('assigned_to', null);
      }

      // Date range filter
      if (filters?.dateFrom) {
        query = query.gte('created_at', filters.dateFrom.toISOString());
      }
      if (filters?.dateTo) {
        query = query.lte('created_at', filters.dateTo.toISOString());
      }

      // Countries filter — match by phone prefix (the source of truth)
      if (filters?.countries && filters.countries.length > 0) {
        const prefixes = Array.from(
          new Set(filters.countries.flatMap((c) => getAllPhonePrefixesForCountry(c)))
        );
        if (prefixes.length > 0) {
          query = query.or(prefixes.map((p) => `phone.like.${p}%`).join(','));
        } else {
          query = query.eq('id', '00000000-0000-0000-0000-000000000000');
        }
      }

      // Search filter
      if (filters?.search) {
        query = query.or(
          `name.ilike.%${filters.search}%,email.ilike.%${filters.search}%,phone.ilike.%${filters.search}%,country.ilike.%${filters.search}%`
        );
      }

      const { data, error } = await query;

      if (error) throw error;
      return (data as unknown) as Lead[];
    },
  });

  // NOTE: Realtime subscription is handled by useLeadsPaginated hook
  // which has proper debouncing and bulk operation protection.
  // Using both causes redundant updates and freezing during bulk actions.

  const createLead = useMutation({
    mutationFn: async (leadData: Omit<Lead, 'id' | 'created_at' | 'updated_at' | 'created_by'> & Partial<Pick<Lead, 'assigned_to' | 'last_contacted_at'>>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from('leads')
        .insert([{ 
          ...leadData, 
          created_by: user.id,
          admin_id: effectiveTenantId || null 
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Lead created",
        description: "The lead has been successfully created.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateLead = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string } & Partial<Omit<Lead, 'id' | 'created_at' | 'updated_at'>>) => {
      // Get old lead data for comparison
      const { data: oldLead } = await supabase
        .from('leads')
        .select('*')
        .eq('id', id)
        .single();

      const { data, error } = await supabase
        .from('leads')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // Log the activity with detailed changes
      const changes: Record<string, { old: unknown; new: unknown }> = {};
      if (oldLead) {
        Object.keys(updates).forEach(key => {
          if (oldLead[key as keyof typeof oldLead] !== updates[key as keyof typeof updates]) {
            changes[key] = {
              old: oldLead[key as keyof typeof oldLead],
              new: updates[key as keyof typeof updates],
            };
          }
        });
      }

      // Determine action type based on changes
      let actionType = 'lead_updated';
      if (updates.status && oldLead?.status !== updates.status) {
        actionType = 'lead_status_changed';
      } else if (updates.assigned_to && oldLead?.assigned_to !== updates.assigned_to) {
        actionType = 'lead_assigned';
      }

      await logAction({
        actionType,
        entityType: 'lead',
        entityId: id,
        details: {
          lead_name: data.name,
          changes,
          old_status: oldLead?.status,
          new_status: updates.status,
          old_assigned_to: oldLead?.assigned_to,
          new_assigned_to: updates.assigned_to,
        },
      });

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Lead updated",
        description: "The lead has been successfully updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteLead = useMutation({
    mutationFn: async (id: string) => {
      // Get lead data before deletion
      const { data: lead } = await supabase
        .from('leads')
        .select('*')
        .eq('id', id)
        .single();

      const { error } = await supabase
        .from('leads')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Log the deletion
      if (lead) {
        await logAction({
          actionType: 'lead_deleted',
          entityType: 'lead',
          entityId: id,
          details: {
            deleted_lead: {
              name: lead.name,
              email: lead.email,
              status: lead.status,
            },
          },
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Lead deleted",
        description: "The lead has been successfully deleted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete lead",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkAssignLeads = useMutation({
    mutationFn: async ({ leadIds, assignedTo }: { leadIds: string[]; assignedTo: string }) => {
      const { error } = await supabase
        .from('leads')
        .update({ 
          assigned_to: assignedTo,
          admin_id: effectiveTenantId || null 
        })
        .in('id', leadIds);

      if (error) throw error;

      // Log bulk assignment
      await logAction({
        actionType: 'leads_bulk_assigned',
        entityType: 'lead',
        details: {
          lead_count: leadIds.length,
          lead_ids: leadIds,
          assigned_to: assignedTo,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Leads assigned",
        description: "The leads have been successfully assigned.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to assign leads",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const bulkDeleteLeads = useMutation({
    mutationFn: async (leadIds: string[]) => {
      const { error } = await supabase
        .from('leads')
        .delete()
        .in('id', leadIds);

      if (error) throw error;

      // Log bulk deletion
      await logAction({
        actionType: 'leads_bulk_deleted',
        entityType: 'lead',
        details: {
          lead_count: leadIds.length,
          lead_ids: leadIds,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Leads deleted",
        description: "The selected leads have been successfully deleted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete leads",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return {
    leads,
    totalCount: totalCount ?? 0,
    isLoading,
    error,
    createLead,
    updateLead,
    deleteLead,
    bulkAssignLeads,
    bulkDeleteLeads,
  };
};
