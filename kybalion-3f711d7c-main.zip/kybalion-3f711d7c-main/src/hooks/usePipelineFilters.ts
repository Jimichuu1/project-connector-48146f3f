import { useState, useMemo, useCallback } from "react";
import { SaleBranchWithClient } from "@/types/pipeline";

interface FilterOptions {
  selectedClients: string[];
  selectedSuperAgents: string[];
  amountRange: [number, number];
  isAmountFilterActive: boolean;
  depositRange: [number, number];
  isDepositFilterActive: boolean;
  searchQuery: string;
}

export function usePipelineFilters(branches: SaleBranchWithClient[] | undefined) {
  const [selectedClients, setSelectedClients] = useState<string[]>([]);
  const [selectedSuperAgents, setSelectedSuperAgents] = useState<string[]>([]);
  const [amountRange, setAmountRange] = useState<[number, number]>([0, 100000]);
  const [isAmountFilterActive, setIsAmountFilterActive] = useState(false);
  const [depositRange, setDepositRange] = useState<[number, number]>([0, 100000]);
  const [isDepositFilterActive, setIsDepositFilterActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const toggleClient = useCallback((clientId: string) => {
    setSelectedClients((prev) =>
      prev.includes(clientId)
        ? prev.filter((c) => c !== clientId)
        : [...prev, clientId]
    );
  }, []);

  const toggleSuperAgent = useCallback((superAgentId: string) => {
    setSelectedSuperAgents((prev) =>
      prev.includes(superAgentId)
        ? prev.filter((s) => s !== superAgentId)
        : [...prev, superAgentId]
    );
  }, []);

  const handleAmountRangeChange = useCallback((values: number[]) => {
    setAmountRange([values[0], values[1]]);
    setIsAmountFilterActive(true);
  }, []);

  const clearAmountFilter = useCallback(() => {
    setAmountRange([0, 100000]);
    setIsAmountFilterActive(false);
  }, []);

  const handleDepositRangeChange = useCallback((values: number[]) => {
    setDepositRange([values[0], values[1]]);
    setIsDepositFilterActive(true);
  }, []);

  const clearDepositFilter = useCallback(() => {
    setDepositRange([0, 100000]);
    setIsDepositFilterActive(false);
  }, []);

  const clearAllFilters = useCallback(() => {
    setSelectedClients([]);
    setSelectedSuperAgents([]);
    setAmountRange([0, 100000]);
    setIsAmountFilterActive(false);
    setDepositRange([0, 100000]);
    setIsDepositFilterActive(false);
    setSearchQuery("");
  }, []);

  // Memoized filter options for dropdowns
  const clientOptions = useMemo(() => {
    return Array.from(
      new Set(branches?.map((b) => b.client_id).filter(Boolean))
    )
      .map((clientId) => {
        const branch = branches?.find((b) => b.client_id === clientId);
        return {
          value: clientId,
          label: branch?.client?.name || "Unknown Client",
        };
      })
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [branches]);

  // Build super agent options using deposit's stored agent for DEPOSIT branches and flipped's for FLIPPED
  const superAgentOptions = useMemo(() => {
    const agentMap = new Map<string, string>();
    
    branches?.forEach((b) => {
      // For DEPOSIT branches, use deposit's stored super_agent
      if (b.status === 'DEPOSIT' && b.deposit_super_agent_id) {
        if (!agentMap.has(b.deposit_super_agent_id)) {
          agentMap.set(
            b.deposit_super_agent_id,
            b.super_agent?.full_name || b.super_agent?.email || "Unknown Agent"
          );
        }
      } else if (b.status === 'FLIPPED' && b.flipped_super_agent_id) {
        // For FLIPPED branches, use flipped record's stored super_agent
        if (!agentMap.has(b.flipped_super_agent_id)) {
          agentMap.set(
            b.flipped_super_agent_id,
            b.flipped_super_agent?.full_name || b.flipped_super_agent?.email || "Unknown Agent"
          );
        }
      } else if (b.client?.assigned_to) {
        // For other branches, use current assignment
        if (!agentMap.has(b.client.assigned_to)) {
          agentMap.set(
            b.client.assigned_to,
            b.client.assigned_user?.full_name || "Unknown Agent"
          );
        }
      }
    });

    return Array.from(agentMap.entries())
      .map(([value, label]) => ({ value, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [branches]);

  // Memoized filter function
  const filterBranches = useCallback(
    (branchesToFilter: SaleBranchWithClient[]) => {
      let filtered = branchesToFilter;

      // Filter by selected clients
      if (selectedClients.length > 0) {
        filtered = filtered.filter((b) => selectedClients.includes(b.client_id));
      }

      // Filter by selected super agents
      // For DEPOSIT/FLIPPED branches, use stored super_agent_id to maintain correct attribution
      if (selectedSuperAgents.length > 0) {
        filtered = filtered.filter((b) => {
          // For DEPOSIT branches, use the deposit's stored super_agent_id
          if (b.status === 'DEPOSIT' && b.deposit_super_agent_id) {
            return selectedSuperAgents.includes(b.deposit_super_agent_id);
          }
          // For FLIPPED branches, use the flipped record's stored super_agent_id
          if (b.status === 'FLIPPED' && b.flipped_super_agent_id) {
            return selectedSuperAgents.includes(b.flipped_super_agent_id);
          }
          // For other branches, use client's current assignment
          return b.client?.assigned_to && selectedSuperAgents.includes(b.client.assigned_to);
        });
      }

      // Filter by amount range if active
      if (isAmountFilterActive) {
        filtered = filtered.filter(
          (b) => b.value >= amountRange[0] && b.value <= amountRange[1]
        );
      }

      // Filter by deposit range if active (based on branch value for DEPOSIT stage)
      if (isDepositFilterActive) {
        filtered = filtered.filter(
          (b) => {
            // Use value field which represents the deposit amount
            const depositValue = b.value || 0;
            return depositValue >= depositRange[0] && depositValue <= depositRange[1];
          }
        );
      }

      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        filtered = filtered.filter(
          (b) =>
            b.client?.name.toLowerCase().includes(query) ||
            b.client?.email.toLowerCase().includes(query)
        );
      }

      return filtered;
    },
    [
      selectedClients,
      selectedSuperAgents,
      amountRange,
      isAmountFilterActive,
      depositRange,
      isDepositFilterActive,
      searchQuery,
    ]
  );

  const hasActiveFilters = useMemo(() => {
    return (
      selectedClients.length > 0 ||
      selectedSuperAgents.length > 0 ||
      isAmountFilterActive ||
      isDepositFilterActive ||
      searchQuery.length > 0
    );
  }, [selectedClients, selectedSuperAgents, isAmountFilterActive, isDepositFilterActive, searchQuery]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (selectedClients.length > 0) count++;
    if (selectedSuperAgents.length > 0) count++;
    if (isAmountFilterActive) count++;
    if (isDepositFilterActive) count++;
    if (searchQuery.length > 0) count++;
    return count;
  }, [selectedClients, selectedSuperAgents, isAmountFilterActive, isDepositFilterActive, searchQuery]);

  return {
    // State
    selectedClients,
    selectedSuperAgents,
    amountRange,
    isAmountFilterActive,
    depositRange,
    isDepositFilterActive,
    searchQuery,
    setSearchQuery,
    
    // Actions
    toggleClient,
    toggleSuperAgent,
    handleAmountRangeChange,
    clearAmountFilter,
    handleDepositRangeChange,
    clearDepositFilter,
    clearAllFilters,
    
    // Memoized data
    clientOptions,
    superAgentOptions,
    filterBranches,
    hasActiveFilters,
    activeFilterCount,
  };
}
