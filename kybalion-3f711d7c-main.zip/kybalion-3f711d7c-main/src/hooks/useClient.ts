import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { isValidUUID } from "@/lib/uuidUtils";

export const useClient = (clientId: string | undefined) => {
  return useQuery({
    queryKey: ['client', clientId],
    enabled: !!clientId && isValidUUID(clientId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('id', clientId!)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    staleTime: 30000,
  });
};
