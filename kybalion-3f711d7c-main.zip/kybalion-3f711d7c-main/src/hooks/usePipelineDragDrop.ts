import { useState, useCallback } from "react";
import {
  DragEndEvent,
  DragStartEvent,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PipelineStage, SaleBranchWithClient } from "@/types/pipeline";
import { Client } from "@/types/clients";

interface UsePipelineDragDropProps {
  branches: SaleBranchWithClient[] | undefined;
  clients: Client[] | undefined;
  updateBranch: {
    mutate: (data: { id: string; status?: PipelineStage; value?: number }) => void;
  };
  onDepositDrop: (branchId: string, leadId: string | null) => void;
  onFlippedDrop: (branchId: string) => void;
}

interface PendingDrop {
  branchId: string;
  newStatus: PipelineStage;
  oldStatus: PipelineStage;
}

export function usePipelineDragDrop({
  branches,
  clients,
  updateBranch,
  onDepositDrop,
  onFlippedDrop,
}: UsePipelineDragDropProps) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const [pendingDrop, setPendingDrop] = useState<PendingDrop | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragEnd = useCallback(
    async (event: DragEndEvent) => {
      const { active, over } = event;

      if (!over) {
        setActiveId(null);
        return;
      }

      const branchId = active.id as string;
      const activeBranch = branches?.find((b) => b.id === branchId);

      if (!activeBranch) {
        setActiveId(null);
        return;
      }

      // Prevent moving from FLIPPED or DEPOSIT columns
      if (activeBranch.status === "FLIPPED" || activeBranch.status === "DEPOSIT") {
        toast.error("Cannot move cards from Flipped or Deposit columns");
        setActiveId(null);
        return;
      }

      // Check if dropped over a column
      if (over.data.current?.type === "column") {
        const newStatus = over.id as PipelineStage;
        const oldStatus = activeBranch.status;

        // Only update if status changed
        if (oldStatus !== newStatus) {
          // If dropping into DEPOSIT, show deposit dialog
          if (
            newStatus === "DEPOSIT" &&
            (oldStatus === "UPCOMING_SALE" || oldStatus === "STUCK")
          ) {
            setPendingDrop({ branchId, newStatus, oldStatus });

            // Try to find converted lead
            const client = clients?.find((c) => c.id === activeBranch.client_id);
            let leadId: string | null = null;
            
            if (client) {
              const { data: clientData } = await supabase
                .from("clients")
                .select("converted_from_lead_id")
                .eq("id", client.id)
                .maybeSingle();

              leadId = clientData?.converted_from_lead_id || null;
            }

            onDepositDrop(branchId, leadId);
          }
          // If dropping into FLIPPED, show confirmation dialog
          else if (newStatus === "FLIPPED") {
            setPendingDrop({ branchId, newStatus, oldStatus });
            onFlippedDrop(branchId);
          }
          // For all other moves, allow freely
          else {
            updateBranch.mutate({ id: branchId, status: newStatus });
            toast.success("Opportunity moved successfully");
          }
        }
      }

      setActiveId(null);
    },
    [branches, clients, updateBranch, onDepositDrop, onFlippedDrop]
  );

  const clearPendingDrop = useCallback(() => {
    setPendingDrop(null);
  }, []);

  const activeBranch = branches?.find((b) => b.id === activeId);

  return {
    activeId,
    activeBranch,
    pendingDrop,
    sensors,
    handleDragStart,
    handleDragEnd,
    clearPendingDrop,
  };
}
