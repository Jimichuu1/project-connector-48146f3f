import { useUserData } from "@/contexts/UserDataContext";

/**
 * @deprecated Use useUserData() directly for better performance.
 * This hook is kept for backwards compatibility and will be removed in a future version.
 */
export function useUserRole() {
  const {
    role,
    isSuperAdmin,
    isTenantOwner,
    isManager,
    isTeamLeader,
    isSuperAgent,
    isAgent,
    hasSuperAdminAccess,
    hasTenantOwnerAccess,
    hasManagerAccess,
    hasTeamLeaderAccess,
    hasSuperAgentAccess,
    loading,
  } = useUserData();

  return {
    role,
    isSuperAdmin,
    isTenantOwner,
    isManager,
    isTeamLeader,
    isSuperAgent,
    isAgent,
    hasSuperAdminAccess,
    hasTenantOwnerAccess,
    hasManagerAccess,
    hasTeamLeaderAccess,
    hasSuperAgentAccess,
    loading,
  };
}
