import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SaleBranch, SaleBranchWithClient, PipelineStage } from "@/types/pipeline";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useRef, useCallback } from "react";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useTenant } from "@/contexts/TenantContext";
import { MutationError, ProfileBasic } from "@/types/supabase-helpers";
import { isValidUUID } from "@/lib/uuidUtils";

export const useSaleBranches = (filters?: {
  // Filter by team member IDs (for managers) - filters clients assigned to these IDs
  teamMemberIds?: string[];
  // Control when the query runs
  enabled?: boolean;
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();
  const { effectiveTenantId, loading: tenantLoading } = useTenant();
  
  // Debounce timer for realtime updates
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  // Track if we have an active mutation to skip realtime during our own changes
  const isMutatingRef = useRef(false);

  const { data: branches, isLoading, error } = useQuery({
    queryKey: ['sale-branches', effectiveTenantId, filters?.teamMemberIds],
    // Wait for tenant context and validate UUID if present
    enabled: filters?.enabled !== false && !tenantLoading && (!effectiveTenantId || isValidUUID(effectiveTenantId)),
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    queryFn: async () => {
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      const currentUserId = currentUser?.id;
      // First fetch sale branches with client info
      let query = supabase
        .from('sale_branches')
        .select(`
          *,
          client:clients(
            id, 
            name,
            assigned_to,
            assigned_user:profiles!clients_assigned_to_fkey(
              id,
              full_name,
              avatar_url
            )
          )
        `)
        .order('created_at', { ascending: false });

      // Filter by tenant if one is active
      if (effectiveTenantId) {
        query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
      }

      const { data: branchesData, error: branchesError } = await query;

      if (branchesError) throw branchesError;

      // Fetch deposit info for branches in DEPOSIT status
      const depositBranchIds = branchesData
        ?.filter(b => b.status === 'DEPOSIT')
        .map(b => b.id) || [];

      let depositInfo: Record<string, { 
        id: string;
        status: string; 
        rejection_reason: string | null;
        agent_id: string | null;
        super_agent_id: string | null;
        agent?: { full_name: string | null; email: string | null } | null;
        super_agent?: { full_name: string | null; email: string | null } | null;
      }> = {};
      
      if (depositBranchIds.length > 0) {
        const { data: depositsData } = await supabase
          .from('deposits')
          .select(`
            id,
            sale_branch_id, 
            status, 
            rejection_reason,
            agent_id,
            super_agent_id,
            agent:profiles!deposits_agent_id_fkey(full_name, email),
            super_agent:profiles!deposits_super_agent_id_fkey(full_name, email)
          `)
          .in('sale_branch_id', depositBranchIds);

        if (depositsData) {
          depositInfo = depositsData.reduce((acc, d) => {
            acc[d.sale_branch_id] = { 
              id: d.id,
              status: d.status, 
              rejection_reason: d.rejection_reason,
              agent_id: d.agent_id,
              super_agent_id: d.super_agent_id,
              agent: d.agent as { full_name: string | null; email: string | null } | null,
              super_agent: d.super_agent as { full_name: string | null; email: string | null } | null,
            };
            return acc;
          }, {} as typeof depositInfo);
        }
      }

      // Fetch flipped records for branches in FLIPPED status
      const flippedBranchIds = branchesData
        ?.filter(b => b.status === 'FLIPPED')
        .map(b => b.id) || [];

      let flippedInfo: Record<string, {
        id: string;
        agent_id: string | null;
        super_agent_id: string | null;
        flipped_by: string | null;
        flipped_at: string | null;
        reason: string | null;
        agent?: { full_name: string | null; email: string | null } | null;
        super_agent?: { full_name: string | null; email: string | null } | null;
      }> = {};

      if (flippedBranchIds.length > 0) {
        const { data: flippedData } = await supabase
          .from('flipped_records')
          .select(`
            id,
            sale_branch_id,
            agent_id,
            super_agent_id,
            flipped_by,
            flipped_at,
            reason,
            agent:profiles!flipped_records_agent_id_fkey(full_name, email),
            super_agent:profiles!flipped_records_super_agent_id_fkey(full_name, email)
          `)
          .in('sale_branch_id', flippedBranchIds);

        if (flippedData) {
          flippedInfo = flippedData.reduce((acc, f) => {
            acc[f.sale_branch_id] = {
              id: f.id,
              agent_id: f.agent_id,
              super_agent_id: f.super_agent_id,
              flipped_by: f.flipped_by,
              flipped_at: f.flipped_at,
              reason: f.reason,
              agent: f.agent as { full_name: string | null; email: string | null } | null,
              super_agent: f.super_agent as { full_name: string | null; email: string | null } | null,
            };
            return acc;
          }, {} as typeof flippedInfo);
        }
      }

      // Merge deposit and flipped info into branches
      let branchesWithAttributionStatus = branchesData?.map(branch => ({
        ...branch,
        // Deposit attribution
        deposit_status: depositInfo[branch.id]?.status as 'pending' | 'approved' | 'rejected' | undefined,
        deposit_rejection_reason: depositInfo[branch.id]?.rejection_reason || null,
        deposit_id: depositInfo[branch.id]?.id || null,
        deposit_agent_id: depositInfo[branch.id]?.agent_id || null,
        deposit_super_agent_id: depositInfo[branch.id]?.super_agent_id || null,
        agent: depositInfo[branch.id]?.agent || null,
        super_agent: depositInfo[branch.id]?.super_agent || null,
        // Flipped attribution
        flipped_record_id: flippedInfo[branch.id]?.id || null,
        flipped_agent_id: flippedInfo[branch.id]?.agent_id || null,
        flipped_super_agent_id: flippedInfo[branch.id]?.super_agent_id || null,
        flipped_agent: flippedInfo[branch.id]?.agent || null,
        flipped_super_agent: flippedInfo[branch.id]?.super_agent || null,
        flipped_at: flippedInfo[branch.id]?.flipped_at || null,
        flipped_by: flippedInfo[branch.id]?.flipped_by || null,
        flipped_reason: flippedInfo[branch.id]?.reason || null,
      })) || [];

      // Filter by team member IDs (for managers) - only show branches for clients assigned to team members
      // For DEPOSIT/FLIPPED branches, use the stored agent/super_agent IDs to maintain correct attribution
      if (filters?.teamMemberIds && filters.teamMemberIds.length > 0) {
        branchesWithAttributionStatus = branchesWithAttributionStatus.filter(branch => {
          // For DEPOSIT branches, check against the deposit's stored agent IDs
          if (branch.status === 'DEPOSIT' && branch.deposit_id) {
            const depositAgentId = depositInfo[branch.id]?.agent_id;
            const depositSuperAgentId = depositInfo[branch.id]?.super_agent_id;
            return (depositAgentId && filters.teamMemberIds!.includes(depositAgentId)) ||
                   (depositSuperAgentId && filters.teamMemberIds!.includes(depositSuperAgentId));
          }
          // For FLIPPED branches, check against the flipped record's stored agent IDs
          if (branch.status === 'FLIPPED' && branch.flipped_record_id) {
            const flippedAgentId = flippedInfo[branch.id]?.agent_id;
            const flippedSuperAgentId = flippedInfo[branch.id]?.super_agent_id;
            return (flippedAgentId && filters.teamMemberIds!.includes(flippedAgentId)) ||
                   (flippedSuperAgentId && filters.teamMemberIds!.includes(flippedSuperAgentId));
          }
          // For non-attributed branches, use client's current assignment
          const clientAssignedTo = (branch.client as { assigned_to?: string } | null)?.assigned_to;
          return clientAssignedTo && filters.teamMemberIds!.includes(clientAssignedTo);
        });
      }

      // Backfill client names for branches whose embedded client join came back null
      // (e.g. Super Agent viewing a branch on a client they no longer own but historically
      // deposited/created the card on). Uses a SECURITY DEFINER RPC scoped to the caller's
      // own historical attribution — does NOT widen visibility on the Clients page.
      const missingClientIds = Array.from(new Set(
        branchesWithAttributionStatus
          .filter(b => !b.client && (b as { client_id?: string }).client_id)
          .map(b => (b as { client_id: string }).client_id)
      ));

      if (missingClientIds.length > 0) {
        const { data: nameRows } = await supabase.rpc('get_attributed_client_names', {
          p_client_ids: missingClientIds,
        });
        const nameMap = new Map(
          ((nameRows as Array<{ id: string; name: string }> | null) || []).map(r => [r.id, r.name])
        );
        branchesWithAttributionStatus = branchesWithAttributionStatus.map(b => {
          if (!b.client && nameMap.has((b as { client_id: string }).client_id)) {
            return {
              ...b,
              client: {
                id: (b as { client_id: string }).client_id,
                name: nameMap.get((b as { client_id: string }).client_id)!,
                assigned_to: null,
                assigned_user: null,
              },
            };
          }
          return b;
        });
      }

      // Mark deposit branches as historical-for-viewer when the current user
      // is a SUPER_AGENT seeing the card only via deposit attribution (the
      // client is no longer assigned to them). These cards must be read-only.
      const finalBranches = branchesWithAttributionStatus.map(b => {
        const clientAssignedTo = (b.client as { assigned_to?: string | null } | null)?.assigned_to ?? null;
        const isHistorical =
          !!currentUserId &&
          b.status === 'DEPOSIT' &&
          clientAssignedTo !== currentUserId;
        return { ...b, is_historical_for_viewer: isHistorical };
      });

      return finalBranches as SaleBranchWithClient[];
    },
  });

  // Debounced invalidation to prevent query storms
  const debouncedInvalidate = useCallback(() => {
    // Skip if we're currently mutating (our own change)
    if (isMutatingRef.current) return;
    
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ['sale-branches'] });
    }, 1000); // 1 second debounce
  }, [queryClient]);

  // Set up real-time subscription for sale_branches and deposits changes
  useEffect(() => {
    const branchesChannel = supabase
      .channel('sale-branches-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'sale_branches',
        },
        () => {
          debouncedInvalidate();
        }
      )
      .subscribe();

    // Subscribe to deposits changes to update approval status
    const depositsChannel = supabase
      .channel('deposits-status-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'deposits',
        },
        () => {
          debouncedInvalidate();
        }
      )
      .subscribe();

    // Subscribe to flipped_records changes
    const flippedChannel = supabase
      .channel('flipped-records-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'flipped_records',
        },
        () => {
          debouncedInvalidate();
        }
      )
      .subscribe();

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      supabase.removeChannel(branchesChannel);
      supabase.removeChannel(depositsChannel);
      supabase.removeChannel(flippedChannel);
    };
  }, [queryClient, debouncedInvalidate]);

  const createBranch = useMutation({
    mutationFn: async (branchData: { client_id: string; name: string; value: number; status?: PipelineStage }) => {
      isMutatingRef.current = true;
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from('sale_branches')
        .insert([{ ...branchData, created_by: user.id }])
        .select()
        .single();

      if (error) throw error;

      // Log the activity
      await logAction({
        actionType: 'pipeline_opportunity_created',
        entityType: 'client',
        entityId: branchData.client_id,
        details: {
          branch_id: data.id,
          name: branchData.name,
          value: branchData.value,
          status: branchData.status || 'UPCOMING_SALE',
        },
      });

      return data;
    },
    onSuccess: () => {
      isMutatingRef.current = false;
      queryClient.invalidateQueries({ queryKey: ['sale-branches'] });
      toast({
        title: "Opportunity created",
        description: "The sales opportunity has been successfully created.",
      });
    },
    onSettled: () => {
      isMutatingRef.current = false;
    },
    onError: (error: MutationError) => {
      toast({
        title: "Failed to create opportunity",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });

  const updateBranch = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string } & Partial<Pick<SaleBranch, 'status' | 'value' | 'name'>>) => {
      // Get the old branch data for comparison
      const { data: oldBranch } = await supabase
        .from('sale_branches')
        .select('*, client:clients(id, name)')
        .eq('id', id)
        .single();

      const { data, error } = await supabase
        .from('sale_branches')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // Log the activity
      const clientId = oldBranch?.client_id || data.client_id;
      await logAction({
        actionType: updates.status ? 'pipeline_status_changed' : 'pipeline_opportunity_updated',
        entityType: 'client',
        entityId: clientId,
        details: {
          branch_id: id,
          branch_name: oldBranch?.name || data.name,
          client_name: (oldBranch?.client as { name?: string } | null)?.name,
          old_status: oldBranch?.status,
          new_status: updates.status,
          old_value: oldBranch?.value,
          new_value: updates.value,
          changes: updates,
        },
      });

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sale-branches'] });
    },
    onError: (error: MutationError) => {
      toast({
        title: "Failed to update opportunity",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });

  const deleteBranch = useMutation({
    mutationFn: async (id: string) => {
      // Get branch data before deletion for audit log
      const { data: branch } = await supabase
        .from('sale_branches')
        .select('*, client:clients(id, name)')
        .eq('id', id)
        .single();

      const { error } = await supabase
        .from('sale_branches')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Log the activity
      if (branch) {
        await logAction({
          actionType: 'pipeline_opportunity_deleted',
          entityType: 'client',
          entityId: branch.client_id,
          details: {
            branch_id: id,
            branch_name: branch.name,
            branch_value: branch.value,
            branch_status: branch.status,
            client_name: (branch.client as { name?: string } | null)?.name,
          },
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sale-branches'] });
      toast({
        title: "Opportunity deleted",
        description: "The sales opportunity has been successfully deleted.",
      });
    },
    onError: (error: MutationError) => {
      toast({
        title: "Failed to delete opportunity",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    },
  });

  return {
    branches,
    isLoading,
    error,
    createBranch,
    updateBranch,
    deleteBranch,
  };
};
