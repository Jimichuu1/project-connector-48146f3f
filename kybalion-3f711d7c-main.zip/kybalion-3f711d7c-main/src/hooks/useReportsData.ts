import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { startOfDay, endOfDay } from "date-fns";
import { useTenant } from "@/contexts/TenantContext";
import { useUserRole } from "@/hooks/useUserRole";
import { useManagerTeam } from "@/hooks/useManagerTeam";

import { isValidUUID } from "@/lib/uuidUtils";


export const useReportsData = (startDate: Date, endDate: Date) => {
  const { effectiveTenantId, loading: tenantLoading, isSuperAdmin } = useTenant();
  const { isManager, isTeamLeader, loading: roleLoading } = useUserRole();
  const { teamMemberIds, agentIds, superAgentIds, hasAgents, hasSuperAgents, isLoading: managerTeamLoading } = useManagerTeam();
  const isManagerOrTL = isManager || isTeamLeader;
  
  // Wait for tenant context and role to load before querying
  const queryEnabled = !tenantLoading && !roleLoading && !managerTeamLoading && (isSuperAdmin || effectiveTenantId !== undefined);

  // Sales Performance Data - for managers with super agents
  const { data: salesData, isLoading: salesLoading } = useQuery({
    queryKey: ['reports-sales', startDate, endDate, effectiveTenantId, isManager, superAgentIds],
    enabled: queryEnabled && (!isManagerOrTL || hasSuperAgents),
    staleTime: 2 * 60 * 1000, // 2 minutes cache for reports
    queryFn: async () => {
      // Single optimized query with all joins
      let query = supabase
        .from('deposits')
        .select(`
          id,
          amount,
          agent_id,
          super_agent_id,
          split_super_agent_id,
          agent_amount,
          super_agent_amount,
          split_super_agent_amount,
          admin_id,
          agent:profiles!deposits_agent_id_fkey(id, full_name, email),
          super_agent:profiles!deposits_super_agent_id_fkey(id, full_name, email)
        `)
        .gte('created_at', startOfDay(startDate).toISOString())
        .lte('created_at', endOfDay(endDate).toISOString())
        .eq('status', 'approved');

      // Filter by tenant if one is active
      if (effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }
      
      // For managers/TLs, filter to only show their super agents' deposits
      if (isManagerOrTL && superAgentIds && superAgentIds.length > 0) {
        query = query.in('super_agent_id', superAgentIds);
      }

      const { data: deposits, error } = await query;

      if (error) throw error;

      // Batch fetch split super agent profiles
      const splitAgentIdsList = [...new Set((deposits || [])
        .filter(d => d.split_super_agent_id)
        .map(d => d.split_super_agent_id))] as string[];
      
      let splitAgentProfiles: Record<string, { id: string; full_name: string | null; email: string }> = {};
      
      if (splitAgentIdsList.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .in('id', splitAgentIdsList);
        
        if (profiles) {
          splitAgentProfiles = profiles.reduce((acc, p) => {
            acc[p.id] = p;
            return acc;
          }, {} as Record<string, { id: string; full_name: string | null; email: string }>);
        }
      }

      // Get tenant users to filter results (single query)
      let tenantUserIds: Set<string> = new Set();
      if (isValidUUID(effectiveTenantId)) {
        const { data: tenantProfiles } = await supabase
          .from('profiles')
          .select('id')
          .or(`admin_id.eq.${effectiveTenantId},id.eq.${effectiveTenantId}`);
        
        if (tenantProfiles) {
          tenantUserIds = new Set(tenantProfiles.map(p => p.id));
        }
      }

      // Group by user (agents, super agents, and split super agents)
      const userMap = new Map();
      let totalRevenue = 0;
      let totalDeposits = 0;

      deposits?.forEach(deposit => {
        totalDeposits++;
        totalRevenue += Number(deposit.amount);

        // Track agent (transferring agent) - only if they belong to tenant
        // NOTE: Transferring agents intentionally excluded from per-user breakdown;
        // only super agents (and split super agent partners) are listed in Sales Performance by User.

        // Track super agent (working super agent) - only if they belong to tenant
        if (deposit.super_agent_id && deposit.super_agent) {
          if (!effectiveTenantId || tenantUserIds.has(deposit.super_agent_id)) {
            const userId = deposit.super_agent_id;
            const existing = userMap.get(userId) || {
              user_name: deposit.super_agent.full_name || 'Unknown',
              user_email: deposit.super_agent.email,
              deals_won: 0,
              total_revenue: 0,
              deposits_count: 0,
            };
            existing.deals_won += 1;
            existing.deposits_count += 1;
            existing.total_revenue += Number(deposit.super_agent_amount);
            userMap.set(userId, existing);
          }
        }

        // Track split super agent (50-50 split partner) - only if they belong to tenant
        if (deposit.split_super_agent_id) {
          if (!effectiveTenantId || tenantUserIds.has(deposit.split_super_agent_id)) {
            const splitProfile = splitAgentProfiles[deposit.split_super_agent_id];
            if (splitProfile) {
              const userId = deposit.split_super_agent_id;
              const existing = userMap.get(userId) || {
                user_name: splitProfile.full_name || 'Unknown',
                user_email: splitProfile.email,
                deals_won: 0,
                total_revenue: 0,
                deposits_count: 0,
              };
              existing.deals_won += 1;
              existing.deposits_count += 1;
              existing.total_revenue += Number(deposit.split_super_agent_amount || 0);
              userMap.set(userId, existing);
            }
          }
        }
      });

      const revenue_by_user = Array.from(userMap.values())
        .map(user => ({
          ...user,
          avg_deal_size: user.total_revenue / user.deals_won,
        }))
        .sort((a, b) => b.total_revenue - a.total_revenue);

      return {
        revenue_by_user,
        total_revenue: totalRevenue,
        total_deals_won: totalDeposits,
        avg_deal_size: totalDeposits > 0 ? totalRevenue / totalDeposits : 0,
      };
    },
  });

  // Pipeline Data - for managers with super agents
  const { data: pipelineData, isLoading: pipelineLoading } = useQuery({
    queryKey: ['reports-pipeline', startDate, endDate, effectiveTenantId, isManager, superAgentIds],
    enabled: queryEnabled && (!isManagerOrTL || hasSuperAgents),
    staleTime: 2 * 60 * 1000, // 2 minutes cache
    queryFn: async () => {
      let query = supabase
        .from('sale_branches')
        .select('status, value')
        .gte('created_at', startOfDay(startDate).toISOString())
        .lte('created_at', endOfDay(endDate).toISOString());

      // Filter by tenant if one is active
      if (effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }

      const { data: branches, error } = await query;

      if (error) throw error;

      const stageMap = new Map();
      let totalPipelineValue = 0;

      branches?.forEach(branch => {
        const stage = branch.status;
        const value = Number(branch.value);
        totalPipelineValue += value;

        const existing = stageMap.get(stage) || {
          stage,
          deal_count: 0,
          total_value: 0,
        };
        existing.deal_count += 1;
        existing.total_value += value;
        stageMap.set(stage, existing);
      });

      const deals_by_stage = Array.from(stageMap.values()).map(stage => ({
        ...stage,
        avg_value: stage.total_value / stage.deal_count,
      }));

      return {
        deals_by_stage,
        total_pipeline_value: totalPipelineValue,
        total_opportunities: branches?.length || 0,
      };
    },
  });

  // Conversion Data - uses database aggregation to avoid row limits
  const { data: conversionData, isLoading: conversionLoading } = useQuery({
    queryKey: ['reports-conversion', startDate, endDate, effectiveTenantId, isManager, teamMemberIds],
    enabled: queryEnabled,
    staleTime: 2 * 60 * 1000, // 2 minutes cache
    queryFn: async () => {
      // Fetch conversion metrics from backend function so restricted roles
      // receive the same dataset as tenant owners without client-side RLS filtering.
      const metricsRes = await supabase.rpc('get_conversion_metrics', {
        p_start_date: startOfDay(startDate).toISOString(),
        p_end_date: endOfDay(endDate).toISOString(),
        p_admin_id: effectiveTenantId || null,
        p_team_member_ids: isManagerOrTL && teamMemberIds && teamMemberIds.length > 0 ? teamMemberIds : null,
      });

      if (metricsRes.error) throw metricsRes.error;

      const result = metricsRes.data as {
        conversion_by_status: Array<{ status: string; count: number; converted: number; conversion_rate: number }>;
        conversion_by_agent: Array<{ agent_id: string; agent_name: string; agent_email: string; leads_assigned: number; converted: number; conversion_rate: number; total_deposits?: number }>;
        transfers_by_super_agent: Array<{ super_agent_id: string; super_agent_name: string; super_agent_email: string; clients_received: number }>;
        total_leads: number;
        total_converted: number;
        overall_conversion_rate: number;
        total_clients: number;
      };

      return {
        conversion_by_status: result.conversion_by_status.map(item => ({
          status: item.status,
          leads: item.count,
          converted: item.converted,
          conversion_rate: item.conversion_rate,
        })),
        conversion_by_agent: result.conversion_by_agent,
        transfers_by_super_agent: result.transfers_by_super_agent,
        overall_conversion_rate: result.overall_conversion_rate,
        total_leads: result.total_leads,
        total_converted: result.total_converted,
        total_clients: result.total_clients,
      };
    },
  });

  // User Activity Data - uses all team members
  const { data: activityData, isLoading: activityLoading } = useQuery({
    queryKey: ['reports-activity', startDate, endDate, effectiveTenantId, isManager, teamMemberIds],
    enabled: queryEnabled,
    staleTime: 2 * 60 * 1000, // 2 minutes cache
    queryFn: async () => {
      let leadsQuery = supabase
        .from('leads')
        .select('created_by, assigned_to')
        .gte('created_at', startOfDay(startDate).toISOString())
        .lte('created_at', endOfDay(endDate).toISOString());
      
      let clientsQuery = supabase
        .from('clients')
        .select('created_by, assigned_to')
        .gte('created_at', startOfDay(startDate).toISOString())
        .lte('created_at', endOfDay(endDate).toISOString());

      // Filter by tenant if one is active
      if (effectiveTenantId) {
        leadsQuery = leadsQuery.eq('admin_id', effectiveTenantId);
        clientsQuery = clientsQuery.eq('admin_id', effectiveTenantId);
      }
      
      // For managers/TLs, filter to only show their team's activity
      if (isManagerOrTL && teamMemberIds && teamMemberIds.length > 0) {
        leadsQuery = leadsQuery.in('assigned_to', teamMemberIds);
        clientsQuery = clientsQuery.in('assigned_to', teamMemberIds);
      }

      // Get user IDs for filtering comments
      let filterUserIds: string[] = [];
      
      // For managers/TLs, use their team IDs
      if (isManagerOrTL && teamMemberIds && teamMemberIds.length > 0) {
        filterUserIds = teamMemberIds;
      } else if (isValidUUID(effectiveTenantId)) {
        const { data: tenantProfiles } = await supabase
          .from('profiles')
          .select('id')
          .or(`admin_id.eq.${effectiveTenantId},id.eq.${effectiveTenantId}`);
        
        if (tenantProfiles) {
          filterUserIds = tenantProfiles.map(p => p.id);
        }
      }

      // Build comments query with user filter
      let commentsQuery = supabase
        .from('lead_comments')
        .select('user_id')
        .gte('created_at', startOfDay(startDate).toISOString())
        .lte('created_at', endOfDay(endDate).toISOString());
      
      // Filter comments by relevant users (manager team or tenant users)
      if (filterUserIds.length > 0) {
        commentsQuery = commentsQuery.in('user_id', filterUserIds);
      }

      // Execute all queries in parallel
      const [leadsRes, clientsRes, commentsRes] = await Promise.all([
        leadsQuery,
        clientsQuery,
        commentsQuery,
      ]);

      const userActivityMap = new Map();

      // Track lead creation
      leadsRes.data?.forEach(lead => {
        const userId = lead.created_by;
        const existing = userActivityMap.get(userId) || {
          leads_created: 0,
          clients_created: 0,
          comments_made: 0,
        };
        existing.leads_created += 1;
        userActivityMap.set(userId, existing);
      });

      // Track client creation
      clientsRes.data?.forEach(client => {
        const userId = client.created_by;
        const existing = userActivityMap.get(userId) || {
          leads_created: 0,
          clients_created: 0,
          comments_made: 0,
        };
        existing.clients_created += 1;
        userActivityMap.set(userId, existing);
      });

      // Track comments
      commentsRes.data?.forEach(comment => {
        const userId = comment.user_id;
        const existing = userActivityMap.get(userId) || {
          leads_created: 0,
          clients_created: 0,
          comments_made: 0,
        };
        existing.comments_made += 1;
        userActivityMap.set(userId, existing);
      });

      return {
        userActivityMap,
        totalLeads: leadsRes.data?.length || 0,
        totalClients: clientsRes.data?.length || 0,
        totalComments: commentsRes.data?.length || 0,
      };
    },
  });

  return {
    salesData,
    salesLoading,
    pipelineData,
    pipelineLoading,
    conversionData,
    conversionLoading,
    activityData,
    activityLoading,
    isLoading: salesLoading || pipelineLoading || conversionLoading || activityLoading,
    // Expose manager team info for conditional rendering
    hasAgents,
    hasSuperAgents,
  };
};
