import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useToast } from "@/hooks/use-toast";

export interface ClientGroup {
  id: string;
  name: string;
  description: string | null;
  is_system: boolean;
  created_by: string | null;
  admin_id: string | null;
  created_at: string;
  updated_at: string;
}

export function useClientGroups() {
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: groups, isLoading, error } = useQuery({
    queryKey: ['client-groups', effectiveTenantId],
    queryFn: async () => {
      let query = supabase
        .from('client_groups')
        .select('*')
        .order('is_system', { ascending: false })
        .order('name');
      
      if (!isSuperAdmin && effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      } else if (isSuperAdmin && effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as ClientGroup[];
    },
  });

  const ensureSystemGroups = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");
      
      if (!effectiveTenantId) throw new Error("No tenant context");

      const { data, error } = await supabase
        .rpc('get_or_create_client_system_groups', {
          p_admin_id: effectiveTenantId,
          p_user_id: user.id
        });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['client-groups'] });
    },
  });

  const addClientToGroup = useMutation({
    mutationFn: async ({ clientId, groupId }: { clientId: string; groupId: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from('client_group_members')
        .insert({
          client_id: clientId,
          group_id: groupId,
          added_by: user.id
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['client-groups'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-members'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-name'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add client to group",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addClientsToGroup = useMutation({
    mutationFn: async ({ groupId, clientIds }: { groupId: string; clientIds: string[] }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const memberships = clientIds.map(clientId => ({
        client_id: clientId,
        group_id: groupId,
        added_by: user.id
      }));

      const { error } = await supabase
        .from('client_group_members')
        .upsert(memberships, { onConflict: 'group_id,client_id' });

      if (error) throw error;
    },
    onSuccess: (_, { clientIds }) => {
      queryClient.invalidateQueries({ queryKey: ['client-groups'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-members'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-name'] });
      toast({
        title: "Success",
        description: `${clientIds.length} client(s) added to group`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add clients to group",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const moveClientsToGroup = useMutation({
    mutationFn: async ({ groupId, clientIds }: { groupId: string; clientIds: string[] }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Remove from all existing groups first
      const { error: deleteError } = await supabase
        .from('client_group_members')
        .delete()
        .in('client_id', clientIds);

      if (deleteError) throw deleteError;

      // Add to new group
      const memberships = clientIds.map(clientId => ({
        client_id: clientId,
        group_id: groupId,
        added_by: user.id
      }));

      const { error: insertError } = await supabase
        .from('client_group_members')
        .insert(memberships);

      if (insertError) throw insertError;
    },
    onSuccess: (_, { clientIds }) => {
      queryClient.invalidateQueries({ queryKey: ['client-groups'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-members'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-name'] });
      toast({
        title: "Success",
        description: `${clientIds.length} client(s) moved to group`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to move clients to group",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeClientFromGroup = useMutation({
    mutationFn: async ({ clientId, groupId }: { clientId: string; groupId: string }) => {
      const { error } = await supabase
        .from('client_group_members')
        .delete()
        .eq('client_id', clientId)
        .eq('group_id', groupId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['client-groups'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-members'] });
      queryClient.invalidateQueries({ queryKey: ['client-group-name'] });
    },
  });

  const getSystemGroupIds = async (): Promise<{ convertedGroupId: string; liveGroupId: string; liveTrafficGroupId: string } | null> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !effectiveTenantId) return null;

    const { data, error } = await supabase
      .rpc('get_or_create_client_system_groups', {
        p_admin_id: effectiveTenantId,
        p_user_id: user.id
      });

    if (error || !data || data.length === 0) return null;

    const row = data[0] as { converted_group_id: string; live_group_id: string; live_traffic_group_id: string };
    return {
      convertedGroupId: row.converted_group_id,
      liveGroupId: row.live_group_id,
      liveTrafficGroupId: row.live_traffic_group_id,
    };
  };

  return {
    groups,
    isLoading,
    error,
    ensureSystemGroups,
    addClientToGroup,
    addClientsToGroup,
    moveClientsToGroup,
    removeClientFromGroup,
    getSystemGroupIds,
  };
}
