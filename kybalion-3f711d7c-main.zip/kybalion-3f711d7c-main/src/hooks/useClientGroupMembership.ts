import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface ClientGroupMembership {
  groupId: string | null;
  groupName: string | null;
  isInLiveGroup: boolean;
  isLoading: boolean;
}

export function useClientGroupMembership(clientId: string): ClientGroupMembership {
  const { data, isLoading } = useQuery({
    queryKey: ["client-group-membership", clientId],
    queryFn: async () => {
      if (!clientId) return null;

      const { data, error } = await supabase
        .from("client_group_members")
        .select(`
          group_id,
          client_groups:group_id (
            id,
            name,
            is_system
          )
        `)
        .eq("client_id", clientId)
        .maybeSingle();

      if (error) {
        console.error("Error fetching client group membership:", error);
        return null;
      }

      return data;
    },
    enabled: !!clientId,
  });

  const groupInfo = data?.client_groups as { id: string; name: string; is_system: boolean } | null;

  return {
    groupId: groupInfo?.id || null,
    groupName: groupInfo?.name || null,
    isInLiveGroup: groupInfo?.name === "Live",
    isLoading,
  };
}
