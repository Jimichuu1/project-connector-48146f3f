import { useState } from "react";
import { Client } from "@/types/clients";

export function useClientActions(_userId: string | undefined) {
  const [showBankDialog, setShowBankDialog] = useState(false);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  const handleAddBank = (client: Client) => {
    setSelectedClient(client);
    setShowBankDialog(true);
  };

  const handleAddNote = (client: Client) => {
    setSelectedClient(client);
    setShowNoteDialog(true);
  };

  const handleCreateAccount = (_client: Client) => {
    // No-op: integration removed.
  };

  return {
    showBankDialog,
    setShowBankDialog,
    showNoteDialog,
    setShowNoteDialog,
    selectedClient,
    handleAddBank,
    handleAddNote,
    handleCreateAccount,
  };
}
