import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";

interface ManagerTeamInfo {
  teamMemberIds: string[];
  hasAgents: boolean;
  hasSuperAgents: boolean;
  agentIds: string[];
  superAgentIds: string[];
  canAccessClients: boolean;
  canAccessPipeline: boolean;
  isLoading: boolean;
}

/**
 * Hook to get manager's team composition and access rights
 * - Managers can only see users they created
 * - Access to Clients/Pipeline requires having SUPER_AGENTS in team
 */
export function useManagerTeam(): ManagerTeamInfo {
  const { session } = useAuth();
  const { isManager, isTeamLeader, loading: roleLoading } = useUserData();
  const userId = session?.user?.id;
  const isManagerOrTL = isManager || isTeamLeader;

  const { data, isLoading } = useQuery({
    queryKey: ['manager-team', userId, isManagerOrTL],
    enabled: isManagerOrTL && !!userId && !roleLoading,
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      // Get all users created by this manager
      const { data: teamMembers, error: profilesError } = await supabase
        .from('profiles')
        .select('id')
        .eq('created_by', userId!);

      if (profilesError) {
        console.error('[ManagerTeam] Profiles query error:', profilesError);
        throw profilesError;
      }

      if (!teamMembers || teamMembers.length === 0) {
        console.log('[ManagerTeam] No team members found for manager:', userId);
        return {
          teamMemberIds: [],
          agentIds: [],
          superAgentIds: [],
          hasAgents: false,
          hasSuperAgents: false,
        };
      }

      const memberIds = teamMembers.map(m => m.id);

      // Get roles for these team members
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .in('user_id', memberIds);

      if (rolesError) {
        console.error('[ManagerTeam] Roles query error:', rolesError);
        throw rolesError;
      }

      const agentIds: string[] = [];
      const superAgentIds: string[] = [];

      roles?.forEach((r) => {
        if (r.role === 'AGENT') {
          agentIds.push(r.user_id);
        } else if (r.role === 'SUPER_AGENT') {
          superAgentIds.push(r.user_id);
        }
      });

      console.log('[ManagerTeam] Team composition:', { 
        userId, 
        memberIds, 
        agentIds, 
        superAgentIds,
        hasSuperAgents: superAgentIds.length > 0 
      });

      return {
        teamMemberIds: [...agentIds, ...superAgentIds],
        agentIds,
        superAgentIds,
        hasAgents: agentIds.length > 0,
        hasSuperAgents: superAgentIds.length > 0,
      };
    },
  });

  // If not a manager or team leader, they have full access (handled by other role checks)
  if (!isManagerOrTL) {
    return {
      teamMemberIds: [],
      hasAgents: false,
      hasSuperAgents: false,
      agentIds: [],
      superAgentIds: [],
      canAccessClients: true,
      canAccessPipeline: true,
      isLoading: roleLoading,
    };
  }

  // While loading, allow access to prevent flashing/hiding menu items
  const stillLoading = isLoading || roleLoading;

  return {
    teamMemberIds: data?.teamMemberIds || [],
    hasAgents: data?.hasAgents || false,
    hasSuperAgents: data?.hasSuperAgents || false,
    agentIds: data?.agentIds || [],
    superAgentIds: data?.superAgentIds || [],
    // Managers/TLs need SUPER_AGENTS to access Clients/Pipeline
    // While loading, default to true to prevent menu flickering
    canAccessClients: stillLoading ? true : (data?.hasSuperAgents || false),
    canAccessPipeline: stillLoading ? true : (data?.hasSuperAgents || false),
    isLoading: stillLoading,
  };
}
