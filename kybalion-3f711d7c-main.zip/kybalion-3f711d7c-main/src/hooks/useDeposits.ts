import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useRef, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useTenant } from "@/contexts/TenantContext";
import { isValidUUID } from "@/lib/uuidUtils";

export interface Deposit {
  id: string;
  sale_branch_id: string;
  client_id: string;
  lead_id: string | null;
  amount: number;
  agent_id: string | null;
  super_agent_id: string | null;
  agent_percentage: number;
  super_agent_percentage: number;
  agent_amount: number;
  super_agent_amount: number;
  status: string;
  created_at: string;
  created_by: string;
  exchanges: string[] | null;
  admin_id: string | null;
  split_super_agent_id: string | null;
  split_super_agent_amount: number;
  closer_agent_id: string | null;
}

export interface DepositWithProfiles extends Deposit {
  agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  super_agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  split_super_agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  closer_agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  client?: {
    id: string;
    name: string;
    email: string;
  };
}

export const useDeposits = (startDate?: Date, endDate?: Date) => {
  const queryClient = useQueryClient();
  const { effectiveTenantId, loading: tenantLoading, isSuperAdmin } = useTenant();
  
  // Debounce timer for realtime updates
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  const { data: deposits, isLoading, error } = useQuery({
    queryKey: ['deposits', startDate, endDate, effectiveTenantId],
    // Wait for tenant context to load before querying
    // SUPER_ADMIN with no tenant selected (null) is allowed to query all
    // Validate UUID if effectiveTenantId is present
    enabled: !tenantLoading && (isSuperAdmin || effectiveTenantId !== undefined) && (!effectiveTenantId || isValidUUID(effectiveTenantId)),
    staleTime: 2 * 60 * 1000, // 2 minutes cache for deposits
    gcTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    queryFn: async () => {
      // Optimized column selection - only fetch needed deposit fields and minimal profile data
      let query = supabase
        .from('deposits')
        .select(`
          id, sale_branch_id, client_id, lead_id, amount, agent_id, super_agent_id,
          agent_percentage, super_agent_percentage, agent_amount, super_agent_amount,
          status, created_at, created_by, exchanges, admin_id, split_super_agent_id, split_super_agent_amount, closer_agent_id, counts_for_agent,
          agent:profiles!deposits_agent_id_fkey(id, full_name, email),
          super_agent:profiles!deposits_super_agent_id_fkey(id, full_name, email),
          client:clients!deposits_client_id_fkey(id, name, email)
        `)
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }

      if (startDate) {
        query = query.gte('created_at', startDate.toISOString());
      }
      if (endDate) {
        query = query.lte('created_at', endDate.toISOString());
      }

      const { data, error } = await query;

      if (error) throw error;
      
      // Fetch split super agent profiles separately for deposits that have them
      const depositsWithSplitAgents = data || [];
      const splitAgentIds = [...new Set(depositsWithSplitAgents
        .filter(d => d.split_super_agent_id)
        .map(d => d.split_super_agent_id))] as string[];
      
      let splitAgentProfiles: Record<string, { id: string; full_name: string | null; email: string }> = {};
      
      if (splitAgentIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .in('id', splitAgentIds);
        
        if (profiles) {
          splitAgentProfiles = profiles.reduce((acc, p) => {
            acc[p.id] = p;
            return acc;
          }, {} as Record<string, { id: string; full_name: string | null; email: string }>);
        }
      }
      
      // Attach split_super_agent to deposits
      return depositsWithSplitAgents.map(d => ({
        ...d,
        split_super_agent: d.split_super_agent_id ? splitAgentProfiles[d.split_super_agent_id] : undefined,
      })) as DepositWithProfiles[];
    },
  });

  // Debounced invalidation to prevent query storms
  const debouncedInvalidate = useCallback(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ['deposits'] });
    }, 1000); // 1 second debounce
  }, [queryClient]);

  // Set up real-time subscription for deposits changes - FILTERED by admin_id
  useEffect(() => {
    // Build filter for real-time subscription - validate UUID to prevent "undefined" string
    const filter = isValidUUID(effectiveTenantId) 
      ? `admin_id=eq.${effectiveTenantId}` 
      : undefined;

    const channel = supabase
      .channel('deposits-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'deposits',
          ...(filter && { filter }),
        },
        () => {
          // Debounced invalidation instead of immediate
          debouncedInvalidate();
        }
      )
      .subscribe();

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      supabase.removeChannel(channel);
    };
  }, [queryClient, effectiveTenantId, debouncedInvalidate]);

  return {
    deposits,
    isLoading,
    error,
  };
};
