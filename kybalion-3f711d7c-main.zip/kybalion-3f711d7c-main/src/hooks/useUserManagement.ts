import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Enums } from "@/integrations/supabase/types";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useTenant } from "@/contexts/TenantContext";
import { useUserRole } from "@/hooks/useUserRole";
import { getErrorMessage } from "@/types/errors";
import { z } from "zod";
import { UserWithIpWhitelist, AppRole } from "@/types/users";

export const userNameSchema = z.object({
  full_name: z.string().trim().min(1, {
    message: "Name cannot be empty"
  }).max(100, {
    message: "Name must be less than 100 characters"
  }).regex(/^[a-zA-Z\s\-']+$/, {
    message: "Name can only contain letters, spaces, hyphens, and apostrophes"
  })
});

export function useUserManagement(userId: string | undefined) {
  const { toast } = useToast();
  const { logAction } = useAuditLog();
  const { effectiveTenantId } = useTenant();
  const { isManager, loading: roleLoading } = useUserRole();
  
  const [currentUserRole, setCurrentUserRole] = useState<AppRole | null>(null);
  const [users, setUsers] = useState<UserWithIpWhitelist[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Wait for role loading AND tenant context to be ready
    // effectiveTenantId === undefined means still loading
    if (!roleLoading && effectiveTenantId !== undefined) {
      fetchUsers();
      fetchCurrentUserRole();
    }
  }, [userId, effectiveTenantId, roleLoading, isManager]);

  const fetchCurrentUserRole = async () => {
    if (!userId) return;
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .maybeSingle();
    setCurrentUserRole(data?.role || null);
  };

  const canDeleteUser = (targetUserRole?: AppRole) => {
    if (!currentUserRole) return false;
    if (currentUserRole === 'SUPER_ADMIN') return true;
    if (currentUserRole === 'TENANT_OWNER') {
      return targetUserRole !== 'SUPER_ADMIN';
    }
    return false;
  };

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      // Hide soft-deleted users from the active user-management list (they remain in DB for history)
      let profilesQuery = supabase.from("profiles").select("*").is("deleted_at", null).order("created_at", { ascending: false });
      
      // Manager sees only their team (users they created)
      if (isManager && userId) {
        profilesQuery = profilesQuery.eq("created_by", userId);
      } else if (effectiveTenantId) {
        // Filter by admin_id (tenant) for non-managers
        profilesQuery = profilesQuery.eq("admin_id", effectiveTenantId);
      }
      
      const { data: profiles, error: profilesError } = await profilesQuery;
      
      if (profilesError) throw profilesError;

      // Fetch all profiles for looking up tenant and creator names (for super admin view)
      const { data: allProfiles } = await supabase.from("profiles").select("id, full_name, email");
      const profileLookup = new Map(allProfiles?.map(p => [p.id, p]) || []);

      const usersWithData = await Promise.all(profiles.map(async profile => {
        const { data: roleData } = await supabase.from("user_roles").select("role").eq("user_id", profile.id).maybeSingle();
        const { data: ipData } = await supabase.from("ip_whitelist").select("id, ip_address, is_active").eq("user_id", profile.id);
        
        // Look up tenant and creator names
        const tenantProfile = profile.admin_id ? profileLookup.get(profile.admin_id) : null;
        const creatorProfile = profile.created_by ? profileLookup.get(profile.created_by) : null;
        
        return {
          ...profile,
          role: roleData?.role,
          ip_whitelist: ipData || [],
          tenant_name: tenantProfile?.full_name || tenantProfile?.email || null,
          created_by_name: creatorProfile?.full_name || creatorProfile?.email || null
        };
      }));
      
      const filteredUsers = usersWithData.filter(u => 
        u.role !== 'TENANT_OWNER' && u.role !== 'SUPER_ADMIN'
      );
      
      setUsers(filteredUsers);
    } catch (error) {
      toast({ title: "Error", description: getErrorMessage(error, "Failed to fetch users"), variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveUser = async (
    selectedUser: UserWithIpWhitelist,
    editedFullName: string,
    editedUsername: string,
    selectedRole: AppRole,
    isCloser = false
  ) => {
    try {
      userNameSchema.parse({ full_name: editedFullName });
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw new Error(error.errors[0].message);
      }
    }

    const { error: profileError } = await supabase.from("profiles").update({
      full_name: editedFullName.trim(),
      username: editedUsername.trim(),
      is_closer: selectedRole === "AGENT" ? isCloser : false
    }).eq("id", selectedUser.id);

    if (profileError) throw profileError;

    const { error: deleteError } = await supabase
      .from("user_roles")
      .delete()
      .eq("user_id", selectedUser.id);
    
    if (deleteError) {
      throw new Error(`Failed to update role: ${deleteError.message}`);
    }
    
    const { error: insertError } = await supabase.from("user_roles").insert({
      user_id: selectedUser.id,
      role: selectedRole
    });
    
    if (insertError) {
      throw new Error(`Failed to assign new role: ${insertError.message}`);
    }

    toast({ title: "User updated successfully" });
    fetchUsers();
  };

  const handleResetPassword = async (userToReset: UserWithIpWhitelist, newPassword: string) => {
    if (!newPassword.trim()) {
      throw new Error("Please enter a new password");
    }
    if (newPassword.length < 6) {
      throw new Error("Password must be at least 6 characters");
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) throw new Error('No active session');

    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-user-password`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${session.access_token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        action: 'update-password',
        userId: userToReset.id,
        newPassword: newPassword
      })
    });

    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Failed to reset password');

    await logAction({
      actionType: 'password_reset',
      entityType: 'user',
      entityId: userToReset.id,
      details: {
        target_username: userToReset.username,
        target_user_id: userToReset.id
      }
    });

    toast({ title: "Password reset successfully" });
  };

  const handleDeleteUser = async (targetUserId: string, force: boolean = false): Promise<{ needsConfirmation?: boolean; assignedClientsCount?: number; assignedLeadsCount?: number }> => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error("No active session. Please log in again.");
    }

    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-user-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({
        action: 'delete-user',
        userId: targetUserId,
        force
      })
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || 'Failed to delete user');
    }

    if (result.needsConfirmation) {
      return {
        needsConfirmation: true,
        assignedClientsCount: result.assignedClientsCount,
        assignedLeadsCount: result.assignedLeadsCount
      };
    }

    await logAction({
      actionType: 'user_deleted',
      entityType: 'user',
      entityId: targetUserId,
      details: {
        force_delete: force,
        had_assignments: result.assignedClientsCount > 0 || result.assignedLeadsCount > 0
      }
    });

    toast({ title: "User deleted successfully" });
    fetchUsers();
    return {};
  };

  const handleBulkPasswordReset = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error("No active session. Please log in again.");
    }

    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-user-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({
        action: 'bulk-update-password',
        newPassword: '123456',
        excludeAdmins: true
      })
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || 'Failed to reset passwords');
    }

    toast({ title: `Successfully reset passwords for ${result.updated} users` });
    if (result.failed > 0) {
      toast({ title: `Failed to reset ${result.failed} user passwords`, variant: "destructive" });
    }
  };

  const handleAddIp = async (targetUserId: string, ipAddress: string) => {
    const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    const ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
    
    const trimmedIp = ipAddress.trim();
    if (!ipv4Regex.test(trimmedIp) && !ipv6Regex.test(trimmedIp)) {
      throw new Error("Invalid IP address format. Please enter a valid IPv4 or IPv6 address.");
    }

    const existingUser = users.find(u => u.id === targetUserId);
    if (existingUser?.ip_whitelist && existingUser.ip_whitelist.length > 0) {
      throw new Error("User can only have one IP address. Please remove the existing IP first.");
    }

    const { error } = await supabase.from("ip_whitelist").insert({
      user_id: targetUserId,
      ip_address: trimmedIp,
      created_by: userId
    });

    if (error) throw error;

    await logAction({
      actionType: 'ip_whitelist_added',
      entityType: 'ip_whitelist',
      entityId: targetUserId,
      details: {
        ip_address: trimmedIp,
        target_user_id: targetUserId
      }
    });

    toast({ title: "IP address added successfully" });
    fetchUsers();
  };

  const handleRemoveIp = async (ipId: string) => {
    const { error } = await supabase.from("ip_whitelist").delete().eq("id", ipId);
    if (error) throw error;

    await logAction({
      actionType: 'ip_whitelist_removed',
      entityType: 'ip_whitelist',
      details: { ip_id: ipId }
    });

    toast({ title: "IP address removed successfully" });
    fetchUsers();
  };

  return {
    users,
    isLoading,
    currentUserRole,
    canDeleteUser,
    fetchUsers,
    handleSaveUser,
    handleResetPassword,
    handleDeleteUser,
    handleBulkPasswordReset,
    handleAddIp,
    handleRemoveIp,
  };
}
