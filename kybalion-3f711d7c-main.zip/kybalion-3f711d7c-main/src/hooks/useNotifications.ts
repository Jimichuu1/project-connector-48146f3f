import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Notification } from "@/types/notifications";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useRef, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";

export const useNotifications = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const notifiedIdsRef = useRef<Set<string>>(new Set());

  const { data: notifications, isLoading } = useQuery({
    queryKey: ['notifications', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      return data as Notification[];
    },
    enabled: !!user?.id,
    staleTime: 60 * 1000, // 1 minute - reduce refetches
    gcTime: 5 * 60 * 1000, // 5 minutes cache
  });

  // Debounced invalidation to batch realtime updates
  const invalidateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const debouncedInvalidate = useCallback(() => {
    if (invalidateTimeoutRef.current) {
      clearTimeout(invalidateTimeoutRef.current);
    }
    invalidateTimeoutRef.current = setTimeout(() => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    }, 1000);
  }, [queryClient]);

  // Subscribe to real-time updates
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel(`notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('[Notification] Real-time payload received:', payload);
          const newNotification = payload.new as Notification;
          
          // Prevent duplicate toasts
          if (!notifiedIdsRef.current.has(newNotification.id)) {
            notifiedIdsRef.current.add(newNotification.id);
            
            // Show toast for new notification
            toast({
              title: "New notification",
              description: newNotification.message,
            });
          }
          
          debouncedInvalidate();
        }
      )
      .subscribe((status) => {
        console.log('[Notification] Subscription status:', status);
      });

    return () => {
      if (invalidateTimeoutRef.current) {
        clearTimeout(invalidateTimeoutRef.current);
      }
      supabase.removeChannel(channel);
    };
  }, [user?.id, toast, debouncedInvalidate]);

  const markAsRead = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', id);

      if (error) throw error;
    },
    // Optimistic update
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ['notifications'] });
      
      const previousNotifications = queryClient.getQueryData<Notification[]>(['notifications', user?.id]);
      
      queryClient.setQueryData<Notification[]>(['notifications', user?.id], (old) =>
        old?.map((n) => (n.id === id ? { ...n, is_read: true } : n))
      );
      
      return { previousNotifications };
    },
    onError: (_err, _id, context) => {
      queryClient.setQueryData(['notifications', user?.id], context?.previousNotifications);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsRead = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error("Not authenticated");

      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false);

      if (error) throw error;
    },
    // Optimistic update
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ['notifications'] });
      
      const previousNotifications = queryClient.getQueryData<Notification[]>(['notifications', user?.id]);
      
      queryClient.setQueryData<Notification[]>(['notifications', user?.id], (old) =>
        old?.map((n) => ({ ...n, is_read: true }))
      );
      
      return { previousNotifications };
    },
    onError: (_err, _vars, context) => {
      queryClient.setQueryData(['notifications', user?.id], context?.previousNotifications);
    },
    onSuccess: () => {
      toast({
        title: "All notifications marked as read",
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // Dismiss notification now just marks as read instead of deleting
  const dismissNotification = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', id);

      if (error) throw error;
    },
    // Optimistic update
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ['notifications'] });
      
      const previousNotifications = queryClient.getQueryData<Notification[]>(['notifications', user?.id]);
      
      queryClient.setQueryData<Notification[]>(['notifications', user?.id], (old) =>
        old?.map((n) => (n.id === id ? { ...n, is_read: true } : n))
      );
      
      return { previousNotifications };
    },
    onError: (_err, _id, context) => {
      queryClient.setQueryData(['notifications', user?.id], context?.previousNotifications);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const unreadCount = notifications?.filter(n => !n.is_read).length || 0;

  return {
    notifications,
    isLoading,
    unreadCount,
    markAsRead,
    markAllAsRead,
    dismissNotification,
  };
};
