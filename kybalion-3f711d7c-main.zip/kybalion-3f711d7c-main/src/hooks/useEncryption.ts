import { supabase } from "@/integrations/supabase/client";

/**
 * Hook for client-side encryption utilities and database encryption functions
 */
export const useEncryption = () => {
  /**
   * Encrypt data using SHA-256 (for hashing, not reversible)
   */
  const hashData = async (data: string): Promise<string> => {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  /**
   * Encrypt sensitive data using database encryption function
   */
  const encryptSensitive = async (data: string): Promise<string | null> => {
    if (!data) return null;
    
    const { data: result, error } = await supabase.rpc('encrypt_sensitive', {
      p_data: data
    });
    
    if (error) {
      console.error("Encryption error:", error);
      return null;
    }
    
    return result;
  };

  /**
   * Decrypt sensitive data using database decryption function
   */
  const decryptSensitive = async (encryptedData: string): Promise<string | null> => {
    if (!encryptedData) return null;
    
    const { data: result, error } = await supabase.rpc('decrypt_sensitive', {
      p_encrypted: encryptedData
    });
    
    if (error) {
      console.error("Decryption error:", error);
      return null;
    }
    
    return result;
  };

  /**
   * Hash a token for secure storage comparison
   */
  const hashToken = async (token: string): Promise<string | null> => {
    if (!token) return null;
    
    const { data: result, error } = await supabase.rpc('hash_token', {
      p_token: token
    });
    
    if (error) {
      console.error("Token hash error:", error);
      // Fallback to client-side hashing
      return hashData(token);
    }
    
    return result;
  };

  return {
    hashData,
    encryptSensitive,
    decryptSensitive,
    hashToken,
  };
};
