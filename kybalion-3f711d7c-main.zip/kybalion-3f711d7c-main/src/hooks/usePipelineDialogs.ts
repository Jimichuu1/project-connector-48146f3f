import { useState, useCallback } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PipelineStage, SaleBranchWithClient } from "@/types/pipeline";

interface UsePipelineDialogsProps {
  updateBranch: {
    mutate: (data: { id: string; status?: PipelineStage; value?: number }) => void;
  };
  onClearPendingDrop: () => void;
  branches?: SaleBranchWithClient[];
}

interface PendingDepositInfo {
  depositId: string;
  amount: number;
  clientName: string;
  agentName?: string;
  superAgentName?: string;
}

export function usePipelineDialogs({
  updateBranch,
  onClearPendingDrop,
  branches,
}: UsePipelineDialogsProps) {
  // Create opportunity dialog
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<{
    id: string;
    name: string;
  } | null>(null);

  // Deposit dialog
  const [depositDialogOpen, setDepositDialogOpen] = useState(false);
  const [depositBranchId, setDepositBranchId] = useState<string | null>(null);
  const [depositLeadId, setDepositLeadId] = useState<string | null>(null);

  // Deposit info dialog
  const [depositInfoDialogOpen, setDepositInfoDialogOpen] = useState(false);
  const [depositInfoBranchId, setDepositInfoBranchId] = useState<string | null>(null);

  // Deposit approval dialog (for pending deposits)
  const [depositApprovalDialogOpen, setDepositApprovalDialogOpen] = useState(false);
  const [pendingDepositInfo, setPendingDepositInfo] = useState<PendingDepositInfo | null>(null);

  // Flipped confirm dialog
  const [flippedDialogOpen, setFlippedDialogOpen] = useState(false);
  const [flippedBranchId, setFlippedBranchId] = useState<string | null>(null);
  const [flippedReason, setFlippedReason] = useState<string>("");

  const openDepositDialog = useCallback((branchId: string, leadId: string | null) => {
    setDepositBranchId(branchId);
    setDepositLeadId(leadId);
    setDepositDialogOpen(true);
  }, []);

  const openFlippedDialog = useCallback((branchId: string) => {
    setFlippedBranchId(branchId);
    setFlippedDialogOpen(true);
  }, []);

  const handleDepositConfirm = useCallback(
    (depositAmount: number) => {
      if (depositBranchId) {
        updateBranch.mutate({
          id: depositBranchId,
          status: "DEPOSIT",
          value: depositAmount,
        });
        setDepositDialogOpen(false);
        setDepositBranchId(null);
        setDepositLeadId(null);
        onClearPendingDrop();
        toast.success("Deposit recorded successfully");
      }
    },
    [depositBranchId, updateBranch, onClearPendingDrop]
  );

  const handleDepositCancel = useCallback(() => {
    setDepositDialogOpen(false);
    setDepositBranchId(null);
    setDepositLeadId(null);
    onClearPendingDrop();
  }, [onClearPendingDrop]);

  const handleFlippedConfirm = useCallback(async (reason?: string) => {
    if (flippedBranchId) {
      try {
        // Find the branch to get client info
        const branch = branches?.find(b => b.id === flippedBranchId);
        if (!branch) {
          toast.error("Branch not found");
          return;
        }

        // Get current user
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          toast.error("Not authenticated");
          return;
        }

        // Get user's admin_id for tenant context
        const { data: profile } = await supabase
          .from('profiles')
          .select('admin_id')
          .eq('id', user.id)
          .single();

        // Get client's assigned_to (super_agent) and transferring_agent (agent)
        const { data: clientData } = await supabase
          .from('clients')
          .select('assigned_to, transferring_agent')
          .eq('id', branch.client_id)
          .single();

        // Create flipped record with historical attribution
        const { error: flippedError } = await supabase
          .from('flipped_records')
          .insert({
            sale_branch_id: flippedBranchId,
            client_id: branch.client_id,
            agent_id: clientData?.transferring_agent || null,
            super_agent_id: clientData?.assigned_to || null,
            flipped_by: user.id,
            reason: reason || flippedReason || null,
            admin_id: profile?.admin_id || null,
          });

        if (flippedError) {
          console.error('Failed to create flipped record:', flippedError);
          toast.error("Failed to create flipped record");
          return;
        }

        // Update the branch status
        updateBranch.mutate({ id: flippedBranchId, status: "FLIPPED" });
        setFlippedDialogOpen(false);
        setFlippedBranchId(null);
        setFlippedReason("");
        onClearPendingDrop();
        toast.success("Moved to Flipped");
      } catch (error) {
        console.error('Error in handleFlippedConfirm:', error);
        toast.error("An error occurred");
      }
    }
  }, [flippedBranchId, branches, updateBranch, onClearPendingDrop, flippedReason]);

  const handleFlippedCancel = useCallback(() => {
    setFlippedDialogOpen(false);
    setFlippedBranchId(null);
    setFlippedReason("");
    onClearPendingDrop();
    toast.info("Move to Flipped cancelled");
  }, [onClearPendingDrop]);

  const handleCardClick = useCallback((branch: SaleBranchWithClient, isAdminOrManager: boolean = false) => {
    if (branch.status === "DEPOSIT") {
      // Check if pending and user is admin/manager - show approval dialog
      const isPending = branch.deposit_status === "pending" || (!branch.deposit_status && branch.status === "DEPOSIT");
      
      if (isPending && isAdminOrManager && branch.deposit_id) {
        setPendingDepositInfo({
          depositId: branch.deposit_id,
          amount: branch.value,
          clientName: branch.client?.name || "Unknown Client",
          agentName: branch.agent?.full_name || branch.agent?.email,
          superAgentName: branch.super_agent?.full_name || branch.super_agent?.email,
        });
        setDepositApprovalDialogOpen(true);
      } else {
        // Show info dialog for non-pending or non-admin users
        setDepositInfoBranchId(branch.id);
        setDepositInfoDialogOpen(true);
      }
    }
  }, []);

  const handleAddOpportunity = useCallback(
    (client: { id: string; name: string }) => {
      setSelectedClient(client);
      setCreateDialogOpen(true);
    },
    []
  );

  return {
    // Create dialog
    createDialogOpen,
    setCreateDialogOpen,
    selectedClient,
    handleAddOpportunity,
    
    // Deposit dialog
    depositDialogOpen,
    depositBranchId,
    depositLeadId,
    openDepositDialog,
    handleDepositConfirm,
    handleDepositCancel,
    setDepositDialogOpen,
    
    // Deposit info dialog
    depositInfoDialogOpen,
    depositInfoBranchId,
    setDepositInfoDialogOpen,
    
    // Deposit approval dialog
    depositApprovalDialogOpen,
    setDepositApprovalDialogOpen,
    pendingDepositInfo,
    
    // Flipped dialog
    flippedDialogOpen,
    flippedBranchId,
    openFlippedDialog,
    handleFlippedConfirm,
    handleFlippedCancel,
    setFlippedDialogOpen,
    
    // Card actions
    handleCardClick,
  };
}
