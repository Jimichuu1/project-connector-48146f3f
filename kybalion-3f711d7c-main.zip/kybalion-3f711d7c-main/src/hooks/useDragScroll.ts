import { useRef, useEffect, useCallback } from "react";

export function useDragScroll<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const isDragging = useRef(false);
  const startX = useRef(0);
  const scrollLeft = useRef(0);

  const onMouseDown = useCallback((e: MouseEvent) => {
    const element = ref.current;
    if (!element) return;
    
    isDragging.current = true;
    startX.current = e.pageX - element.offsetLeft;
    scrollLeft.current = element.scrollLeft;
    element.style.cursor = "grabbing";
    element.style.userSelect = "none";
  }, []);

  const onMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging.current) return;
    const element = ref.current;
    if (!element) return;

    e.preventDefault();
    const x = e.pageX - element.offsetLeft;
    const walk = (x - startX.current) * 1.5; // Scroll speed multiplier
    element.scrollLeft = scrollLeft.current - walk;
  }, []);

  const onMouseUp = useCallback(() => {
    const element = ref.current;
    if (!element) return;
    
    isDragging.current = false;
    element.style.cursor = "grab";
    element.style.userSelect = "";
  }, []);

  const onMouseLeave = useCallback(() => {
    const element = ref.current;
    if (!element) return;
    
    isDragging.current = false;
    element.style.cursor = "grab";
    element.style.userSelect = "";
  }, []);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    element.style.cursor = "grab";

    element.addEventListener("mousedown", onMouseDown);
    element.addEventListener("mousemove", onMouseMove);
    element.addEventListener("mouseup", onMouseUp);
    element.addEventListener("mouseleave", onMouseLeave);

    return () => {
      element.removeEventListener("mousedown", onMouseDown);
      element.removeEventListener("mousemove", onMouseMove);
      element.removeEventListener("mouseup", onMouseUp);
      element.removeEventListener("mouseleave", onMouseLeave);
    };
  }, [onMouseDown, onMouseMove, onMouseUp, onMouseLeave]);

  return ref;
}
