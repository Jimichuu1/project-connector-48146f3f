import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Module-level singleton for server time.
 * Previously each consumer fetched independently, leading to 5+ duplicate
 * `get_server_time` RPCs in parallel. Now there is one fetch + one 5-min
 * interval shared by all subscribers.
 */
type State = {
  serverNow: Date | null;
  isLoading: boolean;
  error: Error | null;
};

let state: State = { serverNow: null, isLoading: true, error: null };
const subscribers = new Set<(s: State) => void>();
let initialized = false;
let intervalId: ReturnType<typeof setInterval> | null = null;
let inflight: Promise<void> | null = null;

function setState(next: Partial<State>) {
  state = { ...state, ...next };
  subscribers.forEach((cb) => cb(state));
}

async function fetchServerTimeOnce(): Promise<void> {
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const { data, error: queryError } = await supabase
        .rpc('get_server_time') as { data: string | null; error: Error | null };

      if (queryError || !data) {
        console.warn('[useServerNow] RPC failed:', queryError);
        setState({
          error: queryError || new Error('No data returned'),
          serverNow: state.serverNow ?? new Date(),
          isLoading: false,
        });
        return;
      }
      setState({ serverNow: new Date(data), error: null, isLoading: false });
    } catch (err) {
      console.error('[useServerNow] Error fetching server time:', err);
      setState({
        error: err as Error,
        serverNow: state.serverNow ?? new Date(),
        isLoading: false,
      });
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

function ensureInitialized() {
  if (initialized) return;
  initialized = true;
  fetchServerTimeOnce();
  intervalId = setInterval(fetchServerTimeOnce, 5 * 60 * 1000);
}

/**
 * Hook to get server time instead of relying on device clock.
 * Shares one fetch across the whole app.
 */
export function useServerNow() {
  const [, force] = useState(0);

  useEffect(() => {
    ensureInitialized();
    const cb = () => force((n) => n + 1);
    subscribers.add(cb);
    return () => {
      subscribers.delete(cb);
    };
  }, []);

  const refetch = useCallback(() => {
    fetchServerTimeOnce();
  }, []);

  return {
    serverNow: state.serverNow,
    isLoading: state.isLoading,
    error: state.error,
    refetch,
  };
}

/**
 * Get "today" date normalized to start of day based on server time and timezone.
 * Uses formatToParts for cross-browser reliability.
 */
export function getServerToday(serverNow: Date | null, timezone?: string): Date {
  const now = serverNow || new Date();

  if (timezone) {
    try {
      const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone: timezone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      });

      const parts = formatter.formatToParts(now);
      const year = parseInt(parts.find(p => p.type === 'year')?.value || '0', 10);
      const month = parseInt(parts.find(p => p.type === 'month')?.value || '0', 10);
      const day = parseInt(parts.find(p => p.type === 'day')?.value || '0', 10);

      return new Date(year, month - 1, day, 0, 0, 0, 0);
    } catch (err) {
      console.warn('[getServerToday] Invalid timezone, using local:', err);
    }
  }

  const today = new Date(now);
  today.setHours(0, 0, 0, 0);
  return today;
}

/**
 * Get "today" as YYYY-MM-DD string based on server time and timezone.
 */
export function getServerTodayKey(serverNow: Date | null, timezone?: string): string {
  const now = serverNow || new Date();

  if (timezone) {
    try {
      const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone: timezone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      });

      const parts = formatter.formatToParts(now);
      const year = parts.find(p => p.type === 'year')?.value || '0000';
      const month = parts.find(p => p.type === 'month')?.value || '00';
      const day = parts.find(p => p.type === 'day')?.value || '00';

      return `${year}-${month}-${day}`;
    } catch (err) {
      console.warn('[getServerTodayKey] Invalid timezone:', err);
    }
  }

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Format a date as YYYY-MM-DD in a specific timezone.
 */
export function formatDateInTimezone(date: Date, timezone?: string): string {
  return getServerTodayKey(date, timezone);
}
