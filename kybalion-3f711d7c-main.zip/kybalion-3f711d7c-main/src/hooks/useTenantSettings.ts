import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export interface TenantSettings {
  id: string;
  admin_id: string;
  work_start_time: string;
  work_end_time: string;
  late_start_fee: number;
  excessive_break_fee: number;
  max_break_minutes: number;
  day_off_fee: number;
  show_phone_to_agents: boolean;
  show_phone_to_super_agents: boolean | null;
  celebration_sound_url: string | null;
  celebration_video_url: string | null;
  password_protection_config: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
  conversion_target_per_agent?: number;
}

export function useTenantSettings() {
  const { user } = useAuth();
  const { isSuperAdmin, tenants, selectedTenantId } = useTenant();
  const queryClient = useQueryClient();

  const [managingTenantId, setManagingTenantId] = useState<string | null>(null);

  useEffect(() => {
    if (isSuperAdmin) {
      setManagingTenantId(selectedTenantId);
    } else if (user) {
      setManagingTenantId(user.id);
    }
  }, [isSuperAdmin, selectedTenantId, user]);

  const { data: settings, isLoading, refetch } = useQuery({
    queryKey: ["tenant-settings", managingTenantId],
    queryFn: async () => {
      if (!managingTenantId) return null;

      const { error: ensureError } = await supabase
        .rpc("get_or_create_tenant_settings", { p_tenant_id: managingTenantId });

      if (ensureError) {
        console.error("Error ensuring settings:", ensureError);
      }

      const { data, error } = await supabase
        .from("admin_settings")
        .select("*")
        .eq("admin_id", managingTenantId)
        .single();

      if (error) throw error;
      return data as unknown as TenantSettings;
    },
    enabled: !!managingTenantId,
  });

  const updateSettings = useMutation({
    mutationFn: async (updates: Partial<TenantSettings>) => {
      if (!settings?.id) throw new Error("No settings to update");

      const { error } = await supabase
        .from("admin_settings")
        .update(updates as never)
        .eq("id", settings.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tenant-settings", managingTenantId] });
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to update settings");
    },
  });

  return {
    settings,
    isLoading,
    refetch,
    updateSettings: updateSettings.mutate,
    isUpdating: updateSettings.isPending,
    managingTenantId,
    setManagingTenantId: isSuperAdmin ? setManagingTenantId : undefined,
    availableTenants: isSuperAdmin ? tenants : [],
    isSuperAdmin,
  };
}
