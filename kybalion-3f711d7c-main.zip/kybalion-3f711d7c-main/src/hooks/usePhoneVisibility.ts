import { useUserData } from "@/contexts/UserDataContext";

/**
 * @deprecated Use useUserData().canViewPhone instead for better performance.
 * This hook is kept for backwards compatibility only.
 * 
 * The centralized UserDataContext fetches all user data (role, settings, visibility)
 * in a single query, eliminating redundant database calls.
 */
export function usePhoneVisibility() {
  const { settings, loading: isLoading, canViewPhone } = useUserData();

  return {
    showPhoneToAgents: settings.show_phone_to_agents,
    showPhoneToSuperAgents: settings.show_phone_to_super_agents,
    canViewPhone,
    isLoading,
  };
}
