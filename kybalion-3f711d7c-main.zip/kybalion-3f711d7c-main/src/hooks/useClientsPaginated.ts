/**
 * Server-side paginated version of useClients hook with debounced realtime
 * Optimized for large datasets with proper server-side filtering
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Client, PipelineStatus } from "@/types/clients";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useRef, useCallback } from "react";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useTenant } from "@/contexts/TenantContext";
import { useAuth } from "@/contexts/AuthContext";
import { PaginationParams, calculatePagination, getOffsetAndLimit } from "@/types/pagination";
import { isValidUUID } from "@/lib/uuidUtils";
import { getAllPhonePrefixesForCountry } from "@/lib/phoneCountryCode";

// Debounce delay for batching realtime updates - increased for heavy operations
const REALTIME_DEBOUNCE_MS = 1000;
// Maximum pending updates before forcing full invalidation
const MAX_PENDING_UPDATES = 100;

// Optimized column selection - only fetch what's needed for table display
const CLIENT_COLUMNS = 'id, name, email, country, home_phone, status, pipeline_status, assigned_to, balance, equity, deposits, created_at, updated_at, admin_id, converted_from_lead_id, transferring_agent, seq_id';

interface ClientFilters {
  assignedTo?: string;
  assignedToList?: string[];
  search?: string;
  status?: string;
  statuses?: string[];
  pipelineStatus?: PipelineStatus;
  countries?: string[];
  teamMemberIds?: string[];
  groupIds?: string[];
  hasDeposited?: boolean;
}

export const useClientsPaginated = (
  filters?: ClientFilters,
  pagination: PaginationParams = { page: 1, pageSize: 50 }
) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();
  const { effectiveTenantId } = useTenant();
  const { user } = useAuth();
  const { offset, limit } = getOffsetAndLimit(pagination.page, pagination.pageSize);

  // Track pending updates for debouncing and mutation tracking
  const pendingUpdatesRef = useRef<Map<string, Partial<Client>>>(new Map());
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const recentMutationIdsRef = useRef<Set<string>>(new Set());
  const bulkOperationInProgressRef = useRef(false);

  // Only run queries when we have a valid tenant context
  const isTenantReady = effectiveTenantId === null || isValidUUID(effectiveTenantId);

  // Apply pending updates in batch
  const applyPendingUpdates = useCallback(() => {
    // Skip if bulk operation in progress
    if (bulkOperationInProgressRef.current) return;
    
    const updates = pendingUpdatesRef.current;
    if (updates.size === 0) return;

    // If too many pending updates, just invalidate
    if (updates.size > MAX_PENDING_UPDATES) {
      pendingUpdatesRef.current = new Map();
      queryClient.invalidateQueries({ queryKey: ['clients-paginated'] });
      return;
    }

    queryClient.setQueriesData(
      { queryKey: ['clients-paginated'] },
      (oldData: Client[] | undefined) => {
        if (!oldData) return oldData;
        return oldData.map(client => {
          const update = updates.get(client.id);
          return update ? { ...client, ...update } : client;
        });
      }
    );

    pendingUpdatesRef.current = new Map();
  }, [queryClient]);

  // Helper to track mutations (prevents processing our own realtime updates)
  // Extended timeout (30s) to handle delayed realtime events during bulk operations
  const trackMutatedIds = useCallback((ids: string[]) => {
    ids.forEach(id => recentMutationIdsRef.current.add(id));
    setTimeout(() => {
      ids.forEach(id => recentMutationIdsRef.current.delete(id));
    }, 30000);
  }, []);

  // Query to get client IDs in selected groups (for group filtering)
  const { data: clientIdsInGroups } = useQuery({
    queryKey: ['clients-in-groups', filters?.groupIds],
    enabled: !!filters?.groupIds && filters.groupIds.length > 0,
    staleTime: 60 * 1000,
    queryFn: async () => {
      const { data } = await supabase
        .from('client_group_members')
        .select('client_id')
        .in('group_id', filters!.groupIds!);
      return data?.map(m => m.client_id) || [];
    },
  });

  // Query to get client IDs that have deposits (for hasDeposited filter)
  const { data: depositedClientIds } = useQuery({
    queryKey: ['clients-with-deposits', effectiveTenantId],
    enabled: !!filters?.hasDeposited,
    staleTime: 2 * 60 * 1000,
    queryFn: async () => {
      let query = supabase
        .from('deposits')
        .select('client_id');
      
      if (effectiveTenantId && typeof effectiveTenantId === 'string') {
        query = query.eq('admin_id', effectiveTenantId);
      }
      
      const { data } = await query;
      // Return unique client IDs
      return [...new Set(data?.map(d => d.client_id) || [])];
    },
  });

  // Count query - use longer stale time to reduce DB load
  const { data: totalCount = 0 } = useQuery({
    queryKey: ['clients-count', filters, effectiveTenantId, clientIdsInGroups, depositedClientIds],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    enabled: isTenantReady && 
      (!(filters?.groupIds?.length) || clientIdsInGroups !== undefined) &&
      (!(filters?.hasDeposited) || depositedClientIds !== undefined),
    queryFn: async () => {
      let query = supabase
        .from('clients_secure' as any)
        .select('*', { count: 'exact', head: true });

      query = applyFilters(query, filters, effectiveTenantId, clientIdsInGroups, depositedClientIds);

      const { count } = await query;
      return count || 0;
    },
  });

  // Paginated data query with optimized column selection and seq_id ordering
  const { data: clients, isLoading, error } = useQuery({
    queryKey: ['clients-paginated', filters, effectiveTenantId, pagination.page, pagination.pageSize, clientIdsInGroups, depositedClientIds],
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    enabled: isTenantReady && 
      (!(filters?.groupIds?.length) || clientIdsInGroups !== undefined) &&
      (!(filters?.hasDeposited) || depositedClientIds !== undefined),
    queryFn: async () => {
      // If group filter is active but no clients in those groups, return empty
      if (filters?.groupIds?.length && clientIdsInGroups?.length === 0) {
        return [] as Client[];
      }
      
      // If hasDeposited filter is active but no deposited clients, return empty
      if (filters?.hasDeposited && depositedClientIds?.length === 0) {
        return [] as Client[];
      }

      let query = supabase
        .from('clients_secure' as any)
        .select(CLIENT_COLUMNS)
        .order('updated_at', { ascending: false }) // Order by last modified first
        .range(offset, offset + limit - 1);

      query = applyFilters(query, filters, effectiveTenantId, clientIdsInGroups, depositedClientIds);

      const { data, error } = await query;

      if (error) throw error;
      return (data as unknown) as Client[];
    },
  });

  // Query to get all deposited client IDs for highlighting (separate from filter)
  const { data: allDepositedClientIds } = useQuery({
    queryKey: ['all-clients-with-deposits', effectiveTenantId],
    staleTime: 2 * 60 * 1000,
    queryFn: async () => {
      let query = supabase
        .from('deposits')
        .select('client_id');
      
      if (effectiveTenantId && typeof effectiveTenantId === 'string') {
        query = query.eq('admin_id', effectiveTenantId);
      }
      
      const { data } = await query;
      return new Set(data?.map(d => d.client_id) || []);
    },
  });

  // Debounced realtime subscription
  useEffect(() => {
    // Skip realtime if tenant not ready
    if (!isTenantReady) return;
    
    // Validate tenant ID before using in filter
    const hasTenantFilter = isValidUUID(effectiveTenantId);
    
    const channelName = hasTenantFilter 
      ? `clients-realtime-${effectiveTenantId}` 
      : 'clients-realtime-all';
    
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'clients',
          ...(hasTenantFilter && { filter: `admin_id=eq.${effectiveTenantId}` }),
        },
        (payload) => {
          // Skip all realtime processing during bulk operations
          if (bulkOperationInProgressRef.current) return;
          
          // For updates, collect and debounce
          if (payload.eventType === 'UPDATE' && payload.new) {
            const clientId = payload.new.id as string;
            
            // Skip if this was from our own recent mutation
            if (recentMutationIdsRef.current.has(clientId)) {
              return;
            }
            
            // Add to pending updates
            pendingUpdatesRef.current.set(clientId, payload.new as Partial<Client>);
            
            // Debounce the batch apply
            if (debounceTimerRef.current) {
              clearTimeout(debounceTimerRef.current);
            }
            debounceTimerRef.current = setTimeout(applyPendingUpdates, REALTIME_DEBOUNCE_MS);
          } else {
            // For inserts/deletes, invalidate after debounce
            if (debounceTimerRef.current) {
              clearTimeout(debounceTimerRef.current);
            }
            debounceTimerRef.current = setTimeout(() => {
              if (!bulkOperationInProgressRef.current) {
                queryClient.invalidateQueries({ queryKey: ['clients-paginated'] });
                queryClient.invalidateQueries({ queryKey: ['clients-count'] });
              }
            }, REALTIME_DEBOUNCE_MS);
          }
        }
      )
      .subscribe();

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      supabase.removeChannel(channel);
    };
  }, [queryClient, effectiveTenantId, applyPendingUpdates, isTenantReady]);

  const paginationMeta = calculatePagination(totalCount, pagination.page, pagination.pageSize);

  // Mutations
  const createClient = useMutation({
    mutationFn: async (clientData: Omit<Client, 'id' | 'created_at' | 'updated_at' | 'created_by'> & Partial<Pick<Client, 'assigned_to'>>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from('clients')
        .insert([{ 
          ...clientData, 
          created_by: user.id,
          admin_id: effectiveTenantId || null 
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['clients-count'] });
      toast({
        title: "Client created",
        description: "The client has been successfully created.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to create client",
        description: message,
        variant: "destructive",
      });
    },
  });

  const updateClient = useMutation({
    mutationFn: async ({ id, ...updates }: { id: string } & Partial<Omit<Client, 'id' | 'created_at' | 'updated_at'>>) => {
      const { data: oldClient } = await supabase
        .from('clients')
        .select('*')
        .eq('id', id)
        .single();

      const { data, error } = await supabase
        .from('clients')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      const changes: Record<string, { old: unknown; new: unknown }> = {};
      if (oldClient) {
        Object.keys(updates).forEach(key => {
          if (oldClient[key as keyof typeof oldClient] !== updates[key as keyof typeof updates]) {
            changes[key] = {
              old: oldClient[key as keyof typeof oldClient],
              new: updates[key as keyof typeof updates],
            };
          }
        });
      }

      let actionType = 'client_updated';
      if (updates.status && oldClient?.status !== updates.status) {
        actionType = 'client_status_changed';
      } else if (updates.assigned_to && oldClient?.assigned_to !== updates.assigned_to) {
        actionType = 'client_assigned';
      }

      await logAction({
        actionType,
        entityType: 'client',
        entityId: id,
        details: {
          client_name: data.name,
          changes,
          old_status: oldClient?.status,
          new_status: updates.status,
          old_assigned_to: oldClient?.assigned_to,
          new_assigned_to: updates.assigned_to,
        },
      });

      return data;
    },
    onMutate: async ({ id, ...updates }) => {
      await queryClient.cancelQueries({ queryKey: ['clients-paginated'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients-paginated'] });
      
      // Track to skip realtime
      trackMutatedIds([id]);
      
      queryClient.setQueriesData(
        { queryKey: ['clients-paginated'] },
        (old: Client[] | undefined) => {
          if (!old) return old;
          return old.map(client => 
            client.id === id ? { ...client, ...updates } : client
          );
        }
      );

      return { previousClients };
    },
    onError: (error: unknown, variables, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to update client",
        description: message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({
        title: "Client updated",
        description: "The client has been successfully updated.",
      });
    },
  });

  const deleteClient = useMutation({
    mutationFn: async (id: string) => {
      const { data: client } = await supabase
        .from('clients')
        .select('*')
        .eq('id', id)
        .single();

      const { error } = await supabase
        .from('clients')
        .delete()
        .eq('id', id);

      if (error) throw error;

      if (client) {
        await logAction({
          actionType: 'client_deleted',
          entityType: 'client',
          entityId: id,
          details: {
            deleted_client: {
              name: client.name,
              email: client.email,
              status: client.status,
            },
          },
        });
      }
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ['clients-paginated'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients-paginated'] });
      
      queryClient.setQueriesData(
        { queryKey: ['clients-paginated'] },
        (old: Client[] | undefined) => old?.filter(client => client.id !== id)
      );

      return { previousClients };
    },
    onError: (error: unknown, id, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to delete client",
        description: message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients-count'] });
      toast({
        title: "Client deleted",
        description: "The client has been successfully deleted.",
      });
    },
  });

  // Bulk assign using Edge Function
  const bulkAssignClients = useMutation({
    mutationFn: async ({ clientIds, assignedTo }: { clientIds: string[]; assignedTo: string }) => {
      if (!user) throw new Error("Not authenticated");
      if (bulkOperationInProgressRef.current) throw new Error("Another bulk operation is in progress");
      
      bulkOperationInProgressRef.current = true;
      
      try {
        const { data, error } = await supabase.functions.invoke('bulk-assign-clients', {
          body: {
            clientIds,
            agentId: assignedTo,
            tenantId: effectiveTenantId,
          },
        });

        if (error) throw error;
        return data;
      } finally {
        bulkOperationInProgressRef.current = false;
      }
    },
    onMutate: async ({ clientIds, assignedTo }) => {
      await queryClient.cancelQueries({ queryKey: ['clients-paginated'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients-paginated'] });
      
      trackMutatedIds(clientIds);
      
      queryClient.setQueriesData(
        { queryKey: ['clients-paginated'] },
        (old: Client[] | undefined) => {
          if (!old) return old;
          return old.map(client => 
            clientIds.includes(client.id) 
              ? { ...client, assigned_to: assignedTo }
              : client
          );
        }
      );

      return { previousClients };
    },
    onError: (err, variables, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to assign clients",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    },
    onSuccess: (_, { clientIds }) => {
      toast({
        title: "Processing in background",
        description: `${clientIds.length} clients are being assigned.`,
      });
    },
  });

  // Bulk update status using Edge Function
  const bulkUpdateStatus = useMutation({
    mutationFn: async ({ clientIds, status }: { clientIds: string[]; status: string }) => {
      if (!user) throw new Error("Not authenticated");
      if (bulkOperationInProgressRef.current) throw new Error("Another bulk operation is in progress");
      
      bulkOperationInProgressRef.current = true;
      
      try {
        const { data, error } = await supabase.functions.invoke('bulk-update-client-status', {
          body: { clientIds, status },
        });

        if (error) throw error;
        return data;
      } finally {
        bulkOperationInProgressRef.current = false;
      }
    },
    onMutate: async ({ clientIds, status }) => {
      await queryClient.cancelQueries({ queryKey: ['clients-paginated'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients-paginated'] });
      
      trackMutatedIds(clientIds);
      
      queryClient.setQueriesData(
        { queryKey: ['clients-paginated'] },
        (old: Client[] | undefined) => {
          if (!old) return old;
          return old.map(client => 
            clientIds.includes(client.id) ? { ...client, status: status as any } : client
          );
        }
      );

      return { previousClients };
    },
    onError: (err, variables, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to update status",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    },
    onSuccess: (_, { clientIds, status }) => {
      toast({
        title: "Processing in background",
        description: `${clientIds.length} clients updated to ${status.replace(/_/g, ' ')}.`,
      });
    },
  });

  // Bulk delete using Edge Function
  const bulkDeleteClients = useMutation({
    mutationFn: async (clientIds: string[]) => {
      if (!user) throw new Error("Not authenticated");
      if (bulkOperationInProgressRef.current) throw new Error("Another bulk operation is in progress");
      
      bulkOperationInProgressRef.current = true;
      
      try {
        const { data, error } = await supabase.functions.invoke('bulk-delete-clients', {
          body: { clientIds },
        });

        if (error) throw error;
        return data;
      } finally {
        bulkOperationInProgressRef.current = false;
      }
    },
    onMutate: async (clientIds) => {
      await queryClient.cancelQueries({ queryKey: ['clients-paginated'] });
      
      const previousClients = queryClient.getQueriesData({ queryKey: ['clients-paginated'] });
      
      // Track these IDs to skip realtime updates
      trackMutatedIds(clientIds);
      
      queryClient.setQueriesData(
        { queryKey: ['clients-paginated'] },
        (old: Client[] | undefined) => old?.filter(client => !clientIds.includes(client.id))
      );

      return { previousClients };
    },
    onError: (err, clientIds, context) => {
      if (context?.previousClients) {
        context.previousClients.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
      toast({
        title: "Failed to delete clients",
        description: err instanceof Error ? err.message : "An error occurred",
        variant: "destructive",
      });
    },
    onSuccess: (_, clientIds) => {
      // Delay count invalidation to let background processing complete
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['clients-count'] });
      }, 3000);
      toast({
        title: "Processing in background",
        description: `${clientIds.length} clients are being deleted.`,
      });
    },
  });

  return {
    clients,
    totalCount,
    isLoading,
    error,
    createClient,
    updateClient,
    deleteClient,
    bulkAssignClients,
    bulkUpdateStatus,
    bulkDeleteClients,
    pagination: paginationMeta,
    depositedClientIds: allDepositedClientIds,
  };
};

// Helper function to apply filters
function applyFilters(
  query: any,
  filters: ClientFilters | undefined,
  effectiveTenantId: string | null,
  clientIdsInGroups?: string[],
  depositedClientIds?: string[]
) {
  // Validate tenant ID before using
  if (effectiveTenantId && typeof effectiveTenantId === 'string' && effectiveTenantId !== 'undefined') {
    query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
  }

  // Filter by client IDs from selected groups
  if (clientIdsInGroups && clientIdsInGroups.length > 0) {
    query = query.in('id', clientIdsInGroups);
  }

  // Filter by deposited clients
  if (filters?.hasDeposited && depositedClientIds && depositedClientIds.length > 0) {
    query = query.in('id', depositedClientIds);
  }

  if (filters?.assignedTo) {
    query = query.eq('assigned_to', filters.assignedTo);
  }

  if (filters?.assignedToList && filters.assignedToList.length > 0) {
    const hasUnassigned = filters.assignedToList.includes('unassigned');
    const userIds = filters.assignedToList.filter(id => id !== 'unassigned');
    
    if (hasUnassigned && userIds.length > 0) {
      query = query.or(`assigned_to.is.null,assigned_to.in.(${userIds.join(',')})`);
    } else if (hasUnassigned) {
      query = query.is('assigned_to', null);
    } else {
      query = query.in('assigned_to', userIds);
    }
  }

  if (filters?.search) {
    query = query.or(
      `name.ilike.%${filters.search}%,email.ilike.%${filters.search}%,country.ilike.%${filters.search}%`
    );
  }

  if (filters?.status) {
    query = query.eq('status', filters.status);
  }

  if (filters?.statuses && filters.statuses.length > 0) {
    query = query.in('status', filters.statuses);
  }

  if (filters?.pipelineStatus) {
    query = query.eq('pipeline_status', filters.pipelineStatus);
  }

  if (filters?.countries && filters.countries.length > 0) {
    // Country filter is driven by phone prefix (source of truth).
    const prefixes = Array.from(
      new Set(filters.countries.flatMap((c) => getAllPhonePrefixesForCountry(c)))
    );
    if (prefixes.length > 0) {
      query = query.or(prefixes.map((p) => `home_phone.like.${p}%`).join(','));
    } else {
      query = query.eq('id', '00000000-0000-0000-0000-000000000000');
    }
  }

  if (filters?.teamMemberIds && filters.teamMemberIds.length > 0) {
    query = query.or(`assigned_to.in.(${filters.teamMemberIds.join(',')}),assigned_to.is.null`);
  }

  return query;
}
