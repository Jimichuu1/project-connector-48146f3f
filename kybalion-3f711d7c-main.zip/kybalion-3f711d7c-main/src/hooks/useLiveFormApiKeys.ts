import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export interface LiveFormApiKey {
  id: string;
  admin_id: string;
  name: string;
  key_prefix: string;
  default_source: string;
  is_active: boolean;
  last_used_at: string | null;
  request_count: number;
  created_at: string;
}

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function generateApiKey(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return (
    "ltk_" +
    Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("")
  );
}

export function useLiveFormApiKeys() {
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();
  const { user } = useAuth();

  const query = useQuery({
    queryKey: ["live-form-api-keys", effectiveTenantId],
    queryFn: async () => {
      let q = supabase
        .from("live_form_api_keys")
        .select("id, admin_id, name, key_prefix, default_source, is_active, last_used_at, request_count, created_at")
        .order("created_at", { ascending: false });
      if (effectiveTenantId) q = q.eq("admin_id", effectiveTenantId);
      const { data, error } = await q;
      if (error) throw error;
      return (data || []) as unknown as LiveFormApiKey[];
    },
    enabled: effectiveTenantId !== undefined,
  });

  const createKey = useMutation({
    mutationFn: async ({ name, defaultSource }: { name: string; defaultSource: string }) => {
      if (!effectiveTenantId) throw new Error("No tenant selected");
      if (!user) throw new Error("Not authenticated");
      const plain = generateApiKey();
      const keyHash = await sha256Hex(plain);
      const keyPrefix = plain.slice(0, 12);
      const { data, error } = await supabase
        .from("live_form_api_keys")
        .insert({
          admin_id: effectiveTenantId,
          name,
          key_hash: keyHash,
          key_prefix: keyPrefix,
          default_source: defaultSource as "WEBSITE",
          created_by: user.id,
        })
        .select("id")
        .single();
      if (error) throw error;
      return { id: (data as { id: string }).id, plainKey: plain };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-form-api-keys"] });
    },
    onError: (e: Error) => toast.error(e.message || "Failed to create key"),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const { error } = await supabase
        .from("live_form_api_keys")
        .update({ is_active: isActive })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-form-api-keys"] });
      toast.success("Key updated");
    },
    onError: (e: Error) => toast.error(e.message || "Failed to update key"),
  });

  const revokeKey = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("live_form_api_keys")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-form-api-keys"] });
      toast.success("Key revoked");
    },
    onError: (e: Error) => toast.error(e.message || "Failed to revoke key"),
  });

  return { ...query, createKey, toggleActive, revokeKey };
}
