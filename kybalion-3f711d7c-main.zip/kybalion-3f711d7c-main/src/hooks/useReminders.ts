import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import type { Tables } from "@/integrations/supabase/types";

export type Reminder = Tables<"reminders">;

export const useReminders = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: reminders = [], isLoading } = useQuery({
    queryKey: ["reminders", user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from("reminders")
        .select("*")
        .eq("user_id", user.id)
        .order("due_date", { ascending: true });

      if (error) throw error;
      return data as Reminder[];
    },
    enabled: !!user,
  });

  const createReminder = useMutation({
    mutationFn: async (reminder: {
      title: string;
      description?: string | null;
      due_date?: string | null;
      timezone?: string | null;
      completed?: boolean;
      priority?: string;
      related_entity_type?: string | null;
      related_entity_id?: string | null;
    }) => {
      if (!user) throw new Error("User not authenticated");

      // Get admin_id from user profile for tenant isolation
      const { data: profile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .single();

      const { data, error } = await supabase
        .from("reminders")
        .insert({
          title: reminder.title,
          description: reminder.description || null,
          due_date: reminder.due_date || null,
          timezone: reminder.timezone || null,
          completed: reminder.completed ?? false,
          priority: reminder.priority || "medium",
          related_entity_type: reminder.related_entity_type || null,
          related_entity_id: reminder.related_entity_id || null,
          user_id: user.id,
          admin_id: profile?.admin_id || user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reminders"] });
      toast.success("Reminder created successfully");
    },
    onError: (error) => {
      toast.error("Failed to create reminder");
      console.error("Create reminder error:", error);
    },
  });

  const updateReminder = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Reminder> & { id: string }) => {
      const { data, error } = await supabase
        .from("reminders")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reminders"] });
      toast.success("Reminder updated successfully");
    },
    onError: (error) => {
      toast.error("Failed to update reminder");
      console.error("Update reminder error:", error);
    },
  });

  const deleteReminder = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("reminders")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reminders"] });
      toast.success("Reminder deleted successfully");
    },
    onError: (error) => {
      toast.error("Failed to delete reminder");
      console.error("Delete reminder error:", error);
    },
  });

  const toggleComplete = useMutation({
    mutationFn: async (id: string) => {
      const reminder = reminders.find(r => r.id === id);
      if (!reminder) throw new Error("Reminder not found");

      const { data, error } = await supabase
        .from("reminders")
        .update({
          completed: !reminder.completed,
          completed_at: !reminder.completed ? new Date().toISOString() : null,
        })
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reminders"] });
    },
    onError: (error) => {
      toast.error("Failed to update reminder");
      console.error("Toggle complete error:", error);
    },
  });

  const pendingCount = reminders.filter(r => !r.completed && new Date(r.due_date) >= new Date()).length;

  return {
    reminders,
    isLoading,
    pendingCount,
    createReminder,
    updateReminder,
    deleteReminder,
    toggleComplete,
  };
};
