import { supabase } from "@/integrations/supabase/client";

interface AuditLogParams {
  actionType: string;
  entityType?: string;
  entityId?: string;
  details?: Record<string, any>;
  adminId?: string | null;
}

// Cache IP address once per session to avoid blocking API calls
let cachedIpAddress: string | null = null;
let ipFetchPromise: Promise<string | null> | null = null;

const fetchIpAddress = async (): Promise<string | null> => {
  if (cachedIpAddress) return cachedIpAddress;
  
  if (!ipFetchPromise) {
    ipFetchPromise = fetch('https://api.ipify.org?format=json', { 
      signal: AbortSignal.timeout(3000) // 3 second timeout
    })
      .then(res => res.json())
      .then(data => {
        cachedIpAddress = data.ip;
        return cachedIpAddress;
      })
      .catch(() => null);
  }
  
  return ipFetchPromise;
};

// Pre-fetch IP on module load (non-blocking)
fetchIpAddress();

export const useAuditLog = () => {
  const logAction = ({ actionType, entityType, entityId, details, adminId }: AuditLogParams) => {
    // Fire-and-forget - don't await this in mutations
    (async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Use cached IP or null - don't block on this
        const ipAddress = cachedIpAddress;
        const userAgent = navigator.userAgent;

        // If adminId not provided, try to get it from user's profile
        let effectiveAdminId = adminId;
        if (effectiveAdminId === undefined) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('admin_id')
            .eq('id', user.id)
            .single();
          effectiveAdminId = profile?.admin_id || null;
        }

        // Insert - fire and forget
        await supabase.from("audit_logs").insert({
          user_id: user.id,
          action_type: actionType,
          entity_type: entityType,
          entity_id: entityId,
          details: details,
          ip_address: ipAddress,
          user_agent: userAgent,
          admin_id: effectiveAdminId,
        });
      } catch (error) {
        console.error("Failed to log audit event:", error);
        // Don't throw - audit logging should not block user actions
      }
    })();
  };

  return { logAction };
};
