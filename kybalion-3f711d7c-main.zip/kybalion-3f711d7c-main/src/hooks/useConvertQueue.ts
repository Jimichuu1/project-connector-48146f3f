import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTenant } from "@/contexts/TenantContext";
import { getErrorMessage } from "@/types/errors";
import { SuperAgentUser, ProfileBasic } from "@/types/supabase-helpers";
import { User } from "@supabase/supabase-js";
import { isValidUUID } from "@/lib/uuidUtils";
import { useAuditLog } from "@/hooks/useAuditLog";

export interface PendingLead {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  balance: number | null;
  equity: number | null;
  created_at: string;
  created_by: string;
  assigned_to: string | null;
  transferring_agent_id: string | null;
  admin_id?: string | null;
  closer_agent_id?: string | null;
  transferring_agent?: ProfileBasic;
  closer_agent?: ProfileBasic;
  lead_group_names?: string[];
}

export interface ConvertedClient {
  id: string;
  name: string;
  email: string;
  home_phone: string | null;
  balance: number | null;
  equity: number | null;
  initial_balance: number | null;
  initial_equity: number | null;
  assigned_to: string | null;
  join_date: string;
  converted_from_lead_id: string | null;
  created_by: string;
  transferring_agent_id: string | null;
  conversion_manager_id: string | null;
  conversion_super_agent_id: string | null;
  closer_agent_id?: string | null;
  admin_id?: string | null;
  lead_group_names?: string[];
  super_agent_profile?: ProfileBasic;
  transferring_agent_profile?: ProfileBasic;
  closer_agent_profile?: ProfileBasic;
}

export function useConvertQueue() {
  const { effectiveTenantId } = useTenant();
  const { logAction } = useAuditLog();
  const [leads, setLeads] = useState<PendingLead[]>([]);
  const [convertedClients, setConvertedClients] = useState<ConvertedClient[]>([]);
  const [deposits, setDeposits] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [superAgents, setSuperAgents] = useState<SuperAgentUser[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAgent, setIsAgent] = useState(false);
  const [isSuperAgent, setIsSuperAgent] = useState(false);
  const [isManager, setIsManager] = useState(false);
  const [isTeamLeader, setIsTeamLeader] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [teamLeaderTeamIds, setTeamLeaderTeamIds] = useState<string[]>([]);
  const [roleCheckComplete, setRoleCheckComplete] = useState(false);

  useEffect(() => {
    checkUserRole();
  }, []);

  useEffect(() => {
    // Wait for role check to complete and tenant to be ready
    if (currentUser !== null && effectiveTenantId !== undefined && roleCheckComplete) {
      // SUPER_AGENT should NOT fetch pending leads - they only see converted clients
      if (!isSuperAgent) {
        fetchPendingLeads();
      }
      fetchConvertedClients();
      // Only fetch super agents if admin (for assignment dropdown)
      if (isAdmin) {
        fetchSuperAgents();
      }
    }
  }, [currentUser, effectiveTenantId, roleCheckComplete, isSuperAgent, isAdmin]);

  const checkUserRole = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      setCurrentUser(user);
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);
      
      if (roles) {
        const hasAgent = roles.some(r => r.role === "AGENT");
        const hasSuperAgent = roles.some(r => r.role === "SUPER_AGENT");
        const hasTenantOwner = roles.some(r => r.role === "TENANT_OWNER");
        const hasManager = roles.some(r => r.role === "MANAGER");
        const hasSuperAdmin = roles.some(r => r.role === "SUPER_ADMIN");
        const hasTeamLeader = roles.some(r => r.role === "TEAM_LEADER");
        
        setIsAgent(hasAgent && !hasTenantOwner && !hasManager && !hasSuperAgent && !hasSuperAdmin && !hasTeamLeader);
        setIsSuperAgent(hasSuperAgent && !hasTenantOwner && !hasManager && !hasSuperAdmin);
        setIsManager(hasManager && !hasTenantOwner && !hasSuperAdmin);
        setIsTeamLeader(hasTeamLeader && !hasTenantOwner && !hasManager && !hasSuperAdmin);
        setIsAdmin(hasTenantOwner || hasManager || hasSuperAdmin);

        // For team leaders, fetch their team member IDs
        if (hasTeamLeader && !hasTenantOwner && !hasManager && !hasSuperAdmin) {
          const { data: teamMembers } = await supabase
            .from("profiles")
            .select("id")
            .eq("created_by", user.id);
          setTeamLeaderTeamIds(teamMembers?.map(m => m.id) || []);
        }
      }
      setRoleCheckComplete(true);
    }
  };

  const fetchPendingLeads = async () => {
    try {
      let query = supabase
        .from("leads_secure" as any)
        .select(`
          id, name, email, phone, balance, equity,
          created_at, created_by, assigned_to, admin_id, closer_agent_id
        `)
        .eq("pending_conversion", true);

      if (isValidUUID(effectiveTenantId)) {
        query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
      }

      // AGENT: show only leads assigned to them (agents request conversion on their assigned leads)
      if (isAgent && currentUser) {
        query = query.eq("assigned_to", currentUser.id);
      }

      // TEAM_LEADER: show own leads + team members' pending leads
      if (isTeamLeader && currentUser) {
        const allIds = [currentUser.id, ...teamLeaderTeamIds];
        query = query.in("assigned_to", allIds);
      }

      const { data: rawData, error } = await query.order("created_at", { ascending: false });
      if (error) throw error;
      
      const data = (rawData as unknown) as Array<{
        id: string;
        name: string;
        email: string | null;
        phone: string | null;
        balance: number | null;
        equity: number | null;
        created_at: string;
        created_by: string;
        assigned_to: string | null;
        admin_id: string | null;
        closer_agent_id: string | null;
      }>;
      
      if (data && data.length > 0) {
        // Self-heal: filter out leads that already have a converted client (stuck/legacy state)
        // and fire-and-forget finalize for each so the DB cleans itself up.
        const leadIds = data.map(l => l.id);
        const { data: alreadyConverted } = await supabase
          .from("clients")
          .select("id, converted_from_lead_id")
          .in("converted_from_lead_id", leadIds);

        const stuckLeadToClient = new Map<string, string>();
        for (const c of alreadyConverted || []) {
          if (c.converted_from_lead_id) stuckLeadToClient.set(c.converted_from_lead_id, c.id);
        }

        if (stuckLeadToClient.size > 0) {
          // Background cleanup; ignore failures
          for (const [leadId, clientId] of stuckLeadToClient) {
            supabase.rpc("convert_lead_to_client_finalize", {
              p_lead_id: leadId,
              p_client_id: clientId,
            }).then(({ error }) => {
              if (error) console.warn("Background convert cleanup failed:", error);
            });
          }
        }

        const visibleData = data.filter(l => !stuckLeadToClient.has(l.id));

        // Get assigned agent IDs and closer agent IDs
        const assignedAgentIds = [...new Set(visibleData.map(l => l.assigned_to).filter(Boolean))] as string[];
        const closerAgentIds = [...new Set(visibleData.map(l => l.closer_agent_id).filter(Boolean))] as string[];
        const allProfileIds = [...new Set([...assignedAgentIds, ...closerAgentIds])];
        
        let profileMap = new Map<string, any>();
        if (allProfileIds.length > 0) {
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("id, full_name, email, avatar_url")
            .in("id", allProfileIds);
          
          profileMap = new Map(profilesData?.map(p => [p.id, p]) || []);
        }

        // Fetch lead group memberships for pending leads
        const visibleLeadIds = visibleData.map(l => l.id);
        const groupMap = new Map<string, string[]>();
        if (visibleLeadIds.length > 0) {
          const { data: memberships } = await supabase
            .from("lead_group_members")
            .select("lead_id, lead_groups(name)")
            .in("lead_id", visibleLeadIds);
          for (const m of (memberships as any[] | null) || []) {
            const name = m.lead_groups?.name;
            if (!name) continue;
            const arr = groupMap.get(m.lead_id) || [];
            arr.push(name);
            groupMap.set(m.lead_id, arr);
          }
        }

        const enrichedLeads = visibleData.map(lead => ({
          ...lead,
          transferring_agent_id: lead.assigned_to,
          closer_agent_id: lead.closer_agent_id,
          transferring_agent: lead.assigned_to ? profileMap.get(lead.assigned_to) : undefined,
          closer_agent: lead.closer_agent_id ? profileMap.get(lead.closer_agent_id) : undefined,
          lead_group_names: groupMap.get(lead.id) || [],
        }));
        
        setLeads(enrichedLeads as PendingLead[]);
      } else {
        setLeads([]);
      }
    } catch (error) {
      toast.error(getErrorMessage(error, "Failed to load pending leads"));
    } finally {
      setIsLoading(false);
    }
  };

  const fetchConvertedClients = async () => {
    try {
      // For agents, use simpler query without transferring_agent field (not available in view for them)
      // Use conversion_super_agent_id to preserve super agent assignment at time of conversion
      const selectFields = isAgent 
        ? `id, name, email, home_phone, balance, equity, assigned_to, created_by, join_date, converted_from_lead_id, admin_id, conversion_super_agent_id, conversion_manager_id, lead_group_names, closer_agent_id`
        : `id, name, email, home_phone, balance, equity, assigned_to, created_by, transferring_agent, join_date, converted_from_lead_id, admin_id, conversion_super_agent_id, conversion_manager_id, lead_group_names, closer_agent_id`;

      let query = supabase
        .from("clients_secure" as any)
        .select(selectFields)
        .not("converted_from_lead_id", "is", null)
        .order("join_date", { ascending: false });

      if (isValidUUID(effectiveTenantId)) {
        query = query.eq("admin_id", effectiveTenantId);
      }

      // AGENT: show clients where they were the transferring agent OR the closer agent
      if (isAgent && currentUser) {
        query = query.or(`transferring_agent.eq.${currentUser.id},closer_agent_id.eq.${currentUser.id}`);
      }

      // TEAM_LEADER: show only clients where they or their team members were the transferring agent
      if (isTeamLeader && currentUser) {
        const allIds = [currentUser.id, ...teamLeaderTeamIds];
        query = query.in("transferring_agent", allIds);
      }
      
      // SUPER_AGENT: show only clients that were originally converted to them (historical)
      // Uses conversion_super_agent_id to preserve history even after reassignments
      if (isSuperAgent && currentUser) {
        query = query.eq("conversion_super_agent_id", currentUser.id);
      }

      // MANAGER: show only clients converted under their management
      // This preserves history - even if agents move to other managers, old conversions remain visible
      if (isManager && currentUser) {
        query = query.eq("conversion_manager_id", currentUser.id);
      }

      const { data: rawData, error } = await query;
      if (error) throw error;

      const data = (rawData as unknown) as Array<{
        id: string;
        name: string;
        email: string | null;
        home_phone: string | null;
        balance: number | null;
        equity: number | null;
        assigned_to: string | null;
        created_by: string;
        transferring_agent?: string | null;
        join_date: string;
        converted_from_lead_id: string | null;
        admin_id: string | null;
        conversion_super_agent_id: string | null;
        conversion_manager_id: string | null;
        lead_group_names: string[] | null;
        closer_agent_id: string | null;
      }>;

      if (data && data.length > 0) {
        // Use conversion_super_agent_id for historical super agent display (doesn't change on reassignment)
        const superAgentIds = data.map(c => c.conversion_super_agent_id).filter(Boolean) as string[];
        const transferringAgentIds = isAgent ? [] : data.map(c => c.transferring_agent).filter(Boolean) as string[];
        const closerAgentIds = data.map(c => c.closer_agent_id).filter(Boolean) as string[];
        const allIds = [...new Set([...superAgentIds, ...transferringAgentIds, ...closerAgentIds])];

        let profileMap = new Map<string, any>();
        if (allIds.length > 0) {
          const { data: profilesData } = await supabase
            .from("profiles")
            .select("id, full_name, email, avatar_url")
            .in("id", allIds);

          profileMap = new Map(profilesData?.map(p => [p.id, p]) || []);
        }

        const enrichedData = data.map(client => ({
          ...client,
          transferring_agent_id: isAgent ? null : client.transferring_agent,
          conversion_super_agent_id: client.conversion_super_agent_id,
          closer_agent_id: client.closer_agent_id,
          initial_balance: client.balance,
          initial_equity: client.equity,
          lead_group_names: client.lead_group_names || [],
          super_agent_profile: client.conversion_super_agent_id ? profileMap.get(client.conversion_super_agent_id) : undefined,
          transferring_agent_profile: isAgent ? undefined : (client.transferring_agent ? profileMap.get(client.transferring_agent) : undefined),
          closer_agent_profile: client.closer_agent_id ? profileMap.get(client.closer_agent_id) : undefined,
        }));

        setConvertedClients(enrichedData as ConvertedClient[]);
      } else {
        setConvertedClients([]);
      }

      if (data && data.length > 0) {
        const clientIds = data.map((c) => c.id);
        const { data: depositsData } = await supabase
          .from("deposits")
          .select("client_id, amount")
          .in("client_id", clientIds)
          .eq("status", "approved");

        const depositMap: Record<string, number> = {};
        depositsData?.forEach(d => {
          depositMap[d.client_id] = (depositMap[d.client_id] || 0) + d.amount;
        });
        setDeposits(depositMap);
      }
    } catch {
      // Silent fail for converted clients load
    }
  };

  const fetchSuperAgents = async (tenantIdOverride?: string | null) => {
    try {
      // Resolve tenant to query (server-side enforces caller's actual tenant for non SUPER_ADMIN)
      const filterTenantId = tenantIdOverride ?? effectiveTenantId;
      const p_tenant_id = isValidUUID(filterTenantId) ? (filterTenantId as string) : null;

      const { data, error } = await supabase.rpc("get_tenant_super_agents", {
        p_tenant_id,
      });

      if (error) throw error;

      const enrichedAgents = (data || []).map((row: any) => ({
        user_id: row.user_id,
        profiles: { id: row.user_id, full_name: row.full_name, email: row.email },
        role: row.role,
      }));

      setSuperAgents(enrichedAgents);
    } catch (error) {
      console.error("Failed to fetch super agents:", error);
    }
  };

  const handleCancelRequest = async (leadId: string) => {
    if (!currentUser) return;

    // Get lead details for logging and notification
    const { data: leadData } = await supabase
      .from("leads")
      .select("name, email, admin_id, assigned_to")
      .eq("id", leadId)
      .single();

    await supabase
      .from("lead_activities")
      .insert({
        lead_id: leadId,
        user_id: currentUser.id,
        activity_type: "conversion_cancelled",
        description: "Conversion request cancelled by admin"
      });

    const { error } = await supabase
      .from("leads")
      .update({ pending_conversion: false })
      .eq("id", leadId);

    if (error) throw error;

    // Log to audit_logs
    logAction({
      actionType: 'conversion_cancelled',
      entityType: 'lead',
      entityId: leadId,
      details: {
        lead_name: leadData?.name,
        lead_email: leadData?.email,
        cancelled_by: currentUser.id,
      },
      adminId: leadData?.admin_id || effectiveTenantId,
    });

    // Send CONVERSION_REJECTED notification to the requesting agent
    if (leadData?.assigned_to && leadData.assigned_to !== currentUser.id) {
      await supabase.from("notifications").insert({
        user_id: leadData.assigned_to,
        type: "CONVERSION_REJECTED",
        message: `Your conversion request for "${leadData.name}" has been rejected`,
        related_entity_type: "lead",
        related_entity_id: leadId,
      });
    }

    toast.success("Conversion request cancelled");
    fetchPendingLeads();
  };

  const handleConvertToClient = async (
    lead: PendingLead,
    selectedAgent: string
  ): Promise<string> => {
    // One atomic RPC: insert client, transfer KYC/docs, write activities/audit/notifications,
    // and delete the lead — all in a single Postgres transaction. Any failure rolls back
    // everything, so the queue can never be left with a stuck "pending" request.
    const { data, error } = await supabase.rpc("convert_lead_to_client_atomic" as any, {
      p_lead_id: lead.id,
      p_assigned_super_agent: selectedAgent,
    });

    if (error) throw error;

    const result = data as { success: boolean; client_id: string; already_existed: boolean } | null;
    if (!result?.client_id) {
      throw new Error("Conversion failed: no client returned");
    }

    if (result.already_existed) {
      toast.success("Lead was already converted — opening existing client");
    } else {
      toast.success("Lead converted to client successfully!");
    }

    fetchPendingLeads();
    fetchConvertedClients();

    return result.client_id;
  };

  return {
    leads,
    convertedClients,
    deposits,
    isLoading,
    superAgents,
    currentUser,
    isAgent,
    isSuperAgent,
    isManager,
    isTeamLeader,
    isAdmin,
    fetchPendingLeads,
    fetchConvertedClients,
    fetchSuperAgents,
    handleCancelRequest,
    handleConvertToClient,
  };
}
