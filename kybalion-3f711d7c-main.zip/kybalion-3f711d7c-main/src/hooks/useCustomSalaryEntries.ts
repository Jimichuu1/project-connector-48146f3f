import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface CustomSalaryEntry {
  id: string;
  admin_id: string;
  month: string;
  name: string;
  base_salary: number;
  commission: number;
  advance: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface CreateEntryData {
  admin_id: string;
  month: string;
  name: string;
  base_salary: number;
  commission: number;
  advance: number;
  notes?: string;
}

interface UpdateEntryData {
  id: string;
  name: string;
  base_salary: number;
  commission: number;
  advance: number;
  notes?: string;
}

export function useCustomSalaryEntries(adminId: string | null, month: string) {
  const queryClient = useQueryClient();
  const queryKey = ["custom-salary-entries", adminId, month];

  const { data: entries = [], isLoading } = useQuery({
    queryKey,
    enabled: !!adminId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("custom_salary_entries")
        .select("*")
        .eq("admin_id", adminId!)
        .eq("month", month)
        .order("created_at", { ascending: true });

      if (error) throw error;
      return data as CustomSalaryEntry[];
    },
  });

  const createEntry = useMutation({
    mutationFn: async (entry: CreateEntryData) => {
      const { data, error } = await supabase
        .from("custom_salary_entries")
        .insert(entry)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      toast.success("Custom salary entry added");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const updateEntry = useMutation({
    mutationFn: async ({ id, ...updates }: UpdateEntryData) => {
      const { data, error } = await supabase
        .from("custom_salary_entries")
        .update(updates)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      toast.success("Custom salary entry updated");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const deleteEntry = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("custom_salary_entries")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      toast.success("Custom salary entry deleted");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return { entries, isLoading, createEntry, updateEntry, deleteEntry };
}
