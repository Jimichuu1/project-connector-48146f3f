import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

const MAX_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

export const useRateLimiter = () => {
  const [isBlocked, setIsBlocked] = useState(false);
  const [needsCaptcha, setNeedsCaptcha] = useState(false);
  const [attemptsRemaining, setAttemptsRemaining] = useState(MAX_ATTEMPTS);

  const getClientIp = async (): Promise<string> => {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch {
      return 'unknown';
    }
  };

  const checkRateLimit = useCallback(async (email?: string): Promise<{ allowed: boolean; needsCaptcha: boolean }> => {
    try {
      const ipAddress = await getClientIp();

      // Check if IP is currently blocked
      const { data: isCurrentlyBlocked } = await supabase.rpc('is_ip_blocked', { 
        p_ip_address: ipAddress 
      });

      if (isCurrentlyBlocked) {
        setIsBlocked(true);
        return { allowed: false, needsCaptcha: false };
      }

      // Count failed attempts in the last 15 minutes
      const { data: failedCount } = await supabase.rpc('count_failed_attempts', {
        p_ip_address: ipAddress,
        p_minutes: LOCKOUT_MINUTES,
      });

      const remaining = MAX_ATTEMPTS - (failedCount || 0);
      setAttemptsRemaining(remaining);

      // Require CAPTCHA after 2 failed attempts
      if (failedCount && failedCount >= 2) {
        setNeedsCaptcha(true);
      }

      // Block after 5 failed attempts
      if (failedCount && failedCount >= MAX_ATTEMPTS) {
        setIsBlocked(true);
        return { allowed: false, needsCaptcha: true };
      }

      return { 
        allowed: true, 
        needsCaptcha: failedCount ? failedCount >= 2 : false 
      };
    } catch (error) {
      console.error("Rate limit check failed:", error);
      return { allowed: true, needsCaptcha: false };
    }
  }, []);

  const recordAttempt = useCallback(async (
    email: string, 
    success: boolean, 
    failureReason?: string
  ) => {
    try {
      const ipAddress = await getClientIp();
      const userAgent = navigator.userAgent;

      await supabase.from("auth_attempts").insert({
        ip_address: ipAddress,
        user_email: email,
        attempt_type: 'login',
        success,
        failure_reason: failureReason,
        user_agent: userAgent,
        blocked_until: success ? null : (
          attemptsRemaining <= 1 
            ? new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000).toISOString()
            : null
        ),
      });

      // If attempt failed, update state
      if (!success) {
        const newRemaining = attemptsRemaining - 1;
        setAttemptsRemaining(newRemaining);
        
        if (newRemaining <= 0) {
          setIsBlocked(true);
        } else if (newRemaining <= 3) {
          setNeedsCaptcha(true);
        }
      } else {
        // Reset on success
        setIsBlocked(false);
        setNeedsCaptcha(false);
        setAttemptsRemaining(MAX_ATTEMPTS);
      }
    } catch (error) {
      console.error("Failed to record auth attempt:", error);
    }
  }, [attemptsRemaining]);

  return {
    isBlocked,
    needsCaptcha,
    attemptsRemaining,
    checkRateLimit,
    recordAttempt,
  };
};
