import { supabase } from "@/integrations/supabase/client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useUserData } from "@/contexts/UserDataContext";

export type PartnerEndpoint =
  | "create-user"
  | "create-transaction"
  | "create-user-with-deposit"
  | "ping";

export interface PartnerCallResult {
  status: number;
  body: any;
  error?: string;
}

async function invokePartner(endpoint: PartnerEndpoint, payload: Record<string, any>): Promise<PartnerCallResult> {
  const { data, error } = await supabase.functions.invoke("partner-api-proxy", {
    body: { endpoint, payload },
  });

  if (error) {
    // supabase-js throws FunctionsHttpError for non-2xx responses; we want the body.
    const ctx: any = (error as any).context;
    let body: any = null;
    let status = 500;
    if (ctx?.response) {
      status = ctx.response.status;
      try {
        body = await ctx.response.clone().json();
      } catch {
        body = { error: error.message };
      }
    } else {
      body = { error: error.message };
    }
    return { status, body, error: error.message };
  }

  return { status: 200, body: data };
}

export function usePartnerApiCall() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ endpoint, payload }: { endpoint: PartnerEndpoint; payload: Record<string, any> }) =>
      invokePartner(endpoint, payload),
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["partner-api-call-log"] });
    },
  });
}

export interface PartnerCallLogRow {
  id: string;
  caller_user_id: string;
  admin_id: string | null;
  endpoint: string;
  request_payload: any;
  response_status: number | null;
  response_body: any;
  created_at: string;
  caller_name?: string | null;
}

export function usePartnerApiCallLog(limit = 20) {
  const { adminId } = useUserData();
  return useQuery({
    queryKey: ["partner-api-call-log", adminId, limit],
    queryFn: async (): Promise<PartnerCallLogRow[]> => {
      let query = supabase
        .from("partner_api_call_log" as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(limit);

      if (adminId) {
        query = query.eq("admin_id", adminId);
      }

      const { data, error } = await query;
      if (error) throw error;
      const rows = (data ?? []) as any as PartnerCallLogRow[];

      // Hydrate caller names
      const callerIds = Array.from(new Set(rows.map((r) => r.caller_user_id))).filter(Boolean);
      if (callerIds.length) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", callerIds);
        const map = new Map((profiles ?? []).map((p: any) => [p.id, p.full_name || p.email]));
        for (const r of rows) {
          r.caller_name = map.get(r.caller_user_id) ?? null;
        }
      }
      return rows;
    },
    enabled: true,
  });
}
