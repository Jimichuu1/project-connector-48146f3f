import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface AdvancePayment {
  id: string;
  admin_id: string;
  user_id: string;
  month: string;
  amount: number;
  note: string | null;
  created_at: string;
}

interface UpsertAdvanceData {
  admin_id: string;
  user_id: string;
  month: string;
  amount: number;
  note?: string;
}

export function useAdvancePayments(adminId: string | null, month: string) {
  const queryClient = useQueryClient();
  const queryKey = ["advance-payments", adminId, month];

  const { data: advances = [], isLoading } = useQuery({
    queryKey,
    enabled: !!adminId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("advance_payments")
        .select("*")
        .eq("admin_id", adminId!)
        .eq("month", month);

      if (error) throw error;
      return data as AdvancePayment[];
    },
  });

  const upsertAdvance = useMutation({
    mutationFn: async (entry: UpsertAdvanceData) => {
      // Check if one already exists
      const { data: existing } = await supabase
        .from("advance_payments")
        .select("id")
        .eq("admin_id", entry.admin_id)
        .eq("user_id", entry.user_id)
        .eq("month", entry.month)
        .maybeSingle();

      if (existing) {
        const { data, error } = await supabase
          .from("advance_payments")
          .update({ amount: entry.amount, note: entry.note || null })
          .eq("id", existing.id)
          .select()
          .single();
        if (error) throw error;
        return data;
      } else {
        const { data, error } = await supabase
          .from("advance_payments")
          .insert(entry)
          .select()
          .single();
        if (error) throw error;
        return data;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      toast.success("Advance payment saved");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const deleteAdvance = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("advance_payments")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
      toast.success("Advance payment removed");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  // Helper to get advance for a specific user
  const getAdvanceForUser = (userId: string): AdvancePayment | undefined => {
    return advances.find((a) => a.user_id === userId);
  };

  return { advances, isLoading, upsertAdvance, deleteAdvance, getAdvanceForUser };
}
