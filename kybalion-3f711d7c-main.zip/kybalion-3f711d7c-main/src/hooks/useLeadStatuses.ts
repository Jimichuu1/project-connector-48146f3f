import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface LeadStatus {
  id: string;
  name: string;
  color: string | null;
  position: number | null;
  is_default: boolean | null;
  is_active: boolean | null;
}

export function useLeadStatuses() {
  return useQuery({
    queryKey: ["lead-statuses"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("lead_statuses")
        .select("*")
        .order("position", { ascending: true });

      if (error) throw error;
      return data as LeadStatus[];
    },
    staleTime: 10 * 60 * 1000, // 10 minutes - statuses rarely change
  });
}

export function useActiveLeadStatuses() {
  const { data: statuses, ...rest } = useLeadStatuses();
  
  return {
    ...rest,
    data: statuses?.filter((s) => s.is_active !== false) ?? [],
  };
}

export function getLeadStatusConfig(statuses: LeadStatus[], statusName: string) {
  const status = statuses?.find((s) => s.name === statusName);
  if (status) {
    return {
      label: status.name,
      color: status.color || "#6366f1",
    };
  }
  // Fallback for unknown statuses
  return {
    label: statusName,
    color: "#6366f1",
  };
}
