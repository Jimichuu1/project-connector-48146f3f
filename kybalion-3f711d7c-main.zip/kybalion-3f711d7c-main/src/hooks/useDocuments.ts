import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Document, DocumentType } from "@/types/documents";
import { useToast } from "@/hooks/use-toast";
import { useAuditLog } from "@/hooks/useAuditLog";
import { DocumentUploadData } from "@/types/supabase-helpers";

export const useDocuments = (entityId?: string, entityType?: 'lead' | 'client') => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();

  const { data: documents, isLoading } = useQuery({
    queryKey: ['documents', entityId, entityType],
    queryFn: async () => {
      if (!entityId || !entityType) return [];
      
      let query = supabase.from('documents').select('*');
      
      if (entityType === 'lead') {
        query = query.eq('lead_id', entityId);
      } else {
        query = query.eq('client_id', entityId);
      }
      
      const { data, error } = await query.order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as Document[];
    },
    enabled: !!entityId && !!entityType,
  });

  const uploadDocument = useMutation({
    mutationFn: async ({
      file,
      entityId,
      entityType,
      kycRecordId,
    }: {
      file: File;
      entityId: string;
      entityType: 'lead' | 'client';
      kycRecordId?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Determine document type
      const getDocType = (mimeType: string): DocumentType => {
        if (mimeType.includes('pdf')) return 'PDF';
        if (mimeType.includes('word') || mimeType.includes('document')) return 'DOCX';
        if (mimeType.includes('sheet') || mimeType.includes('excel')) return 'XLSX';
        if (mimeType.includes('image')) return 'IMAGE';
        return 'OTHER';
      };

      // Upload to storage
      const fileExt = file.name.split('.').pop();
      const filePath = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Create document record
      const docData: DocumentUploadData = {
        name: file.name,
        size: file.size,
        type: getDocType(file.type),
        file_path: filePath,
        uploaded_by: user.id,
        lead_id: entityType === 'lead' ? entityId : undefined,
        client_id: entityType === 'client' ? entityId : undefined,
        kyc_record_id: kycRecordId,
      };

      const { data, error } = await supabase
        .from('documents')
        .insert([docData])
        .select()
        .single();

      if (error) throw error;

      // Log the activity
      await logAction({
        actionType: 'document_uploaded',
        entityType,
        entityId,
        details: {
          document_id: data.id,
          document_name: file.name,
          document_type: getDocType(file.type),
          document_size: file.size,
          kyc_record_id: kycRecordId,
        },
      });

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      toast({
        title: "Document uploaded",
        description: "The document has been successfully uploaded.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Upload failed",
        description: message,
        variant: "destructive",
      });
    },
  });

  const deleteDocument = useMutation({
    mutationFn: async (id: string) => {
      // Get document to delete from storage
      const { data: doc } = await supabase
        .from('documents')
        .select('*')
        .eq('id', id)
        .single();

      if (doc) {
        await supabase.storage.from('documents').remove([doc.file_path]);
      }

      const { error } = await supabase
        .from('documents')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Log the activity
      if (doc) {
        await logAction({
          actionType: 'document_deleted',
          entityType: doc.lead_id ? 'lead' : 'client',
          entityId: doc.lead_id || doc.client_id || id,
          details: {
            document_id: id,
            document_name: doc.name,
            document_type: doc.type,
          },
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      toast({
        title: "Document deleted",
        description: "The document has been successfully deleted.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Delete failed",
        description: message,
        variant: "destructive",
      });
    },
  });

  const downloadDocument = async (filePath: string, fileName: string) => {
    const { data, error } = await supabase.storage
      .from('documents')
      .download(filePath);

    if (error) {
      toast({
        title: "Download failed",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return {
    documents,
    isLoading,
    uploadDocument,
    deleteDocument,
    downloadDocument,
  };
};
