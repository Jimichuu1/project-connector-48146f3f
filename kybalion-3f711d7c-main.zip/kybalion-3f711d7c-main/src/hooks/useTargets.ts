import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, format } from "date-fns";

export interface TargetHistoryRow {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  target_type: "transfers" | "deposits" | "team_transfers";
  target_value: number;
  period: "daily" | "weekly" | "monthly";
  period_start: string;
  period_end: string;
  notes: string | null;
  current_value: number;
  achieved: boolean;
}

export function useTargetHistory(adminId: string | null | undefined, monthDate: Date) {
  const startStr = format(startOfMonth(monthDate), "yyyy-MM-dd");
  const endStr = format(endOfMonth(monthDate), "yyyy-MM-dd");
  const query = useQuery({
    queryKey: ["target-history", adminId, startStr, endStr],
    enabled: !!adminId,
    staleTime: 60 * 1000,
    queryFn: async () => {
      const { data, error } = await (supabase as any).rpc("get_target_history", {
        p_admin_id: adminId,
        p_month_start: startStr,
        p_month_end: endStr,
      });
      if (error) throw error;
      return (data as TargetHistoryRow[]) || [];
    },
  });
  return { ...query, monthStart: startStr, monthEnd: endStr };
}

export type TargetType = "transfers" | "deposits" | "team_transfers";
export type TargetPeriod = "daily" | "weekly" | "monthly";

export interface PerformanceTarget {
  id: string;
  admin_id: string;
  user_id: string;
  target_type: TargetType;
  target_value: number;
  period: TargetPeriod;
  period_start: string;
  period_end: string;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface TargetProgress {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  target_type: TargetType;
  target_value: number;
  period: TargetPeriod;
  period_start: string;
  period_end: string;
  notes: string | null;
  current_value: number;
}

export function getPeriodRange(period: TargetPeriod, ref: Date = new Date()) {
  if (period === "daily") {
    return { start: startOfDay(ref), end: endOfDay(ref) };
  }
  if (period === "weekly") {
    return {
      start: startOfWeek(ref, { weekStartsOn: 1 }),
      end: endOfWeek(ref, { weekStartsOn: 1 }),
    };
  }
  return { start: startOfMonth(ref), end: endOfMonth(ref) };
}

export function useTargetProgress(adminId: string | null | undefined, period: TargetPeriod) {
  const { start, end } = getPeriodRange(period);
  const startStr = format(start, "yyyy-MM-dd");
  const endStr = format(end, "yyyy-MM-dd");

  return useQuery({
    queryKey: ["target-progress", adminId, period, startStr, endStr],
    enabled: !!adminId,
    staleTime: 60 * 1000,
    queryFn: async () => {
      const { data, error } = await (supabase as any).rpc("get_target_progress", {
        p_admin_id: adminId,
        p_period_start: startStr,
        p_period_end: endStr,
      });
      if (error) throw error;
      return ((data as TargetProgress[]) || []).filter(t => t.period === period);
    },
  });
}

export function useMyTargets(userId: string | null | undefined) {
  return useQuery({
    queryKey: ["my-targets", userId],
    enabled: !!userId,
    staleTime: 60 * 1000,
    queryFn: async () => {
      const today = format(new Date(), "yyyy-MM-dd");
      const { data, error } = await supabase
        .from("performance_targets" as any)
        .select("*")
        .eq("user_id", userId!)
        .lte("period_start", today)
        .gte("period_end", today);
      if (error) throw error;
      return (data as unknown as PerformanceTarget[]) || [];
    },
  });
}

export function useCreateTarget() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      adminId: string;
      userIds: string[];
      target_type: TargetType;
      target_value: number;
      period: TargetPeriod;
      notes?: string;
      createdBy: string;
      referenceDate?: Date;
    }) => {
      const { start, end } = getPeriodRange(input.period, input.referenceDate || new Date());
      const rows = input.userIds.map(uid => ({
        admin_id: input.adminId,
        user_id: uid,
        target_type: input.target_type,
        target_value: input.target_value,
        period: input.period,
        period_start: format(start, "yyyy-MM-dd"),
        period_end: format(end, "yyyy-MM-dd"),
        notes: input.notes || null,
        created_by: input.createdBy,
      }));
      const { error } = await supabase
        .from("performance_targets" as any)
        .upsert(rows, { onConflict: "user_id,target_type,period,period_start" });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["target-progress"] });
      qc.invalidateQueries({ queryKey: ["my-targets"] });
      toast.success("Target(s) saved");
    },
    onError: (e: any) => toast.error(e.message || "Failed to save target"),
  });
}

export function useUpdateTarget() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { id: string; target_value: number; notes?: string | null }) => {
      const { error } = await supabase
        .from("performance_targets" as any)
        .update({ target_value: input.target_value, notes: input.notes ?? null })
        .eq("id", input.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["target-progress"] });
      qc.invalidateQueries({ queryKey: ["my-targets"] });
      toast.success("Target updated");
    },
    onError: (e: any) => toast.error(e.message || "Failed to update"),
  });
}

export function useDeleteTarget() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("performance_targets" as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["target-progress"] });
      qc.invalidateQueries({ queryKey: ["my-targets"] });
      toast.success("Target deleted");
    },
    onError: (e: any) => toast.error(e.message || "Failed to delete"),
  });
}
