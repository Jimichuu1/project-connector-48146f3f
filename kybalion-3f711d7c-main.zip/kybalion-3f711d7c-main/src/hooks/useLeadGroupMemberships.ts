import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";

export const useLeadGroupMemberships = (leadIds: string[]) => {
  const { effectiveTenantId } = useTenant();

  return useQuery({
    queryKey: ['lead-group-memberships', leadIds.sort().join(','), effectiveTenantId],
    queryFn: async () => {
      if (leadIds.length === 0) return new Map<string, string[]>();

      // Batch fetch all memberships for the given leads
      const { data: memberships, error: membershipError } = await supabase
        .from('lead_group_members')
        .select('lead_id, group_id')
        .in('lead_id', leadIds);

      if (membershipError || !memberships || memberships.length === 0) {
        return new Map<string, string[]>();
      }

      // Get unique group IDs
      const groupIds = [...new Set(memberships.map(m => m.group_id))];

      // Fetch all group names at once
      const { data: groups, error: groupError } = await supabase
        .from('lead_groups')
        .select('id, name')
        .in('id', groupIds);

      if (groupError || !groups) {
        return new Map<string, string[]>();
      }

      // Create a map of group ID to name
      const groupNameMap = new Map(groups.map(g => [g.id, g.name]));

      // Create a map of lead ID to array of group names
      const leadGroupMap = new Map<string, string[]>();
      memberships.forEach(m => {
        const groupName = groupNameMap.get(m.group_id);
        if (groupName) {
          const existing = leadGroupMap.get(m.lead_id) || [];
          existing.push(groupName);
          leadGroupMap.set(m.lead_id, existing);
        }
      });

      return leadGroupMap;
    },
    staleTime: 30000, // Cache for 30 seconds
    enabled: leadIds.length > 0,
  });
};
