import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { waitFor } from '@testing-library/dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';

// Mock the UserDataContext
const mockUseUserData = vi.fn();

vi.mock('@/contexts/UserDataContext', () => ({
  useUserData: () => mockUseUserData(),
}));

// Import after mocking
import { useUserRole } from '../useUserRole';

const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
    },
  });
  return ({ children }: { children: React.ReactNode }) =>
    React.createElement(QueryClientProvider, { client: queryClient }, children);
};

describe('useUserRole', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns loading state when user data is loading', () => {
    mockUseUserData.mockReturnValue({
      role: null,
      isSuperAdmin: false,
      isTenantOwner: false,
      isManager: false,
      isSuperAgent: false,
      isAgent: false,
      hasSuperAdminAccess: false,
      hasTenantOwnerAccess: false,
      hasManagerAccess: false,
      hasSuperAgentAccess: false,
      loading: true,
    });

    const { result } = renderHook(() => useUserRole(), {
      wrapper: createWrapper(),
    });

    expect(result.current.loading).toBe(true);
  });

  it('returns role data when user data is loaded', async () => {
    mockUseUserData.mockReturnValue({
      role: 'TENANT_OWNER',
      isSuperAdmin: false,
      isTenantOwner: true,
      isManager: false,
      isSuperAgent: false,
      isAgent: false,
      hasSuperAdminAccess: false,
      hasTenantOwnerAccess: true,
      hasManagerAccess: true,
      hasSuperAgentAccess: true,
      loading: false,
    });

    const { result } = renderHook(() => useUserRole(), {
      wrapper: createWrapper(),
    });

    expect(result.current.loading).toBe(false);
    expect(result.current.role).toBe('TENANT_OWNER');
    expect(result.current.isTenantOwner).toBe(true);
    expect(result.current.isAgent).toBe(false);
  });

  it('returns correct boolean flags for agent role', async () => {
    mockUseUserData.mockReturnValue({
      role: 'AGENT',
      isSuperAdmin: false,
      isTenantOwner: false,
      isManager: false,
      isSuperAgent: false,
      isAgent: true,
      hasSuperAdminAccess: false,
      hasTenantOwnerAccess: false,
      hasManagerAccess: false,
      hasSuperAgentAccess: false,
      loading: false,
    });

    const { result } = renderHook(() => useUserRole(), {
      wrapper: createWrapper(),
    });

    expect(result.current.role).toBe('AGENT');
    expect(result.current.isAgent).toBe(true);
    expect(result.current.isTenantOwner).toBe(false);
    expect(result.current.isManager).toBe(false);
    expect(result.current.isSuperAgent).toBe(false);
  });
});
