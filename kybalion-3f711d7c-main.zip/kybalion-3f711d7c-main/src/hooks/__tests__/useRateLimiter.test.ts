import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock fetch for IP retrieval
global.fetch = vi.fn();

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    rpc: vi.fn(),
    from: vi.fn(() => ({
      insert: vi.fn(() => ({
        data: null,
        error: null
      }))
    })),
    auth: {
      getUser: vi.fn(() => Promise.resolve({ data: { user: { id: 'user-1' } }, error: null }))
    }
  }
}));

describe('useRateLimiter hook', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (global.fetch as any).mockResolvedValue({
      json: () => Promise.resolve({ ip: '192.168.1.1' })
    });
  });

  it('should be importable', async () => {
    const { useRateLimiter } = await import('../useRateLimiter');
    expect(useRateLimiter).toBeDefined();
  });
});

describe('Rate limiting logic', () => {
  it('should determine if IP is blocked', () => {
    const isIpBlocked = (failedAttempts: number, maxAttempts: number) => 
      failedAttempts >= maxAttempts;
    
    expect(isIpBlocked(5, 5)).toBe(true);
    expect(isIpBlocked(4, 5)).toBe(false);
    expect(isIpBlocked(10, 5)).toBe(true);
  });

  it('should calculate remaining attempts', () => {
    const getRemainingAttempts = (failedAttempts: number, maxAttempts: number) => 
      Math.max(0, maxAttempts - failedAttempts);
    
    expect(getRemainingAttempts(3, 5)).toBe(2);
    expect(getRemainingAttempts(5, 5)).toBe(0);
    expect(getRemainingAttempts(0, 5)).toBe(5);
  });

  it('should determine if CAPTCHA is needed', () => {
    const needsCaptcha = (failedAttempts: number, captchaThreshold: number) => 
      failedAttempts >= captchaThreshold;
    
    expect(needsCaptcha(3, 3)).toBe(true);
    expect(needsCaptcha(2, 3)).toBe(false);
  });

  it('should calculate block duration', () => {
    const calculateBlockDuration = (failedAttempts: number, baseMinutes: number = 15) => {
      const multiplier = Math.floor(failedAttempts / 5);
      return baseMinutes * Math.pow(2, multiplier);
    };
    
    expect(calculateBlockDuration(5)).toBe(30); // 15 * 2^1
    expect(calculateBlockDuration(10)).toBe(60); // 15 * 2^2
  });

  it('should check if block has expired', () => {
    const isBlockExpired = (blockedUntil: Date) => new Date() > blockedUntil;
    
    const pastDate = new Date('2020-01-01');
    const futureDate = new Date('2099-01-01');
    
    expect(isBlockExpired(pastDate)).toBe(true);
    expect(isBlockExpired(futureDate)).toBe(false);
  });

  it('should validate IP address format', () => {
    const isValidIpv4 = (ip: string) => {
      const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
      if (!ipv4Regex.test(ip)) return false;
      return ip.split('.').every(octet => parseInt(octet) <= 255);
    };
    
    expect(isValidIpv4('192.168.1.1')).toBe(true);
    expect(isValidIpv4('256.1.1.1')).toBe(false);
    expect(isValidIpv4('invalid')).toBe(false);
  });
});
