import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import React from 'react';

// Mock Supabase
vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        order: vi.fn(() => ({
          data: [
            {
              id: '1',
              amount: 5000,
              status: 'approved',
              client_id: 'client-1',
              agent_id: 'agent-1',
              agent_percentage: 30,
              agent_amount: 1500,
              super_agent_id: 'super-agent-1',
              super_agent_percentage: 70,
              super_agent_amount: 3500,
            },
          ],
          error: null,
        })),
        eq: vi.fn(() => ({
          order: vi.fn(() => ({
            data: [],
            error: null,
          })),
        })),
      })),
      insert: vi.fn(() => ({
        select: vi.fn(() => ({
          single: vi.fn(() => ({
            data: { id: '2', amount: 10000 },
            error: null,
          })),
        })),
      })),
      update: vi.fn(() => ({
        eq: vi.fn(() => ({
          select: vi.fn(() => ({
            single: vi.fn(() => ({
              data: { id: '1', status: 'approved' },
              error: null,
            })),
          })),
        })),
      })),
    })),
    channel: vi.fn(() => ({
      on: vi.fn(() => ({
        subscribe: vi.fn(),
      })),
    })),
    removeChannel: vi.fn(),
  },
}));

// Mock AuthContext
vi.mock('@/contexts/AuthContext', () => ({
  useAuth: () => ({
    user: { id: 'test-user-id' },
    session: { access_token: 'test-token' },
  }),
}));

const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

  return ({ children }: { children: React.ReactNode }) =>
    React.createElement(QueryClientProvider, { client: queryClient }, children);
};

describe('useDeposits hook', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should be importable', async () => {
    const { useDeposits } = await import('@/hooks/useDeposits');
    expect(useDeposits).toBeDefined();
  });

  it('should return expected structure', async () => {
    const { useDeposits } = await import('@/hooks/useDeposits');
    const { result } = renderHook(() => useDeposits(), {
      wrapper: createWrapper(),
    });

    expect(result.current).toHaveProperty('deposits');
    expect(result.current).toHaveProperty('isLoading');
    expect(result.current).toHaveProperty('createDeposit');
    expect(result.current).toHaveProperty('approveDeposit');
    expect(result.current).toHaveProperty('rejectDeposit');
  });
});
