import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: [
            { id: '1', bank_name: 'Test Bank', notes: 'Test notes', status: 'PENDING' }
          ],
          error: null
        }))
      })),
      insert: vi.fn(() => ({
        select: vi.fn(() => ({
          single: vi.fn(() => ({
            data: { id: '2', bank_name: 'New Bank' },
            error: null
          }))
        }))
      })),
      update: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: { id: '1', status: 'VERIFIED' },
          error: null
        }))
      })),
      delete: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: null,
          error: null
        }))
      }))
    })),
    auth: {
      getUser: vi.fn(() => Promise.resolve({ data: { user: { id: 'user-1' } }, error: null }))
    }
  }
}));

describe('useKYC hook', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should be importable', async () => {
    const { useKYC } = await import('../useKYC');
    expect(useKYC).toBeDefined();
  });
});

describe('KYC validation', () => {
  it('should validate KYC status values', () => {
    const validStatuses = ['PENDING', 'VERIFIED', 'REJECTED'];
    expect(validStatuses.includes('PENDING')).toBe(true);
    expect(validStatuses.includes('INVALID')).toBe(false);
  });

  it('should validate bank name is not empty', () => {
    const isValidBankName = (name: string) => name.trim().length > 0;
    expect(isValidBankName('Test Bank')).toBe(true);
    expect(isValidBankName('')).toBe(false);
    expect(isValidBankName('   ')).toBe(false);
  });

  it('should check if lead has required KYC for conversion', () => {
    const hasRequiredKYC = (kycRecords: { bank_name?: string; notes?: string }[]) => {
      const hasBank = kycRecords.some(r => r.bank_name && r.bank_name.trim().length > 0);
      const hasNotes = kycRecords.some(r => r.notes && r.notes.trim().length > 0);
      return hasBank && hasNotes;
    };
    
    expect(hasRequiredKYC([{ bank_name: 'Bank', notes: 'Notes' }])).toBe(true);
    expect(hasRequiredKYC([{ bank_name: 'Bank' }])).toBe(false);
    expect(hasRequiredKYC([{ notes: 'Notes' }])).toBe(false);
    expect(hasRequiredKYC([])).toBe(false);
  });

  it('should count KYC records by type', () => {
    const countByType = (records: { bank_name?: string; notes?: string }[]) => ({
      banks: records.filter(r => r.bank_name).length,
      notes: records.filter(r => r.notes).length
    });
    
    const records = [
      { bank_name: 'Bank 1' },
      { bank_name: 'Bank 2', notes: 'Note 1' },
      { notes: 'Note 2' }
    ];
    
    const counts = countByType(records);
    expect(counts.banks).toBe(2);
    expect(counts.notes).toBe(2);
  });
});
