import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: [
            { id: '1', name: 'document.pdf', type: 'ID_DOCUMENT', size: 1024000 }
          ],
          error: null
        }))
      })),
      insert: vi.fn(() => ({
        select: vi.fn(() => ({
          single: vi.fn(() => ({
            data: { id: '2', name: 'new-doc.pdf' },
            error: null
          }))
        }))
      })),
      delete: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: null,
          error: null
        }))
      }))
    })),
    storage: {
      from: vi.fn(() => ({
        upload: vi.fn(() => ({ data: { path: 'uploads/doc.pdf' }, error: null })),
        download: vi.fn(() => ({ data: new Blob(), error: null })),
        remove: vi.fn(() => ({ data: null, error: null })),
        getPublicUrl: vi.fn(() => ({ data: { publicUrl: 'https://example.com/doc.pdf' } }))
      }))
    },
    auth: {
      getUser: vi.fn(() => Promise.resolve({ data: { user: { id: 'user-1' } }, error: null }))
    }
  }
}));

describe('useDocuments hook', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should be importable', async () => {
    const { useDocuments } = await import('../useDocuments');
    expect(useDocuments).toBeDefined();
  });
});

describe('Document validation', () => {
  it('should validate file type', () => {
    const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'application/msword'];
    const isValidType = (mimeType: string) => allowedTypes.includes(mimeType);
    
    expect(isValidType('application/pdf')).toBe(true);
    expect(isValidType('image/png')).toBe(true);
    expect(isValidType('application/exe')).toBe(false);
  });

  it('should validate file size', () => {
    const maxSizeBytes = 10 * 1024 * 1024; // 10MB
    const isValidSize = (size: number) => size <= maxSizeBytes;
    
    expect(isValidSize(5 * 1024 * 1024)).toBe(true);
    expect(isValidSize(15 * 1024 * 1024)).toBe(false);
  });

  it('should format file size for display', () => {
    const formatFileSize = (bytes: number) => {
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    };
    
    expect(formatFileSize(500)).toBe('500 B');
    expect(formatFileSize(1536)).toBe('1.5 KB');
    expect(formatFileSize(1572864)).toBe('1.5 MB');
  });

  it('should validate document type enum', () => {
    const validTypes = ['ID_DOCUMENT', 'PROOF_OF_ADDRESS', 'BANK_STATEMENT', 'OTHER'];
    expect(validTypes.includes('ID_DOCUMENT')).toBe(true);
    expect(validTypes.includes('INVALID')).toBe(false);
  });

  it('should extract file extension', () => {
    const getExtension = (filename: string) => {
      const parts = filename.split('.');
      return parts.length > 1 ? parts.pop()?.toLowerCase() : '';
    };
    
    expect(getExtension('document.pdf')).toBe('pdf');
    expect(getExtension('image.PNG')).toBe('png');
    expect(getExtension('noextension')).toBe('');
  });

  it('should generate unique file path', () => {
    const generatePath = (userId: string, filename: string) => {
      const timestamp = Date.now();
      const sanitized = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
      return `${userId}/${timestamp}_${sanitized}`;
    };
    
    const path = generatePath('user-1', 'my document.pdf');
    expect(path).toContain('user-1/');
    expect(path).toContain('my_document.pdf');
  });
});
