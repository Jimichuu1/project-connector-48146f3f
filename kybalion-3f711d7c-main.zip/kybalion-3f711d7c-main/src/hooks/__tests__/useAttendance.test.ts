import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          order: vi.fn(() => ({
            data: [
              { id: '1', clock_in: '2024-01-01T09:00:00Z', clock_out: '2024-01-01T17:00:00Z' }
            ],
            error: null
          }))
        }))
      })),
      insert: vi.fn(() => ({
        select: vi.fn(() => ({
          single: vi.fn(() => ({
            data: { id: '2', clock_in: new Date().toISOString() },
            error: null
          }))
        }))
      })),
      update: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: { id: '1', clock_out: new Date().toISOString() },
          error: null
        }))
      }))
    })),
    auth: {
      getUser: vi.fn(() => Promise.resolve({ data: { user: { id: 'user-1' } }, error: null }))
    }
  }
}));

describe('useAttendance hook', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should be importable', async () => {
    const { useAttendance } = await import('../useAttendance');
    expect(useAttendance).toBeDefined();
  });
});

describe('Attendance calculations', () => {
  it('should calculate working hours correctly', () => {
    const calculateWorkingHours = (clockIn: Date, clockOut: Date) => {
      const diffMs = clockOut.getTime() - clockIn.getTime();
      return diffMs / (1000 * 60 * 60);
    };
    
    const clockIn = new Date('2024-01-01T09:00:00Z');
    const clockOut = new Date('2024-01-01T17:00:00Z');
    
    expect(calculateWorkingHours(clockIn, clockOut)).toBe(8);
  });

  it('should calculate break minutes correctly', () => {
    const calculateBreakMinutes = (periods: { start: string; end: string }[]) => {
      return periods.reduce((total, period) => {
        const start = new Date(period.start);
        const end = new Date(period.end);
        return total + (end.getTime() - start.getTime()) / (1000 * 60);
      }, 0);
    };
    
    const periods = [
      { start: '2024-01-01T12:00:00Z', end: '2024-01-01T12:30:00Z' },
      { start: '2024-01-01T15:00:00Z', end: '2024-01-01T15:15:00Z' }
    ];
    
    expect(calculateBreakMinutes(periods)).toBe(45);
  });

  it('should determine if clock-in is late', () => {
    const isLate = (clockIn: Date, startTime: string) => {
      const [hours, minutes] = startTime.split(':').map(Number);
      const expectedStart = new Date(clockIn);
      expectedStart.setHours(hours, minutes, 0, 0);
      return clockIn > expectedStart;
    };
    
    const lateClockIn = new Date('2024-01-01T09:30:00');
    const onTimeClockIn = new Date('2024-01-01T08:55:00');
    
    expect(isLate(lateClockIn, '09:00')).toBe(true);
    expect(isLate(onTimeClockIn, '09:00')).toBe(false);
  });

  it('should calculate late fee correctly', () => {
    const calculateLateFee = (minutesLate: number, feePerMinute: number) => 
      minutesLate * feePerMinute;
    
    expect(calculateLateFee(30, 0.5)).toBe(15);
    expect(calculateLateFee(0, 0.5)).toBe(0);
  });

  it('should calculate excessive break fee correctly', () => {
    const calculateBreakFee = (breakMinutes: number, maxAllowed: number, feePerMinute: number) => {
      const excessMinutes = Math.max(0, breakMinutes - maxAllowed);
      return excessMinutes * feePerMinute;
    };
    
    expect(calculateBreakFee(90, 60, 1)).toBe(30);
    expect(calculateBreakFee(45, 60, 1)).toBe(0);
  });
});
