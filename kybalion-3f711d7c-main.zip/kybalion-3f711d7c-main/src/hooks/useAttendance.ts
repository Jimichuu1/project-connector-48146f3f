import { useState, useEffect, useRef, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import type { Attendance, AttendanceWithProfile, TenantAttendanceGroup, TenantSettings, RuleSnapshot } from "@/types/attendance";
import { format } from "date-fns";
import { useTenant } from "@/contexts/TenantContext";
import type { Json } from "@/integrations/supabase/types";
import { localTimeToUTC } from "@/lib/timezoneUtils";

// Helper to get server time as YYYY-MM-DD in UTC (consistent with ClockButtons/WorkingToggle)
async function fetchServerTimeKey(): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_server_time') as { data: string | null; error: Error | null };
    if (error || !data) {
      console.warn('[useAttendance] Failed to fetch server time, using device time');
      return new Date().toISOString().split("T")[0];
    }
    return new Date(data).toISOString().split("T")[0];
  } catch (err) {
    console.error('[useAttendance] Error fetching server time:', err);
    return new Date().toISOString().split("T")[0];
  }
}

// Helper to get server timestamp for clock-in/out
async function fetchServerTimestamp(): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_server_time') as { data: string | null; error: Error | null };
    if (error || !data) {
      console.warn('[useAttendance] Failed to fetch server timestamp, using device time');
      return new Date().toISOString();
    }
    return data;
  } catch (err) {
    console.error('[useAttendance] Error fetching server timestamp:', err);
    return new Date().toISOString();
  }
}

const REALTIME_DEBOUNCE_MS = 1000;
// Holiday dates are now fetched dynamically from admin_settings per tenant

const DEFAULT_SETTINGS: TenantSettings = {
  work_start_time: "09:00",
  work_end_time: "18:00",
  late_start_fee: 0,
  excessive_break_fee: 0,
  day_off_fee: 0,
  max_break_minutes: 60,
  monthly_honorable_absences: 0,
};

const normalizeTimeValue = (value: unknown): string | null => {
  if (typeof value !== "string") return null;
  const [hours, minutes] = value.split(":");
  if (hours == null || minutes == null) return null;
  const normalizedHours = Number(hours);
  const normalizedMinutes = Number(minutes);
  if (!Number.isFinite(normalizedHours) || !Number.isFinite(normalizedMinutes)) return null;
  return `${String(normalizedHours).padStart(2, "0")}:${String(normalizedMinutes).padStart(2, "0")}`;
};

const toNumberOrZero = (value: unknown): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const parseRuleSnapshot = (snapshot: Json | null | undefined): RuleSnapshot | null => {
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) return null;

  const source = snapshot as Record<string, unknown>;
  const workStartTime = normalizeTimeValue(source.work_start_time);
  const workEndTime = normalizeTimeValue(source.work_end_time);

  if (!workStartTime || !workEndTime) return null;

  return {
    work_start_time: workStartTime,
    work_end_time: workEndTime,
    late_start_fee: toNumberOrZero(source.late_start_fee),
    excessive_break_fee: toNumberOrZero(source.excessive_break_fee),
    day_off_fee: toNumberOrZero(source.day_off_fee),
    max_break_minutes: toNumberOrZero(source.max_break_minutes) || 60,
  };
};

interface UseAttendanceOptions {
  teamMemberIds?: string[];
}

export const useAttendance = (dateRange?: { from: Date; to: Date }, options?: UseAttendanceOptions) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { effectiveTenantId, isSuperAdmin, isTenantOwner } = useTenant();
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [allAttendance, setAllAttendance] = useState<AttendanceWithProfile[]>([]);
  const [tenantGroups, setTenantGroups] = useState<TenantAttendanceGroup[]>([]);
  const [todayAttendance, setTodayAttendance] = useState<Attendance | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdminUser, setIsAdminUser] = useState(false);
  const [settings, setSettings] = useState<TenantSettings>(DEFAULT_SETTINGS);
  const [holidayDates, setHolidayDates] = useState<Set<string>>(new Set());
  
  // Debounce ref for realtime updates
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const teamMemberIds = options?.teamMemberIds;
  
  // Debounced fetch for realtime updates
  const debouncedFetchAttendance = useCallback(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      fetchAttendance();
    }, REALTIME_DEBOUNCE_MS);
  }, []);

  useEffect(() => {
    if (user) {
      checkAdminStatus();
      fetchSettings();
      fetchAttendance();
    }
  }, [user, dateRange, effectiveTenantId, teamMemberIds?.join(',')]);

  // Real-time subscription for attendance updates with debouncing
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('attendance-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'attendance'
        },
        () => {
          // Debounced refetch attendance on any change
          debouncedFetchAttendance();
        }
      )
      .subscribe();

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      supabase.removeChannel(channel);
    };
  }, [user, dateRange, effectiveTenantId, teamMemberIds?.join(','), debouncedFetchAttendance]);

  const checkAdminStatus = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["TENANT_OWNER", "MANAGER", "SUPER_ADMIN"])
      .maybeSingle();

    setIsAdminUser(!!data);
  };

  const fetchSettings = async () => {
    if (!user) return;

    // First try to get tenant-specific settings from admin_settings
    if (effectiveTenantId) {
      const { data: tenantSettings } = await supabase
        .from("admin_settings")
        .select("work_start_time, work_end_time, late_start_fee, excessive_break_fee, day_off_fee, max_break_minutes, monthly_honorable_absences, holiday_dates")
        .eq("admin_id", effectiveTenantId)
        .maybeSingle();
      
      if (tenantSettings) {
        setSettings({
          work_start_time: tenantSettings.work_start_time.substring(0, 5),
          work_end_time: tenantSettings.work_end_time.substring(0, 5),
          late_start_fee: Number(tenantSettings.late_start_fee),
          excessive_break_fee: Number(tenantSettings.excessive_break_fee),
          day_off_fee: Number(tenantSettings.day_off_fee),
          max_break_minutes: Number(tenantSettings.max_break_minutes) || 60,
          monthly_honorable_absences: Number(tenantSettings.monthly_honorable_absences) || 0,
        });
        setHolidayDates(new Set((tenantSettings as any).holiday_dates || []));
        return;
      }
    }

    // No tenant context — leave defaults in place; settings live in admin_settings only.
    return;
  };

  const fetchAttendance = async (showLoading = true) => {
    if (!user) return;

    try {
      if (showLoading) setLoading(true);

      // Check admin status first
      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .in("role", ["TENANT_OWNER", "MANAGER", "SUPER_ADMIN"])
        .maybeSingle();

      const hasAdminAccess = !!roleData;
      const isSuperAdminRole = roleData?.role === 'SUPER_ADMIN';
      const isManagerRole = roleData?.role === 'MANAGER';

      if (hasAdminAccess) {
        // Determine date range
        const fromDate = dateRange?.from ? format(dateRange.from, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd");
        const toDate = dateRange?.to ? format(dateRange.to, "yyyy-MM-dd") : fromDate;

        // Fetch all users with AGENT or SUPER_AGENT roles
        const { data: agentRoles } = await supabase
          .from("user_roles")
          .select("user_id")
          .in("role", ["AGENT", "SUPER_AGENT", "TEAM_LEADER"]);

        let agentUserIds = agentRoles?.map((r) => r.user_id) || [];

        // For managers, filter to only team members
        if (isManagerRole) {
          if (teamMemberIds !== undefined) {
            agentUserIds = teamMemberIds.length > 0 
              ? agentUserIds.filter(id => teamMemberIds.includes(id))
              : []; // No team members = no results
          }
        }

        // Build profiles query - filter by tenant if not super admin or if tenant is selected
        let profilesQuery = supabase
          .from("profiles")
          .select("id, full_name, email, admin_id, created_at")
          .in("id", agentUserIds.length > 0 ? agentUserIds : ['no-users']);

        // Filter by tenant for non-super-admins or when a specific tenant is selected
        if (effectiveTenantId) {
          profilesQuery = profilesQuery.eq("admin_id", effectiveTenantId);
        }

        const { data: profilesData } = await profilesQuery;
        
        // Update agentUserIds based on filtered profiles
        agentUserIds = profilesData?.map(p => p.id) || [];

        // Fetch attendance records for date range
        let attendanceQuery = supabase
          .from("attendance")
          .select("*")
          .gte("date", fromDate)
          .lte("date", toDate)
          .in("user_id", agentUserIds.length > 0 ? agentUserIds : ['no-users'])
          .order("date", { ascending: false })
          .order("clock_in", { ascending: false });

        const { data: attendanceData, error } = await attendanceQuery;

        if (error) throw error;

        // Also fetch full-month attendance dates for honorable absence calculation
        // (the view range may be partial, but honorable counting must span the full month)
        const uniqueMonths = new Set<string>();
        const viewFromDate = new Date(fromDate);
        const viewToDate = new Date(toDate);
        let m = new Date(viewFromDate.getFullYear(), viewFromDate.getMonth(), 1);
        while (m <= viewToDate) {
          uniqueMonths.add(format(m, "yyyy-MM"));
          m = new Date(m.getFullYear(), m.getMonth() + 1, 1);
        }
        const fullMonthStart = format(new Date(viewFromDate.getFullYear(), viewFromDate.getMonth(), 1), "yyyy-MM-dd");
        const lastMonth = [...uniqueMonths].sort().pop()!;
        const [ly, lm] = lastMonth.split("-").map(Number);
        const fullMonthEnd = format(new Date(ly, lm, 0), "yyyy-MM-dd"); // last day of last month

        let fullMonthAttendanceDates: Array<{ user_id: string; date: string; notes: string | null }> = [];
        if (fullMonthStart !== fromDate || fullMonthEnd !== toDate) {
          // Need to fetch broader range for honorable counting (include notes to filter day-off records)
          const { data: fullData } = await supabase
            .from("attendance")
            .select("user_id, date, notes")
            .gte("date", fullMonthStart)
            .lte("date", fullMonthEnd)
            .in("user_id", agentUserIds.length > 0 ? agentUserIds : ['no-users']);
          fullMonthAttendanceDates = fullData || [];
        }

        // Note: we no longer filter out holiday dates from attendance data
        // Holidays are shown in the table but generate "Holiday" virtual records with no fees
        const filteredAttendanceData = attendanceData || [];
        const filteredFullMonthAttendanceDates = fullMonthAttendanceDates;

        // Create a map of attendance by user_id and date
        const attendanceMap = new Map<string, Attendance>();
        filteredAttendanceData.forEach((a) => {
          attendanceMap.set(`${a.user_id}-${a.date}`, a);
        });

        // Build full-month attendance set per user for honorable counting
        // IMPORTANT: Exclude "Day off" records — they are still day-offs even if stored as real records
        const fullMonthAttendanceByUser = new Map<string, Set<string>>();
        // Include view-range records (only non-day-off ones)
        filteredAttendanceData.forEach((a) => {
          if (a.notes?.includes("Day off")) return; // day-off records don't count as "present"
          const set = fullMonthAttendanceByUser.get(a.user_id) || new Set();
          set.add(a.date);
          fullMonthAttendanceByUser.set(a.user_id, set);
        });
        // Include broader range records
        filteredFullMonthAttendanceDates.forEach((a) => {
          if (a.notes?.includes("Day off")) return;
          const set = fullMonthAttendanceByUser.get(a.user_id) || new Set();
          set.add(a.date);
          fullMonthAttendanceByUser.set(a.user_id, set);
        });

        // Generate date range array (include all dates; holidays handled later)
        const dates: string[] = [];
        const currentDate = new Date(fromDate);
        const endDate = new Date(toDate);
        while (currentDate <= endDate) {
          const dateKey = format(currentDate, "yyyy-MM-dd");
          dates.push(dateKey);
          currentDate.setDate(currentDate.getDate() + 1);
        }

        // Get unique tenant IDs from profiles
        const tenantIds = [...new Set(profilesData?.map(p => p.admin_id).filter(Boolean) || [])];

        // Fetch all tenant settings and names
        const { data: tenantProfiles } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", tenantIds);

        const { data: allTenantSettings } = await supabase
          .from("admin_settings")
          .select("admin_id, work_start_time, work_end_time, late_start_fee, excessive_break_fee, day_off_fee, max_break_minutes, monthly_honorable_absences, holiday_dates")
          .in("admin_id", tenantIds);

        // Build combined holiday dates set from all tenants
        const holidayDatesSet = new Set<string>();
        allTenantSettings?.forEach(s => {
          ((s as any).holiday_dates || []).forEach((d: string) => holidayDatesSet.add(d));
        });
        // Also build per-tenant holiday sets for correct per-tenant handling
        const holidayDatesByTenant = new Map<string, Set<string>>();
        allTenantSettings?.forEach(s => {
          holidayDatesByTenant.set(s.admin_id, new Set((s as any).holiday_dates || []));
        });

        // Create a map of settings by tenant ID
        const settingsMap = new Map<string, TenantSettings>();
        allTenantSettings?.forEach(s => {
          settingsMap.set(s.admin_id, {
            work_start_time: s.work_start_time.substring(0, 5),
            work_end_time: s.work_end_time.substring(0, 5),
            late_start_fee: Number(s.late_start_fee),
            excessive_break_fee: Number(s.excessive_break_fee),
            day_off_fee: Number(s.day_off_fee),
            max_break_minutes: Number(s.max_break_minutes) || 60,
            monthly_honorable_absences: Number(s.monthly_honorable_absences) || 0,
          });
        });

        // Load historical snapshots up to selected end date so day-off fees stay historically correct
        const historicalRulesByTenant = new Map<string, Array<{ date: string; rules: RuleSnapshot }>>();
        if (tenantIds.length > 0) {
          const { data: historicalSnapshots } = await supabase
            .from("attendance")
            .select("admin_id, date, rule_snapshot")
            .in("admin_id", tenantIds)
            .lte("date", toDate)
            .not("rule_snapshot", "is", null)
            .order("date", { ascending: true });

          historicalSnapshots?.forEach((row) => {
            if (!row.admin_id) return;
            const parsed = parseRuleSnapshot(row.rule_snapshot as Json | null);
            if (!parsed) return;

            const existing = historicalRulesByTenant.get(row.admin_id) || [];
            existing.push({ date: row.date, rules: parsed });
            historicalRulesByTenant.set(row.admin_id, existing);
          });
        }

        const resolveRulesForDate = (tenantId: string | null | undefined, date: string, isVirtual = false): RuleSnapshot => {
          if (!tenantId) return { ...DEFAULT_SETTINGS };

          const currentSettings = settingsMap.get(tenantId);

          // For virtual records (no real attendance row), prefer current live
          // settings for recent/future dates so admin fee changes take effect
          // immediately. Only fall back to snapshots for genuinely historical dates.
          if (isVirtual && currentSettings) {
            const todayStr = format(new Date(), "yyyy-MM-dd");
            // If the date is today or in the future, always use live settings
            if (date >= todayStr) {
              return currentSettings;
            }
            // For past virtual records, check if any snapshot exists from
            // *after* that date – if not, the admin may have changed settings
            // since then, so use live settings for recent unsnapshot dates.
            const historicalRules = historicalRulesByTenant.get(tenantId) || [];
            const latestSnapshotDate = historicalRules.length > 0
              ? historicalRules[historicalRules.length - 1].date
              : null;
            // If this date is after the latest snapshot, use current settings
            if (!latestSnapshotDate || date > latestSnapshotDate) {
              return currentSettings;
            }
          }

          const historicalRules = historicalRulesByTenant.get(tenantId) || [];
          for (let i = historicalRules.length - 1; i >= 0; i -= 1) {
            if (historicalRules[i].date <= date) {
              return historicalRules[i].rules;
            }
          }

          return currentSettings || { ...DEFAULT_SETTINGS };
        };

        // Create tenant name map
        const tenantNameMap = new Map<string, string>();
        tenantProfiles?.forEach(t => {
          tenantNameMap.set(t.id, t.full_name || t.email);
        });

        // Create complete attendance records including day off users
        const completeAttendance: AttendanceWithProfile[] = [];

        // Get today's date for comparison (start of day)
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Pre-compute which day-off dates are "honorable" per user using FULL month data
        // This ensures partial date range views still get correct honorable status
        const honorableDayOffDates = new Set<string>(); // keys: "userId-date"

        profilesData?.forEach((profile) => {
          const tenantSettings = profile.admin_id ? settingsMap.get(profile.admin_id) : null;
          const honorableLimit = tenantSettings?.monthly_honorable_absences || 0;
          if (honorableLimit <= 0) return;

          const userAttendanceDates = fullMonthAttendanceByUser.get(profile.id) || new Set();
          const userCreatedAt = profile.created_at ? new Date(profile.created_at) : null;
          const userCreatedDate = userCreatedAt ? new Date(userCreatedAt.getFullYear(), userCreatedAt.getMonth(), userCreatedAt.getDate()) : null;

          // For each month in the view, generate all weekdays and count day-offs
          uniqueMonths.forEach((monthKey) => {
            const [y, mo] = monthKey.split("-").map(Number);
            const monthStart = new Date(y, mo - 1, 1);
            const monthEnd = new Date(y, mo, 0); // last day
            let dayOffCount = 0;

            const cursor = new Date(monthStart);
            while (cursor <= monthEnd && cursor <= today) {
              const dow = cursor.getDay();
              const dateStr = format(cursor, "yyyy-MM-dd");
              const dateObj = new Date(dateStr + 'T00:00:00');

              if (dow !== 0 && dow !== 6 && !holidayDatesSet.has(dateStr)) { // weekday
                const isBeforeCreation = userCreatedDate && dateObj < userCreatedDate;
                if (!isBeforeCreation && !userAttendanceDates.has(dateStr)) {
                  dayOffCount++;
                  if (dayOffCount <= honorableLimit) {
                    honorableDayOffDates.add(`${profile.id}-${dateStr}`);
                  }
                }
              }
              cursor.setDate(cursor.getDate() + 1);
            }
          });
        });

        // Sort dates chronologically for correct record generation
        const sortedDates = [...dates].sort();

        sortedDates.forEach((date) => {
          const dateObj = new Date(date + 'T00:00:00');
          const dayOfWeek = dateObj.getDay();
          const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
          const isFutureDate = dateObj > today;

          profilesData?.forEach((profile) => {
            const attendanceKey = `${profile.id}-${date}`;
            const existingAttendance = attendanceMap.get(attendanceKey);
            const isVirtual = !existingAttendance;
            const tenantRulesForDate = resolveRulesForDate(profile.admin_id, date, isVirtual);
            const tenantHolidays = profile.admin_id ? (holidayDatesByTenant.get(profile.admin_id) || new Set()) : new Set();
            const isHoliday = tenantHolidays.has(date);

            const userCreatedAt = profile.created_at ? new Date(profile.created_at) : null;
            const userCreatedDate = userCreatedAt ? new Date(userCreatedAt.getFullYear(), userCreatedAt.getMonth(), userCreatedAt.getDate()) : null;
            const isBeforeUserCreation = userCreatedDate && dateObj < userCreatedDate;

            if (existingAttendance) {
              // If it's a holiday, override to show as Holiday with no fees
              if (isHoliday) {
                completeAttendance.push({
                  ...existingAttendance,
                  admin_id: existingAttendance.admin_id || profile.admin_id,
                  profiles: { full_name: profile.full_name, email: profile.email },
                  notes: "Holiday",
                  total_fees: 0,
                  late_start_fee: 0,
                  break_time_fee: 0,
                });
              } else {
                // For real "Day off" records (from fee release/restore), apply honorable logic
                const isDayOffRecord = existingAttendance.notes?.includes("Day off");
                const isHonorableExisting = isDayOffRecord && honorableDayOffDates.has(`${profile.id}-${date}`);
                
                completeAttendance.push({
                  ...existingAttendance,
                  admin_id: existingAttendance.admin_id || profile.admin_id,
                  profiles: { full_name: profile.full_name, email: profile.email },
                  ...(isDayOffRecord ? {
                    notes: isHonorableExisting ? "Day off (Honorable)" : "Day off",
                    total_fees: isHonorableExisting ? 0 : existingAttendance.total_fees,
                  } : {}),
                });
              }
            } else if (!isFutureDate && !isBeforeUserCreation) {
              if (isWeekend) {
                // Skip weekends — do not generate virtual records
              } else if (isHoliday) {
                // Holiday — show as "Holiday" with no fees
                completeAttendance.push({
                  id: `holiday-${profile.id}-${date}`,
                  user_id: profile.id,
                  date: date,
                  clock_in: "",
                  clock_out: null,
                  notes: "Holiday",
                  created_at: "",
                  updated_at: "",
                  late_start_fee: 0,
                  break_time_fee: 0,
                  total_fees: 0,
                  released_fees: 0,
                  is_late: false,
                  break_minutes: 0,
                  admin_id: profile.admin_id,
                  rule_snapshot: tenantRulesForDate,
                  profiles: { full_name: profile.full_name, email: profile.email },
                } as AttendanceWithProfile);
              } else {
                // Weekday day off - check pre-computed honorable status
                const isHonorable = honorableDayOffDates.has(`${profile.id}-${date}`);
                const dayOffFee = isHonorable ? 0 : tenantRulesForDate.day_off_fee;

                completeAttendance.push({
                  id: `day-off-${profile.id}-${date}`,
                  user_id: profile.id,
                  date: date,
                  clock_in: "",
                  clock_out: null,
                  notes: isHonorable ? "Day off (Honorable)" : "Day off",
                  created_at: "",
                  updated_at: "",
                  late_start_fee: 0,
                  break_time_fee: 0,
                  total_fees: dayOffFee,
                  released_fees: 0,
                  is_late: false,
                  break_minutes: 0,
                  admin_id: profile.admin_id,
                  rule_snapshot: tenantRulesForDate,
                  profiles: { full_name: profile.full_name, email: profile.email },
                } as AttendanceWithProfile);
              }
            }
            // Future dates are skipped - no record created
          });
        });

        setAllAttendance(completeAttendance);

        // For super admin without specific tenant selected, group by tenant
        if (isSuperAdminRole && !effectiveTenantId) {
          const groups: TenantAttendanceGroup[] = tenantIds.map(tenantId => ({
            tenantId: tenantId as string,
            tenantName: tenantNameMap.get(tenantId as string) || 'Unknown Tenant',
            settings: settingsMap.get(tenantId as string) || DEFAULT_SETTINGS,
            attendance: completeAttendance.filter(a => a.admin_id === tenantId),
          }));
          setTenantGroups(groups);
        } else {
          setTenantGroups([]);
        }
      } else {
        // Fetch only user's own attendance
        const { data, error } = await supabase
          .from("attendance")
          .select("*")
          .eq("user_id", user.id)
          .order("date", { ascending: false })
          .order("clock_in", { ascending: false });

        if (error) throw error;
        const filteredData = data || [];
        setAttendance(filteredData);

        // Find today's active attendance (clocked in but not clocked out)
        // Use server time to determine "today" for consistency across devices
        const today = await fetchServerTimeKey();
        const todayRecords = filteredData.filter((a) => a.date === today);
        const activeRecord = todayRecords.find((a) => !a.clock_out);
        setTodayAttendance(activeRecord || null);
      }
    } catch (error) {
      console.error("Error fetching attendance:", error);
      toast({ title: "Failed to load attendance records", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const clockIn = async (notes?: string) => {
    if (!user) return;

    try {
      // Use server time for consistent date key and timestamps
      const today = await fetchServerTimeKey();
      const now = await fetchServerTimestamp();
      const clockInTime = new Date(now);

      // Get user's admin_id from their profile
      const { data: profile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .maybeSingle();

      const userAdminId = profile?.admin_id || effectiveTenantId;

      // Check if there's an existing record for today
      const { data: existingRecords } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .order("clock_in", { ascending: false })
        .limit(1);

      const existingRecord = existingRecords?.[0];

      if (existingRecord && !existingRecord.clock_out) {
        // Already clocked in with active session
        toast({ title: "You are already clocked in", variant: "destructive" });
        fetchAttendance();
        return;
      }

      if (existingRecord && existingRecord.clock_out) {
        // Resume session: calculate break time (gap between clock_out and now)
        const lastClockOut = new Date(existingRecord.clock_out);
        const gapMinutes = Math.round((clockInTime.getTime() - lastClockOut.getTime()) / (1000 * 60));
        
        // Add gap to existing break_minutes
        const newBreakMinutes = (existingRecord.break_minutes || 0) + gapMinutes;

        // Get tenant settings to calculate break fee
        // Skip fee calculations on weekends (Saturday=6, Sunday=0)
        const resumeDayOfWeek = clockInTime.getDay();
        const isResumeWeekend = resumeDayOfWeek === 0 || resumeDayOfWeek === 6;
        let breakFee = 0;
        if (userAdminId && !isResumeWeekend) {
          const { data: tenantSettings } = await supabase
            .from("admin_settings")
            .select("max_break_minutes, excessive_break_fee")
            .eq("admin_id", userAdminId)
            .maybeSingle();

          if (tenantSettings && newBreakMinutes > tenantSettings.max_break_minutes) {
            breakFee = parseFloat(tenantSettings.excessive_break_fee.toString());
            toast({ 
              title: "Break time exceeded", 
              description: `Total break: ${newBreakMinutes} min. Fee: $${breakFee}` 
            });
          }
        }

        // Update existing record: clear clock_out, update break_minutes
        const { data: updatedData, error } = await supabase
          .from("attendance")
          .update({
            clock_out: null,
            working_started_at: now,
            break_minutes: newBreakMinutes,
            break_time_fee: breakFee,
            total_fees: (existingRecord.late_start_fee || 0) + breakFee,
            notes: notes || existingRecord.notes,
          })
          .eq("id", existingRecord.id)
          .select()
          .single();

        if (error) throw error;

        toast({ title: "Resumed session", description: `Break added: ${gapMinutes} min` });
        setTodayAttendance(updatedData);
        fetchAttendance();
        return;
      }

      // First clock-in of the day - create new record
      // Get tenant settings for late fee calculation
      let isLate = false;
      let lateFee = 0;

      // Skip fee calculations on weekends (Saturday=6, Sunday=0) - use UTC to match server time
      const dayOfWeek = clockInTime.getUTCDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

      if (userAdminId && !isWeekend) {
        const { data: tenantSettings } = await supabase
          .from("admin_settings")
          .select("work_start_time, late_start_fee, late_grace_minutes, timezone")
          .eq("admin_id", userAdminId)
          .maybeSingle();

        if (tenantSettings) {
          const timezone = (tenantSettings as Record<string, unknown>).timezone as string || 'Asia/Yerevan';
          const workStartTime = localTimeToUTC(tenantSettings.work_start_time, timezone, clockInTime);

          const graceMinutes = (tenantSettings as Record<string, unknown>).late_grace_minutes as number ?? 0;
          const minutesLate = (clockInTime.getTime() - workStartTime.getTime()) / (1000 * 60) - graceMinutes;

          if (minutesLate > 0) {
            isLate = true;
            lateFee = parseFloat(tenantSettings.late_start_fee.toString());
            toast({ title: "Late Clock-in", description: `You are late by ${Math.round(minutesLate)} minutes! Fee: $${lateFee}` });
          }
        }
      }

      // Build rule_snapshot from fetched settings
      let ruleSnapshot: Record<string, unknown> | null = null;
      if (userAdminId) {
        const { data: fullSettings } = await supabase
          .from("admin_settings")
          .select("work_start_time, work_end_time, late_start_fee, excessive_break_fee, day_off_fee, max_break_minutes, timezone, late_grace_minutes")
          .eq("admin_id", userAdminId)
          .maybeSingle();
        if (fullSettings) {
          ruleSnapshot = {
            work_start_time: fullSettings.work_start_time.substring(0, 5),
            work_end_time: fullSettings.work_end_time.substring(0, 5),
            late_start_fee: Number(fullSettings.late_start_fee),
            excessive_break_fee: Number(fullSettings.excessive_break_fee),
            day_off_fee: Number(fullSettings.day_off_fee),
            max_break_minutes: Number(fullSettings.max_break_minutes),
            timezone: (fullSettings as Record<string, unknown>).timezone as string || 'Asia/Yerevan',
            late_grace_minutes: (fullSettings as Record<string, unknown>).late_grace_minutes as number ?? 0,
          };
        }
      }

      const insertPayload: Record<string, unknown> = {
        user_id: user.id,
        date: today,
        clock_in: now,
        working_started_at: now,
        notes: notes || null,
        admin_id: userAdminId,
        is_late: isLate,
        late_start_fee: lateFee,
        total_fees: lateFee,
      };
      if (ruleSnapshot) {
        insertPayload.rule_snapshot = ruleSnapshot;
      }

      const { data: insertedData, error } = await supabase
        .from("attendance")
        .insert(insertPayload as never)
        .select()
        .single();

      if (error) {
        console.error("Clock in error:", error);
        throw error;
      }

      toast({ title: "Clocked in successfully" });
      setTodayAttendance(insertedData);
      fetchAttendance();
    } catch (error) {
      console.error("Error clocking in:", error);
      const pgError = error as { code?: string; message?: string };
      if (pgError.code === "23505") {
        toast({ title: "You have already clocked in today", variant: "destructive" });
      } else {
        toast({ title: `Failed to clock in: ${pgError.message || 'Unknown error'}`, variant: "destructive" });
      }
    }
  };

  const clockOut = async (notes?: string) => {
    if (!user) return;

    try {
      // Use server time for consistent date key
      const today = await fetchServerTimeKey();
      
      // Find the active session (clocked in but not clocked out)
      const { data: records } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .is("clock_out", null)
        .order("clock_in", { ascending: false })
        .limit(1);

      const activeRecord = records?.[0];

      if (!activeRecord) {
        toast({ title: "No active clock-in session found", variant: "destructive" });
        return;
      }

      // Use server timestamp for clock out
      const clockOutTime = await fetchServerTimestamp();

      // Evaluate break fee at clock-out: check if total break_minutes exceeds max
      let breakFee = activeRecord.break_time_fee || 0;
      const snapshot = activeRecord.rule_snapshot as { max_break_minutes?: number; excessive_break_fee?: number } | null;
      const maxBreakMinutes = snapshot?.max_break_minutes ?? settings.max_break_minutes ?? 120;
      const excessiveBreakFee = snapshot?.excessive_break_fee ?? settings.excessive_break_fee ?? 0;
      const totalBreakMinutes = activeRecord.break_minutes || 0;

      if (totalBreakMinutes > maxBreakMinutes && breakFee === 0 && excessiveBreakFee > 0) {
        breakFee = excessiveBreakFee;
        toast({ title: "Break time exceeded", description: `Total break: ${totalBreakMinutes} min (limit: ${maxBreakMinutes}). Fee: $${breakFee}` });
      }

      // Day-off fee must never be applied on clock-out.
      const newTotalFees = (activeRecord.late_start_fee || 0) + breakFee;

      const { error } = await supabase
        .from("attendance")
        .update({
          clock_out: clockOutTime,
          notes: notes || activeRecord.notes,
          break_time_fee: breakFee,
          total_fees: newTotalFees,
        })
        .eq("id", activeRecord.id);

      if (error) throw error;

      toast({ title: "Clocked out successfully" });
      fetchAttendance();
    } catch (error) {
      console.error("Error clocking out:", error);
      toast({ title: "Failed to clock out", variant: "destructive" });
    }
  };

  const toggleWorking = async (isOn: boolean) => {
    if (!user) return;

    try {
      // Use server time for consistent date key
      const today = await fetchServerTimeKey();
      
      // Get today's active attendance record (clocked in but not clocked out)
      const { data: records } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .is("clock_out", null)
        .order("clock_in", { ascending: false })
        .limit(1);

      const todayRecord = records?.[0];

      if (!todayRecord) {
        toast({ title: "Please clock in first", variant: "destructive" });
        return;
      }

      // Use server timestamp for working period tracking
      const now = await fetchServerTimestamp();
      
      if (isOn) {
        // Starting work - record working_started_at
        const { error } = await supabase
          .from("attendance")
          .update({ working_started_at: now })
          .eq("id", todayRecord.id);

        if (error) throw error;
        toast({ title: "Work started" });
      } else {
        // Stopping work (break) - save the period and clear working_started_at
        if (!todayRecord.working_started_at) {
          toast({ title: "Working period not found", variant: "destructive" });
          return;
        }

        interface WorkingPeriod {
          started_at: string;
          ended_at: string;
        }
        const existingPeriods = (todayRecord.working_periods as unknown as WorkingPeriod[]) || [];
        const periods: WorkingPeriod[] = [...existingPeriods, {
          started_at: todayRecord.working_started_at as string,
          ended_at: now,
        }];

        // Calculate total break minutes
        const totalWorkMinutes = periods.reduce((sum: number, period: WorkingPeriod) => {
          const start = new Date(period.started_at);
          const end = new Date(period.ended_at);
          return sum + (end.getTime() - start.getTime()) / (1000 * 60);
        }, 0);

        const clockInTime = new Date(todayRecord.clock_in);
        const totalMinutes = (new Date(now).getTime() - clockInTime.getTime()) / (1000 * 60);
        const breakMinutes = Math.round(totalMinutes - totalWorkMinutes);

        // Get break settings from rule_snapshot if available, otherwise fetch from admin_settings
        const snapshot = todayRecord.rule_snapshot as { max_break_minutes?: number; excessive_break_fee?: number } | null;
        let maxBreakMinutes = snapshot?.max_break_minutes;
        let excessiveBreakFee = snapshot?.excessive_break_fee;

        if (maxBreakMinutes == null || excessiveBreakFee == null) {
          let settingsQuery = supabase.from("admin_settings").select("max_break_minutes, excessive_break_fee");
          if (effectiveTenantId) {
            settingsQuery = settingsQuery.eq("admin_id", effectiveTenantId);
          }
          const { data: breakSettings } = await settingsQuery.maybeSingle();
          maxBreakMinutes = breakSettings?.max_break_minutes ?? 60;
          excessiveBreakFee = breakSettings ? parseFloat(breakSettings.excessive_break_fee.toString()) : 0;
        }

        let breakFee = 0;
        if (breakMinutes > maxBreakMinutes) {
          breakFee = excessiveBreakFee;
        }

        const { error } = await supabase
          .from("attendance")
          .update({
            working_started_at: null,
            working_periods: periods as unknown as Json,
            break_minutes: breakMinutes,
            break_time_fee: breakFee,
            total_fees: (todayRecord.late_start_fee || 0) + breakFee,
          })
          .eq("id", todayRecord.id);

        if (error) throw error;
        toast({ title: "Break started" });
      }

      fetchAttendance();
    } catch (error) {
      console.error("Error toggling working status:", error);
      toast({ title: "Failed to update working status", variant: "destructive" });
    }
  };

  const calculateWorkingHours = useCallback((clockIn: string, clockOut: string | null): number | null => {
    if (!clockOut) return null;
    const start = new Date(clockIn);
    const end = new Date(clockOut);
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
    return Math.round(hours * 100) / 100;
  }, []);

  const releaseFee = useCallback(async (attendanceId: string, feeCategories?: ('late' | 'break')[]) => {
    if (!user) {
      toast({ title: "Not authenticated", description: "Please log in again", variant: "destructive" });
      return;
    }

    try {
      // Handle virtual day-off records - create real record first
      if (attendanceId.startsWith('day-off-')) {
        // Parse user_id and date from virtual ID: day-off-{user_id}-{date}
        const parts = attendanceId.replace('day-off-', '').split('-');
        const dateStr = parts.slice(-3).join('-'); // Get last 3 parts as date (YYYY-MM-DD)
        const userId = parts.slice(0, -3).join('-'); // Everything else is user_id (UUID)
        
        // Get user's admin_id and creation date
        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("admin_id, created_at")
          .eq("id", userId)
          .maybeSingle();
        
        if (profileError) {
          console.error("Error fetching profile:", profileError);
          toast({ 
            title: "Failed to release fees", 
            description: "Could not fetch user profile",
            variant: "destructive" 
          });
          return;
        }
        
        // Validate: don't create records for dates before user was created
        if (profile?.created_at) {
          const userCreatedAt = new Date(profile.created_at);
          const userCreatedDate = new Date(userCreatedAt.getFullYear(), userCreatedAt.getMonth(), userCreatedAt.getDate());
          const recordDate = new Date(dateStr + 'T00:00:00');
          
          if (recordDate < userCreatedDate) {
            toast({ 
              title: "Cannot release fees", 
              description: "This date is before the user was created",
              variant: "destructive" 
            });
            return;
          }
        }
        
        const adminId = profile?.admin_id || effectiveTenantId;
        
        if (!adminId) {
          toast({ 
            title: "Cannot release fees", 
            description: "Unable to determine user's tenant",
            variant: "destructive" 
          });
          return;
        }
        
        // Resolve day-off fee from historical snapshots first, then fallback to current settings
        const { data: historicalRuleRecord } = await supabase
          .from("attendance")
          .select("rule_snapshot")
          .eq("admin_id", adminId)
          .lte("date", dateStr)
          .not("rule_snapshot", "is", null)
          .order("date", { ascending: false })
          .limit(1)
          .maybeSingle();

        const historicalRules = parseRuleSnapshot(historicalRuleRecord?.rule_snapshot as Json | null);

        const { data: tenantSettings } = await supabase
          .from("admin_settings")
          .select("work_start_time, work_end_time, late_start_fee, excessive_break_fee, day_off_fee, max_break_minutes")
          .eq("admin_id", adminId)
          .maybeSingle();

        const fallbackRules: RuleSnapshot | null = tenantSettings ? {
          work_start_time: tenantSettings.work_start_time.substring(0, 5),
          work_end_time: tenantSettings.work_end_time.substring(0, 5),
          late_start_fee: Number(tenantSettings.late_start_fee),
          excessive_break_fee: Number(tenantSettings.excessive_break_fee),
          day_off_fee: Number(tenantSettings.day_off_fee),
          max_break_minutes: Number(tenantSettings.max_break_minutes) || 60,
        } : null;

        const resolvedRules = historicalRules || fallbackRules;
        const dayOffFee = resolvedRules?.day_off_fee ?? settings.day_off_fee ?? 0;

        // Create a real attendance record with released fees
        const dayOffPayload: Record<string, unknown> = {
          user_id: userId,
          date: dateStr,
          clock_in: new Date().toISOString(),
          clock_out: new Date().toISOString(),
          notes: "Day off",
          late_start_fee: 0,
          break_time_fee: 0,
          total_fees: 0,
          released_fees: dayOffFee,
          is_late: false,
          break_minutes: 0,
          admin_id: adminId,
        };

        if (resolvedRules) {
          dayOffPayload.rule_snapshot = resolvedRules;
        }

        const { error } = await supabase
          .from("attendance")
          .insert(dayOffPayload as never);

        if (error) {
          console.error("Error creating day-off record:", error);
          toast({ 
            title: "Failed to release fees", 
            description: error.message || "Could not create attendance record",
            variant: "destructive" 
          });
          return;
        }
        
        toast({ title: "Day off fees released successfully" });
        fetchAttendance(false);
        return;
      }

      // Skip weekend virtual records (no fees to release)
      if (attendanceId.startsWith('weekend-')) {
        toast({ title: "No fees to release for weekends" });
        return;
      }

      // Get current fees before releasing
      const { data: currentRecord, error: fetchError } = await supabase
        .from("attendance")
        .select("total_fees, released_fees, admin_id, user_id, late_start_fee, break_time_fee")
        .eq("id", attendanceId)
        .maybeSingle();

      if (fetchError) {
        toast({ 
          title: "Failed to release fees", 
          description: fetchError.message || "Could not find attendance record",
          variant: "destructive" 
        });
        return;
      }

      if (!currentRecord) {
        toast({ 
          title: "Failed to release fees", 
          description: "Attendance record not found. You may not have permission.",
          variant: "destructive" 
        });
        return;
      }

      const currentFees = currentRecord.total_fees || 0;
      const previouslyReleased = currentRecord.released_fees || 0;

      if (currentFees === 0) {
        toast({ title: "No fees to release", description: "This record has no pending fees." });
        return;
      }

      // Calculate selective release based on feeCategories
      let releaseAmount = currentFees;
      let newLateFee = 0;
      let newBreakFee = 0;

      if (feeCategories && feeCategories.length > 0) {
        // Selective release
        const lateFee = currentRecord.late_start_fee || 0;
        const breakFee = currentRecord.break_time_fee || 0;
        releaseAmount = 0;

        if (feeCategories.includes('late')) {
          releaseAmount += lateFee;
          newLateFee = 0;
        } else {
          newLateFee = lateFee;
        }

        if (feeCategories.includes('break')) {
          releaseAmount += breakFee;
          newBreakFee = 0;
        } else {
          newBreakFee = breakFee;
        }
      }

      const newTotalFees = feeCategories ? (newLateFee + newBreakFee) : 0;

      const { data: updatedRows, error } = await supabase
        .from("attendance")
        .update({
          late_start_fee: feeCategories ? newLateFee : 0,
          break_time_fee: feeCategories ? newBreakFee : 0,
          total_fees: newTotalFees,
          released_fees: previouslyReleased + releaseAmount,
        })
        .eq("id", attendanceId)
        .select();

      if (error) {
        toast({ 
          title: "Failed to release fees", 
          description: error.message || "Could not update attendance record",
          variant: "destructive" 
        });
        return;
      }

      if (!updatedRows || updatedRows.length === 0) {
        toast({ 
          title: "Failed to release fees", 
          description: "Could not update record. You may not have permission.",
          variant: "destructive" 
        });
        return;
      }

      toast({ title: "Fees released successfully" });
      fetchAttendance(false);
    } catch (error) {
      console.error("Error releasing fees:", error);
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({ 
        title: "Failed to release fees", 
        description: errorMessage,
        variant: "destructive" 
      });
    }
  }, [user, effectiveTenantId, settings, toast]);

  const restoreFee = useCallback(async (attendanceId: string) => {
    if (!user) {
      toast({ title: "Not authenticated", description: "Please log in again", variant: "destructive" });
      return;
    }

    try {
      // Get current record to know released_fees amount
      const { data: currentRecord, error: fetchError } = await supabase
        .from("attendance")
        .select("total_fees, released_fees, late_start_fee, break_time_fee, admin_id, notes")
        .eq("id", attendanceId)
        .maybeSingle();

      if (fetchError || !currentRecord) {
        toast({ title: "Failed to restore fees", description: fetchError?.message || "Record not found", variant: "destructive" });
        return;
      }

      const releasedAmount = currentRecord.released_fees || 0;
      if (releasedAmount === 0) {
        toast({ title: "No fees to restore", description: "This record has no released fees." });
        return;
      }

      // Restore: move released_fees back to total_fees and restore individual fee fields
      // Use rule_snapshot to determine the breakdown, or treat full amount as late_start_fee
      const isDayOff = currentRecord.notes?.includes("Day off");
      const snapshot = (currentRecord as any).rule_snapshot as RuleSnapshot | null;

      let restoredLateFee = 0;
      let restoredBreakFee = 0;

      if (isDayOff && snapshot) {
        // Day-off records: the released amount is the day_off_fee
        // No need to restore late/break fees for day-off records
      } else {
        // For normal records: restore the original fee breakdown
        // The released amount = late_start_fee + break_time_fee at time of release
        // Since we zeroed both on release, we need to figure out the split
        // Best effort: if record had only late fee or only break fee, restore accordingly
        // Since both were zeroed, use rule_snapshot to reconstruct
        const origLateFee = currentRecord.late_start_fee || 0;
        const origBreakFee = currentRecord.break_time_fee || 0;
        
        if (origLateFee === 0 && origBreakFee === 0) {
          // Both were zeroed during release - the full releasedAmount needs restoring
          // We can't know the exact split, so restore as total_fees only
          // But we should try: if record was marked is_late, restore late fee from snapshot
          restoredLateFee = releasedAmount; // conservative: assign all to late
          restoredBreakFee = 0;
        } else {
          restoredLateFee = origLateFee;
          restoredBreakFee = origBreakFee;
        }
      }

      const { error } = await supabase
        .from("attendance")
        .update({
          total_fees: releasedAmount,
          released_fees: 0,
          late_start_fee: restoredLateFee,
          break_time_fee: restoredBreakFee,
        })
        .eq("id", attendanceId)
        .select();

      if (error) {
        toast({ title: "Failed to restore fees", description: error.message, variant: "destructive" });
        return;
      }

      toast({ title: "Fees restored successfully" });
      fetchAttendance(false);
    } catch (error) {
      console.error("Error restoring fees:", error);
      const errorMessage = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({ title: "Failed to restore fees", description: errorMessage, variant: "destructive" });
    }
  }, [user, toast]);

  return {
    attendance,
    allAttendance,
    tenantGroups,
    todayAttendance,
    loading,
    isAdmin: isAdminUser,
    isSuperAdmin: isSuperAdmin && !effectiveTenantId,
    settings,
    clockIn,
    clockOut,
    toggleWorking,
    calculateWorkingHours,
    releaseFee,
    restoreFee,
    refetch: fetchAttendance,
  };
};
