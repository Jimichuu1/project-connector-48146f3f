/**
 * Barrel file for hooks - exports all custom hooks
 */

// Core hooks
export { useIsMobile } from "./use-mobile";
export { useToast, toast } from "./use-toast";

// Auth & User hooks
export { useUserRole } from "./useUserRole";
export { useTokenRotation } from "./useTokenRotation";
export { useAuditLog } from "./useAuditLog";
export { useRateLimiter } from "./useRateLimiter";
export { useAgentsCache } from "./useAgentsCache";

// Data hooks
export { useLeads } from "./useLeads";
export { useClients } from "./useClients";
export { useDeposits } from "./useDeposits";
export { useDocuments } from "./useDocuments";
export { useKYC } from "./useKYC";
export { useLeadGroups } from "./useLeadGroups";
export { useSaleBranches } from "./useSaleBranches";

// Settings hooks
export { usePhoneVisibility } from "./usePhoneVisibility";
export { useAttendance } from "./useAttendance";
export { useUserPreferences } from "./useUserPreferences";

// UI hooks
export { useNotifications } from "./useNotifications";
export { useReminders } from "./useReminders";
export { usePipelineFilters } from "./usePipelineFilters";
export { useDragScroll } from "./useDragScroll";
export { useEncryption } from "./useEncryption";

// Reports
export { useReportsData } from "./useReportsData";
