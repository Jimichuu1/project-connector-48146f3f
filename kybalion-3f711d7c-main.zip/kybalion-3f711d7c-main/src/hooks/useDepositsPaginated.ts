/**
 * Server-side paginated version of useDeposits hook
 * Optimized for large datasets (500k+ records)
 */

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";
import { useTenant } from "@/contexts/TenantContext";
import { PaginationParams, calculatePagination, getOffsetAndLimit } from "@/types/pagination";

export interface Deposit {
  id: string;
  sale_branch_id: string;
  client_id: string;
  lead_id: string | null;
  amount: number;
  agent_id: string | null;
  super_agent_id: string | null;
  agent_percentage: number;
  super_agent_percentage: number;
  agent_amount: number;
  super_agent_amount: number;
  status: string;
  created_at: string;
  created_by: string;
  exchanges: string[] | null;
  admin_id: string | null;
  split_super_agent_id: string | null;
  split_super_agent_amount: number;
}

export interface DepositWithProfiles extends Deposit {
  agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  super_agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  split_super_agent?: {
    id: string;
    full_name: string | null;
    email: string;
  };
  client?: {
    id: string;
    name: string;
    email: string;
  };
}

interface DepositFilters {
  startDate?: Date;
  endDate?: Date;
  status?: string;
  agentId?: string;
  clientId?: string;
}

export const useDepositsPaginated = (
  filters?: DepositFilters,
  pagination: PaginationParams = { page: 1, pageSize: 100 }
) => {
  const queryClient = useQueryClient();
  const { effectiveTenantId, loading: tenantLoading, isSuperAdmin } = useTenant();
  const { offset, limit } = getOffsetAndLimit(pagination.page, pagination.pageSize);
  
  // Count query
  const { data: totalCount = 0 } = useQuery({
    queryKey: ['deposits-count', filters, effectiveTenantId],
    enabled: !tenantLoading && (isSuperAdmin || effectiveTenantId !== undefined),
    staleTime: 60000, // Cache count for 1 minute
    queryFn: async () => {
      let query = supabase
        .from('deposits')
        .select('*', { count: 'exact', head: true });

      if (effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }

      if (filters?.status) {
        query = query.eq('status', filters.status);
      } else {
        query = query.eq('status', 'approved');
      }

      if (filters?.startDate) {
        query = query.gte('created_at', filters.startDate.toISOString());
      }
      if (filters?.endDate) {
        query = query.lte('created_at', filters.endDate.toISOString());
      }

      if (filters?.agentId) {
        query = query.eq('agent_id', filters.agentId);
      }

      if (filters?.clientId) {
        query = query.eq('client_id', filters.clientId);
      }

      const { count } = await query;
      return count || 0;
    },
  });

  // Paginated data query
  const { data: deposits, isLoading, error } = useQuery({
    queryKey: ['deposits-paginated', filters, effectiveTenantId, pagination.page, pagination.pageSize],
    enabled: !tenantLoading && (isSuperAdmin || effectiveTenantId !== undefined),
    staleTime: 30000,
    queryFn: async () => {
      let query = supabase
        .from('deposits')
        .select(`
          *,
          agent:profiles!deposits_agent_id_fkey(id, full_name, email),
          super_agent:profiles!deposits_super_agent_id_fkey(id, full_name, email),
          client:clients(id, name, email)
        `)
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      if (effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }

      if (filters?.status) {
        query = query.eq('status', filters.status);
      } else {
        query = query.eq('status', 'approved');
      }

      if (filters?.startDate) {
        query = query.gte('created_at', filters.startDate.toISOString());
      }
      if (filters?.endDate) {
        query = query.lte('created_at', filters.endDate.toISOString());
      }

      if (filters?.agentId) {
        query = query.eq('agent_id', filters.agentId);
      }

      if (filters?.clientId) {
        query = query.eq('client_id', filters.clientId);
      }

      const { data, error } = await query;

      if (error) throw error;
      
      // Fetch split super agent profiles in parallel
      const depositsData = data || [];
      const splitAgentIds = [...new Set(depositsData
        .filter(d => d.split_super_agent_id)
        .map(d => d.split_super_agent_id))] as string[];
      
      let splitAgentProfiles: Record<string, { id: string; full_name: string | null; email: string }> = {};
      
      if (splitAgentIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .in('id', splitAgentIds);
        
        if (profiles) {
          splitAgentProfiles = profiles.reduce((acc, p) => {
            acc[p.id] = p;
            return acc;
          }, {} as Record<string, { id: string; full_name: string | null; email: string }>);
        }
      }
      
      return depositsData.map(d => ({
        ...d,
        split_super_agent: d.split_super_agent_id ? splitAgentProfiles[d.split_super_agent_id] : undefined,
      })) as DepositWithProfiles[];
    },
  });

  // Filtered real-time subscription - only listen to tenant changes
  useEffect(() => {
    if (tenantLoading) return;

    const channelName = effectiveTenantId 
      ? `deposits-realtime-${effectiveTenantId}` 
      : 'deposits-realtime-all';
    
    const channel = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'deposits',
          // Filter by tenant to reduce unnecessary refetches
          ...(effectiveTenantId && { filter: `admin_id=eq.${effectiveTenantId}` }),
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['deposits-paginated'] });
          queryClient.invalidateQueries({ queryKey: ['deposits-count'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient, effectiveTenantId, tenantLoading]);

  // Calculate pagination meta
  const paginationMeta = calculatePagination(totalCount, pagination.page, pagination.pageSize);

  return {
    deposits,
    totalCount,
    isLoading,
    error,
    pagination: paginationMeta,
  };
};
