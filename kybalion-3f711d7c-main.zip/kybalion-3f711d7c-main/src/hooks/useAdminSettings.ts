import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { useTenant } from "@/contexts/TenantContext";

export interface AdminSettings {
  id: string;
  admin_id: string;
  work_start_time: string;
  work_end_time: string;
  late_start_fee: number;
  excessive_break_fee: number;
  max_break_minutes: number;
  day_off_fee: number;
  show_phone_to_agents: boolean;
  show_phone_to_super_agents: boolean;
  celebration_sound_url: string | null;
  celebration_video_url: string | null;
  created_at: string;
  updated_at: string;
  holiday_dates?: string[];
  conversion_target_per_agent?: number;
}

export const useAdminSettings = () => {
  const { user } = useAuth();
  const { effectiveTenantId, isTenantOwner } = useTenant();
  const queryClient = useQueryClient();

  const { data: settings, isLoading, error } = useQuery({
    queryKey: ["admin-settings", effectiveTenantId, user?.id],
    queryFn: async () => {
      if (!user) return null;

      const targetAdminId = effectiveTenantId || (isTenantOwner ? user.id : null);
      if (!targetAdminId) return null;

      const { data: adminSettings, error: adminError } = await supabase
        .from("admin_settings")
        .select("*")
        .eq("admin_id", targetAdminId)
        .maybeSingle();

      if (adminError) throw adminError;
      return (adminSettings as unknown as AdminSettings) ?? null;
    },
    enabled: !!user,
  });

  const updateSettings = useMutation({
    mutationFn: async (updates: Partial<AdminSettings>) => {
      if (!user) throw new Error("User not authenticated");

      const targetAdminId = effectiveTenantId || (isTenantOwner ? user.id : null);
      if (!targetAdminId) {
        throw new Error("Select a tenant first to edit its settings");
      }

      const { data: existing } = await supabase
        .from("admin_settings")
        .select("id")
        .eq("admin_id", targetAdminId)
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from("admin_settings")
          .update({ ...updates, updated_at: new Date().toISOString() })
          .eq("admin_id", targetAdminId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("admin_settings")
          .insert({ admin_id: targetAdminId, ...updates });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-settings"] });
      toast.success("Settings updated successfully");
    },
    onError: (error: any) => {
      toast.error(error?.message || "Failed to update settings");
      console.error("Update settings error:", error);
    },
  });

  return { settings, isLoading, error, updateSettings };
};
