import { useState } from "react";
import { Lead } from "@/types/leads";

export function useLeadActions(_userId: string | undefined) {
  const [showBankDialog, setShowBankDialog] = useState(false);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [convertDialogOpen, setConvertDialogOpen] = useState(false);
  const [leadToConvert, setLeadToConvert] = useState<Lead | null>(null);
  const [selectedLeadForAction, setSelectedLeadForAction] = useState<Lead | null>(null);

  const handleAddBank = (lead: Lead) => {
    setSelectedLeadForAction(lead);
    setShowBankDialog(true);
  };

  const handleAddNote = (lead: Lead) => {
    setSelectedLeadForAction(lead);
    setShowNoteDialog(true);
  };

  const handleCreateAccount = (_lead: Lead) => {
    // No-op: integration removed.
  };

  const handleConvert = (lead: Lead) => {
    setLeadToConvert(lead);
    setConvertDialogOpen(true);
  };

  return {
    showBankDialog,
    setShowBankDialog,
    showNoteDialog,
    setShowNoteDialog,
    convertDialogOpen,
    setConvertDialogOpen,
    leadToConvert,
    selectedLeadForAction,
    handleAddBank,
    handleAddNote,
    handleCreateAccount,
    handleConvert,
  };
}
