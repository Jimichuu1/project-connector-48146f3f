import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";

interface UserWithSessions {
  id: string;
  email: string;
  full_name: string | null;
  admin_id: string | null;
  sessions: {
    id: string;
    ip_address: string | null;
    user_agent: string | null;
    last_activity: string;
    created_at: string;
  }[];
}

interface TenantSessionGroup {
  tenantId: string;
  tenantName: string;
  users: UserWithSessions[];
  totalSessions: number;
}

interface LoginHistoryItem {
  id: string;
  user_id: string;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
  last_activity: string;
  expires_at: string;
  is_active: boolean;
  profile: {
    id: string;
    email: string;
    full_name: string | null;
    admin_id: string | null;
  } | null;
}

interface TenantLoginHistoryGroup {
  tenantId: string;
  tenantName: string;
  sessions: LoginHistoryItem[];
}

export function useSecurityMonitoring() {
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  const { role } = useUserData();
  const isSuperAdminRole = role === "SUPER_ADMIN";

  // Fetch failed login attempts
  const { data: failedAttempts, isLoading: loadingAttempts } = useQuery({
    queryKey: ["security-failed-attempts"],
    queryFn: async () => {
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
      const { data, error } = await supabase
        .from("auth_attempts")
        .select("*")
        .eq("success", false)
        .gte("created_at", oneHourAgo)
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) throw error;
      return data;
    },
    refetchInterval: 30000,
  });

  // Fetch recent uploads
  const { data: recentUploads, isLoading: loadingUploads } = useQuery({
    queryKey: ["security-recent-uploads", effectiveTenantId],
    queryFn: async () => {
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
      
      let query = supabase
        .from("documents")
        .select("*")
        .gte("created_at", oneHourAgo)
        .order("created_at", { ascending: false })
        .limit(50);

      if (effectiveTenantId) {
        query = query.eq("admin_id", effectiveTenantId);
      }

      const { data: docs, error } = await query;
      if (error) throw error;

      const userIds = [...new Set(docs?.map(d => d.uploaded_by) || [])];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, email, full_name")
        .in("id", userIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);
      
      return docs?.map(doc => ({
        ...doc,
        profile: profileMap.get(doc.uploaded_by)
      }));
    },
    refetchInterval: 30000,
  });

  // Fetch active sessions grouped by tenant
  const { data: sessionData, isLoading: loadingSessions } = useQuery({
    queryKey: ["security-sessions-by-tenant", effectiveTenantId, isSuperAdminRole],
    queryFn: async () => {
      // Get all active sessions
      const { data: sessions, error: sessionsError } = await supabase
        .from("user_sessions")
        .select("*")
        .eq("is_active", true)
        .order("last_activity", { ascending: false });

      if (sessionsError) throw sessionsError;

      const userIds = [...new Set(sessions?.map(s => s.user_id) || [])];

      // Get profiles with admin_id
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, email, full_name, admin_id")
        .in("id", userIds);

      if (profilesError) throw profilesError;

      // Get tenant names if super admin
      let tenantNames: Record<string, string> = {};
      if (isSuperAdminRole && !effectiveTenantId) {
        const tenantIds = [...new Set(profiles?.map(p => p.admin_id).filter(Boolean) || [])];
        if (tenantIds.length > 0) {
          const { data: tenants } = await supabase
            .from("profiles")
            .select("id, full_name, email")
            .in("id", tenantIds);
          
          tenants?.forEach(t => {
            tenantNames[t.id] = t.full_name || t.email;
          });
        }
      }

      // Build user sessions map
      const usersMap = new Map<string, UserWithSessions>();
      profiles?.forEach(profile => {
        usersMap.set(profile.id, {
          id: profile.id,
          email: profile.email,
          full_name: profile.full_name,
          admin_id: profile.admin_id,
          sessions: [],
        });
      });

      sessions?.forEach(session => {
        const user = usersMap.get(session.user_id);
        if (user) {
          user.sessions.push({
            id: session.id,
            ip_address: session.ip_address,
            user_agent: session.user_agent,
            last_activity: session.last_activity,
            created_at: session.created_at,
          });
        }
      });

      const allUsers = Array.from(usersMap.values());

      // Filter by tenant if needed
      if (effectiveTenantId) {
        const filteredUsers = allUsers.filter(u => u.admin_id === effectiveTenantId);
        return {
          tenantGroups: [] as TenantSessionGroup[],
          users: filteredUsers,
          totalSessions: filteredUsers.reduce((sum, u) => sum + u.sessions.length, 0),
        };
      }

      // Group by tenant for super admin
      if (isSuperAdminRole) {
        const groupedByTenant = new Map<string, UserWithSessions[]>();
        
        allUsers.forEach(user => {
          const tenantId = user.admin_id || "unassigned";
          if (!groupedByTenant.has(tenantId)) {
            groupedByTenant.set(tenantId, []);
          }
          groupedByTenant.get(tenantId)!.push(user);
        });

        const tenantGroups: TenantSessionGroup[] = Array.from(groupedByTenant.entries()).map(([tenantId, users]) => ({
          tenantId,
          tenantName: tenantId === "unassigned" ? "Unassigned" : tenantNames[tenantId] || "Unknown Tenant",
          users,
          totalSessions: users.reduce((sum, u) => sum + u.sessions.length, 0),
        }));

        return {
          tenantGroups,
          users: allUsers,
          totalSessions: allUsers.reduce((sum, u) => sum + u.sessions.length, 0),
        };
      }

      return {
        tenantGroups: [] as TenantSessionGroup[],
        users: allUsers,
        totalSessions: allUsers.reduce((sum, u) => sum + u.sessions.length, 0),
      };
    },
    refetchInterval: 15000,
  });

  // Fetch login history grouped by tenant
  const { data: loginHistoryData, isLoading: loadingHistory } = useQuery({
    queryKey: ["security-login-history-by-tenant", effectiveTenantId, isSuperAdminRole],
    queryFn: async () => {
      const { data: sessions, error } = await supabase
        .from("user_sessions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) throw error;

      const userIds = [...new Set(sessions?.map(s => s.user_id) || [])];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, email, full_name, admin_id")
        .in("id", userIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

      // Get tenant names if super admin
      let tenantNames: Record<string, string> = {};
      if (isSuperAdminRole && !effectiveTenantId) {
        const tenantIds = [...new Set(profiles?.map(p => p.admin_id).filter(Boolean) || [])];
        if (tenantIds.length > 0) {
          const { data: tenants } = await supabase
            .from("profiles")
            .select("id, full_name, email")
            .in("id", tenantIds);
          
          tenants?.forEach(t => {
            tenantNames[t.id] = t.full_name || t.email;
          });
        }
      }

      const allSessions: LoginHistoryItem[] = sessions?.map(session => ({
        ...session,
        profile: profileMap.get(session.user_id) || null,
      })) || [];

      // Filter by tenant if needed
      if (effectiveTenantId) {
        const filteredSessions = allSessions.filter(s => s.profile?.admin_id === effectiveTenantId);
        return {
          tenantGroups: [] as TenantLoginHistoryGroup[],
          sessions: filteredSessions,
        };
      }

      // Group by tenant for super admin
      if (isSuperAdminRole) {
        const groupedByTenant = new Map<string, LoginHistoryItem[]>();
        
        allSessions.forEach(session => {
          const tenantId = session.profile?.admin_id || "unassigned";
          if (!groupedByTenant.has(tenantId)) {
            groupedByTenant.set(tenantId, []);
          }
          groupedByTenant.get(tenantId)!.push(session);
        });

        const tenantGroups: TenantLoginHistoryGroup[] = Array.from(groupedByTenant.entries()).map(([tenantId, sessions]) => ({
          tenantId,
          tenantName: tenantId === "unassigned" ? "Unassigned" : tenantNames[tenantId] || "Unknown Tenant",
          sessions,
        }));

        return {
          tenantGroups,
          sessions: allSessions,
        };
      }

      return {
        tenantGroups: [] as TenantLoginHistoryGroup[],
        sessions: allSessions,
      };
    },
    refetchInterval: 30000,
  });

  // Analyze data for alerts
  const failedLoginsByIP = failedAttempts?.reduce((acc, attempt) => {
    acc[attempt.ip_address] = (acc[attempt.ip_address] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const suspiciousIPs = Object.entries(failedLoginsByIP || {}).filter(([_, count]) => count >= 5);

  const uploadsByUser = recentUploads?.reduce((acc, doc) => {
    if (!acc[doc.uploaded_by]) {
      acc[doc.uploaded_by] = { count: 0, size: 0, user: doc.profile };
    }
    acc[doc.uploaded_by].count++;
    acc[doc.uploaded_by].size += doc.size;
    return acc;
  }, {} as Record<string, { count: number; size: number; user: { full_name: string | null; email: string } | null }>);

  const suspiciousUploads = Object.entries(uploadsByUser || {}).filter(
    ([_, data]) => data.count >= 10 || data.size >= 50 * 1024 * 1024
  );

  return {
    failedAttempts,
    failedLoginsByIP,
    suspiciousIPs,
    recentUploads,
    uploadsByUser,
    suspiciousUploads,
    sessionData,
    loginHistoryData,
    isLoading: loadingAttempts || loadingSessions || loadingHistory || loadingUploads,
    loadingAttempts,
    loadingSessions,
    loadingHistory,
    loadingUploads,
    isSuperAdminRole,
    effectiveTenantId,
  };
}
