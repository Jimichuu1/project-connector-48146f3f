import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { KYCRecord, KYCRecordWithDocuments } from "@/types/documents";
import { useToast } from "@/hooks/use-toast";
import { useAuditLog } from "@/hooks/useAuditLog";
import { KYCRecordCreateData, KYCRecordUpdateData, KYCStatus } from "@/types/supabase-helpers";

export const useKYC = (entityId?: string, entityType?: 'lead' | 'client') => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logAction } = useAuditLog();

  const { data: kycRecords, isLoading } = useQuery({
    queryKey: ['kyc-records', entityId, entityType],
    queryFn: async () => {
      if (!entityId || !entityType) return [];
      
      let query = supabase
        .from('kyc_records')
        .select(`
          *,
          documents(*),
          verified_profile:profiles!kyc_records_verified_by_fkey(id, full_name, email)
        `);
      
      if (entityType === 'lead') {
        query = query.eq('lead_id', entityId);
      } else {
        query = query.eq('client_id', entityId);
      }
      
      // Limit to 100 records per entity to prevent performance issues
      const { data, error } = await query
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) throw error;
      return data as KYCRecordWithDocuments[];
    },
    enabled: !!entityId && !!entityType,
  });

  const createKYCRecord = useMutation({
    mutationFn: async ({
      entityId,
      entityType,
      bankName,
      notes,
    }: {
      entityId: string;
      entityType: 'lead' | 'client';
      bankName?: string;
      notes?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Get admin_id from user's profile for tenant isolation
      const { data: profile } = await supabase
        .from('profiles')
        .select('admin_id')
        .eq('id', user.id)
        .maybeSingle();

      const recordData: KYCRecordCreateData = {
        status: 'PENDING' as KYCStatus,
        created_by: user.id,
        admin_id: profile?.admin_id || user.id,
        bank_name: bankName,
        notes: notes,
        lead_id: entityType === 'lead' ? entityId : undefined,
        client_id: entityType === 'client' ? entityId : undefined,
      };

      const { data, error } = await supabase
        .from('kyc_records')
        .insert([recordData])
        .select()
        .single();

      if (error) throw error;

      // Log the activity
      const actionType = bankName ? 'bank_added' : 'note_added';
      try {
        await logAction({
          actionType,
          entityType,
          entityId,
          details: {
            kyc_record_id: data.id,
            bank_name: bankName || null,
            notes: notes || null,
            record_type: bankName ? 'bank' : 'note',
          },
        });
      } catch (logError) {
        // Don't fail the main action if audit logging fails
        console.error('Audit log error:', logError);
      }

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['kyc-records'] });
      const recordType = variables.bankName ? "Bank" : "Note";
      toast({
        title: `${recordType} added`,
        description: `The ${recordType.toLowerCase()} has been successfully added.`,
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to create KYC record",
        description: message,
        variant: "destructive",
      });
    },
  });

  const updateKYCRecord = useMutation({
    mutationFn: async ({
      id,
      ...updates
    }: {
      id: string;
      status?: KYCStatus;
      bank_name?: string;
      notes?: string;
    }) => {
      const updateData: KYCRecordUpdateData = { ...updates };
      
      if (updates.status === 'VERIFIED') {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          updateData.verified_date = new Date().toISOString();
          updateData.verified_by = user.id;
        }
      }

      const { data, error } = await supabase
        .from('kyc_records')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // Log the activity
      await logAction({
        actionType: 'kyc_record_updated',
        entityType: entityType || 'client',
        entityId: entityId || id,
        details: {
          kyc_record_id: id,
          changes: updates,
        },
      });

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kyc-records'] });
      toast({
        title: "KYC record updated",
        description: "The KYC record has been successfully updated.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to update KYC record",
        description: message,
        variant: "destructive",
      });
    },
  });

  const deleteKYCRecord = useMutation({
    mutationFn: async (id: string) => {
      // Get record details before deleting for audit log
      const { data: record } = await supabase
        .from('kyc_records')
        .select('*')
        .eq('id', id)
        .single();

      const { error } = await supabase
        .from('kyc_records')
        .delete()
        .eq('id', id);

      if (error) throw error;

      // Log the activity
      await logAction({
        actionType: 'kyc_record_deleted',
        entityType: entityType || 'client',
        entityId: entityId || id,
        details: {
          kyc_record_id: id,
          deleted_record: {
            bank_name: record?.bank_name,
            notes: record?.notes,
          },
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kyc-records'] });
      toast({
        title: "KYC record deleted",
        description: "The KYC record has been successfully deleted.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to delete KYC record",
        description: message,
        variant: "destructive",
      });
    },
  });

  return {
    kycRecords,
    isLoading,
    createKYCRecord,
    updateKYCRecord,
    deleteKYCRecord,
  };
};
