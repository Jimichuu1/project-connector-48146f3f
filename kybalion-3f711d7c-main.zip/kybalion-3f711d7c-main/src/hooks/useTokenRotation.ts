// Token rotation is now handled entirely by the Supabase SDK's built-in
// autoRefreshToken mechanism. Manual rotation was causing refresh-token
// race conditions and "Refresh Token Not Found" errors.

export const useTokenRotation = () => {
  // No-op — SDK handles token refresh via autoRefreshToken: true
  return { rotateToken: async () => {} };
};
