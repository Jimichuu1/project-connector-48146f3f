import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface ClientStatus {
  id: string;
  name: string;
  color: string | null;
  position: number | null;
  is_default: boolean | null;
  is_active: boolean | null;
}

export function useClientStatuses() {
  return useQuery({
    queryKey: ["client-statuses"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_statuses")
        .select("*")
        .order("position", { ascending: true });

      if (error) throw error;
      return data as ClientStatus[];
    },
    staleTime: 10 * 60 * 1000, // 10 minutes - statuses rarely change
  });
}

export function useActiveClientStatuses() {
  const { data: statuses, ...rest } = useClientStatuses();
  
  return {
    ...rest,
    data: statuses?.filter((s) => s.is_active !== false) ?? [],
  };
}

export function getClientStatusConfig(statuses: ClientStatus[], statusName: string) {
  const status = statuses?.find((s) => s.name === statusName);
  if (status) {
    return {
      label: status.name,
      color: status.color || "#6366f1",
    };
  }
  // Fallback for unknown statuses
  return {
    label: statusName,
    color: "#6366f1",
  };
}
