import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export type LiveSubmissionStatus = "new" | "assigned" | "converted" | "dismissed" | "moved";

export interface LiveSubmission {
  id: string;
  admin_id: string;
  api_key_id: string | null;
  name: string;
  email: string | null;
  phone: string | null;
  country: string | null;
  phone_normalized: string | null;
  metadata: Record<string, unknown>;
  source_url: string | null;
  ip_address: string | null;
  user_agent: string | null;
  is_duplicate: boolean;
  duplicate_of_lead_id: string | null;
  status: LiveSubmissionStatus;
  assigned_to: string | null;
  assigned_at: string | null;
  assigned_by: string | null;
  converted_client_id: string | null;
  converted_at: string | null;
  converted_by: string | null;
  moved_lead_id: string | null;
  moved_lead_group_id: string | null;
  moved_at: string | null;
  created_at: string;
}

export function useLiveTrafficSubmissions() {
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();
  const { user } = useAuth();
  const { isSuperAgent, hasTenantOwnerAccess } = useUserData();

  const query = useQuery({
    queryKey: ["live-traffic-submissions", effectiveTenantId, user?.id, isSuperAgent],
    queryFn: async () => {
      let q = supabase
        .from("live_traffic_submissions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(500);
      if (effectiveTenantId) q = q.eq("admin_id", effectiveTenantId);
      // Super Agents only see their own assigned submissions
      if (isSuperAgent && !hasTenantOwnerAccess && user?.id) {
        q = q.eq("assigned_to", user.id);
      }
      const { data, error } = await q;
      if (error) throw error;
      return (data || []) as unknown as LiveSubmission[];
    },
    enabled: effectiveTenantId !== undefined && !!user,
  });

  // Realtime - instant updates without refresh
  useEffect(() => {
    if (!effectiveTenantId) return;
    const ch = supabase
      .channel(`live-traffic-${effectiveTenantId}-${user?.id ?? "anon"}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "live_traffic_submissions",
          filter: `admin_id=eq.${effectiveTenantId}`,
        },
        (payload) => {
          const row = payload.new as unknown as LiveSubmission;
          // Super Agents only see their own assigned submissions
          if (isSuperAgent && !hasTenantOwnerAccess && user?.id && row.assigned_to !== user.id) {
            return;
          }
          queryClient.setQueriesData<LiveSubmission[]>(
            { queryKey: ["live-traffic-submissions"] },
            (old) => {
              if (!old) return [row];
              if (old.some((r) => r.id === row.id)) return old;
              return [row, ...old];
            },
          );
        },
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "live_traffic_submissions",
          filter: `admin_id=eq.${effectiveTenantId}`,
        },
        (payload) => {
          const row = payload.new as unknown as LiveSubmission;
          queryClient.setQueriesData<LiveSubmission[]>(
            { queryKey: ["live-traffic-submissions"] },
            (old) => {
              if (!old) return old;
              const idx = old.findIndex((r) => r.id === row.id);
              if (idx === -1) {
                if (isSuperAgent && !hasTenantOwnerAccess && user?.id && row.assigned_to !== user.id) {
                  return old;
                }
                return [row, ...old];
              }
              if (isSuperAgent && !hasTenantOwnerAccess && user?.id && row.assigned_to !== user.id) {
                return old.filter((r) => r.id !== row.id);
              }
              const next = [...old];
              next[idx] = { ...next[idx], ...row };
              return next;
            },
          );
        },
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "live_traffic_submissions",
          filter: `admin_id=eq.${effectiveTenantId}`,
        },
        (payload) => {
          const oldRow = payload.old as { id?: string };
          if (!oldRow?.id) return;
          queryClient.setQueriesData<LiveSubmission[]>(
            { queryKey: ["live-traffic-submissions"] },
            (old) => (old ? old.filter((r) => r.id !== oldRow.id) : old),
          );
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [effectiveTenantId, queryClient, user?.id, isSuperAgent, hasTenantOwnerAccess]);

  const assignToSuperAgent = useMutation({
    mutationFn: async ({
      submissionId,
      superAgentId,
    }: {
      submissionId: string;
      superAgentId: string;
    }) => {
      const { data, error } = await supabase.rpc("assign_live_submission", {
        p_submission_id: submissionId,
        p_super_agent_id: superAgentId,
      });
      if (error) throw error;
      return data as unknown as string;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });
    },
  });

  const unassign = useMutation({
    mutationFn: async (submissionId: string) => {
      const { error } = await supabase.rpc("unassign_live_submission", {
        p_submission_id: submissionId,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });
      toast.success("Unassigned");
    },
    onError: (e: Error) => toast.error(e.message || "Failed to unassign"),
  });

  const convert = useMutation({
    mutationFn: async (submissionId: string) => {
      const { data, error } = await supabase.rpc("convert_live_submission", {
        p_submission_id: submissionId,
      });
      if (error) throw error;
      return data as unknown as string;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });
      queryClient.invalidateQueries({ queryKey: ["clients-paginated"] });
      queryClient.invalidateQueries({ queryKey: ["client-groups"] });
      queryClient.invalidateQueries({ queryKey: ["client-group-members"] });
    },
  });

  const dismiss = useMutation({
    mutationFn: async (submissionId: string) => {
      const { error } = await supabase
        .from("live_traffic_submissions")
        .update({
          status: "dismissed",
          dismissed_at: new Date().toISOString(),
        } as never)
        .eq("id", submissionId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });
      toast.success("Submission dismissed");
    },
    onError: (e: Error) => toast.error(e.message || "Failed to dismiss"),
  });

  const remove = useMutation({
    mutationFn: async (submissionId: string) => {
      const { error } = await supabase
        .from("live_traffic_submissions")
        .delete()
        .eq("id", submissionId);
      if (error) throw error;
      return submissionId;
    },
    onSuccess: (id) => {
      queryClient.setQueriesData<LiveSubmission[]>(
        { queryKey: ["live-traffic-submissions"] },
        (old) => (old ? old.filter((r) => r.id !== id) : old),
      );
      toast.success("Submission deleted");
    },
    onError: (e: Error) => toast.error(e.message || "Failed to delete"),
  });

  return { ...query, assignToSuperAgent, unassign, convert, dismiss, remove };
}
