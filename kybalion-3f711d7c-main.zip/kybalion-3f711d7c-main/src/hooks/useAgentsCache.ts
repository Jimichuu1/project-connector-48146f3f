/**
 * Global cache for agents list to avoid redundant queries
 * Used by LeadAssignmentDropdown, AssignGroupDialog, etc.
 */
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useAuth } from "@/contexts/AuthContext";
import { useUserRole } from "@/hooks/useUserRole";

export interface CachedAgent {
  id: string;
  name: string;
  email: string;
  avatar: string | null;
  role: "AGENT" | "SUPER_AGENT" | "TEAM_LEADER" | "UNKNOWN";
}

export const useAgentsCache = () => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const { isManager } = useUserRole();

  return useQuery({
    queryKey: ['agents-cache', effectiveTenantId, isManager, user?.id],
    staleTime: 10 * 60 * 1000, // 10 minutes - agents don't change often
    gcTime: 30 * 60 * 1000, // Keep in cache for 30 minutes
    enabled: !!user,
    queryFn: async () => {
      // Get AGENT and SUPER_AGENT user_ids from user_roles
      const { data: userRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .in('role', ['AGENT', 'SUPER_AGENT', 'TEAM_LEADER']);
      
      if (rolesError) throw rolesError;
      if (!userRoles || userRoles.length === 0) return [];
      
      const userIds = [...new Set(userRoles.map(r => r.user_id))];
      
      // Get profiles - select only needed columns
      let profilesQuery = supabase
        .from('profiles')
        .select('id, full_name, email, avatar_url, created_by');
      
      if (effectiveTenantId) {
        profilesQuery = profilesQuery.eq('admin_id', effectiveTenantId);
      }
      
      // Manager sees only their team
      if (isManager && user?.id) {
        profilesQuery = profilesQuery.eq('created_by', user.id);
      }
      
      const { data: profiles, error: profilesError } = await profilesQuery;
      if (profilesError) throw profilesError;
      
      // Build role map
      const roleMap = new Map<string, string>();
      (userRoles || []).forEach(r => roleMap.set(r.user_id, r.role));

      // Filter to agents, map, and sort: Agents first then Super Agents, alphabetically within
      const agents: CachedAgent[] = (profiles || [])
        .filter(p => userIds.includes(p.id))
        .map(profile => ({
          id: profile.id,
          name: profile.full_name || profile.email || 'Unknown',
          email: profile.email || '',
          avatar: profile.avatar_url,
          role: ((roleMap.get(profile.id) || "UNKNOWN") as CachedAgent["role"]),
        }))
        .sort((a, b) => {
          const order = { AGENT: 0, SUPER_AGENT: 1, TEAM_LEADER: 2, UNKNOWN: 3 };
          const diff = (order[a.role] ?? 3) - (order[b.role] ?? 3);
          if (diff !== 0) return diff;
          return a.name.localeCompare(b.name);
        });

      return agents;
    },
  });
};
