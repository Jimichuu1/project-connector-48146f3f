import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { isValidUUID } from "@/lib/uuidUtils";
import type { Lead } from "@/types/leads";

export const useLead = (leadId: string | undefined) => {
  return useQuery({
    queryKey: ['lead', leadId],
    enabled: !!leadId && isValidUUID(leadId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .eq('id', leadId!)
        .maybeSingle();
      
      if (error) throw error;
      return data as Lead | null;
    },
    staleTime: 30000, // 30 seconds
  });
};
