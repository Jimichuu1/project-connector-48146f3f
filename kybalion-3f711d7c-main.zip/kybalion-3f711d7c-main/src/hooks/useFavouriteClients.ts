import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useMemo } from "react";

export function useFavouriteClients() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const userId = user?.id;

  const { data: favourites = [], isLoading } = useQuery({
    queryKey: ["favourite-clients", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("favourite_clients")
        .select("client_id")
        .eq("user_id", userId!);
      if (error) throw error;
      return data.map((r) => r.client_id);
    },
  });

  const favouriteIds = useMemo(() => new Set(favourites), [favourites]);

  const toggleFavourite = useMutation({
    mutationFn: async (clientId: string) => {
      if (!userId) throw new Error("Not authenticated");
      const isFav = favouriteIds.has(clientId);
      if (isFav) {
        const { error } = await supabase
          .from("favourite_clients")
          .delete()
          .eq("client_id", clientId)
          .eq("user_id", userId);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("favourite_clients")
          .insert({ client_id: clientId, user_id: userId });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["favourite-clients", userId] });
    },
  });

  return { favouriteIds, favourites, isLoading, toggleFavourite };
}
