import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTenant } from "@/contexts/TenantContext";

export interface LeadGroup {
  id: string;
  name: string;
  description: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
  admin_id: string | null;
}

export interface LeadGroupMember {
  id: string;
  group_id: string;
  lead_id: string;
  added_by: string;
  added_at: string;
}

export const useLeadGroups = () => {
  const queryClient = useQueryClient();
  const { effectiveTenantId, isSuperAdmin } = useTenant();

  const { data: groups, isLoading } = useQuery({
    queryKey: ["lead-groups", effectiveTenantId, isSuperAdmin],
    queryFn: async () => {
      let query = supabase
        .from("lead_groups")
        .select("*")
        .order("created_at", { ascending: false });

      // SUPER_ADMIN without tenant selected sees all groups
      // SUPER_ADMIN with tenant selected sees that tenant's groups
      // TENANT_OWNER sees only their own groups
      if (!isSuperAdmin && effectiveTenantId) {
        // Tenant owner - filter by their admin_id
        query = query.eq("admin_id", effectiveTenantId);
      } else if (isSuperAdmin && effectiveTenantId) {
        // Super admin viewing specific tenant
        query = query.eq("admin_id", effectiveTenantId);
      }
      // If isSuperAdmin and no effectiveTenantId, show all groups

      const { data, error } = await query;

      if (error) throw error;
      return data as LeadGroup[];
    },
  });

  const createGroup = useMutation({
    mutationFn: async (group: { name: string; description?: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from("lead_groups")
        .insert({
          name: group.name,
          description: group.description,
          created_by: user.id,
          admin_id: effectiveTenantId || user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      toast.success("Lead group created successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to create lead group");
    },
  });

  const updateGroup = useMutation({
    mutationFn: async ({ groupId, name }: { groupId: string; name: string }) => {
      const { error } = await supabase
        .from("lead_groups")
        .update({ name })
        .eq("id", groupId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      toast.success("Group renamed successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to rename group");
    },
  });

  const deleteGroup = useMutation({
    mutationFn: async ({ groupId, deleteLeads }: { groupId: string; deleteLeads: boolean }) => {
      if (deleteLeads) {
        // Get all leads in the group
        const { data: members } = await supabase
          .from("lead_group_members")
          .select("lead_id")
          .eq("group_id", groupId);

        if (members && members.length > 0) {
          const leadIds = members.map(m => m.lead_id);
          
          // Delete leads in batches of 50 to avoid URL length limits
          const BATCH_SIZE = 50;
          for (let i = 0; i < leadIds.length; i += BATCH_SIZE) {
            const batch = leadIds.slice(i, i + BATCH_SIZE);
            const { error: deleteLeadsError } = await supabase
              .from("leads")
              .delete()
              .in("id", batch);

            if (deleteLeadsError) throw deleteLeadsError;
          }
        }
      }

      // Remove all members from group first (also in batches)
      const { data: allMembers } = await supabase
        .from("lead_group_members")
        .select("lead_id")
        .eq("group_id", groupId);
      
      if (allMembers && allMembers.length > 0) {
        const memberLeadIds = allMembers.map(m => m.lead_id);
        const BATCH_SIZE = 50;
        
        for (let i = 0; i < memberLeadIds.length; i += BATCH_SIZE) {
          const batch = memberLeadIds.slice(i, i + BATCH_SIZE);
          const { error: membersError } = await supabase
            .from("lead_group_members")
            .delete()
            .eq("group_id", groupId)
            .in("lead_id", batch);

          if (membersError) throw membersError;
        }
      }

      // Delete the group
      const { error } = await supabase
        .from("lead_groups")
        .delete()
        .eq("id", groupId);

      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      toast.success(variables.deleteLeads 
        ? "Group and leads deleted successfully" 
        : "Group deleted, leads moved to all leads");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to delete lead group");
    },
  });

  const addLeadsToGroup = useMutation({
    mutationFn: async ({ groupId, leadIds }: { groupId: string; leadIds: string[] }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const members = leadIds.map(leadId => ({
        group_id: groupId,
        lead_id: leadId,
        added_by: user.id,
      }));

      const { error } = await supabase
        .from("lead_group_members")
        .insert(members);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      toast.success("Leads added to group successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to add leads to group");
    },
  });

  const moveLeadsToGroup = useMutation({
    mutationFn: async ({ groupId, leadIds }: { groupId: string; leadIds: string[] }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // First, remove leads from all their current groups
      const { error: deleteError } = await supabase
        .from("lead_group_members")
        .delete()
        .in("lead_id", leadIds);

      if (deleteError) throw deleteError;

      // Then add them to the new group
      const members = leadIds.map(leadId => ({
        group_id: groupId,
        lead_id: leadId,
        added_by: user.id,
      }));

      const { error: insertError } = await supabase
        .from("lead_group_members")
        .insert(members);

      if (insertError) throw insertError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      toast.success("Leads moved to group successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to move leads to group");
    },
  });

  const mergeGroups = useMutation({
    mutationFn: async ({ groupIds, newName }: { groupIds: string[]; newName: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // 1. Create the new group
      const { data: newGroup, error: createError } = await supabase
        .from("lead_groups")
        .insert({
          name: newName,
          created_by: user.id,
          admin_id: effectiveTenantId || user.id,
        })
        .select()
        .single();

      if (createError) throw createError;

      // 2. Get ALL members from source groups (paginate to bypass 1000 row limit)
      const allMembers: { lead_id: string }[] = [];
      const PAGE_SIZE = 1000;
      let offset = 0;
      let hasMore = true;

      while (hasMore) {
        const { data: page, error: fetchError } = await supabase
          .from("lead_group_members")
          .select("lead_id")
          .in("group_id", groupIds)
          .range(offset, offset + PAGE_SIZE - 1);

        if (fetchError) throw fetchError;

        if (page && page.length > 0) {
          allMembers.push(...page);
          offset += PAGE_SIZE;
          hasMore = page.length === PAGE_SIZE;
        } else {
          hasMore = false;
        }
      }

      // 3. Deduplicate lead_ids and add to new group
      if (allMembers.length > 0) {
        const uniqueLeadIds = [...new Set(allMembers.map(m => m.lead_id))];
        const newMembers = uniqueLeadIds.map(leadId => ({
          group_id: newGroup.id,
          lead_id: leadId,
          added_by: user.id,
        }));

        // Insert in batches
        const BATCH_SIZE = 50;
        for (let i = 0; i < newMembers.length; i += BATCH_SIZE) {
          const batch = newMembers.slice(i, i + BATCH_SIZE);
          const { error: insertError } = await supabase
            .from("lead_group_members")
            .insert(batch);
          if (insertError) throw insertError;
        }
      }

      // 4. Remove members from old groups
      for (const groupId of groupIds) {
        const { error: delMembersError } = await supabase
          .from("lead_group_members")
          .delete()
          .eq("group_id", groupId);
        if (delMembersError) throw delMembersError;
      }

      // 5. Delete old groups
      const { error: delGroupsError } = await supabase
        .from("lead_groups")
        .delete()
        .in("id", groupIds);

      if (delGroupsError) throw delGroupsError;

      return newGroup;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      queryClient.invalidateQueries({ queryKey: ["leads-stats"] });
      toast.success("Groups merged successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to merge groups");
    },
  });

  const removeLeadFromGroup = useMutation({
    mutationFn: async ({ groupId, leadId }: { groupId: string; leadId: string }) => {
      const { error } = await supabase
        .from("lead_group_members")
        .delete()
        .eq("group_id", groupId)
        .eq("lead_id", leadId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["lead-groups"] });
      toast.success("Lead removed from group successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to remove lead from group");
    },
  });

  const assignGroupToAgent = useMutation({
    mutationFn: async ({ groupId, agentId }: { groupId: string; agentId: string }) => {
      // Get all leads in the group
      const { data: members, error: fetchError } = await supabase
        .from("lead_group_members")
        .select("lead_id")
        .eq("group_id", groupId);

      if (fetchError) throw fetchError;

      if (!members || members.length === 0) {
        throw new Error("No leads in this group");
      }

      // Update all leads to be assigned to the agent
      const { error: updateError } = await supabase
        .from("leads")
        .update({ assigned_to: agentId })
        .in("id", members.map(m => m.lead_id));

      if (updateError) throw updateError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      toast.success("Group assigned to agent successfully");
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to assign group to agent");
    },
  });

  const getGroupMembers = async (groupId: string) => {
    const { data, error } = await supabase
      .from("lead_group_members")
      .select("lead_id, leads(*)")
      .eq("group_id", groupId);

    if (error) throw error;
    return data;
  };

  return {
    groups,
    isLoading,
    createGroup,
    updateGroup,
    deleteGroup,
    mergeGroups,
    addLeadsToGroup,
    moveLeadsToGroup,
    removeLeadFromGroup,
    assignGroupToAgent,
    getGroupMembers,
  };
};
