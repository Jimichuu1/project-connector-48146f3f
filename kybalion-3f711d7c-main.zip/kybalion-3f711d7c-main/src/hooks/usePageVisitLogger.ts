import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { HASH_TO_ROUTE, ROUTE_HASHES } from "@/lib/routeMap";
import { canAccessRoute, Role } from "@/lib/canAccessRoute";

const DEBOUNCE_MS = 60_000; // 1 row per (user, path) per minute

function resolveReadable(pathname: string): { readable: string; hashed: string | null } {
  // Direct match
  if (HASH_TO_ROUTE[pathname]) return { readable: HASH_TO_ROUTE[pathname], hashed: pathname };

  // Detail route: /p/m8Yz3/abc -> /clients/abc
  const segs = pathname.split("/").filter(Boolean);
  if (segs.length >= 2 && segs[0] === "p") {
    const prefix = "/p/" + segs[1];
    const readableBase = HASH_TO_ROUTE[prefix];
    if (readableBase) {
      return { readable: readableBase + "/" + segs.slice(2).join("/"), hashed: pathname };
    }
  }

  // Already readable
  if (Object.values(ROUTE_HASHES).indexOf(pathname) === -1) {
    return { readable: pathname, hashed: ROUTE_HASHES[pathname] || null };
  }

  return { readable: pathname, hashed: null };
}

export function usePageVisitLogger() {
  const location = useLocation();
  const { session } = useAuth();
  const { role, adminId, profile } = useUserData();
  const lastLogged = useRef<Map<string, number>>(new Map());
  const lastNotified = useRef<Map<string, number>>(new Map());

  useEffect(() => {
    const userId = session?.user?.id;
    if (!userId || !role) return;

    const path = location.pathname;
    if (path === "/" || path.startsWith("/access-denied")) return;

    const { readable, hashed } = resolveReadable(path);
    const key = `${userId}::${readable}`;
    const now = Date.now();
    const prev = lastLogged.current.get(key) || 0;
    if (now - prev < DEBOUNCE_MS) return;
    lastLogged.current.set(key, now);

    const wasDenied = !canAccessRoute(role as Role, readable);

    supabase
      .from("page_visits")
      .insert({
        user_id: userId,
        admin_id: adminId || null,
        path: readable,
        hashed_path: hashed,
        was_denied: wasDenied,
      })
      .then(({ error }) => {
        if (error) console.warn("page_visits insert failed", error.message);
      });

    // Notify Tenant Owners (and Super Admins) about denied access attempts
    if (wasDenied && adminId) {
      const notifyKey = `notify::${key}`;
      const prevNotified = lastNotified.current.get(notifyKey) || 0;
      // Throttle to one notification per (user, path) per 10 minutes
      if (now - prevNotified < 10 * 60_000) return;
      lastNotified.current.set(notifyKey, now);

      const displayPath = hashed || readable;
      const userName = profile?.full_name || profile?.username || profile?.email || "Unknown user";
      const message = `${userName} trying to reach page ${displayPath}`;

      (async () => {
        try {
          const { error } = await supabase.rpc("notify_page_access_denied", {
            p_path: hashed || readable,
            p_message: message,
          });
          if (error) console.warn("denied-access notification failed", error.message);
        } catch (err) {
          console.warn("denied-access notification error", err);
        }
      })();
    }
  }, [location.pathname, session?.user?.id, role, adminId, profile?.full_name, profile?.username, profile?.email]);
  
}
