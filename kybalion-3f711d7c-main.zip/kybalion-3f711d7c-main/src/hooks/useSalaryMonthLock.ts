import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";
import { toast } from "sonner";

/**
 * Tracks whether the salary month is locked for the active tenant.
 * Locking prevents edits to rules / advances / custom entries so historical
 * salary records stay frozen.
 *
 * Only TENANT_OWNER and SUPER_ADMIN can toggle the lock (also enforced by RLS).
 */
export function useSalaryMonthLock(month: string) {
  const { effectiveTenantId } = useTenant();
  const { profile, isSuperAdmin, isTenantOwner } = useUserData();
  const queryClient = useQueryClient();

  const userId = profile?.id;
  const canToggle = isTenantOwner || isSuperAdmin;

  const { data: lock, isLoading } = useQuery({
    queryKey: ["salary-month-lock", effectiveTenantId, month],
    enabled: !!effectiveTenantId && !!month,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("salary_month_locks")
        .select("*")
        .eq("admin_id", effectiveTenantId)
        .eq("month", month)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const toggle = useMutation({
    mutationFn: async (next: boolean) => {
      if (!effectiveTenantId) throw new Error("No tenant");
      if (next) {
        const { error } = await supabase
          .from("salary_month_locks")
          .insert({ admin_id: effectiveTenantId, month, locked_by: userId });
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("salary_month_locks")
          .delete()
          .eq("admin_id", effectiveTenantId)
          .eq("month", month);
        if (error) throw error;
      }
    },
    onSuccess: (_d, next) => {
      queryClient.invalidateQueries({ queryKey: ["salary-month-lock", effectiveTenantId, month] });
      toast.success(next ? "Month locked" : "Month unlocked");
    },
    onError: (err: Error) => {
      toast.error("Failed to update lock: " + err.message);
    },
  });

  return {
    isLocked: !!lock,
    isAutoLocked: !!lock && !lock.locked_by,
    isLoading,
    canToggle,
    toggle,
  };
}
