import { createRoot } from "react-dom/client";
import { ThemeProvider } from "next-themes";
import App from "./App.tsx";
import "./index.css";
import { initSentry } from "@/lib/sentry";
import { installPerfWatch } from "@/lib/perfWatch";

// Initialize Sentry for error tracking and performance monitoring
initSentry();
// Log slow Supabase requests (>5s) to the console for diagnostics
installPerfWatch();

createRoot(document.getElementById("root")!).render(
  <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
    <App />
  </ThemeProvider>
);
