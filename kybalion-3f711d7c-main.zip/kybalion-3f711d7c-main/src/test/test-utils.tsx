import React, { ReactElement } from 'react';
import { render as rtlRender, RenderOptions, RenderResult } from '@testing-library/react';
import { screen, waitFor, fireEvent, within } from '@testing-library/dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import { TooltipProvider } from '@/components/ui/tooltip';
import { vi } from 'vitest';

// Re-export from testing-library/dom
export { screen, waitFor, fireEvent, within };

// Create a new QueryClient for each test
const createTestQueryClient = () =>
  new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        gcTime: 0,
        staleTime: 0,
      },
      mutations: {
        retry: false,
      },
    },
  });

// Mock AuthContext
const mockAuthContext = {
  user: null,
  session: null,
  isLoading: false,
  login: vi.fn(),
  logout: vi.fn(),
  isAdmin: false,
  isManager: false,
  isSuperAgent: false,
  isAgent: false,
};

// Mock AuthProvider
const MockAuthProvider = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

interface AllProvidersProps {
  children: React.ReactNode;
}

const AllProviders = ({ children }: AllProvidersProps) => {
  const queryClient = createTestQueryClient();

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <TooltipProvider>
          <MockAuthProvider>{children}</MockAuthProvider>
        </TooltipProvider>
      </BrowserRouter>
    </QueryClientProvider>
  );
};

const customRender = (
  ui: ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>
): RenderResult => rtlRender(ui, { wrapper: AllProviders, ...options });

export { customRender as render };
export { createTestQueryClient, mockAuthContext };
