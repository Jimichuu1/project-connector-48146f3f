import { http, HttpResponse } from 'msw';

// Mock API handlers for testing
export const handlers = [
  // Auth endpoints
  http.post('*/auth/v1/token', () => {
    return HttpResponse.json({
      access_token: 'mock-access-token',
      refresh_token: 'mock-refresh-token',
      expires_in: 3600,
      user: {
        id: 'mock-user-id',
        email: 'test@example.com'
      }
    });
  }),

  http.post('*/auth/v1/signup', () => {
    return HttpResponse.json({
      id: 'new-user-id',
      email: 'newuser@example.com'
    });
  }),

  http.post('*/auth/v1/logout', () => {
    return HttpResponse.json({ success: true });
  }),

  http.get('*/auth/v1/user', () => {
    return HttpResponse.json({
      id: 'mock-user-id',
      email: 'test@example.com',
      user_metadata: {
        full_name: 'Test User'
      }
    });
  }),

  // REST API endpoints
  http.get('*/rest/v1/profiles', () => {
    return HttpResponse.json([
      { id: 'profile-1', full_name: 'User One', email: 'user1@test.com' },
      { id: 'profile-2', full_name: 'User Two', email: 'user2@test.com' }
    ]);
  }),

  http.get('*/rest/v1/leads', () => {
    return HttpResponse.json([
      { id: 'lead-1', name: 'Lead One', email: 'lead1@test.com', status: 'NEW' },
      { id: 'lead-2', name: 'Lead Two', email: 'lead2@test.com', status: 'ACTIVE' }
    ]);
  }),

  http.get('*/rest/v1/clients', () => {
    return HttpResponse.json([
      { id: 'client-1', name: 'Client One', email: 'client1@test.com', balance: 1000 },
      { id: 'client-2', name: 'Client Two', email: 'client2@test.com', balance: 2000 }
    ]);
  }),

  http.get('*/rest/v1/deposits', () => {
    return HttpResponse.json([
      { id: 'deposit-1', amount: 1000, status: 'pending' },
      { id: 'deposit-2', amount: 2000, status: 'approved' }
    ]);
  }),

  http.get('*/rest/v1/user_roles', () => {
    return HttpResponse.json([
      { id: 'role-1', user_id: 'mock-user-id', role: 'ADMIN' }
    ]);
  }),

  http.get('*/rest/v1/general_settings', () => {
    return HttpResponse.json([
      {
        id: 'settings-1',
        work_start_time: '09:00:00',
        work_end_time: '18:00:00',
        show_phone_to_agents: false,
        show_email_to_agents: false
      }
    ]);
  }),

  // Edge functions
  http.post('*/functions/v1/health-check', () => {
    return HttpResponse.json({ status: 'ok', timestamp: new Date().toISOString() });
  }),

  http.post('*/functions/v1/initiate-call', () => {
    return HttpResponse.json({ 
      success: true, 
      callId: 'call-123',
      message: 'Call initiated' 
    });
  }),

  http.post('*/functions/v1/send-email', () => {
    return HttpResponse.json({ 
      success: true, 
      messageId: 'msg-123' 
    });
  }),

  // RPC functions
  http.post('*/rest/v1/rpc/is_ip_blocked', () => {
    return HttpResponse.json(false);
  }),

  http.post('*/rest/v1/rpc/count_failed_attempts', () => {
    return HttpResponse.json(0);
  }),

  http.post('*/rest/v1/rpc/has_role', () => {
    return HttpResponse.json(true);
  }),

  // Fallback for unhandled requests
  http.all('*', ({ request }) => {
    console.warn(`Unhandled ${request.method} request to ${request.url}`);
    return HttpResponse.json({ error: 'Not found' }, { status: 404 });
  })
];
