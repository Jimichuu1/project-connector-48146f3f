// SVG string for the Kybalion logo (transparent background)
const kybalionSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none">
  <circle cx="50" cy="50" r="45" stroke="hsl(270, 70%, 60%)" stroke-width="5" fill="none"/>
  <polygon points="50,12 10,78 90,78" stroke="hsl(270, 70%, 60%)" stroke-width="5" fill="none" stroke-linejoin="round"/>
  <rect x="28" y="46" width="44" height="32" stroke="hsl(270, 70%, 60%)" stroke-width="5" fill="none"/>
  <circle cx="50" cy="62" r="12" stroke="hsl(270, 70%, 60%)" stroke-width="5" fill="none"/>
</svg>`;

let originalFaviconUrl: string | null = null;

const createLogoDataUrl = (): string => {
  return 'data:image/svg+xml,' + encodeURIComponent(kybalionSvg);
};

export const updateFaviconWithBadge = (count: number) => {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const img = new Image();
  
  if (!originalFaviconUrl) {
    originalFaviconUrl = createLogoDataUrl();
  }
  
  canvas.width = 32;
  canvas.height = 32;
  
  img.onload = () => {
    if (!ctx) return;
    
    // Draw logo
    ctx.drawImage(img, 0, 0, 32, 32);
    
    if (count > 0) {
      // Draw red badge circle
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(24, 8, 10, 0, 2 * Math.PI);
      ctx.fill();
      
      // Draw white border
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Draw count text
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 12px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(count > 9 ? '9+' : count.toString(), 24, 8);
    }
    
    // Update favicon
    let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    link.href = canvas.toDataURL('image/png');
  };
  
  img.src = originalFaviconUrl;
};

export const resetFavicon = () => {
  if (originalFaviconUrl) {
    const link = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
    if (link) {
      link.href = originalFaviconUrl;
    }
  }
};
