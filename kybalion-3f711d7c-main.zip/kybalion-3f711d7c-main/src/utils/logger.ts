/**
 * Global logger utility for consistent error logging across the application.
 * In production, this can be extended to send logs to external services like Sentry, LogRocket, etc.
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  context?: Record<string, unknown>;
  stack?: string;
}

interface LoggerConfig {
  minLevel: LogLevel;
  enableConsole: boolean;
  enableRemote: boolean;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
};

const defaultConfig: LoggerConfig = {
  minLevel: import.meta.env.DEV ? 'debug' : 'warn',
  enableConsole: true,
  enableRemote: !import.meta.env.DEV, // Enable remote logging in production
};

class Logger {
  private config: LoggerConfig;
  private logBuffer: LogEntry[] = [];
  private readonly MAX_BUFFER_SIZE = 100;

  constructor(config: Partial<LoggerConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
  }

  private shouldLog(level: LogLevel): boolean {
    return LOG_LEVELS[level] >= LOG_LEVELS[this.config.minLevel];
  }

  private createEntry(level: LogLevel, message: string, context?: Record<string, unknown>, error?: Error): LogEntry {
    return {
      level,
      message,
      timestamp: new Date().toISOString(),
      context,
      stack: error?.stack,
    };
  }

  private writeToConsole(entry: LogEntry): void {
    if (!this.config.enableConsole) return;

    const { level, message, context, stack } = entry;
    const prefix = `[${entry.timestamp}] [${level.toUpperCase()}]`;

    switch (level) {
      case 'debug':
        console.debug(prefix, message, context || '');
        break;
      case 'info':
        console.info(prefix, message, context || '');
        break;
      case 'warn':
        console.warn(prefix, message, context || '');
        break;
      case 'error':
        console.error(prefix, message, context || '', stack || '');
        break;
    }
  }

  private addToBuffer(entry: LogEntry): void {
    this.logBuffer.push(entry);
    if (this.logBuffer.length > this.MAX_BUFFER_SIZE) {
      this.logBuffer.shift();
    }
  }

  private async sendToRemote(entry: LogEntry): Promise<void> {
    if (!this.config.enableRemote) return;

    // In production, implement remote logging service integration
    // Example: Sentry, LogRocket, custom backend, etc.
    // For now, we just buffer the logs
    this.addToBuffer(entry);
  }

  debug(message: string, context?: Record<string, unknown>): void {
    if (!this.shouldLog('debug')) return;
    const entry = this.createEntry('debug', message, context);
    this.writeToConsole(entry);
  }

  info(message: string, context?: Record<string, unknown>): void {
    if (!this.shouldLog('info')) return;
    const entry = this.createEntry('info', message, context);
    this.writeToConsole(entry);
    this.sendToRemote(entry);
  }

  warn(message: string, context?: Record<string, unknown>): void {
    if (!this.shouldLog('warn')) return;
    const entry = this.createEntry('warn', message, context);
    this.writeToConsole(entry);
    this.sendToRemote(entry);
  }

  error(message: string, error?: Error, context?: Record<string, unknown>): void {
    if (!this.shouldLog('error')) return;
    const entry = this.createEntry('error', message, context, error);
    this.writeToConsole(entry);
    this.sendToRemote(entry);
  }

  /**
   * Log a React component error caught by an Error Boundary
   */
  logComponentError(error: Error, componentStack: string, componentName?: string): void {
    this.error('React Component Error', error, {
      componentName,
      componentStack,
      errorName: error.name,
      errorMessage: error.message,
    });
  }

  /**
   * Log an unhandled promise rejection
   */
  logUnhandledRejection(reason: unknown): void {
    const error = reason instanceof Error ? reason : new Error(String(reason));
    this.error('Unhandled Promise Rejection', error);
  }

  /**
   * Get buffered logs (useful for debugging)
   */
  getLogBuffer(): LogEntry[] {
    return [...this.logBuffer];
  }

  /**
   * Clear the log buffer
   */
  clearBuffer(): void {
    this.logBuffer = [];
  }
}

// Export singleton instance
export const logger = new Logger();

// Export for testing/custom instances
export { Logger };
