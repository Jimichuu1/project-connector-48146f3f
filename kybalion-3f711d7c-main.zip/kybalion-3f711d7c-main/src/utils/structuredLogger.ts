/**
 * Structured Logger for Production-Ready Logging
 * 
 * Provides consistent, structured logging with:
 * - Log levels (debug, info, warn, error)
 * - Structured JSON output for external services
 * - Context preservation across requests
 * - Performance timing utilities
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  context?: Record<string, unknown>;
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
  duration_ms?: number;
  user_id?: string;
  session_id?: string;
  request_id?: string;
}

interface LoggerConfig {
  minLevel: LogLevel;
  enableConsole: boolean;
  enableBuffer: boolean;
  maxBufferSize: number;
  appName: string;
  environment: string;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
};

const defaultConfig: LoggerConfig = {
  minLevel: import.meta.env.DEV ? 'debug' : 'info',
  enableConsole: true,
  enableBuffer: true,
  maxBufferSize: 100,
  appName: 'forex-crm',
  environment: import.meta.env.MODE || 'development',
};

class StructuredLogger {
  private config: LoggerConfig;
  private buffer: LogEntry[] = [];
  private context: Record<string, unknown> = {};

  constructor(config: Partial<LoggerConfig> = {}) {
    this.config = { ...defaultConfig, ...config };
  }

  private shouldLog(level: LogLevel): boolean {
    return LOG_LEVELS[level] >= LOG_LEVELS[this.config.minLevel];
  }

  private createEntry(
    level: LogLevel,
    message: string,
    data?: Record<string, unknown>,
    error?: Error
  ): LogEntry {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...this.context,
    };

    if (data) {
      entry.context = data;
    }

    if (error) {
      entry.error = {
        name: error.name,
        message: error.message,
        stack: error.stack,
      };
    }

    return entry;
  }

  private output(entry: LogEntry): void {
    if (this.config.enableConsole) {
      const consoleMethod = entry.level === 'debug' ? 'log' : entry.level;
      const formatted = `[${entry.timestamp}] [${entry.level.toUpperCase()}] ${entry.message}`;
      
      if (entry.error) {
        console[consoleMethod](formatted, entry.context || '', entry.error);
      } else if (entry.context) {
        console[consoleMethod](formatted, entry.context);
      } else {
        console[consoleMethod](formatted);
      }
    }

    if (this.config.enableBuffer) {
      this.buffer.push(entry);
      if (this.buffer.length > this.config.maxBufferSize) {
        this.buffer.shift();
      }
    }
  }

  // Set context that will be included in all subsequent logs
  setContext(context: Record<string, unknown>): void {
    this.context = { ...this.context, ...context };
  }

  clearContext(): void {
    this.context = {};
  }

  setUserId(userId: string): void {
    this.context.user_id = userId;
  }

  setSessionId(sessionId: string): void {
    this.context.session_id = sessionId;
  }

  setRequestId(requestId: string): void {
    this.context.request_id = requestId;
  }

  debug(message: string, data?: Record<string, unknown>): void {
    if (this.shouldLog('debug')) {
      this.output(this.createEntry('debug', message, data));
    }
  }

  info(message: string, data?: Record<string, unknown>): void {
    if (this.shouldLog('info')) {
      this.output(this.createEntry('info', message, data));
    }
  }

  warn(message: string, data?: Record<string, unknown>): void {
    if (this.shouldLog('warn')) {
      this.output(this.createEntry('warn', message, data));
    }
  }

  error(message: string, error?: Error | unknown, data?: Record<string, unknown>): void {
    if (this.shouldLog('error')) {
      const err = error instanceof Error ? error : new Error(String(error));
      this.output(this.createEntry('error', message, data, err));
    }
  }

  // Performance timing
  time(label: string): () => void {
    const start = performance.now();
    return () => {
      const duration = performance.now() - start;
      this.info(`${label} completed`, { duration_ms: Math.round(duration * 100) / 100 });
    };
  }

  // Log API request
  logApiRequest(
    method: string,
    url: string,
    status: number,
    durationMs: number,
    data?: Record<string, unknown>
  ): void {
    const level: LogLevel = status >= 500 ? 'error' : status >= 400 ? 'warn' : 'info';
    this[level](`API ${method} ${url}`, {
      status,
      duration_ms: durationMs,
      ...data,
    });
  }

  // Log user action
  logUserAction(action: string, data?: Record<string, unknown>): void {
    this.info(`User action: ${action}`, data);
  }

  // Log security event
  logSecurityEvent(event: string, data?: Record<string, unknown>): void {
    this.warn(`Security event: ${event}`, { security: true, ...data });
  }

  // Get buffered logs
  getBuffer(): LogEntry[] {
    return [...this.buffer];
  }

  // Clear buffer
  clearBuffer(): void {
    this.buffer = [];
  }

  // Export logs as JSON (for external service integration)
  exportLogs(): string {
    return JSON.stringify({
      app: this.config.appName,
      environment: this.config.environment,
      exported_at: new Date().toISOString(),
      entries: this.buffer,
    });
  }
}

// Export singleton instance
export const structuredLogger = new StructuredLogger();

// Export class for custom instances
export { StructuredLogger };
