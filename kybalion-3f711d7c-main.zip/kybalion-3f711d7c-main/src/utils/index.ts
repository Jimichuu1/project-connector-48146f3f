/**
 * Barrel file for utils - exports all utility functions
 */

// Core utilities
export { cn } from "@/lib/utils";

// Logger
export { logger, Logger } from "./logger";
export type { LogLevel, LogEntry } from "./logger";

// Structured Logger (production-ready)
export { structuredLogger, StructuredLogger } from "./structuredLogger";

// Formatters
export {
  formatCurrency,
  formatPhone,
  formatDate,
  formatDateTime,
  formatNumber,
  formatPercent,
  formatRelativeTime,
  truncate,
} from "./formatters";

// Validation
export {
  emailSchema,
  usernameSchema,
  passwordSchema,
  fullNameSchema,
  ipAddressSchema,
  positiveNumberSchema,
  nonNegativeNumberSchema,
  isValidEmail,
  isValidUsername,
  isValidPassword,
  isValidIpAddress,
  sanitizeHtml,
  sanitizeSearchQuery,
} from "./validation";
