import { describe, it, expect } from 'vitest';
import {
  formatCurrency,
  formatPhone,
  formatDate,
  formatDateTime,
  formatNumber,
  formatPercent,
  formatRelativeTime,
  truncate,
} from '../formatters';

describe('formatters', () => {
  describe('formatCurrency', () => {
    it('should format positive numbers as currency', () => {
      const result = formatCurrency(1234.56);
      expect(result).toContain('1,234');
    });

    it('should handle zero', () => {
      const result = formatCurrency(0);
      expect(result).toContain('0');
    });

    it('should handle negative numbers', () => {
      const result = formatCurrency(-500);
      expect(result).toContain('500');
    });

    it('should handle undefined/null gracefully', () => {
      expect(formatCurrency(undefined as any)).toBeDefined();
      expect(formatCurrency(null as any)).toBeDefined();
    });
  });

  describe('formatPhone', () => {
    it('should format phone numbers', () => {
      const phone = '+1234567890';
      const result = formatPhone(phone);
      expect(result).toBeDefined();
      expect(typeof result).toBe('string');
    });

    it('should handle empty string', () => {
      const result = formatPhone('');
      expect(result).toBeDefined();
    });

    it('should handle null/undefined', () => {
      expect(formatPhone(null as any)).toBeDefined();
      expect(formatPhone(undefined as any)).toBeDefined();
    });
  });

  describe('formatDate', () => {
    it('should format date strings', () => {
      const date = '2024-01-15';
      const result = formatDate(date);
      expect(result).toBeDefined();
      expect(typeof result).toBe('string');
    });

    it('should format Date objects', () => {
      const date = new Date('2024-01-15');
      const result = formatDate(date);
      expect(result).toBeDefined();
    });
  });

  describe('formatDateTime', () => {
    it('should format datetime with time', () => {
      const datetime = '2024-01-15T14:30:00Z';
      const result = formatDateTime(datetime);
      expect(result).toBeDefined();
      expect(typeof result).toBe('string');
    });
  });

  describe('formatNumber', () => {
    it('should format large numbers with separators', () => {
      const result = formatNumber(1234567);
      expect(result).toContain('1,234,567');
    });

    it('should handle decimals', () => {
      const result = formatNumber(1234.567, 2);
      expect(result).toContain('1,234');
    });

    it('should handle zero', () => {
      expect(formatNumber(0)).toBe('0');
    });
  });

  describe('formatPercent', () => {
    it('should format as percentage', () => {
      const result = formatPercent(0.75);
      expect(result).toContain('75');
      expect(result).toContain('%');
    });

    it('should handle 100%', () => {
      const result = formatPercent(1);
      expect(result).toContain('100');
    });

    it('should handle 0%', () => {
      const result = formatPercent(0);
      expect(result).toContain('0');
    });
  });

  describe('formatRelativeTime', () => {
    it('should format recent dates as relative', () => {
      const recentDate = new Date();
      recentDate.setMinutes(recentDate.getMinutes() - 5);
      const result = formatRelativeTime(recentDate);
      expect(result).toBeDefined();
      expect(typeof result).toBe('string');
    });

    it('should format older dates', () => {
      const oldDate = new Date();
      oldDate.setDate(oldDate.getDate() - 7);
      const result = formatRelativeTime(oldDate);
      expect(result).toBeDefined();
    });
  });

  describe('truncate', () => {
    it('should truncate long strings', () => {
      const longText = 'This is a very long string that should be truncated';
      const result = truncate(longText, 20);
      expect(result.length).toBeLessThanOrEqual(23); // 20 + '...'
      expect(result).toContain('...');
    });

    it('should not truncate short strings', () => {
      const shortText = 'Short';
      const result = truncate(shortText, 20);
      expect(result).toBe(shortText);
    });

    it('should handle empty string', () => {
      expect(truncate('', 10)).toBe('');
    });
  });
});
