import { describe, it, expect } from 'vitest';
import {
  isValidEmail,
  isValidUsername,
  isValidPassword,
  isValidIpAddress,
  sanitizeHtml,
  sanitizeSearchQuery,
  emailSchema,
  usernameSchema,
  passwordSchema,
} from '../validation';

describe('validation utilities', () => {
  describe('isValidEmail', () => {
    it('should accept valid emails', () => {
      expect(isValidEmail('test@example.com')).toBe(true);
      expect(isValidEmail('user.name@domain.org')).toBe(true);
      expect(isValidEmail('user+tag@example.co.uk')).toBe(true);
    });

    it('should reject invalid emails', () => {
      expect(isValidEmail('notanemail')).toBe(false);
      expect(isValidEmail('missing@')).toBe(false);
      expect(isValidEmail('@nodomain.com')).toBe(false);
      expect(isValidEmail('')).toBe(false);
    });
  });

  describe('isValidUsername', () => {
    it('should accept valid usernames', () => {
      expect(isValidUsername('john_doe')).toBe(true);
      expect(isValidUsername('user123')).toBe(true);
      expect(isValidUsername('test-user')).toBe(true);
    });

    it('should reject invalid usernames', () => {
      expect(isValidUsername('ab')).toBe(false); // too short
      expect(isValidUsername('user@name')).toBe(false); // invalid char
      expect(isValidUsername('')).toBe(false);
    });
  });

  describe('isValidPassword', () => {
    it('should accept valid passwords', () => {
      expect(isValidPassword('SecurePass123!')).toBe(true);
      expect(isValidPassword('MyP@ssw0rd')).toBe(true);
    });

    it('should reject weak passwords', () => {
      expect(isValidPassword('short')).toBe(false);
      expect(isValidPassword('nouppercasenumber')).toBe(false);
      expect(isValidPassword('')).toBe(false);
    });
  });

  describe('isValidIpAddress', () => {
    it('should accept valid IPv4 addresses', () => {
      expect(isValidIpAddress('192.168.1.1')).toBe(true);
      expect(isValidIpAddress('10.0.0.1')).toBe(true);
      expect(isValidIpAddress('255.255.255.255')).toBe(true);
    });

    it('should accept valid IPv6 addresses', () => {
      expect(isValidIpAddress('::1')).toBe(true);
      expect(isValidIpAddress('2001:db8::1')).toBe(true);
    });

    it('should reject invalid IPs', () => {
      expect(isValidIpAddress('256.1.1.1')).toBe(false);
      expect(isValidIpAddress('notanip')).toBe(false);
      expect(isValidIpAddress('')).toBe(false);
    });
  });

  describe('sanitizeHtml', () => {
    it('should strip dangerous HTML tags', () => {
      const input = '<script>alert("xss")</script>Hello';
      const result = sanitizeHtml(input);
      expect(result).not.toContain('<script>');
      expect(result).toContain('Hello');
    });

    it('should handle onclick attributes', () => {
      const input = '<div onclick="evil()">Click</div>';
      const result = sanitizeHtml(input);
      expect(result).not.toContain('onclick');
    });

    it('should preserve safe content', () => {
      const input = 'Plain text content';
      expect(sanitizeHtml(input)).toBe(input);
    });
  });

  describe('sanitizeSearchQuery', () => {
    it('should remove SQL injection attempts', () => {
      const input = "'; DROP TABLE users; --";
      const result = sanitizeSearchQuery(input);
      expect(result).not.toContain('DROP');
      expect(result).not.toContain(';');
    });

    it('should preserve alphanumeric content', () => {
      const input = 'search term 123';
      const result = sanitizeSearchQuery(input);
      expect(result).toContain('search');
      expect(result).toContain('term');
    });

    it('should trim whitespace', () => {
      const input = '  search  ';
      const result = sanitizeSearchQuery(input);
      expect(result).toBe('search');
    });
  });

  describe('Zod schemas', () => {
    describe('emailSchema', () => {
      it('should validate correct emails', () => {
        const result = emailSchema.safeParse('test@example.com');
        expect(result.success).toBe(true);
      });

      it('should reject invalid emails', () => {
        const result = emailSchema.safeParse('invalid');
        expect(result.success).toBe(false);
      });
    });

    describe('usernameSchema', () => {
      it('should validate correct usernames', () => {
        const result = usernameSchema.safeParse('valid_user123');
        expect(result.success).toBe(true);
      });

      it('should reject short usernames', () => {
        const result = usernameSchema.safeParse('ab');
        expect(result.success).toBe(false);
      });
    });

    describe('passwordSchema', () => {
      it('should validate strong passwords', () => {
        const result = passwordSchema.safeParse('SecurePass123!');
        expect(result.success).toBe(true);
      });

      it('should reject weak passwords', () => {
        const result = passwordSchema.safeParse('weak');
        expect(result.success).toBe(false);
      });
    });
  });
});
