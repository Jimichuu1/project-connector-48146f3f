import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

describe('StructuredLogger', () => {
  let consoleSpy: {
    log: ReturnType<typeof vi.spyOn>;
    info: ReturnType<typeof vi.spyOn>;
    warn: ReturnType<typeof vi.spyOn>;
    error: ReturnType<typeof vi.spyOn>;
  };

  beforeEach(() => {
    consoleSpy = {
      log: vi.spyOn(console, 'log').mockImplementation(() => {}),
      info: vi.spyOn(console, 'info').mockImplementation(() => {}),
      warn: vi.spyOn(console, 'warn').mockImplementation(() => {}),
      error: vi.spyOn(console, 'error').mockImplementation(() => {}),
    };
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should be importable', async () => {
    const module = await import('../structuredLogger');
    expect(module.structuredLogger).toBeDefined();
    expect(module.StructuredLogger).toBeDefined();
  });

  it('should have logging methods', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    expect(typeof structuredLogger.debug).toBe('function');
    expect(typeof structuredLogger.info).toBe('function');
    expect(typeof structuredLogger.warn).toBe('function');
    expect(typeof structuredLogger.error).toBe('function');
  });

  it('should log info messages', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    structuredLogger.info('Test message');
    
    expect(consoleSpy.info).toHaveBeenCalled();
  });

  it('should log warning messages', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    structuredLogger.warn('Warning message');
    
    expect(consoleSpy.warn).toHaveBeenCalled();
  });

  it('should log error messages with error object', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    const error = new Error('Test error');
    structuredLogger.error('Error occurred', error);
    
    expect(consoleSpy.error).toHaveBeenCalled();
  });

  it('should support context setting', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    structuredLogger.setUserId('user-123');
    structuredLogger.setSessionId('session-456');
    
    // Should not throw
    expect(() => structuredLogger.info('With context')).not.toThrow();
  });

  it('should support timing operations', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    const endTimer = structuredLogger.time('test-operation');
    
    // Simulate some work
    await new Promise(resolve => setTimeout(resolve, 10));
    
    // Should not throw
    expect(() => endTimer()).not.toThrow();
  });

  it('should export logs as JSON', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    structuredLogger.info('Test for export');
    
    const exported = structuredLogger.exportLogs();
    expect(() => JSON.parse(exported)).not.toThrow();
    
    const parsed = JSON.parse(exported);
    expect(parsed).toHaveProperty('app');
    expect(parsed).toHaveProperty('entries');
  });

  it('should clear buffer', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    structuredLogger.info('Message 1');
    structuredLogger.info('Message 2');
    
    structuredLogger.clearBuffer();
    
    expect(structuredLogger.getBuffer()).toHaveLength(0);
  });

  it('should log API requests', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    expect(() => {
      structuredLogger.logApiRequest('GET', '/api/test', 200, 150);
    }).not.toThrow();
  });

  it('should log security events', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    expect(() => {
      structuredLogger.logSecurityEvent('login_attempt', { ip: '127.0.0.1' });
    }).not.toThrow();
    
    expect(consoleSpy.warn).toHaveBeenCalled();
  });

  it('should log user actions', async () => {
    const { structuredLogger } = await import('../structuredLogger');
    
    expect(() => {
      structuredLogger.logUserAction('button_click', { button: 'submit' });
    }).not.toThrow();
  });
});
