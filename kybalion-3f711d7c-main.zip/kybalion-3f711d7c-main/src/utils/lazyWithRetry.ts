import { lazy, ComponentType } from 'react';

/**
 * Lazy load with retry logic for handling dynamic import failures
 * This handles cases where chunk files are stale after a deployment
 */
export function lazyWithRetry<T extends ComponentType<unknown>>(
  importFn: () => Promise<{ default: T }>,
  retries = 2,
  interval = 500
): React.LazyExoticComponent<T> {
  return lazy(async () => {
    for (let i = 0; i < retries; i++) {
      try {
        return await importFn();
      } catch (error) {
        const isChunkError =
          error instanceof Error &&
          (error.message.includes('Failed to fetch dynamically imported module') ||
           error.message.includes('Loading chunk') ||
           error.message.includes('Loading CSS chunk') ||
           error.message.includes('404'));
        
        if (isChunkError) {
          // On first retry, wait a bit and try again
          if (i === 0) {
            await new Promise(resolve => setTimeout(resolve, interval));
            continue;
          }
          
          // On second failure, force reload to get fresh chunks
          // Store a flag to prevent infinite reload loops
          const reloadKey = 'chunk_reload_' + Date.now().toString().slice(0, -4); // Round to ~10 seconds
          const lastReload = sessionStorage.getItem('chunk_reload_time');
          const now = Date.now();
          
          // Only reload if we haven't reloaded in the last 10 seconds
          if (!lastReload || now - parseInt(lastReload) > 10000) {
            sessionStorage.setItem('chunk_reload_time', now.toString());
            window.location.reload();
            // Return a never-resolving promise since we're reloading
            return new Promise(() => {});
          }
        }
        
        throw error;
      }
    }
    
    throw new Error('Failed to load module after retries');
  });
}
