import { describe, it, expect, vi, beforeEach } from 'vitest';

// Mock Supabase
vi.mock('@/integrations/supabase/client', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          single: vi.fn(() => ({
            data: { email: 'test@example.com' },
            error: null,
          })),
        })),
        gte: vi.fn(() => ({
          data: [{ id: '1' }],
          error: null,
        })),
      })),
      insert: vi.fn(() => ({
        select: vi.fn(() => ({
          single: vi.fn(() => ({
            data: { id: '1' },
            error: null,
          })),
        })),
        data: null,
        error: null,
      })),
      update: vi.fn(() => ({
        eq: vi.fn(() => ({
          data: null,
          error: null,
        })),
      })),
    })),
    rpc: vi.fn(() => ({
      data: false,
      error: null,
    })),
  },
}));

describe('authService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getClientIp', () => {
    it('should be exported', async () => {
      const { getClientIp } = await import('@/services/authService');
      expect(getClientIp).toBeDefined();
      expect(typeof getClientIp).toBe('function');
    });

    it('should return an IP string', async () => {
      const { getClientIp } = await import('@/services/authService');
      const ip = await getClientIp();
      expect(typeof ip).toBe('string');
    });
  });

  describe('checkIpBlocked', () => {
    it('should be exported', async () => {
      const { checkIpBlocked } = await import('@/services/authService');
      expect(checkIpBlocked).toBeDefined();
    });
  });

  describe('recordAuthAttempt', () => {
    it('should be exported', async () => {
      const { recordAuthAttempt } = await import('@/services/authService');
      expect(recordAuthAttempt).toBeDefined();
    });
  });

  describe('createUserSession', () => {
    it('should be exported', async () => {
      const { createUserSession } = await import('@/services/authService');
      expect(createUserSession).toBeDefined();
    });
  });

  describe('deactivateUserSessions', () => {
    it('should be exported', async () => {
      const { deactivateUserSessions } = await import('@/services/authService');
      expect(deactivateUserSessions).toBeDefined();
    });
  });

  describe('logAuditEvent', () => {
    it('should be exported', async () => {
      const { logAuditEvent } = await import('@/services/authService');
      expect(logAuditEvent).toBeDefined();
    });
  });

  describe('getEmailByUsername', () => {
    it('should be exported', async () => {
      const { getEmailByUsername } = await import('@/services/authService');
      expect(getEmailByUsername).toBeDefined();
    });
  });
});
