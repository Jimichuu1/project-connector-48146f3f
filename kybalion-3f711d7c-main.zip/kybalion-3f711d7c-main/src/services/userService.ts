/**
 * User service - handles all user-related API calls
 */
import { supabase } from "@/integrations/supabase/client";
import { logger } from "@/utils/logger";
import { UserProfile, UserWithRole, UserWithIpWhitelist, IpWhitelistEntry, AppRole } from "@/types/users";

/**
 * Fetch all user profiles, optionally filtered by tenant
 */
export async function fetchProfiles(effectiveTenantId?: string | null): Promise<UserProfile[]> {
  try {
    let query = supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });
    
    // Filter by admin_id (tenant) - this catches users created by managers too
    if (effectiveTenantId) {
      query = query.eq("admin_id", effectiveTenantId);
    }
    
    const { data, error } = await query;
    
    if (error) {
      logger.error('Error fetching profiles', error);
      throw error;
    }
    
    return data || [];
  } catch (error) {
    logger.error('Failed to fetch profiles', error instanceof Error ? error : new Error(String(error)));
    throw error;
  }
}

/**
 * Fetch a user's role
 */
export async function fetchUserRole(userId: string): Promise<AppRole | null> {
  try {
    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .maybeSingle();
    
    if (error) {
      logger.error('Error fetching user role', error);
      return null;
    }
    
    return data?.role || null;
  } catch (error) {
    logger.error('Failed to fetch user role', error instanceof Error ? error : new Error(String(error)));
    return null;
  }
}

/**
 * Fetch IP whitelist entries for a user
 */
export async function fetchUserIpWhitelist(userId: string): Promise<IpWhitelistEntry[]> {
  try {
    const { data, error } = await supabase
      .from("ip_whitelist")
      .select("id, ip_address, is_active")
      .eq("user_id", userId);
    
    if (error) {
      logger.error('Error fetching IP whitelist', error);
      return [];
    }
    
    return data || [];
  } catch (error) {
    logger.error('Failed to fetch IP whitelist', error instanceof Error ? error : new Error(String(error)));
    return [];
  }
}

/**
 * Fetch all users with their roles and IP whitelist, optionally filtered by tenant
 */
export async function fetchUsersWithData(effectiveTenantId?: string | null): Promise<UserWithIpWhitelist[]> {
  try {
    const profiles = await fetchProfiles(effectiveTenantId);
    
    const usersWithData = await Promise.all(
      profiles.map(async (profile) => {
        const [role, ip_whitelist] = await Promise.all([
          fetchUserRole(profile.id),
          fetchUserIpWhitelist(profile.id),
        ]);
        
        return {
          ...profile,
          role: role || undefined,
          ip_whitelist,
        };
      })
    );
    
    return usersWithData;
  } catch (error) {
    logger.error('Failed to fetch users with data', error instanceof Error ? error : new Error(String(error)));
    throw error;
  }
}

/**
 * Update a user's profile
 */
export async function updateProfile(
  userId: string,
  updates: { full_name?: string; username?: string; is_closer?: boolean }
): Promise<void> {
  try {
    const { error } = await supabase
      .from("profiles")
      .update(updates)
      .eq("id", userId);
    
    if (error) {
      logger.error('Error updating profile', error);
      throw error;
    }
  } catch (error) {
    logger.error('Failed to update profile', error instanceof Error ? error : new Error(String(error)));
    throw error;
  }
}

/**
 * Update a user's role
 */
export async function updateUserRole(userId: string, role: AppRole): Promise<void> {
  try {
    // Delete existing role with error check
    const { error: deleteError } = await supabase
      .from("user_roles")
      .delete()
      .eq("user_id", userId);
    
    if (deleteError) {
      logger.error('Error deleting existing user role', deleteError);
      throw new Error(`Failed to update role: ${deleteError.message}`);
    }
    
    // Insert new role
    const { error: insertError } = await supabase.from("user_roles").insert({
      user_id: userId,
      role,
    });
    
    if (insertError) {
      logger.error('Error inserting new user role', insertError);
      throw new Error(`Failed to assign new role: ${insertError.message}`);
    }
  } catch (error) {
    logger.error('Failed to update user role', error instanceof Error ? error : new Error(String(error)));
    throw error;
  }
}

/**
 * Add an IP address to user's whitelist
 */
export async function addIpToWhitelist(
  userId: string,
  ipAddress: string,
  createdBy: string
): Promise<void> {
  try {
    const { error } = await supabase.from("ip_whitelist").insert({
      user_id: userId,
      ip_address: ipAddress,
      created_by: createdBy,
    });
    
    if (error) {
      logger.error('Error adding IP to whitelist', error);
      throw error;
    }
  } catch (error) {
    logger.error('Failed to add IP to whitelist', error instanceof Error ? error : new Error(String(error)));
    throw error;
  }
}

/**
 * Remove an IP address from whitelist
 */
export async function removeIpFromWhitelist(ipId: string): Promise<void> {
  try {
    const { error } = await supabase.from("ip_whitelist").delete().eq("id", ipId);
    
    if (error) {
      logger.error('Error removing IP from whitelist', error);
      throw error;
    }
  } catch (error) {
    logger.error('Failed to remove IP from whitelist', error instanceof Error ? error : new Error(String(error)));
    throw error;
  }
}

/**
 * Delete a user via edge function
 */
export async function deleteUser(userId: string, force = false): Promise<{
  success: boolean;
  needsConfirmation?: boolean;
  assignedClientsCount?: number;
  assignedLeadsCount?: number;
  error?: string;
}> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error("No active session");
    }
    
    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-user-password`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          action: 'delete-user',
          userId,
          force,
        }),
      }
    );
    
    const result = await response.json();
    
    if (!response.ok) {
      return { success: false, error: result.error || 'Failed to delete user' };
    }
    
    if (result.needsConfirmation) {
      return {
        success: false,
        needsConfirmation: true,
        assignedClientsCount: result.assignedClientsCount,
        assignedLeadsCount: result.assignedLeadsCount,
      };
    }
    
    return { success: true };
  } catch (error) {
    logger.error('Failed to delete user', error instanceof Error ? error : new Error(String(error)));
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

/**
 * Reset a user's password via edge function
 */
export async function resetUserPassword(userId: string, newPassword: string): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error("No active session");
    }
    
    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-user-password`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          action: 'update-password',
          userId,
          newPassword,
        }),
      }
    );
    
    const result = await response.json();
    
    if (!response.ok) {
      return { success: false, error: result.error || 'Failed to reset password' };
    }
    
    return { success: true };
  } catch (error) {
    logger.error('Failed to reset password', error instanceof Error ? error : new Error(String(error)));
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

/**
 * Bulk reset passwords for all non-admin users
 */
export async function bulkResetPasswords(): Promise<{
  success: boolean;
  updated?: number;
  failed?: number;
  error?: string;
}> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      throw new Error("No active session");
    }
    
    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manage-user-password`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          action: 'bulk-update-password',
          newPassword: '123456',
          excludeAdmins: true,
        }),
      }
    );
    
    const result = await response.json();
    
    if (!response.ok) {
      return { success: false, error: result.error || 'Failed to reset passwords' };
    }
    
    return { success: true, updated: result.updated, failed: result.failed };
  } catch (error) {
    logger.error('Failed to bulk reset passwords', error instanceof Error ? error : new Error(String(error)));
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}
