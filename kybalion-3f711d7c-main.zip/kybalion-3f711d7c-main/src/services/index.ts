/**
 * Barrel file for services - exports all service functions
 */

// Auth Service
export {
  getClientIp,
  checkIpBlocked,
  getFailedAttempts,
  recordAuthAttempt,
  createUserSession,
  deactivateUserSessions,
  logAuditEvent,
  getEmailByUsername,
} from "./authService";
export type { AuthAttemptResult, SessionInfo } from "./authService";

// User Service
export {
  fetchProfiles,
  fetchUserRole,
  fetchUserIpWhitelist,
  fetchUsersWithData,
  updateProfile,
  updateUserRole,
  addIpToWhitelist,
  removeIpFromWhitelist,
  deleteUser,
  resetUserPassword,
  bulkResetPasswords,
} from "./userService";
