/**
 * Authentication service - handles all auth-related API calls
 */
import { supabase } from "@/integrations/supabase/client";
import { logger } from "@/utils/logger";

export interface AuthAttemptResult {
  success: boolean;
  needsCaptcha?: boolean;
  isBlocked?: boolean;
  attemptsRemaining?: number;
  error?: string;
}

export interface SessionInfo {
  userId: string;
  sessionToken: string;
  ipAddress: string;
  userAgent: string;
  expiresAt: string;
}

/**
 * Get the client's IP address
 */
export async function getClientIp(): Promise<string> {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch (error) {
    logger.warn('Failed to fetch client IP', { error });
    return 'unknown';
  }
}

/**
 * Check if an IP address is blocked
 */
export async function checkIpBlocked(ipAddress: string): Promise<boolean> {
  try {
    const { data, error } = await supabase.rpc('is_ip_blocked', { 
      p_ip_address: ipAddress 
    });
    
    if (error) {
      logger.error('Error checking IP block status', error);
      return false;
    }
    
    return data === true;
  } catch (error) {
    logger.error('Failed to check IP block status', error instanceof Error ? error : new Error(String(error)));
    return false;
  }
}

/**
 * Get count of failed login attempts for an IP
 */
export async function getFailedAttempts(ipAddress: string, minutes: number): Promise<number> {
  try {
    const { data, error } = await supabase.rpc('count_failed_attempts', {
      p_ip_address: ipAddress,
      p_minutes: minutes,
    });
    
    if (error) {
      logger.error('Error counting failed attempts', error);
      return 0;
    }
    
    return data || 0;
  } catch (error) {
    logger.error('Failed to count failed attempts', error instanceof Error ? error : new Error(String(error)));
    return 0;
  }
}

/**
 * Record a login attempt
 */
export async function recordAuthAttempt(
  ipAddress: string,
  userEmail: string,
  success: boolean,
  failureReason?: string,
  blockedUntil?: string
): Promise<void> {
  try {
    const { error } = await supabase.from("auth_attempts").insert({
      ip_address: ipAddress,
      user_email: userEmail,
      attempt_type: 'login',
      success,
      failure_reason: failureReason,
      user_agent: navigator.userAgent,
      blocked_until: blockedUntil,
    });
    
    if (error) {
      logger.error('Error recording auth attempt', error);
    }
  } catch (error) {
    logger.error('Failed to record auth attempt', error instanceof Error ? error : new Error(String(error)));
  }
}

/**
 * Create a user session record
 */
export async function createUserSession(sessionInfo: SessionInfo): Promise<void> {
  try {
    const { error } = await supabase.from("user_sessions").insert({
      user_id: sessionInfo.userId,
      session_token: sessionInfo.sessionToken,
      ip_address: sessionInfo.ipAddress,
      user_agent: sessionInfo.userAgent,
      expires_at: sessionInfo.expiresAt,
    });
    
    if (error) {
      logger.error('Error creating user session', error);
    }
  } catch (error) {
    logger.error('Failed to create user session', error instanceof Error ? error : new Error(String(error)));
  }
}

/**
 * Deactivate a user's active sessions
 */
export async function deactivateUserSessions(userId: string): Promise<void> {
  try {
    const { error } = await supabase
      .from("user_sessions")
      .update({ is_active: false })
      .eq("user_id", userId)
      .eq("is_active", true);
    
    if (error) {
      logger.error('Error deactivating user sessions', error);
    }
  } catch (error) {
    logger.error('Failed to deactivate user sessions', error instanceof Error ? error : new Error(String(error)));
  }
}

/**
 * Log an audit event
 */
export async function logAuditEvent(
  userId: string,
  actionType: string,
  ipAddress?: string,
  userAgent?: string,
  details?: Record<string, unknown>
): Promise<void> {
  try {
    const { error } = await supabase.from("audit_logs").insert([{
      user_id: userId,
      action_type: actionType,
      ip_address: ipAddress || null,
      user_agent: userAgent || null,
      details: (details as Record<string, string | number | boolean | null>) || null,
    }]);
    
    if (error) {
      logger.error('Error logging audit event', error);
    }
  } catch (error) {
    logger.error('Failed to log audit event', error instanceof Error ? error : new Error(String(error)));
  }
}

/**
 * Get email by username
 */
export async function getEmailByUsername(username: string): Promise<string | null> {
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("email")
      .eq("username", username)
      .maybeSingle();
    
    if (error) {
      logger.error('Error fetching email by username', error);
      return null;
    }
    
    return data?.email || null;
  } catch (error) {
    logger.error('Failed to fetch email by username', error instanceof Error ? error : new Error(String(error)));
    return null;
  }
}
