// Routes are now readable. This module is kept as an identity map so existing
// callers (idCipher hrefs, page-visit logger, sidebar) keep working without
// per-file changes. Hashed `/p/...` URLs were removed; legacy ones are
// redirected in App.tsx for backward compatibility with old bookmarks.

export const ROUTE_HASHES: Record<string, string> = {
  "/dashboard": "/dashboard",
  "/live-traffic": "/live-traffic",
  "/settings/live": "/settings/live",
  "/settings/app-integration": "/settings/app-integration",
  "/leads": "/leads",
  "/clients": "/clients",
  "/pipeline": "/pipeline",
  "/reports": "/reports",
  "/salary": "/salary",
  "/targets": "/targets",
  "/user-management": "/user-management",
  "/convert-queue": "/convert-queue",
  "/attendance": "/attendance",
  "/settings": "/settings",
  "/settings/profile": "/settings/profile",
  "/security-monitoring": "/security-monitoring",
  "/team-management": "/team-management",
  "/tenant-management": "/tenant-management",
  "/notifications": "/notifications",
  "/scripts": "/scripts",
  "/favourite-clients": "/favourite-clients",
};

export const DETAIL_HASHES: Record<string, string> = {
  "/leads": "/leads",
  "/clients": "/clients",
  "/live-traffic": "/live-traffic",
};

export const HASH_TO_ROUTE: Record<string, string> = Object.fromEntries(
  Object.entries(ROUTE_HASHES).map(([k, v]) => [v, k])
);

export function toHashedPath(pathname: string): string | null {
  if (ROUTE_HASHES[pathname]) return ROUTE_HASHES[pathname];
  for (const [readable, hashed] of Object.entries(DETAIL_HASHES)) {
    if (pathname.startsWith(readable + "/")) {
      return hashed + pathname.slice(readable.length);
    }
  }
  return null;
}

// Legacy hashed → readable map for redirecting old bookmarks.
export const LEGACY_HASH_TO_READABLE: Record<string, string> = {
  "/p/h7Qx2": "/dashboard",
  "/p/k9Lm4": "/live-traffic",
  "/p/v2Nx8": "/settings/live",
  "/p/b6Tq1": "/settings/app-integration",
  "/p/a3Wc5": "/leads",
  "/p/m8Yz3": "/clients",
  "/p/r4Hb9": "/pipeline",
  "/p/n7Df2": "/reports",
  "/p/s1Kj6": "/salary",
  "/p/w5Pv0": "/targets",
  "/p/u9Rg7": "/user-management",
  "/p/c2Ze4": "/convert-queue",
  "/p/t6Ma8": "/attendance",
  "/p/g0Sn3": "/settings",
  "/p/p4Bx9": "/settings/profile",
  "/p/x8Cv1": "/security-monitoring",
  "/p/y5Lr2": "/team-management",
  "/p/z3Qm7": "/tenant-management",
  "/p/d1Wt4": "/notifications",
  "/p/f7Hn0": "/scripts",
  "/p/q2Jp8": "/favourite-clients",
};
