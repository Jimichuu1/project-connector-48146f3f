import { Lead } from "@/types/leads";
import { Client } from "@/types/clients";
import { ConversionMetrics } from "@/types/reports";
import { toast } from "sonner";
import * as XLSX from "xlsx";
export function escapeCSVValue(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return "";
  const stringValue = String(value);
  // Escape quotes and wrap in quotes if contains comma, quote, or newline
  if (stringValue.includes(",") || stringValue.includes('"') || stringValue.includes("\n")) {
    return `"${stringValue.replace(/"/g, '""')}"`;
  }
  return stringValue;
}

export function downloadCSV(content: string, filename: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}

export function downloadLeadsTemplate() {
  const headers = [
    "Name",
    "Email",
    "Phone",
    "Country",
    "Bank",
    "KYC Note",
  ];

  const exampleRow = [
    "John Doe",
    "john@example.com",
    "+1234567890",
    "United States",
    "Bank of America",
    "Verified identity documents",
  ];

  const csvContent = [headers.join(","), exampleRow.join(",")].join("\n");
  downloadCSV(csvContent, "leads-import-template.csv");
  toast.success("Template downloaded");
}

export function exportLeadsToCSV(
  leads: Lead[] | undefined, 
  kycData?: { leadId: string; banks: string[]; notes: string[] }[],
  assignedUsers?: { id: string; name: string }[],
  groups?: { leadId: string; groupName: string }[]
) {
  if (!leads || leads.length === 0) {
    toast.error("No leads to export");
    return;
  }

  const headers = [
    "Name",
    "Email",
    "Phone",
    "Country",
    "Status",
    "Assigned To",
    "Group",
    "Bank",
    "KYC Note",
    "Created At",
  ];

  const rows = leads.map((lead) => {
    const kyc = kycData?.find(k => k.leadId === lead.id);
    const assignedUser = assignedUsers?.find(u => u.id === lead.assigned_to);
    const group = groups?.find(g => g.leadId === lead.id);
    return [
      escapeCSVValue(lead.name),
      escapeCSVValue(lead.email),
      escapeCSVValue(lead.phone),
      escapeCSVValue(lead.country),
      escapeCSVValue(lead.status),
      escapeCSVValue(assignedUser?.name || ""),
      escapeCSVValue(group?.groupName || ""),
      escapeCSVValue(kyc?.banks?.join("; ") || ""),
      escapeCSVValue(kyc?.notes?.join("; ") || ""),
      escapeCSVValue(lead.created_at ? new Date(lead.created_at).toLocaleDateString() : ""),
    ];
  });

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.join(",")),
  ].join("\n");

  const filename = `leads-export-${new Date().toISOString().split("T")[0]}.csv`;
  downloadCSV(csvContent, filename);
  toast.success(`Exported ${leads.length} leads`);
}

export function exportLeadsCCToCSV(leads: Lead[] | undefined) {
  if (!leads || leads.length === 0) {
    toast.error("No leads to export");
    return;
  }

  const headers = ["Phone", "Name", "Country", "Email"];

  const rows = leads.map((lead) => [
    escapeCSVValue(lead.phone),
    escapeCSVValue(lead.name),
    escapeCSVValue(lead.country),
    escapeCSVValue(lead.email),
  ]);

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.join(",")),
  ].join("\n");

  const filename = `leads-cc-export-${new Date().toISOString().split("T")[0]}.csv`;
  downloadCSV(csvContent, filename);
  toast.success(`Exported ${leads.length} leads (CC format)`);
}

export function exportClientsToCSV(
  clients: Client[] | undefined, 
  kycData?: { clientId: string; banks: string[]; notes: string[] }[],
  assignedUsers?: { id: string; name: string }[],
  groups?: { clientId: string; groupName: string }[]
) {
  if (!clients || clients.length === 0) {
    toast.error("No clients to export");
    return;
  }

  const headers = [
    "Name",
    "Email",
    "Phone",
    "Country",
    "Status",
    "Assigned To",
    "Balance",
    "Initial Amount",
    "Deposits",
    "Pipeline Status",
    "Group",
    "Bank",
    "KYC Note",
    "Join Date",
    "Created At",
  ];

  const rows = clients.map((client) => {
    const kyc = kycData?.find(k => k.clientId === client.id);
    const assignedUser = assignedUsers?.find(u => u.id === client.assigned_to);
    const group = groups?.find(g => g.clientId === client.id);
    return [
      escapeCSVValue(client.name),
      escapeCSVValue(client.email),
      escapeCSVValue(client.home_phone),
      escapeCSVValue(client.country),
      escapeCSVValue(client.status),
      escapeCSVValue(assignedUser?.name || ""),
      escapeCSVValue(client.balance),
      escapeCSVValue(client.equity),
      escapeCSVValue(client.deposits),
      escapeCSVValue(client.pipeline_status),
      escapeCSVValue(group?.groupName || ""),
      escapeCSVValue(kyc?.banks?.join("; ") || ""),
      escapeCSVValue(kyc?.notes?.join("; ") || ""),
      escapeCSVValue(client.join_date ? new Date(client.join_date).toLocaleDateString() : ""),
      escapeCSVValue(client.created_at ? new Date(client.created_at).toLocaleDateString() : ""),
    ];
  });

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.join(",")),
  ].join("\n");

  const filename = `clients-export-${new Date().toISOString().split("T")[0]}.csv`;
  downloadCSV(csvContent, filename);
  toast.success(`Exported ${clients.length} clients`);
}

export function downloadClientsTemplate() {
  const headers = [
    "Name",
    "Email",
    "Phone",
    "Country",
    "Bank",
    "KYC Note",
  ];

  const exampleRow = [
    "Jane Smith",
    "jane@example.com",
    "+1987654321",
    "United Kingdom",
    "HSBC",
    "KYC completed",
  ];

  const csvContent = [headers.join(","), exampleRow.join(",")].join("\n");
  downloadCSV(csvContent, "clients-import-template.csv");
  toast.success("Template downloaded");
}

// Status name mapping for conversion report
const statusNames: Record<string, string> = {
  new: "New",
  active: "Active",
  contacted: "Contacted",
  qualified: "Qualified",
  unqualified: "Unqualified",
  converted: "Converted",
  lost: "Lost",
};

// Converted clients export types
interface ConvertedClientExport {
  id: string;
  name: string;
  email: string;
  home_phone?: string | null;
  balance: number | null;
  equity: number | null;
  join_date: string;
  country?: string | null;
  super_agent_profile?: { full_name: string | null };
  transferring_agent_profile?: { full_name: string | null };
}

export function exportConvertedClientsToCSV(
  clients: ConvertedClientExport[],
  deposits: Record<string, number>
) {
  if (!clients || clients.length === 0) {
    toast.error("No clients to export");
    return;
  }

  const headers = [
    "Name", "Email", "Phone", "Balance", "Initial Amount",
    "Deposit", "Super Agent", "Transferring Agent", "Converted Date",
  ];

  const rows = clients.map((c) => [
    escapeCSVValue(c.name),
    escapeCSVValue(c.email),
    escapeCSVValue(c.home_phone),
    escapeCSVValue(c.balance),
    escapeCSVValue(c.equity),
    escapeCSVValue(deposits[c.id] || 0),
    escapeCSVValue(c.super_agent_profile?.full_name || ""),
    escapeCSVValue(c.transferring_agent_profile?.full_name || ""),
    escapeCSVValue(c.join_date ? new Date(c.join_date).toLocaleDateString() : ""),
  ]);

  const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
  downloadCSV(csvContent, `converted-clients-export-${new Date().toISOString().split("T")[0]}.csv`);
  toast.success(`Exported ${clients.length} converted clients`);
}

export function exportConvertedClientsCCToCSV(clients: ConvertedClientExport[]) {
  if (!clients || clients.length === 0) {
    toast.error("No clients to export");
    return;
  }

  const headers = ["Phone", "Name", "Country", "Email"];
  const rows = clients.map((c) => [
    escapeCSVValue(c.home_phone),
    escapeCSVValue(c.name),
    escapeCSVValue(c.country || ""),
    escapeCSVValue(c.email),
  ]);

  const csvContent = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
  downloadCSV(csvContent, `converted-clients-cc-export-${new Date().toISOString().split("T")[0]}.csv`);
  toast.success(`Exported ${clients.length} converted clients (CC format)`);
}

export function exportConversionReportToCSV(data: ConversionMetrics) {
  if (!data) {
    toast.error("No conversion data to export");
    return;
  }

  const lines: string[] = [];
  
  // Header
  lines.push("Conversion Report");
  lines.push(`Generated:,${new Date().toLocaleDateString()}`);
  lines.push("");
  
  // Summary section
  lines.push("Summary");
  lines.push(`Total Leads,${data.total_leads}`);
  lines.push(`Total Converted,${data.total_converted}`);
  lines.push(`Conversion Rate,${data.overall_conversion_rate.toFixed(2)}%`);
  if (data.avg_time_to_conversion_days) {
    lines.push(`Avg Days to Convert,${data.avg_time_to_conversion_days.toFixed(1)}`);
  }
  lines.push("");
  
  // Conversion by Status
  if (data.conversion_by_status && data.conversion_by_status.length > 0) {
    lines.push("Conversion by Status");
    lines.push("Status,Leads,Converted,Conversion Rate");
    data.conversion_by_status.forEach((item) => {
      const statusName = statusNames[item.status || ""] || item.status || "Unknown";
      const leads = item.leads || item.count || 0;
      const converted = item.converted || 0;
      const rate = item.conversion_rate || 0;
      lines.push(`${escapeCSVValue(statusName)},${leads},${converted},${rate.toFixed(2)}%`);
    });
    lines.push("");
  }
  
  // Conversion by Agent
  if (data.conversion_by_agent && data.conversion_by_agent.length > 0) {
    lines.push("Conversion by Agent");
    lines.push("Agent Name,Email,Leads Assigned,Converted,Conversion Rate");
    data.conversion_by_agent.forEach((agent) => {
      lines.push(
        `${escapeCSVValue(agent.agent_name)},${escapeCSVValue(agent.agent_email)},${agent.leads_assigned},${agent.converted},${agent.conversion_rate.toFixed(2)}%`
      );
    });
  }

  const csvContent = lines.join("\n");
  const filename = `conversion-report-${new Date().toISOString().split("T")[0]}.csv`;
  downloadCSV(csvContent, filename);
  toast.success("Conversion report exported as CSV");
}

export function exportConversionReportToExcel(data: ConversionMetrics) {
  if (!data) {
    toast.error("No conversion data to export");
    return;
  }

  const workbook = XLSX.utils.book_new();

  // Summary Sheet
  const summaryData = [
    ["Conversion Report Summary"],
    ["Generated", new Date().toLocaleDateString()],
    [],
    ["Metric", "Value"],
    ["Total Leads", data.total_leads],
    ["Total Converted", data.total_converted],
    ["Conversion Rate", `${data.overall_conversion_rate.toFixed(2)}%`],
  ];
  if (data.avg_time_to_conversion_days) {
    summaryData.push(["Avg Days to Convert", data.avg_time_to_conversion_days.toFixed(1)]);
  }
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  summarySheet["!cols"] = [{ wch: 20 }, { wch: 20 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");

  // By Status Sheet
  if (data.conversion_by_status && data.conversion_by_status.length > 0) {
    const statusData = [
      ["Conversion by Status"],
      [],
      ["Status", "Leads", "Converted", "Conversion Rate"],
      ...data.conversion_by_status.map((item) => {
        const statusName = statusNames[item.status || ""] || item.status || "Unknown";
        const leads = item.leads || item.count || 0;
        const converted = item.converted || 0;
        const rate = item.conversion_rate || 0;
        return [statusName, leads, converted, `${rate.toFixed(2)}%`];
      }),
    ];
    const statusSheet = XLSX.utils.aoa_to_sheet(statusData);
    statusSheet["!cols"] = [{ wch: 15 }, { wch: 10 }, { wch: 12 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(workbook, statusSheet, "By Status");
  }

  // By Agent Sheet
  if (data.conversion_by_agent && data.conversion_by_agent.length > 0) {
    const agentData = [
      ["Conversion by Agent"],
      [],
      ["Agent Name", "Email", "Leads Assigned", "Converted", "Conversion Rate"],
      ...data.conversion_by_agent.map((agent) => [
        agent.agent_name,
        agent.agent_email,
        agent.leads_assigned,
        agent.converted,
        `${agent.conversion_rate.toFixed(2)}%`,
      ]),
    ];
    const agentSheet = XLSX.utils.aoa_to_sheet(agentData);
    agentSheet["!cols"] = [{ wch: 20 }, { wch: 25 }, { wch: 15 }, { wch: 12 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(workbook, agentSheet, "By Agent");
  }

  // Generate and download
  const filename = `conversion-report-${new Date().toISOString().split("T")[0]}.xlsx`;
  XLSX.writeFile(workbook, filename);
  toast.success("Conversion report exported as Excel");
}
