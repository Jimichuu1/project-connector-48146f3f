import { QueryClient } from "@tanstack/react-query";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes - data considered fresh
      gcTime: 30 * 60 * 1000, // 30 minutes - cache retention time
      retry: 1,
      refetchOnWindowFocus: false, // Prevent refetch on tab focus
      refetchOnMount: false, // Use cached data when component remounts
      refetchOnReconnect: false, // Prevent refetch on network reconnect
    },
  },
});
