// Comprehensive phone country code to country name mapping
// Codes are sorted by length (longest first) for proper matching
const phoneCodeToCountry: Record<string, string> = {
  // 4-digit codes
  '1242': 'Bahamas',
  '1246': 'Barbados',
  '1264': 'Anguilla',
  '1268': 'Antigua and Barbuda',
  '1284': 'British Virgin Islands',
  '1340': 'US Virgin Islands',
  '1345': 'Cayman Islands',
  '1441': 'Bermuda',
  '1473': 'Grenada',
  '1649': 'Turks and Caicos',
  '1664': 'Montserrat',
  '1670': 'Northern Mariana Islands',
  '1671': 'Guam',
  '1684': 'American Samoa',
  '1721': 'Sint Maarten',
  '1758': 'Saint Lucia',
  '1767': 'Dominica',
  '1784': 'Saint Vincent and the Grenadines',
  '1787': 'Puerto Rico',
  '1809': 'Dominican Republic',
  '1829': 'Dominican Republic',
  '1849': 'Dominican Republic',
  '1868': 'Trinidad and Tobago',
  '1869': 'Saint Kitts and Nevis',
  '1876': 'Jamaica',
  '1939': 'Puerto Rico',
  
  // 3-digit codes
  '212': 'Morocco',
  '213': 'Algeria',
  '216': 'Tunisia',
  '218': 'Libya',
  '220': 'Gambia',
  '221': 'Senegal',
  '222': 'Mauritania',
  '223': 'Mali',
  '224': 'Guinea',
  '225': 'Ivory Coast',
  '226': 'Burkina Faso',
  '227': 'Niger',
  '228': 'Togo',
  '229': 'Benin',
  '230': 'Mauritius',
  '231': 'Liberia',
  '232': 'Sierra Leone',
  '233': 'Ghana',
  '234': 'Nigeria',
  '235': 'Chad',
  '236': 'Central African Republic',
  '237': 'Cameroon',
  '238': 'Cape Verde',
  '239': 'Sao Tome and Principe',
  '240': 'Equatorial Guinea',
  '241': 'Gabon',
  '242': 'Republic of the Congo',
  '243': 'Democratic Republic of the Congo',
  '244': 'Angola',
  '245': 'Guinea-Bissau',
  '246': 'British Indian Ocean Territory',
  '247': 'Ascension Island',
  '248': 'Seychelles',
  '249': 'Sudan',
  '250': 'Rwanda',
  '251': 'Ethiopia',
  '252': 'Somalia',
  '253': 'Djibouti',
  '254': 'Kenya',
  '255': 'Tanzania',
  '256': 'Uganda',
  '257': 'Burundi',
  '258': 'Mozambique',
  '260': 'Zambia',
  '261': 'Madagascar',
  '262': 'Reunion',
  '263': 'Zimbabwe',
  '264': 'Namibia',
  '265': 'Malawi',
  '266': 'Lesotho',
  '267': 'Botswana',
  '268': 'Eswatini',
  '269': 'Comoros',
  '290': 'Saint Helena',
  '291': 'Eritrea',
  '297': 'Aruba',
  '298': 'Faroe Islands',
  '299': 'Greenland',
  '350': 'Gibraltar',
  '351': 'Portugal',
  '352': 'Luxembourg',
  '353': 'Ireland',
  '354': 'Iceland',
  '355': 'Albania',
  '356': 'Malta',
  '357': 'Cyprus',
  '358': 'Finland',
  '359': 'Bulgaria',
  '370': 'Lithuania',
  '371': 'Latvia',
  '372': 'Estonia',
  '373': 'Moldova',
  '374': 'Armenia',
  '375': 'Belarus',
  '376': 'Andorra',
  '377': 'Monaco',
  '378': 'San Marino',
  '380': 'Ukraine',
  '381': 'Serbia',
  '382': 'Montenegro',
  '383': 'Kosovo',
  '385': 'Croatia',
  '386': 'Slovenia',
  '387': 'Bosnia and Herzegovina',
  '389': 'North Macedonia',
  '420': 'Czech Republic',
  '421': 'Slovakia',
  '423': 'Liechtenstein',
  '500': 'Falkland Islands',
  '501': 'Belize',
  '502': 'Guatemala',
  '503': 'El Salvador',
  '504': 'Honduras',
  '505': 'Nicaragua',
  '506': 'Costa Rica',
  '507': 'Panama',
  '508': 'Saint Pierre and Miquelon',
  '509': 'Haiti',
  '590': 'Guadeloupe',
  '591': 'Bolivia',
  '592': 'Guyana',
  '593': 'Ecuador',
  '594': 'French Guiana',
  '595': 'Paraguay',
  '596': 'Martinique',
  '597': 'Suriname',
  '598': 'Uruguay',
  '599': 'Curacao',
  '670': 'East Timor',
  '672': 'Norfolk Island',
  '673': 'Brunei',
  '674': 'Nauru',
  '675': 'Papua New Guinea',
  '676': 'Tonga',
  '677': 'Solomon Islands',
  '678': 'Vanuatu',
  '679': 'Fiji',
  '680': 'Palau',
  '681': 'Wallis and Futuna',
  '682': 'Cook Islands',
  '683': 'Niue',
  '685': 'Samoa',
  '686': 'Kiribati',
  '687': 'New Caledonia',
  '688': 'Tuvalu',
  '689': 'French Polynesia',
  '690': 'Tokelau',
  '691': 'Micronesia',
  '692': 'Marshall Islands',
  '850': 'North Korea',
  '852': 'Hong Kong',
  '853': 'Macau',
  '855': 'Cambodia',
  '856': 'Laos',
  '880': 'Bangladesh',
  '886': 'Taiwan',
  '960': 'Maldives',
  '961': 'Lebanon',
  '962': 'Jordan',
  '963': 'Syria',
  '964': 'Iraq',
  '965': 'Kuwait',
  '966': 'Saudi Arabia',
  '967': 'Yemen',
  '968': 'Oman',
  '970': 'Palestine',
  '971': 'United Arab Emirates',
  '972': 'Israel',
  '973': 'Bahrain',
  '974': 'Qatar',
  '975': 'Bhutan',
  '976': 'Mongolia',
  '977': 'Nepal',
  '992': 'Tajikistan',
  '993': 'Turkmenistan',
  '994': 'Azerbaijan',
  '995': 'Georgia',
  '996': 'Kyrgyzstan',
  '998': 'Uzbekistan',
  
  // 2-digit codes
  '20': 'Egypt',
  '27': 'South Africa',
  '30': 'Greece',
  '31': 'Netherlands',
  '32': 'Belgium',
  '33': 'France',
  '34': 'Spain',
  '36': 'Hungary',
  '39': 'Italy',
  '40': 'Romania',
  '41': 'Switzerland',
  '43': 'Austria',
  '44': 'United Kingdom',
  '45': 'Denmark',
  '46': 'Sweden',
  '47': 'Norway',
  '48': 'Poland',
  '49': 'Germany',
  '51': 'Peru',
  '52': 'Mexico',
  '53': 'Cuba',
  '54': 'Argentina',
  '55': 'Brazil',
  '56': 'Chile',
  '57': 'Colombia',
  '58': 'Venezuela',
  '60': 'Malaysia',
  '61': 'Australia',
  '62': 'Indonesia',
  '63': 'Philippines',
  '64': 'New Zealand',
  '65': 'Singapore',
  '66': 'Thailand',
  '81': 'Japan',
  '82': 'South Korea',
  '84': 'Vietnam',
  '86': 'China',
  '90': 'Turkey',
  '91': 'India',
  '92': 'Pakistan',
  '93': 'Afghanistan',
  '94': 'Sri Lanka',
  '95': 'Myanmar',
  '98': 'Iran',
  
  // 1-digit codes (special handling for NANP)
  '1': 'Canada',
  '7': 'Russia', // Also covers Kazakhstan
};

/**
 * Extracts country name from a phone number based on international calling codes
 * @param phone - Phone number (with or without + prefix)
 * @returns Country name or null if no match found
 */
export function getCountryFromPhone(phone: string | null | undefined): string | null {
  if (!phone) return null;
  
  // Strip all non-digits except leading +
  let digits = phone.replace(/[^\d+]/g, '');
  
  // Remove leading + if present
  if (digits.startsWith('+')) {
    digits = digits.substring(1);
  }
  
  // Need at least 1 digit to match
  if (digits.length === 0) return null;
  
  // All +1 numbers are Canadian (business requirement)
  if (digits.startsWith('1')) {
    return 'Canada';
  }
  
  // Try longest match first (4-digit codes like 1242, 1246)
  // Then 3-digit, 2-digit, and finally 1-digit
  for (const length of [4, 3, 2, 1]) {
    if (digits.length >= length) {
      const prefix = digits.substring(0, length);
      if (phoneCodeToCountry[prefix]) {
        return phoneCodeToCountry[prefix];
      }
    }
  }
  
  return null;
}

/**
 * Checks if a country should be auto-filled based on current value
 * @param currentCountry - Current country value
 * @param phone - Phone number to detect country from
 * @returns The country to use (detected or current)
 */
export function getAutoCountry(_currentCountry: string, phone: string): string {
  // Always derive country from the phone number — fully automated, no manual override.
  return getCountryFromPhone(phone) || '';
}

// Country name to short code mapping (ISO 3166-1 alpha-3 or common abbreviations)
const countryToCode: Record<string, string> = {
  'United States': 'USA',
  'United Kingdom': 'UK',
  'United Arab Emirates': 'UAE',
  'Germany': 'DE',
  'France': 'FR',
  'Spain': 'ES',
  'Italy': 'IT',
  'Netherlands': 'NL',
  'Belgium': 'BE',
  'Switzerland': 'CH',
  'Austria': 'AT',
  'Sweden': 'SE',
  'Norway': 'NO',
  'Denmark': 'DK',
  'Finland': 'FI',
  'Poland': 'PL',
  'Portugal': 'PT',
  'Ireland': 'IE',
  'Greece': 'GR',
  'Czech Republic': 'CZ',
  'Romania': 'RO',
  'Hungary': 'HU',
  'Bulgaria': 'BG',
  'Croatia': 'HR',
  'Slovakia': 'SK',
  'Slovenia': 'SI',
  'Lithuania': 'LT',
  'Latvia': 'LV',
  'Estonia': 'EE',
  'Luxembourg': 'LU',
  'Malta': 'MT',
  'Cyprus': 'CY',
  'Iceland': 'IS',
  'Russia': 'RU',
  'Ukraine': 'UA',
  'Turkey': 'TR',
  'Canada': 'CA',
  'Mexico': 'MX',
  'Brazil': 'BR',
  'Argentina': 'AR',
  'Chile': 'CL',
  'Colombia': 'CO',
  'Peru': 'PE',
  'Venezuela': 'VE',
  'Australia': 'AU',
  'New Zealand': 'NZ',
  'Japan': 'JP',
  'China': 'CN',
  'South Korea': 'KR',
  'India': 'IN',
  'Indonesia': 'ID',
  'Thailand': 'TH',
  'Vietnam': 'VN',
  'Philippines': 'PH',
  'Malaysia': 'MY',
  'Singapore': 'SG',
  'Hong Kong': 'HK',
  'Taiwan': 'TW',
  'Pakistan': 'PK',
  'Bangladesh': 'BD',
  'Saudi Arabia': 'SA',
  'Israel': 'IL',
  'Egypt': 'EG',
  'South Africa': 'ZA',
  'Nigeria': 'NG',
  'Kenya': 'KE',
  'Morocco': 'MA',
  'Algeria': 'DZ',
  'Tunisia': 'TN',
  'Ghana': 'GH',
  'Serbia': 'RS',
  'Bosnia and Herzegovina': 'BA',
  'North Macedonia': 'MK',
  'Albania': 'AL',
  'Montenegro': 'ME',
  'Kosovo': 'XK',
  'Moldova': 'MD',
  'Belarus': 'BY',
  'Georgia': 'GE',
  'Armenia': 'AM',
  'Azerbaijan': 'AZ',
  'Kazakhstan': 'KZ',
  'Uzbekistan': 'UZ',
  'Dominican Republic': 'DO',
  'Puerto Rico': 'PR',
  'Jamaica': 'JM',
  'Trinidad and Tobago': 'TT',
  'Cuba': 'CU',
  'Haiti': 'HT',
  'Costa Rica': 'CR',
  'Panama': 'PA',
  'Guatemala': 'GT',
  'Ecuador': 'EC',
  'Bolivia': 'BO',
  'Paraguay': 'PY',
  'Uruguay': 'UY',
  'Iran': 'IR',
  'Iraq': 'IQ',
  'Jordan': 'JO',
  'Lebanon': 'LB',
  'Kuwait': 'KW',
  'Qatar': 'QA',
  'Bahrain': 'BH',
  'Oman': 'OM',
  'Sri Lanka': 'LK',
  'Nepal': 'NP',
  'Cambodia': 'KH',
  'Myanmar': 'MM',
  'Afghanistan': 'AF',
};

// Reverse mapping: country name → canonical phone prefix (shortest code wins)
const countryToPhonePrefixMap: Record<string, string> = (() => {
  const map: Record<string, string> = {};
  // Process codes from shortest to longest so shorter (canonical) codes overwrite longer ones
  const entries = Object.entries(phoneCodeToCountry);
  entries.sort((a, b) => a[0].length - b[0].length);
  for (const [code, country] of entries) {
    const key = country.toLowerCase();
    if (!map[key]) {
      map[key] = code;
    }
  }
  return map;
})();

/**
 * Gets the international dialing prefix for a country name
 * @param country - Country name (e.g., "United Arab Emirates")
 * @returns Dialing code (e.g., "971") or null if not found
 */
export function getPhonePrefixFromCountry(country: string | null | undefined): string | null {
  if (!country) return null;
  const key = country.trim().toLowerCase();
  if (!key) return null;

  // Direct match
  if (countryToPhonePrefixMap[key]) return countryToPhonePrefixMap[key];

  // Try partial matching (e.g., "UAE" → "United Arab Emirates")
  // Check common abbreviations
  const abbreviations: Record<string, string> = {
    'usa': 'united states', 'us': 'united states',
    'uk': 'united kingdom', 'gb': 'united kingdom',
    'uae': 'united arab emirates',
    'ksa': 'saudi arabia',
    'rsa': 'south africa',
  };
  const expanded = abbreviations[key];
  if (expanded && countryToPhonePrefixMap[expanded]) return countryToPhonePrefixMap[expanded];

  // Substring match as last resort
  for (const [mapKey, code] of Object.entries(countryToPhonePrefixMap)) {
    if (mapKey.includes(key) || key.includes(mapKey)) return code;
  }

  return null;
}

// Reverse mapping: country name → ALL phone prefixes (one country may have many, e.g. Canada/NANP).
const countryToAllPrefixes: Record<string, string[]> = (() => {
  const map: Record<string, string[]> = {};
  for (const [code, country] of Object.entries(phoneCodeToCountry)) {
    const key = country.toLowerCase();
    if (!map[key]) map[key] = [];
    map[key].push(code);
  }
  // Sort each list shortest → longest so .like('1%') (broadest) is tried first
  for (const k of Object.keys(map)) {
    map[k].sort((a, b) => a.length - b.length);
  }
  return map;
})();

/**
 * Returns all international dialing prefixes for a canonical country name.
 * For Canada this returns ['1'] (the broadest) — every NANP prefix starts with 1
 * so a single LIKE '1%' covers them all.
 */
export function getAllPhonePrefixesForCountry(country: string | null | undefined): string[] {
  if (!country) return [];
  const key = country.trim().toLowerCase();
  if (!key) return [];

  const direct = countryToAllPrefixes[key];
  if (direct && direct.length) {
    // Deduplicate by broadest prefix: if '1' is in the list, drop '1242', '1246', etc.
    const sorted = [...direct];
    const result: string[] = [];
    for (const p of sorted) {
      if (!result.some((r) => p.startsWith(r))) result.push(p);
    }
    return result;
  }

  // Common abbreviations
  const abbreviations: Record<string, string> = {
    'usa': 'united states', 'us': 'united states',
    'uk': 'united kingdom', 'gb': 'united kingdom',
    'uae': 'united arab emirates',
    'ksa': 'saudi arabia',
    'rsa': 'south africa',
  };
  const expanded = abbreviations[key];
  if (expanded && countryToAllPrefixes[expanded]) {
    return getAllPhonePrefixesForCountry(expanded);
  }
  return [];
}

/**
 * Converts a full country name to its short code/abbreviation
 * @param country - Full country name
 * @returns Short code (e.g., "USA") or original name if no mapping exists
 */
export function getCountryCode(country: string | null | undefined): string {
  if (!country) return '';
  
  const trimmed = country.trim();
  
  // Check if it's already a short code (2-3 chars)
  if (trimmed.length <= 3) {
    return trimmed.toUpperCase();
  }
  
  return countryToCode[trimmed] || trimmed;
}
