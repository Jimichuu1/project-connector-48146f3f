import { supabase } from "@/integrations/supabase/client";
import { exportLeadsToCSV, exportClientsToCSV, exportLeadsCCToCSV } from "@/lib/exportCsv";
import { Lead } from "@/types/leads";
import { Client } from "@/types/clients";
import { toast } from "sonner";

function chunkArray<T>(items: T[], chunkSize: number): T[][] {
  if (chunkSize <= 0) return [items];
  const chunks: T[][] = [];
  for (let i = 0; i < items.length; i += chunkSize) {
    chunks.push(items.slice(i, i + chunkSize));
  }
  return chunks;
}

/**
 * Fetches ALL rows by paginating with range(from,to).
 * IMPORTANT: Do not rely on `data.length === batchSize` because the backend may cap max rows per request.
 */
async function fetchAllWithRange<T>(
  fetchPage: (from: number, to: number) => Promise<{ data: T[] | null; error: any }>,
  opts: { batchSize?: number; maxIterations?: number } = {}
): Promise<T[]> {
  const batchSize = opts.batchSize ?? 1000;
  const maxIterations = opts.maxIterations ?? 5000;

  const all: T[] = [];
  let from = 0;
  let iterations = 0;

  while (iterations < maxIterations) {
    iterations += 1;
    const to = from + batchSize - 1;
    const { data, error } = await fetchPage(from, to);
    if (error) throw error;

    const chunk = (data ?? []) as T[];
    if (chunk.length === 0) break;

    all.push(...chunk);
    from += chunk.length; // advance by actual returned rows (handles server-side caps)
  }

  return all;
}

interface KycExportData {
  leadId?: string;
  clientId?: string;
  banks: string[];
  notes: string[];
}

interface AssignedUser {
  id: string;
  name: string;
}

interface GroupInfo {
  leadId?: string;
  clientId?: string;
  groupName: string;
}

interface LeadFilters {
  search?: string;
  statuses?: string[];
  assignedToList?: string[];
  unassigned?: boolean;
  countries?: string[];
  groupIds?: string[];
  dateFrom?: Date;
  dateTo?: Date;
  teamMemberIds?: string[];
  adminId?: string;
}

interface ClientFilters {
  search?: string;
  statuses?: string[];
  assignedToList?: string[];
  countries?: string[];
  groupIds?: string[];
  teamMemberIds?: string[];
  hasDeposited?: boolean;
  adminId?: string;
}

/**
 * Export ALL leads with KYC data (fetches all from database, not just paginated)
 */
export async function exportAllLeadsWithKycData(filters: LeadFilters = {}) {
  toast.loading("Fetching all leads for export...", { id: "export-leads" });
  
  try {
    // Select only columns we actually export / need for lookups
    const LEAD_EXPORT_COLUMNS =
      "id, name, email, phone, country, status, assigned_to, created_at, created_by, admin_id";

    // Helper to apply filters (supports base table or embedded `leads` table)
    const applyFilters = (query: any, relationPrefix?: "leads") => {
      const col = (name: string) => (relationPrefix ? `${relationPrefix}.${name}` : name);
      const applyOr = (filter: string) =>
        relationPrefix ? query.or(filter, { foreignTable: relationPrefix }) : query.or(filter);

      if (filters.adminId) {
        query = applyOr(`admin_id.eq.${filters.adminId},created_by.eq.${filters.adminId}`);
      }

      if (filters.search) {
        const s = filters.search;
        query = applyOr(`name.ilike.%${s}%,email.ilike.%${s}%,phone.ilike.%${s}%,country.ilike.%${s}%`);
      }

      if (filters.statuses && filters.statuses.length > 0) {
        query = query.in(col("status"), filters.statuses);
      }

      if (filters.assignedToList && filters.assignedToList.length > 0) {
        query = query.in(col("assigned_to"), filters.assignedToList);
      }

      if (filters.unassigned) {
        query = query.is(col("assigned_to"), null);
      }

      if (filters.countries && filters.countries.length > 0) {
        query = query.in(col("country"), filters.countries);
      }

      if (filters.dateFrom) {
        query = query.gte(col("created_at"), filters.dateFrom.toISOString());
      }

      if (filters.dateTo) {
        query = query.lte(col("created_at"), filters.dateTo.toISOString());
      }

      if (filters.teamMemberIds && filters.teamMemberIds.length > 0) {
        // Match the UI behavior (team members + unassigned)
        query = applyOr(`assigned_to.in.(${filters.teamMemberIds.join(",")}),assigned_to.is.null`);
      }

      return query;
    };

    // Fetch ALL leads matching filters (including groupIds) using safe pagination
    const allLeads = await fetchAllWithRange<any>(async (from, to) => {
      // When groupIds are active, query through join to avoid fetching everything then filtering
      if (filters.groupIds && filters.groupIds.length > 0) {
        let q = supabase
          .from("lead_group_members")
          .select(`lead_id, leads!inner(${LEAD_EXPORT_COLUMNS})`)
          .in("group_id", filters.groupIds)
          .order("created_at", { ascending: false, foreignTable: "leads" })
          .range(from, to);

        q = applyFilters(q, "leads");

        const { data, error } = await q;
        if (error) return { data: null, error };

        const joined = (data as any[] | null | undefined)
          ?.map((row) => row?.leads)
          .filter(Boolean);

        return { data: (joined ?? []) as Lead[], error: null };
      }

      let q = supabase
        .from("leads")
        .select(LEAD_EXPORT_COLUMNS)
        .order("created_at", { ascending: false })
        .range(from, to);

      q = applyFilters(q);
      const { data, error } = await q;
      return { data: (data ?? []) as Lead[], error };
    });

    // De-duplicate (can happen with multi-group selection)
    const leadsById = new Map<string, Lead>();
    for (const l of allLeads as Lead[]) {
      if (l?.id && !leadsById.has(l.id)) leadsById.set(l.id, l);
    }
    const leads = Array.from(leadsById.values());

    if (!leads || leads.length === 0) {
      toast.error("No leads to export", { id: "export-leads" });
      return;
    }

    toast.loading(`Exporting ${leads.length} leads...`, { id: "export-leads" });

    // Fetch related data
    const leadIds = leads.map((l) => l.id);
    const assignedToIds = Array.from(
      new Set(leads.map((l) => l.assigned_to).filter(Boolean) as string[])
    );

    const leadIdChunks = chunkArray(leadIds, 500);
    const assignedToChunks = chunkArray(assignedToIds, 500);

    const [kycRows, profileRows, groupRows] = await Promise.all([
      Promise.all(
        leadIdChunks.map(async (chunk) => {
          const { data, error } = await supabase
            .from("kyc_records")
            .select("lead_id, bank_name, notes")
            .in("lead_id", chunk);
          if (error) throw error;
          return data ?? [];
        })
      ).then((parts) => parts.flat()),
      assignedToIds.length > 0
        ? Promise.all(
            assignedToChunks.map(async (chunk) => {
              const { data, error } = await supabase
                .from("profiles")
                .select("id, full_name")
                .in("id", chunk);
              if (error) throw error;
              return data ?? [];
            })
          ).then((parts) => parts.flat())
        : Promise.resolve([] as any[]),
      Promise.all(
        leadIdChunks.map(async (chunk) => {
          const { data, error } = await supabase
            .from("lead_group_members")
            .select("lead_id, group_id, lead_groups(name)")
            .in("lead_id", chunk);
          if (error) throw error;
          return data ?? [];
        })
      ).then((parts) => parts.flat()),
    ]);

    const kycAgg = new Map<string, { banks: string[]; notes: string[] }>();
    for (const row of kycRows as any[]) {
      const id = row?.lead_id as string | undefined;
      if (!id) continue;
      const current = kycAgg.get(id) ?? { banks: [], notes: [] };
      if (row.bank_name) current.banks.push(String(row.bank_name));
      if (row.notes) current.notes.push(String(row.notes));
      kycAgg.set(id, current);
    }

    const kycData: KycExportData[] = leadIds.map((leadId) => ({
      leadId,
      banks: kycAgg.get(leadId)?.banks ?? [],
      notes: kycAgg.get(leadId)?.notes ?? [],
    }));

    const assignedUsers: AssignedUser[] = (profileRows as any[]).map((p) => ({
      id: p.id,
      name: p.full_name || "",
    }));

    // Keep current behavior: a single group name per lead (first match)
    const groupByLead = new Map<string, string>();
    for (const g of groupRows as any[]) {
      const id = g?.lead_id as string | undefined;
      if (!id || groupByLead.has(id)) continue;
      groupByLead.set(id, (g.lead_groups as { name?: string })?.name || "");
    }
    const groups: GroupInfo[] = leadIds.map((leadId) => ({
      leadId,
      groupName: groupByLead.get(leadId) || "",
    }));

    exportLeadsToCSV(leads, kycData as any, assignedUsers, groups as any);
    toast.success(`Exported ${leads.length} leads`, { id: "export-leads" });
  } catch (error) {
    console.error("Export leads error:", error);
    toast.error("Failed to export leads", { id: "export-leads" });
  }
}

/**
 * Export ALL leads in CC format (Phone, Name, Country, Email)
 */
export async function exportAllLeadsCCFormat(filters: LeadFilters = {}) {
  toast.loading("Fetching leads for CC export...", { id: "export-leads-cc" });

  try {
    const LEAD_CC_COLUMNS = "id, name, email, phone, country, status, assigned_to, created_at, created_by, admin_id";

    const applyFilters = (query: any, relationPrefix?: "leads") => {
      const col = (name: string) => (relationPrefix ? `${relationPrefix}.${name}` : name);
      const applyOr = (filter: string) =>
        relationPrefix ? query.or(filter, { foreignTable: relationPrefix }) : query.or(filter);

      if (filters.adminId) {
        query = applyOr(`admin_id.eq.${filters.adminId},created_by.eq.${filters.adminId}`);
      }
      if (filters.search) {
        const s = filters.search;
        query = applyOr(`name.ilike.%${s}%,email.ilike.%${s}%,phone.ilike.%${s}%,country.ilike.%${s}%`);
      }
      if (filters.statuses && filters.statuses.length > 0) {
        query = query.in(col("status"), filters.statuses);
      }
      if (filters.assignedToList && filters.assignedToList.length > 0) {
        query = query.in(col("assigned_to"), filters.assignedToList);
      }
      if (filters.unassigned) {
        query = query.is(col("assigned_to"), null);
      }
      if (filters.countries && filters.countries.length > 0) {
        query = query.in(col("country"), filters.countries);
      }
      if (filters.dateFrom) {
        query = query.gte(col("created_at"), filters.dateFrom.toISOString());
      }
      if (filters.dateTo) {
        query = query.lte(col("created_at"), filters.dateTo.toISOString());
      }
      if (filters.teamMemberIds && filters.teamMemberIds.length > 0) {
        query = applyOr(`assigned_to.in.(${filters.teamMemberIds.join(",")}),assigned_to.is.null`);
      }
      return query;
    };

    const allLeads = await fetchAllWithRange<any>(async (from, to) => {
      if (filters.groupIds && filters.groupIds.length > 0) {
        let q = supabase
          .from("lead_group_members")
          .select(`lead_id, leads!inner(${LEAD_CC_COLUMNS})`)
          .in("group_id", filters.groupIds)
          .order("created_at", { ascending: false, foreignTable: "leads" })
          .range(from, to);
        q = applyFilters(q, "leads");
        const { data, error } = await q;
        if (error) return { data: null, error };
        const joined = (data as any[] | null | undefined)?.map((row) => row?.leads).filter(Boolean);
        return { data: (joined ?? []) as Lead[], error: null };
      }

      let q = supabase
        .from("leads")
        .select(LEAD_CC_COLUMNS)
        .order("created_at", { ascending: false })
        .range(from, to);
      q = applyFilters(q);
      const { data, error } = await q;
      return { data: (data ?? []) as Lead[], error };
    });

    const leadsById = new Map<string, Lead>();
    for (const l of allLeads as Lead[]) {
      if (l?.id && !leadsById.has(l.id)) leadsById.set(l.id, l);
    }
    const leads = Array.from(leadsById.values());

    exportLeadsCCToCSV(leads);
    toast.dismiss("export-leads-cc");
  } catch (error) {
    console.error("CC Export leads error:", error);
    toast.error("Failed to export leads (CC format)", { id: "export-leads-cc" });
  }
}

/**
 * Export ALL clients with KYC data (fetches all from database, not just paginated)
 */
export async function exportAllClientsWithKycData(filters: ClientFilters = {}) {
  toast.loading("Fetching all clients for export...", { id: "export-clients" });
  
  try {
    // Fetch all clients with pagination (Supabase has 1000 row limit per query)
    let allClients: Client[] = [];
    let hasMore = true;
    let offset = 0;
    const batchSize = 1000;

    while (hasMore) {
      let query = supabase
        .from("clients")
        .select("*")
        .order("created_at", { ascending: false })
        .range(offset, offset + batchSize - 1);

      // CRITICAL: Apply admin_id filter for tenant isolation
      if (filters.adminId) {
        query = query.or(`admin_id.eq.${filters.adminId},created_by.eq.${filters.adminId}`);
      }

      // Apply filters
      if (filters.search) {
        query = query.or(`name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
      }
      if (filters.statuses && filters.statuses.length > 0) {
        query = query.in("status", filters.statuses);
      }
      if (filters.assignedToList && filters.assignedToList.length > 0) {
        query = query.in("assigned_to", filters.assignedToList);
      }
      if (filters.countries && filters.countries.length > 0) {
        query = query.in("country", filters.countries);
      }
      if (filters.teamMemberIds && filters.teamMemberIds.length > 0) {
        query = query.in("assigned_to", filters.teamMemberIds);
      }

      const { data: clients, error } = await query;

      if (error) {
        toast.error("Failed to fetch clients", { id: "export-clients" });
        console.error("Export clients error:", error);
        return;
      }

      allClients = [...allClients, ...(clients as Client[] || [])];
      hasMore = (clients?.length || 0) === batchSize;
      offset += batchSize;
    }

    if (allClients.length === 0) {
      toast.error("No clients to export", { id: "export-clients" });
      return;
    }

    let filteredClients = allClients;

    // Filter by group if needed
    if (filters.groupIds && filters.groupIds.length > 0) {
      const { data: groupMembers } = await supabase
        .from("client_group_members")
        .select("client_id")
        .in("group_id", filters.groupIds);
      
      const clientIdsInGroup = new Set(groupMembers?.map(m => m.client_id) || []);
      filteredClients = filteredClients.filter(c => clientIdsInGroup.has(c.id));
    }

    // Filter by deposited if needed
    if (filters.hasDeposited !== undefined) {
      const { data: depositedData } = await supabase
        .from("deposits")
        .select("client_id")
        .eq("status", "approved");
      
      const depositedClientIds = new Set(depositedData?.map(d => d.client_id) || []);
      
      if (filters.hasDeposited) {
        filteredClients = filteredClients.filter(c => depositedClientIds.has(c.id));
      } else {
        filteredClients = filteredClients.filter(c => !depositedClientIds.has(c.id));
      }
    }

    if (filteredClients.length === 0) {
      toast.error("No clients to export", { id: "export-clients" });
      return;
    }

    toast.loading(`Exporting ${filteredClients.length} clients...`, { id: "export-clients" });

    // Fetch related data
    const clientIds = filteredClients.map(c => c.id);
    const assignedToIds = filteredClients.map(c => c.assigned_to).filter(Boolean) as string[];
    const convertedFromLeadIds = filteredClients.map(c => c.converted_from_lead_id).filter(Boolean) as string[];

    const [kycResult, profilesResult, groupMembersResult] = await Promise.all([
      supabase.from("kyc_records").select("client_id, bank_name, notes").in("client_id", clientIds),
      assignedToIds.length > 0
        ? supabase.from("profiles").select("id, full_name").in("id", assignedToIds)
        : Promise.resolve({ data: [] }),
      convertedFromLeadIds.length > 0
        ? supabase.from("lead_group_members").select("lead_id, group_id, lead_groups(name)").in("lead_id", convertedFromLeadIds)
        : Promise.resolve({ data: [] }),
    ]);

    const kycData = clientIds.map(clientId => {
      const records = kycResult.data?.filter(r => r.client_id === clientId) || [];
      return {
        clientId,
        banks: records.filter(r => r.bank_name).map(r => r.bank_name!),
        notes: records.filter(r => r.notes).map(r => r.notes!),
      };
    });

    const assignedUsers: AssignedUser[] =
      profilesResult.data?.map(p => ({ id: p.id, name: p.full_name || "" })) || [];

    const groups = filteredClients.map(client => {
      const groupMember = groupMembersResult.data?.find(g => g.lead_id === client.converted_from_lead_id);
      return {
        clientId: client.id,
        groupName: (groupMember?.lead_groups as { name?: string })?.name || "",
      };
    });

    exportClientsToCSV(filteredClients, kycData, assignedUsers, groups);
    toast.success(`Exported ${filteredClients.length} clients`, { id: "export-clients" });
  } catch (error) {
    console.error("Export clients error:", error);
    toast.error("Failed to export clients", { id: "export-clients" });
  }
}
