/**
 * UUID validation utilities
 */

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Validates that a string is a valid UUID format
 */
export const isValidUUID = (str: string | null | undefined): str is string => {
  if (!str) return false;
  if (typeof str !== 'string') return false;
  if (str === 'undefined' || str === 'null') return false;
  return UUID_REGEX.test(str);
};
