/**
 * Safe HTML sanitization utility using DOMPurify
 * Prevents XSS attacks by sanitizing all HTML content before rendering
 */
import DOMPurify from 'dompurify';

/**
 * Default allowed tags for general HTML content
 */
const DEFAULT_ALLOWED_TAGS = [
  'a', 'b', 'i', 'u', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li',
  'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'pre', 'code',
  'span', 'div', 'table', 'thead', 'tbody', 'tr', 'th', 'td',
  'img', 'hr', 'sub', 'sup', 'small'
];

/**
 * Default allowed attributes
 */
const DEFAULT_ALLOWED_ATTR = [
  'href', 'target', 'rel', 'src', 'alt', 'title', 'class', 'style',
  'width', 'height', 'colspan', 'rowspan', 'align', 'valign'
];

/**
 * Email-specific additional tags
 */
const EMAIL_ALLOWED_TAGS = [
  ...DEFAULT_ALLOWED_TAGS,
  'style', 'font', 'center', 'header', 'footer', 'section', 'article',
  'aside', 'nav', 'figure', 'figcaption', 'address'
];

/**
 * Email-specific additional attributes
 */
const EMAIL_ALLOWED_ATTR = [
  ...DEFAULT_ALLOWED_ATTR,
  'bgcolor', 'color', 'face', 'size', 'border', 'cellpadding', 'cellspacing'
];

/**
 * Sanitize HTML content to prevent XSS attacks
 * @param dirty - The untrusted HTML string
 * @returns Sanitized HTML string safe for rendering
 */
export function sanitizeHTML(dirty: string | null | undefined): string {
  if (!dirty) return '';
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: DEFAULT_ALLOWED_TAGS,
    ALLOWED_ATTR: DEFAULT_ALLOWED_ATTR,
    ALLOW_DATA_ATTR: false,
    FORBID_TAGS: ['script', 'iframe', 'object', 'embed', 'form', 'input', 'button'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'onfocus', 'onblur'],
  });
}

/**
 * Sanitize email HTML content with email-specific allowed tags
 * @param dirty - The untrusted email HTML string
 * @returns Sanitized HTML string safe for rendering
 */
export function sanitizeEmailHTML(dirty: string | null | undefined): string {
  if (!dirty) return '';
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: EMAIL_ALLOWED_TAGS,
    ALLOWED_ATTR: EMAIL_ALLOWED_ATTR,
    ALLOW_DATA_ATTR: false,
    FORBID_TAGS: ['script', 'iframe', 'object', 'embed'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'onfocus', 'onblur'],
  });
}

/**
 * Create a safe HTML object for use with dangerouslySetInnerHTML
 * @param dirty - The untrusted HTML string
 * @param isEmail - Whether the content is email HTML (uses more permissive config)
 * @returns Object with __html property containing sanitized HTML
 */
export function createSafeHTML(
  dirty: string | null | undefined,
  isEmail: boolean = false
): { __html: string } {
  const sanitized = isEmail ? sanitizeEmailHTML(dirty) : sanitizeHTML(dirty);
  return { __html: sanitized };
}

/**
 * Check if a string contains potentially dangerous HTML
 * @param html - HTML string to check
 * @returns true if the HTML contains dangerous content
 */
export function containsDangerousHTML(html: string | null | undefined): boolean {
  if (!html) return false;
  const sanitized = sanitizeHTML(html);
  return sanitized !== html;
}

export default {
  sanitizeHTML,
  sanitizeEmailHTML,
  createSafeHTML,
  containsDangerousHTML,
};
