/**
 * Utility functions for the CRM application.
 * @module lib/utils
 */

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Combines class names using clsx and tailwind-merge.
 * Handles conditional classes, arrays, and objects.
 * @param inputs - Class values to combine
 * @returns Merged class string with Tailwind conflicts resolved
 * @example
 * cn("px-2 py-1", condition && "bg-blue-500", { "text-white": isActive })
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Formats a number as USD currency.
 * @param value - Number, string, null, or undefined to format
 * @returns Formatted currency string (e.g., "$1,234.56")
 * @example
 * formatCurrency(1234.5) // "$1,234.50"
 * formatCurrency(null) // "$0.00"
 */
export function formatCurrency(value: number | string | null | undefined): string {
  const num = Number(value);
  if (isNaN(num)) return "$0.00";
  return `$${num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/**
 * Formats a phone number by removing non-numeric characters except +.
 * @param phone - Phone number string to format
 * @returns Cleaned phone number with only digits and +
 * @example
 * formatPhone("(555) 123-4567") // "5551234567"
 * formatPhone("+1 555-123-4567") // "+15551234567"
 */
export function formatPhone(phone: string | null | undefined): string {
  if (!phone) return "";
  return phone.replace(/[^\d+]/g, "");
}
