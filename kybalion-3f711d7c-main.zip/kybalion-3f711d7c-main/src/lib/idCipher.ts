/**
 * Reversible, deterministic UUID <-> short opaque token.
 * - Encodes 16 UUID bytes XOR'd with a static keystream into base64url (22 chars, no padding).
 * - Decodes the token back to a canonical UUID v4-style string.
 * - Backward compatible: if a value already looks like a UUID, it's returned unchanged
 *   (so old links/bookmarks keep working).
 *
 * NOTE: This is obfuscation, not authorization. RLS + role guards remain the source of truth.
 */

const KEY = new Uint8Array([
  0x9a, 0x3f, 0x71, 0xc4, 0x08, 0xd2, 0x6e, 0x55,
  0xb1, 0x27, 0xfa, 0x4d, 0x83, 0x1c, 0x6b, 0xe0,
]);

const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const HEX32_RE = /^[0-9a-f]{32}$/i;

function uuidToBytes(uuid: string): Uint8Array | null {
  const hex = uuid.replace(/-/g, "");
  if (!HEX32_RE.test(hex)) return null;
  const out = new Uint8Array(16);
  for (let i = 0; i < 16; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}

function bytesToUuid(bytes: Uint8Array): string {
  const hex = Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function xor(bytes: Uint8Array): Uint8Array {
  const out = new Uint8Array(16);
  for (let i = 0; i < 16; i++) out[i] = bytes[i] ^ KEY[i];
  return out;
}

function bytesToB64url(bytes: Uint8Array): string {
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64urlToBytes(s: string): Uint8Array | null {
  try {
    const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
    const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/") + pad);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  } catch {
    return null;
  }
}

/**
 * Encode a UUID into a short opaque token.
 * Returns the original input if it isn't a valid UUID (defensive).
 */
export function encodeId(uuid: string | undefined | null): string {
  if (!uuid) return "";
  if (!UUID_RE.test(uuid)) return uuid;
  const bytes = uuidToBytes(uuid);
  if (!bytes) return uuid;
  return bytesToB64url(xor(bytes));
}

/**
 * Decode a token back to a UUID. If the value already looks like a UUID,
 * returns it as-is (backward compatibility). Returns null if undecodable.
 */
export function decodeId(token: string | undefined | null): string | null {
  if (!token) return null;
  if (UUID_RE.test(token)) return token.toLowerCase();
  const bytes = b64urlToBytes(token);
  if (!bytes || bytes.length !== 16) return null;
  return bytesToUuid(xor(bytes));
}

/** Convenience href builders (emit hashed routes). */
import { ROUTE_HASHES } from "@/lib/routeMap";
export const clientHref = (id: string | undefined | null) =>
  id ? `${ROUTE_HASHES["/clients"]}/${encodeId(id)}` : ROUTE_HASHES["/clients"];
export const leadHref = (id: string | undefined | null) =>
  id ? `${ROUTE_HASHES["/leads"]}/${encodeId(id)}` : ROUTE_HASHES["/leads"];
export const liveSubmissionHref = (id: string | undefined | null) =>
  id ? `${ROUTE_HASHES["/live-traffic"]}/${encodeId(id)}` : ROUTE_HASHES["/live-traffic"];

