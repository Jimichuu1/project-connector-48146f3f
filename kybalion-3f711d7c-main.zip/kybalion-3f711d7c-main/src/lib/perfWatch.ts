/**
 * perfWatch — wraps window.fetch and warns to the console when any Supabase
 * request takes longer than the threshold. Helps pinpoint slow calls that
 * cause the app to "hang" on a loading spinner.
 *
 * No UI impact. Logs only. Safe to remove at any time.
 */
const SLOW_THRESHOLD_MS = 5000;

let installed = false;

export function installPerfWatch() {
  if (installed || typeof window === "undefined" || !window.fetch) return;
  installed = true;

  const originalFetch = window.fetch.bind(window);

  window.fetch = async (...args: Parameters<typeof fetch>) => {
    const started = performance.now();
    const url = typeof args[0] === "string" ? args[0] : (args[0] as Request | URL).toString();
    try {
      const res = await originalFetch(...args);
      const dur = Math.round(performance.now() - started);
      if (dur > SLOW_THRESHOLD_MS && url.includes("supabase.co")) {
        // eslint-disable-next-line no-console
        console.warn(`[perfWatch] Slow request ${dur}ms — ${url}`);
      }
      return res;
    } catch (err) {
      const dur = Math.round(performance.now() - started);
      if (dur > SLOW_THRESHOLD_MS && url.includes("supabase.co")) {
        // eslint-disable-next-line no-console
        console.warn(`[perfWatch] Slow failed request ${dur}ms — ${url}`);
      }
      throw err;
    }
  };
}
