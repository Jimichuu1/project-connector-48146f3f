import { supabase } from "@/integrations/supabase/client";
import { exportLeadsToCSV } from "@/lib/exportCsv";
import { Lead } from "@/types/leads";

interface KycExportData {
  leadId: string;
  banks: string[];
  notes: string[];
}

interface AssignedUser {
  id: string;
  name: string;
}

interface GroupInfo {
  leadId: string;
  groupName: string;
}

export async function exportLeadsWithKycData(leads: Lead[] | undefined) {
  if (!leads || leads.length === 0) {
    exportLeadsToCSV(leads);
    return;
  }

  const leadIds = leads.map((l) => l.id);
  const assignedToIds = leads
    .map((l) => l.assigned_to)
    .filter(Boolean) as string[];

  const [kycResult, profilesResult, groupMembersResult] = await Promise.all([
    supabase
      .from("kyc_records")
      .select("lead_id, bank_name, notes")
      .in("lead_id", leadIds),
    assignedToIds.length > 0
      ? supabase.from("profiles").select("id, full_name").in("id", assignedToIds)
      : Promise.resolve({ data: [] }),
    supabase
      .from("lead_group_members")
      .select("lead_id, group_id, lead_groups(name)")
      .in("lead_id", leadIds),
  ]);

  const kycData: KycExportData[] = leadIds.map((leadId) => {
    const records = kycResult.data?.filter((r) => r.lead_id === leadId) || [];
    return {
      leadId,
      banks: records.filter((r) => r.bank_name).map((r) => r.bank_name!),
      notes: records.filter((r) => r.notes).map((r) => r.notes!),
    };
  });

  const assignedUsers: AssignedUser[] =
    profilesResult.data?.map((p) => ({ id: p.id, name: p.full_name || "" })) || [];

  const groups: GroupInfo[] =
    groupMembersResult.data?.map((g) => ({
      leadId: g.lead_id,
      groupName: (g.lead_groups as { name?: string })?.name || "",
    })) || [];

  exportLeadsToCSV(leads, kycData, assignedUsers, groups);
}
