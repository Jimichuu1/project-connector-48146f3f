import * as XLSX from "xlsx";

interface DepositDetail {
  id: string;
  amount: number;
  creditedAmount: number;
  clientName: string;
  date: string;
  isSplit: boolean;
}

interface SalaryRow {
  userId: string;
  fullName: string;
  role: string;
  baseSalary: number;
  totalDeposits: number;
  commission: number;
  commissionRate: number;
  teamCommission: number;
  teamCommissionRate: number;
  transferValue: number;
  singleTransferPrice: number;
  totalFees: number;
  advanceAmount: number;
  netSalary: number;
  depositDetails: DepositDetail[];
  conversions?: number;
}

interface CustomEntry {
  id: string;
  name: string;
  base_salary: number;
  commission: number;
  advance: number;
}

export function exportSalaryToExcel(
  salaryData: SalaryRow[],
  customEntries: CustomEntry[],
  monthLabel: string
) {
  const wb = XLSX.utils.book_new();

  // ── Sheet 1: Salary Summary ──
  // Columns: A=Name, B=Role, C=Base Salary, D=Total Deposits, E=Commission %,
  //          F=Commission, G=Team Comm., H=Transfer Value, I=Fees, J=Advance, K=Net Salary
  const headers = [
    "Name", "Role", "Base Salary", "Total Deposits", "Commission %",
    "Commission", "Team Comm.", "Transfer Value", "Fees", "Advance", "Net Salary"
  ];

  const summaryRows: unknown[][] = [headers];
  const dataStartRow = 2;

  salaryData.forEach((row, i) => {
    const r = dataStartRow + i;
    // Commission formula: D{r} * E{r} / 100
    const commissionFormula = { f: `D${r}*E${r}/100` };
    // Net Salary formula: C + F + G + H - I - J
    const netFormula = { f: `C${r}+F${r}+G${r}+H${r}-I${r}-J${r}` };

    summaryRows.push([
      row.fullName,
      row.role === "MANAGER" ? "Manager" : row.role === "TEAM_LEADER" ? "Team Leader" : row.role === "SUPER_AGENT" ? "Super Agent" : "Agent",
      row.baseSalary,
      row.totalDeposits,
      row.commissionRate,
      commissionFormula,
      row.teamCommission,
      row.transferValue,
      row.totalFees,
      row.advanceAmount,
      netFormula,
    ]);
  });

  // Custom entries
  customEntries.forEach((entry, i) => {
    const r = dataStartRow + salaryData.length + i;
    const netFormula = { f: `C${r}+F${r}+G${r}-J${r}` };
    summaryRows.push([
      entry.name,
      "Custom",
      Number(entry.base_salary),
      0,
      0,
      Number(entry.commission),
      0,
      0,
      0,
      Number(entry.advance) || 0,
      netFormula,
    ]);
  });

  // Totals row
  const totalCount = salaryData.length + customEntries.length;
  const lastDataRow = dataStartRow + totalCount - 1;
  summaryRows.push([
    "TOTAL",
    "",
    { f: `SUM(C${dataStartRow}:C${lastDataRow})` },
    { f: `SUM(D${dataStartRow}:D${lastDataRow})` },
    "",
    { f: `SUM(F${dataStartRow}:F${lastDataRow})` },
    { f: `SUM(G${dataStartRow}:G${lastDataRow})` },
    { f: `SUM(H${dataStartRow}:H${lastDataRow})` },
    { f: `SUM(I${dataStartRow}:I${lastDataRow})` },
    { f: `SUM(J${dataStartRow}:J${lastDataRow})` },
    { f: `SUM(K${dataStartRow}:K${lastDataRow})` },
  ]);

  const ws1 = XLSX.utils.aoa_to_sheet(summaryRows);

  // Apply 2-decimal number format to currency columns (C,D,F,G,H,I,J,K)
  const fmt2 = "#,##0.00";
  const currencyCols1 = [2, 3, 5, 6, 7, 8, 9, 10];
  for (let r = 1; r < summaryRows.length; r++) {
    currencyCols1.forEach((c) => {
      const addr = XLSX.utils.encode_cell({ r, c });
      if (ws1[addr]) ws1[addr].z = fmt2;
    });
  }

  ws1["!cols"] = [
    { wch: 25 }, { wch: 14 }, { wch: 14 }, { wch: 16 }, { wch: 14 },
    { wch: 14 }, { wch: 14 }, { wch: 16 }, { wch: 12 }, { wch: 12 }, { wch: 14 },
  ];

  XLSX.utils.book_append_sheet(wb, ws1, "Salary Summary");

  // ── Sheet 2: Deposit Details ──
  const depositRows: unknown[][] = [
    ["Agent Name", "Role", "Client Name", "Date", "Deposit Amount", "Credited Amount", "Split (50%)"]
  ];

  const agentRowMap = new Map<string, number>();
  salaryData.forEach((row, i) => {
    agentRowMap.set(row.userId, dataStartRow + i);
  });

  salaryData.forEach((row) => {
    if (row.depositDetails.length === 0) return;

    const summaryRow = agentRowMap.get(row.userId);
    const agentNameWithLink = summaryRow
      ? { f: `'Salary Summary'!A${summaryRow}` }
      : row.fullName;

    row.depositDetails.forEach((dep, idx) => {
      depositRows.push([
        idx === 0 ? agentNameWithLink : "",
        idx === 0 ? (row.role === "MANAGER" ? "Manager" : row.role === "TEAM_LEADER" ? "Team Leader" : row.role === "SUPER_AGENT" ? "Super Agent" : "Agent") : "",
        dep.clientName,
        dep.date,
        dep.amount,
        dep.creditedAmount,
        dep.isSplit ? "Yes" : "No",
      ]);
    });

    const firstDepRow = depositRows.length - row.depositDetails.length + 1;
    const lastDepRow = depositRows.length;
    depositRows.push([
      "",
      "",
      "",
      `Subtotal (${row.depositDetails.length} deposits)`,
      { f: `SUM(E${firstDepRow}:E${lastDepRow})` },
      { f: `SUM(F${firstDepRow}:F${lastDepRow})` },
      "",
    ]);

    depositRows.push(["", "", "", "", "", "", ""]);
  });

  const ws2 = XLSX.utils.aoa_to_sheet(depositRows);

  const currencyCols2 = [4, 5];
  for (let r = 1; r < depositRows.length; r++) {
    currencyCols2.forEach((c) => {
      const addr = XLSX.utils.encode_cell({ r, c });
      if (ws2[addr]) ws2[addr].z = fmt2;
    });
  }

  ws2["!cols"] = [
    { wch: 25 }, { wch: 14 }, { wch: 22 }, { wch: 18 }, { wch: 16 }, { wch: 16 }, { wch: 12 },
  ];

  XLSX.utils.book_append_sheet(wb, ws2, "Deposit Details");

  XLSX.writeFile(wb, `Salary_${monthLabel.replace(/\s+/g, "_")}.xlsx`);
}
