// Country normalization helpers.
// `normalizeCountryName` lives in `countryFlags.ts` (canonical full name from any
// known alias / ISO-2 code). This module adds the inverse operation:
// given a canonical full name, return every stored variant we should match
// against in the database (e.g. "Australia" -> ["Australia", "AU"]).

import { normalizeCountryName } from "./countryFlags";

// Build canonical -> ISO-2 map by re-using normalizeCountryName for a few
// common codes is too brittle. Instead we re-derive it lazily from a small
// hand-maintained list extracted from the project's countryFlags.ts entries.
// Keeping this list narrow on purpose: only the codes we know appear (or are
// likely to appear) as raw values in our leads/clients tables.
const CANONICAL_TO_CODES: Record<string, string[]> = {
  "Australia": ["AU"],
  "Sweden": ["SE"],
  "Denmark": ["DK", "Denmark (DK)"],
  "Norway": ["NO"],
  "Switzerland": ["CH"],
  "United Kingdom": ["UK", "GB"],
  "United States": ["US", "USA"],
  "Germany": ["DE"],
  "France": ["FR"],
  "Netherlands": ["NL"],
  "Finland": ["FI"],
  "Belgium": ["BE"],
  "Poland": ["PL"],
  "Ireland": ["IE"],
  "Italy": ["IT"],
  "Latvia": ["LV"],
  "Canada": ["CA"],
  "Spain": ["ES"],
  "Portugal": ["PT"],
  "Austria": ["AT"],
};

/**
 * Given a canonical country name (e.g. "Australia"), return every value
 * that should match it when filtering rows whose `country` column may
 * contain ISO-2 codes or other variants.
 */
export function expandCountryAliases(canonical: string): string[] {
  if (!canonical) return [];
  const extras = CANONICAL_TO_CODES[canonical] ?? [];
  return Array.from(new Set([canonical, ...extras]));
}

/**
 * Expand a list of canonical country names into the full set of values
 * (canonical name + known aliases) to use in a `.in('country', …)` query.
 */
export function expandCountryListForQuery(canonicals: string[]): string[] {
  const out = new Set<string>();
  for (const c of canonicals) {
    for (const v of expandCountryAliases(c)) out.add(v);
  }
  return Array.from(out);
}

export { normalizeCountryName };
