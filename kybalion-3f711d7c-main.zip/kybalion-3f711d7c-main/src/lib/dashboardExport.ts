import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { format, startOfMonth, endOfMonth } from "date-fns";

interface ExportData {
  tenantId: string | null;
  month: string;
}

interface DepositWithDetails {
  id: string;
  amount: number;
  status: string;
  created_at: string;
  client_id: string;
  agent_id: string | null;
  super_agent_id: string | null;
  split_super_agent_id: string | null;
  agent_percentage: number;
  super_agent_percentage: number;
  agent_amount: number;
  super_agent_amount: number;
  split_super_agent_amount: number | null;
}

interface ClientGroupInfo {
  clientId: string;
  groupNames: string[];
  pipelineStatus: string;
}

interface SalaryInfo {
  userId: string;
  fullName: string;
  role: string;
  baseSalary: number;
  totalDeposits: number;
  commission: number;
  commissionRate: number;
  totalFees: number;
  netSalary: number;
  conversions?: number;
}

export async function exportDashboardToExcel({ tenantId, month }: ExportData) {
  try {
    toast.info("Preparing export data...");

    // Parse month for date range
    const [year, monthNum] = month.split("-").map(Number);
    const monthDate = new Date(year, monthNum - 1, 1);
    const startDate = startOfMonth(monthDate).toISOString();
    const endDate = endOfMonth(monthDate).toISOString();

    // Fetch all data in parallel
    const [
      depositsResult,
      clientsResult,
      profilesResult,
      rolesResult,
      clientGroupMembersResult,
      clientGroupsResult,
      attendanceResult,
      tierSettingsResult,
      managerSettingsResult,
    ] = await Promise.all([
      // Deposits for the month
      supabase
        .from("deposits")
        .select("*")
        .eq("status", "approved")
        .gte("created_at", startDate)
        .lte("created_at", endDate)
        .then(r => tenantId ? 
          supabase.from("deposits").select("*").eq("status", "approved").eq("admin_id", tenantId).gte("created_at", startDate).lte("created_at", endDate) : 
          r
        ),
      // All clients
      tenantId
        ? supabase.from("clients").select("*").eq("admin_id", tenantId)
        : supabase.from("clients").select("*"),
      // All profiles
      tenantId
        ? supabase.from("profiles").select("id, full_name, username, admin_id, created_by").eq("admin_id", tenantId)
        : supabase.from("profiles").select("id, full_name, username, admin_id, created_by"),
      // All roles
      supabase.from("user_roles").select("user_id, role"),
      // Client group memberships
      supabase.from("client_group_members").select("client_id, group_id"),
      // Client groups
      tenantId
        ? supabase.from("client_groups").select("id, name").eq("admin_id", tenantId)
        : supabase.from("client_groups").select("id, name"),
      // Attendance for the month
      tenantId
        ? supabase.from("attendance").select("user_id, late_start_fee, break_time_fee, total_fees").eq("admin_id", tenantId).gte("date", month + "-01").lte("date", month + "-31")
        : supabase.from("attendance").select("user_id, late_start_fee, break_time_fee, total_fees").gte("date", month + "-01").lte("date", month + "-31"),
      // Tier settings for salary calculation
      tenantId
        ? supabase.from("commission_tier_settings").select("*").eq("admin_id", tenantId).eq("month", month).maybeSingle()
        : supabase.from("commission_tier_settings").select("*").eq("month", month).limit(1).maybeSingle(),
      // Manager settings
      tenantId
        ? supabase.from("manager_commission_settings").select("*").eq("admin_id", tenantId)
        : supabase.from("manager_commission_settings").select("*"),
    ]);

    const deposits = depositsResult.data || [];
    const clients = clientsResult.data || [];
    const profiles = profilesResult.data || [];
    const roles = rolesResult.data || [];
    const clientGroupMembers = clientGroupMembersResult.data || [];
    const clientGroups = clientGroupsResult.data || [];
    const attendance = attendanceResult.data || [];
    const tierSettings = tierSettingsResult.data;
    const managerSettings = managerSettingsResult.data || [];

    // Create lookup maps
    const profileMap = new Map(profiles.map(p => [p.id, p.full_name || p.username || "Unknown"]));
    const roleMap = new Map(roles.map(r => [r.user_id, r.role]));
    const groupMap = new Map(clientGroups.map(g => [g.id, g.name]));
    
    // Build client group info
    const clientGroupInfo = new Map<string, ClientGroupInfo>();
    clients.forEach(client => {
      const memberships = clientGroupMembers.filter(m => m.client_id === client.id);
      const groupNames = memberships.map(m => groupMap.get(m.group_id) || "").filter(Boolean);
      clientGroupInfo.set(client.id, {
        clientId: client.id,
        groupNames,
        pipelineStatus: client.pipeline_status || "live",
      });
    });

    // ===== SHEET 1: Deposited Clients =====
    const depositedClientIds = [...new Set(deposits.map(d => d.client_id))];
    const depositedClientsData: (string | number)[][] = [
      ["Client Name", "Email", "Phone", "Country", "Status", "Pipeline Status", "Group Names", "Agent Name", "Super Agent Name", "Total Deposits", "Join Date"]
    ];

    depositedClientIds.forEach(clientId => {
      const client = clients.find(c => c.id === clientId);
      if (!client) return;

      const clientDeposits = deposits.filter(d => d.client_id === clientId);
      const totalDeposits = clientDeposits.reduce((sum, d) => sum + Number(d.amount), 0);
      const groupInfo = clientGroupInfo.get(clientId);
      const agentName = client.assigned_to ? profileMap.get(client.assigned_to) || "" : "";
      
      // Get super agent from latest deposit
      const latestDeposit = clientDeposits.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      )[0];
      const superAgentName = latestDeposit?.super_agent_id 
        ? profileMap.get(latestDeposit.super_agent_id) || ""
        : "";

      depositedClientsData.push([
        client.name || "",
        client.email || "",
        client.home_phone || "",
        client.country || "",
        client.status || "",
        groupInfo?.pipelineStatus || "live",
        groupInfo?.groupNames.join(", ") || "",
        agentName,
        superAgentName,
        totalDeposits,
        client.join_date ? format(new Date(client.join_date), "yyyy-MM-dd") : "",
      ]);
    });

    // ===== SHEET 2: All Deposits Detail =====
    const depositsDetailData: (string | number)[][] = [
      ["Date", "Client Name", "Amount", "Agent Name", "Agent %", "Agent Amount", "Super Agent Name", "Super Agent %", "Super Agent Amount", "Split Super Agent", "Split Amount", "Status"]
    ];

    deposits.forEach(deposit => {
      const client = clients.find(c => c.id === deposit.client_id);
      depositsDetailData.push([
        format(new Date(deposit.created_at), "yyyy-MM-dd HH:mm"),
        client?.name || "Unknown",
        Number(deposit.amount),
        deposit.agent_id ? profileMap.get(deposit.agent_id) || "" : "",
        deposit.agent_percentage || 0,
        Number(deposit.agent_amount) || 0,
        deposit.super_agent_id ? profileMap.get(deposit.super_agent_id) || "" : "",
        deposit.super_agent_percentage || 0,
        Number(deposit.super_agent_amount) || 0,
        deposit.split_super_agent_id ? profileMap.get(deposit.split_super_agent_id) || "" : "",
        Number(deposit.split_super_agent_amount) || 0,
        deposit.status || "",
      ]);
    });

    // ===== SHEET 3: Converted Clients (with deposit) =====
    const convertedClientsData: (string | number)[][] = [
      ["Client Name", "Email", "Phone", "Country", "Status", "Assigned Agent", "Total Deposits", "Balance", "Equity", "Pipeline Status", "Join Date", "Groups"]
    ];

    // Get converted clients (those with deposits or marked as closed won)
    const clientsWithDeposits = clients.filter(c => {
      const hasDeposit = deposits.some(d => d.client_id === c.id);
      const isConverted = c.pipeline_status === "CLOSED_WON";
      return hasDeposit || isConverted;
    });

    clientsWithDeposits.forEach(client => {
      const clientDeposits = deposits.filter(d => d.client_id === client.id);
      const totalDeposits = clientDeposits.reduce((sum, d) => sum + Number(d.amount), 0);
      const groupInfo = clientGroupInfo.get(client.id);
      
      convertedClientsData.push([
        client.name || "",
        client.email || "",
        client.home_phone || "",
        client.country || "",
        client.status || "",
        client.assigned_to ? profileMap.get(client.assigned_to) || "" : "",
        totalDeposits,
        Number(client.balance) || 0,
        Number(client.equity) || 0,
        client.pipeline_status || "",
        client.join_date ? format(new Date(client.join_date), "yyyy-MM-dd") : "",
        groupInfo?.groupNames.join(", ") || "",
      ]);
    });

    // ===== SHEET 4: Salary Summary =====
    const salaryData: SalaryInfo[] = [];
    
    // Default tier rates if no settings found
    const defaultAgentTransferTiers = [{ minConversions: 0, baseSalary: 800, singleTransferValue: 0 }];
    const defaultAgentCommissionTiers = [{ minDeposit: 0, commissionPercent: 5 }];
    const defaultSuperAgentTiers = [{ minDeposit: 0, commissionPercent: 8, baseSalary: 1000 }];
    const defaultManagerTiers = [{ minDeposit: 0, commissionPercent: 3, baseSalary: 1500 }];

    const agentTransferTiers = tierSettings?.agent_tiers as { minConversions: number; baseSalary: number; singleTransferValue?: number }[] || defaultAgentTransferTiers;
    const agentCommissionTiers = (tierSettings as Record<string, unknown>)?.agent_commission_tiers as { minDeposit: number; commissionPercent: number }[] || defaultAgentCommissionTiers;
    const superAgentTiers = tierSettings?.super_agent_tiers as { minDeposit: number; commissionPercent: number; baseSalary: number }[] || defaultSuperAgentTiers;
    
    // Build team membership map
    const teamByManager = new Map<string, string[]>();
    profiles.forEach(p => {
      if (p.created_by) {
        const team = teamByManager.get(p.created_by) || [];
        team.push(p.id);
        teamByManager.set(p.created_by, team);
      }
    });

    // Count conversions by agent (all clients assigned to them)
    const conversionsByAgent = new Map<string, number>();
    clients.forEach(c => {
      if (c.assigned_to) {
        conversionsByAgent.set(c.assigned_to, (conversionsByAgent.get(c.assigned_to) || 0) + 1);
      }
    });

    // Calculate salary for agents, super agents, and managers
    const eligibleUsers = profiles.filter(p => {
      const role = roleMap.get(p.id);
      return role === "AGENT" || role === "SUPER_AGENT" || role === "MANAGER";
    });

    eligibleUsers.forEach(user => {
      const role = roleMap.get(user.id) || "AGENT";
      const isAgent = role === "AGENT";
      const isSuperAgent = role === "SUPER_AGENT";
      const isManager = role === "MANAGER";

      let totalDeposits = 0;

      if (isAgent) {
        deposits.filter(d => d.agent_id === user.id).forEach(d => {
          totalDeposits += Number(d.amount) || 0;
        });
      } else if (isSuperAgent) {
        deposits.forEach(d => {
          const hasSplit = d.split_super_agent_id && d.split_super_agent_id !== d.super_agent_id;
          if (d.super_agent_id === user.id) {
            totalDeposits += hasSplit ? Number(d.amount) / 2 : Number(d.amount);
          } else if (d.split_super_agent_id === user.id) {
            totalDeposits += Number(d.amount) / 2;
          }
        });
      } else if (isManager) {
        const teamMemberIds = teamByManager.get(user.id) || [];
        deposits.forEach(d => {
          const isFromTeam = 
            (d.agent_id && teamMemberIds.includes(d.agent_id)) ||
            (d.super_agent_id && teamMemberIds.includes(d.super_agent_id));
          if (isFromTeam) {
            totalDeposits += Number(d.amount) || 0;
          }
        });
      }

      // Calculate base salary and commission rate based on tiers
      let baseSalary = 0;
      let commissionRate = 0;
      let conversions: number | undefined;

      if (isAgent) {
        conversions = conversionsByAgent.get(user.id) || 0;
        // Transfer tier lookup
        const sortedTransferTiers = [...agentTransferTiers].sort((a, b) => b.minConversions - a.minConversions);
        const transferTier = sortedTransferTiers.find(t => conversions! >= t.minConversions) || agentTransferTiers[0];
        baseSalary = transferTier.baseSalary;
        // Commission tier lookup (deposit-based)
        const sortedCommTiers = [...agentCommissionTiers].sort((a, b) => b.minDeposit - a.minDeposit);
        const commTier = sortedCommTiers.find(t => totalDeposits >= t.minDeposit) || agentCommissionTiers[0];
        commissionRate = commTier.commissionPercent;
      } else if (isSuperAgent) {
        const sortedTiers = [...superAgentTiers].sort((a, b) => b.minDeposit - a.minDeposit);
        const tier = sortedTiers.find(t => totalDeposits >= t.minDeposit) || superAgentTiers[0];
        baseSalary = tier.baseSalary;
        commissionRate = tier.commissionPercent;
      } else if (isManager) {
        const managerSetting = managerSettings.find(m => m.manager_id === user.id);
        baseSalary = managerSetting?.base_salary ?? 1500;
        commissionRate = managerSetting?.commission_percentage ?? 3;
      }

      const commission = totalDeposits * (commissionRate / 100);

      // Calculate total fees
      const userAttendance = attendance.filter(a => a.user_id === user.id);
      const totalFees = userAttendance.reduce((sum, a) => sum + (Number(a.total_fees) || 0), 0);

      const netSalary = baseSalary + commission - totalFees;

      salaryData.push({
        userId: user.id,
        fullName: user.full_name || user.username || "Unknown",
        role,
        baseSalary,
        totalDeposits,
        commission,
        commissionRate,
        totalFees,
        netSalary,
        conversions,
      });
    });

    // Sort by net salary descending
    salaryData.sort((a, b) => b.netSalary - a.netSalary);

    const salarySheetData: (string | number)[][] = [
      ["Name", "Role", "Base Salary", "Total Deposits", "Commission Rate %", "Commission", "Deductions", "Net Salary", "Conversions"]
    ];

    salaryData.forEach(s => {
      salarySheetData.push([
        s.fullName,
        s.role,
        s.baseSalary,
        s.totalDeposits,
        s.commissionRate,
        s.commission,
        s.totalFees,
        s.netSalary,
        s.conversions ?? "",
      ]);
    });

    // Add totals row
    const totalBaseSalary = salaryData.reduce((sum, s) => sum + s.baseSalary, 0);
    const totalDepositsSum = salaryData.reduce((sum, s) => sum + s.totalDeposits, 0);
    const totalCommission = salaryData.reduce((sum, s) => sum + s.commission, 0);
    const totalFees = salaryData.reduce((sum, s) => sum + s.totalFees, 0);
    const totalNetSalary = salaryData.reduce((sum, s) => sum + s.netSalary, 0);

    salarySheetData.push([]);
    salarySheetData.push([
      "TOTALS",
      "",
      totalBaseSalary,
      totalDepositsSum,
      "",
      totalCommission,
      totalFees,
      totalNetSalary,
      "",
    ]);

    // ===== SHEET 5: Summary =====
    const summaryData: (string | number)[][] = [
      ["Dashboard Export Summary"],
      [""],
      ["Report Period", format(monthDate, "MMMM yyyy")],
      ["Generated At", format(new Date(), "yyyy-MM-dd HH:mm:ss")],
      [""],
      ["Key Metrics", ""],
      ["Total Deposited Clients", depositedClientIds.length],
      ["Total Deposits Amount", deposits.reduce((sum, d) => sum + Number(d.amount), 0)],
      ["Total Converted Clients", clientsWithDeposits.length],
      ["Total Active Agents", salaryData.filter(s => s.role === "AGENT").length],
      ["Total Super Agents", salaryData.filter(s => s.role === "SUPER_AGENT").length],
      ["Total Managers", salaryData.filter(s => s.role === "MANAGER").length],
      [""],
      ["Salary Totals", ""],
      ["Total Base Salaries", totalBaseSalary],
      ["Total Commissions", totalCommission],
      ["Total Deductions", totalFees],
      ["Total Net Salaries", totalNetSalary],
    ];

    // ===== CREATE WORKBOOK =====
    const workbook = XLSX.utils.book_new();

    // Summary sheet
    const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
    summarySheet["!cols"] = [{ wch: 25 }, { wch: 25 }];
    XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");

    // Deposited Clients sheet
    const depositedSheet = XLSX.utils.aoa_to_sheet(depositedClientsData);
    depositedSheet["!cols"] = [
      { wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 15 }, { wch: 15 },
      { wch: 15 }, { wch: 25 }, { wch: 20 }, { wch: 20 }, { wch: 15 }, { wch: 12 }
    ];
    XLSX.utils.book_append_sheet(workbook, depositedSheet, "Deposited Clients");

    // Deposits Detail sheet
    const depositsSheet = XLSX.utils.aoa_to_sheet(depositsDetailData);
    depositsSheet["!cols"] = [
      { wch: 18 }, { wch: 25 }, { wch: 12 }, { wch: 20 }, { wch: 10 },
      { wch: 12 }, { wch: 20 }, { wch: 10 }, { wch: 15 }, { wch: 20 }, { wch: 12 }, { wch: 10 }
    ];
    XLSX.utils.book_append_sheet(workbook, depositsSheet, "Deposits Detail");

    // Converted Clients sheet
    const convertedSheet = XLSX.utils.aoa_to_sheet(convertedClientsData);
    convertedSheet["!cols"] = [
      { wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 15 }, { wch: 15 },
      { wch: 20 }, { wch: 15 }, { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 12 }, { wch: 25 }
    ];
    XLSX.utils.book_append_sheet(workbook, convertedSheet, "Converted Clients");

    // Salary Summary sheet
    const salarySheet = XLSX.utils.aoa_to_sheet(salarySheetData);
    salarySheet["!cols"] = [
      { wch: 25 }, { wch: 15 }, { wch: 12 }, { wch: 15 }, { wch: 15 },
      { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 }
    ];
    XLSX.utils.book_append_sheet(workbook, salarySheet, "Salary Summary");

    // Generate filename
    const filename = `dashboard-report-${month}.xlsx`;

    // Download
    XLSX.writeFile(workbook, filename);

    toast.success(`Exported dashboard data to ${filename}`);
  } catch (error) {
    console.error("Export error:", error);
    toast.error("Failed to export dashboard data");
  }
}
