// Centralized role -> route access map. Mirrors the guards in App.tsx.
// Used by RoleProtectedRoute and the page visit logger.

export type Role =
  | "SUPER_ADMIN"
  | "TENANT_OWNER"
  | "MANAGER"
  | "TEAM_LEADER"
  | "SUPER_AGENT"
  | "AGENT";

const ALL: Role[] = ["SUPER_ADMIN", "TENANT_OWNER", "MANAGER", "TEAM_LEADER", "SUPER_AGENT", "AGENT"];
const TO_ONLY: Role[] = ["SUPER_ADMIN", "TENANT_OWNER"];

// Readable path -> roles allowed
export const ROUTE_ACCESS: Record<string, Role[]> = {
  "/dashboard": TO_ONLY,
  "/live-traffic": ["SUPER_ADMIN", "TENANT_OWNER", "SUPER_AGENT"],
  "/settings/live": TO_ONLY,
  "/settings/app-integration": TO_ONLY,
  "/leads": ALL,
  "/clients": ALL,
  "/pipeline": ALL,
  "/reports": ALL,
  "/salary": TO_ONLY,
  "/targets": TO_ONLY,
  "/user-management": TO_ONLY,
  "/convert-queue": ALL,
  "/attendance": ALL,
  "/settings": TO_ONLY,
  "/settings/profile": ALL,
  "/security-monitoring": TO_ONLY,
  "/team-management": TO_ONLY,
  "/tenant-management": TO_ONLY,
  "/notifications": ALL,
  "/scripts": ALL,
  "/favourite-clients": TO_ONLY,
};

export function canAccessRoute(role: Role | null | undefined, readablePath: string): boolean {
  if (!role) return false;
  // Strip detail segments: /clients/abc -> /clients
  const base = "/" + readablePath.split("/").filter(Boolean)[0];
  const twoSeg = readablePath.split("/").filter(Boolean).slice(0, 2).join("/");
  const twoSegPath = "/" + twoSeg;

  const allowed =
    ROUTE_ACCESS[readablePath] ||
    ROUTE_ACCESS[twoSegPath] ||
    ROUTE_ACCESS[base];

  if (!allowed) return true; // unknown route - don't flag as denied
  return allowed.includes(role);
}
