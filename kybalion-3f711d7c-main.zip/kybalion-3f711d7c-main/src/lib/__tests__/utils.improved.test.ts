import { describe, it, expect } from "vitest";
import { cn } from "@/lib/utils";

describe("cn utility function", () => {
  it("merges class names correctly", () => {
    const result = cn("class1", "class2");
    expect(result).toBe("class1 class2");
  });

  it("handles conditional classes", () => {
    const isActive = true;
    const isDisabled = false;
    const result = cn("base", isActive && "active", isDisabled && "disabled");
    expect(result).toBe("base active");
  });

  it("handles undefined and null values", () => {
    const result = cn("base", undefined, null, "valid");
    expect(result).toBe("base valid");
  });

  it("handles empty strings", () => {
    const result = cn("base", "", "valid");
    expect(result).toBe("base valid");
  });

  it("merges tailwind classes correctly", () => {
    const result = cn("px-2 py-1", "px-4");
    expect(result).toBe("py-1 px-4");
  });

  it("handles array of classes", () => {
    const result = cn(["class1", "class2"]);
    expect(result).toBe("class1 class2");
  });

  it("handles object notation", () => {
    const result = cn({
      "class1": true,
      "class2": false,
      "class3": true,
    });
    expect(result).toBe("class1 class3");
  });

  it("handles complex combinations", () => {
    const result = cn(
      "base",
      ["array-class"],
      { "conditional-true": true, "conditional-false": false },
      undefined,
      "final"
    );
    expect(result).toBe("base array-class conditional-true final");
  });
});

describe("formatCurrency utility", () => {
  // Since formatCurrency is in lib/utils, let's test the pattern
  it("formats positive numbers correctly", () => {
    const format = (value: number) =>
      new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
      }).format(value);

    expect(format(1000)).toBe("$1,000.00");
    expect(format(1234.56)).toBe("$1,234.56");
    expect(format(0)).toBe("$0.00");
  });

  it("handles negative numbers", () => {
    const format = (value: number) =>
      new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
      }).format(value);

    expect(format(-100)).toBe("-$100.00");
  });
});

describe("string utilities", () => {
  it("truncates long strings", () => {
    const truncate = (str: string, maxLength: number): string => {
      if (str.length <= maxLength) return str;
      return str.slice(0, maxLength - 3) + "...";
    };

    expect(truncate("Hello World", 5)).toBe("He...");
    expect(truncate("Hi", 5)).toBe("Hi");
    expect(truncate("Hello", 5)).toBe("Hello");
  });

  it("sanitizes HTML entities", () => {
    const sanitize = (str: string): string => {
      return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    };

    expect(sanitize("<script>alert('xss')</script>")).toBe(
      "&lt;script&gt;alert(&#039;xss&#039;)&lt;/script&gt;"
    );
  });
});
