import { describe, it, expect } from 'vitest';

// File validation utilities
const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
];

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

const isValidMimeType = (mimeType: string) => ALLOWED_MIME_TYPES.includes(mimeType);
const isValidFileSize = (size: number) => size > 0 && size <= MAX_FILE_SIZE;
const getFileExtension = (filename: string) => filename.split('.').pop()?.toLowerCase() || '';

describe('File type validation', () => {
  it('should accept PDF files', () => {
    expect(isValidMimeType('application/pdf')).toBe(true);
  });

  it('should accept image files', () => {
    expect(isValidMimeType('image/png')).toBe(true);
    expect(isValidMimeType('image/jpeg')).toBe(true);
  });

  it('should accept document files', () => {
    expect(isValidMimeType('application/msword')).toBe(true);
    expect(isValidMimeType('application/vnd.openxmlformats-officedocument.wordprocessingml.document')).toBe(true);
  });

  it('should accept spreadsheet files', () => {
    expect(isValidMimeType('application/vnd.ms-excel')).toBe(true);
    expect(isValidMimeType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')).toBe(true);
  });

  it('should reject invalid file types', () => {
    expect(isValidMimeType('application/exe')).toBe(false);
    expect(isValidMimeType('text/javascript')).toBe(false);
    expect(isValidMimeType('application/x-msdownload')).toBe(false);
  });
});

describe('File size validation', () => {
  it('should accept files within size limit', () => {
    expect(isValidFileSize(1024)).toBe(true); // 1KB
    expect(isValidFileSize(1024 * 1024)).toBe(true); // 1MB
    expect(isValidFileSize(5 * 1024 * 1024)).toBe(true); // 5MB
    expect(isValidFileSize(MAX_FILE_SIZE)).toBe(true); // Exactly 10MB
  });

  it('should reject files over size limit', () => {
    expect(isValidFileSize(MAX_FILE_SIZE + 1)).toBe(false);
    expect(isValidFileSize(20 * 1024 * 1024)).toBe(false); // 20MB
  });

  it('should reject zero or negative sizes', () => {
    expect(isValidFileSize(0)).toBe(false);
    expect(isValidFileSize(-1)).toBe(false);
  });
});

describe('File extension extraction', () => {
  it('should extract common extensions', () => {
    expect(getFileExtension('document.pdf')).toBe('pdf');
    expect(getFileExtension('image.png')).toBe('png');
    expect(getFileExtension('photo.JPEG')).toBe('jpeg');
  });

  it('should handle multiple dots in filename', () => {
    expect(getFileExtension('my.file.name.pdf')).toBe('pdf');
  });

  it('should handle files without extension', () => {
    expect(getFileExtension('noextension')).toBe('noextension');
  });

  it('should handle empty string', () => {
    expect(getFileExtension('')).toBe('');
  });
});

describe('CSV file validation', () => {
  const isValidCSVContent = (content: string) => {
    const lines = content.split('\n').filter(l => l.trim());
    if (lines.length < 2) return false; // Need header + at least one row
    const headerColumns = lines[0].split(',').length;
    return lines.every(line => line.split(',').length === headerColumns);
  };

  it('should validate proper CSV structure', () => {
    const validCSV = 'name,email,phone\nJohn,john@test.com,1234567890';
    expect(isValidCSVContent(validCSV)).toBe(true);
  });

  it('should reject CSV with inconsistent columns', () => {
    const invalidCSV = 'name,email,phone\nJohn,john@test.com';
    expect(isValidCSVContent(invalidCSV)).toBe(false);
  });

  it('should reject empty CSV', () => {
    expect(isValidCSVContent('')).toBe(false);
  });

  it('should reject header-only CSV', () => {
    expect(isValidCSVContent('name,email,phone')).toBe(false);
  });
});

describe('Image dimension validation', () => {
  const isValidImageDimensions = (width: number, height: number, maxWidth: number = 4096, maxHeight: number = 4096) => {
    return width > 0 && height > 0 && width <= maxWidth && height <= maxHeight;
  };

  it('should accept valid dimensions', () => {
    expect(isValidImageDimensions(800, 600)).toBe(true);
    expect(isValidImageDimensions(1920, 1080)).toBe(true);
    expect(isValidImageDimensions(4096, 4096)).toBe(true);
  });

  it('should reject oversized images', () => {
    expect(isValidImageDimensions(5000, 3000)).toBe(false);
    expect(isValidImageDimensions(3000, 5000)).toBe(false);
  });

  it('should reject zero or negative dimensions', () => {
    expect(isValidImageDimensions(0, 600)).toBe(false);
    expect(isValidImageDimensions(800, 0)).toBe(false);
    expect(isValidImageDimensions(-100, 600)).toBe(false);
  });
});
