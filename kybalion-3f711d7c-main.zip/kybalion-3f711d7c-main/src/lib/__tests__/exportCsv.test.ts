import { describe, it, expect } from 'vitest';

// CSV export utilities
const escapeCSVField = (field: any): string => {
  if (field === null || field === undefined) return '';
  const str = String(field);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

const arrayToCSVRow = (arr: any[]): string => {
  return arr.map(escapeCSVField).join(',');
};

const objectsToCSV = (objects: Record<string, any>[], headers: string[]): string => {
  const headerRow = arrayToCSVRow(headers);
  const dataRows = objects.map(obj => 
    arrayToCSVRow(headers.map(header => obj[header]))
  );
  return [headerRow, ...dataRows].join('\n');
};

describe('CSV field escaping', () => {
  it('should escape fields with commas', () => {
    expect(escapeCSVField('hello, world')).toBe('"hello, world"');
  });

  it('should escape fields with quotes', () => {
    expect(escapeCSVField('say "hello"')).toBe('"say ""hello"""');
  });

  it('should escape fields with newlines', () => {
    expect(escapeCSVField('line1\nline2')).toBe('"line1\nline2"');
  });

  it('should handle null and undefined', () => {
    expect(escapeCSVField(null)).toBe('');
    expect(escapeCSVField(undefined)).toBe('');
  });

  it('should convert numbers to strings', () => {
    expect(escapeCSVField(123)).toBe('123');
    expect(escapeCSVField(45.67)).toBe('45.67');
  });

  it('should not escape simple strings', () => {
    expect(escapeCSVField('simple')).toBe('simple');
  });
});

describe('Array to CSV row', () => {
  it('should join array elements with commas', () => {
    expect(arrayToCSVRow(['a', 'b', 'c'])).toBe('a,b,c');
  });

  it('should escape fields as needed', () => {
    expect(arrayToCSVRow(['hello', 'hello, world', 'test'])).toBe('hello,"hello, world",test');
  });

  it('should handle empty array', () => {
    expect(arrayToCSVRow([])).toBe('');
  });

  it('should handle mixed types', () => {
    expect(arrayToCSVRow(['text', 123, true])).toBe('text,123,true');
  });
});

describe('Objects to CSV', () => {
  it('should convert array of objects to CSV', () => {
    const objects = [
      { name: 'John', email: 'john@test.com' },
      { name: 'Jane', email: 'jane@test.com' }
    ];
    const headers = ['name', 'email'];
    const result = objectsToCSV(objects, headers);
    
    expect(result).toBe('name,email\nJohn,john@test.com\nJane,jane@test.com');
  });

  it('should handle missing fields', () => {
    const objects = [
      { name: 'John', email: 'john@test.com' },
      { name: 'Jane' }
    ];
    const headers = ['name', 'email'];
    const result = objectsToCSV(objects, headers);
    
    expect(result).toContain('Jane,');
  });

  it('should handle empty array', () => {
    const result = objectsToCSV([], ['name', 'email']);
    expect(result).toBe('name,email');
  });

  it('should escape special characters in data', () => {
    const objects = [
      { name: 'John, Jr.', email: 'john@test.com' }
    ];
    const headers = ['name', 'email'];
    const result = objectsToCSV(objects, headers);
    
    expect(result).toContain('"John, Jr."');
  });
});

describe('CSV parsing', () => {
  const parseCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        result.push(current);
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current);
    return result;
  };

  it('should parse simple CSV line', () => {
    expect(parseCSVLine('a,b,c')).toEqual(['a', 'b', 'c']);
  });

  it('should parse quoted fields', () => {
    expect(parseCSVLine('"hello, world",test')).toEqual(['hello, world', 'test']);
  });

  it('should parse escaped quotes', () => {
    expect(parseCSVLine('"say ""hello"""')).toEqual(['say "hello"']);
  });
});
