/**
 * File Upload Security Utilities
 * Validates file signatures, scans for malicious content
 */

// File signature magic numbers (first few bytes that identify file types)
const FILE_SIGNATURES: Record<string, number[][]> = {
  'image/jpeg': [[0xFF, 0xD8, 0xFF]],
  'image/png': [[0x89, 0x50, 0x4E, 0x47]],
  'image/gif': [[0x47, 0x49, 0x46, 0x38]],
  'image/webp': [[0x52, 0x49, 0x46, 0x46]], // RIFF
  'application/pdf': [[0x25, 0x50, 0x44, 0x46]], // %PDF
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': [[0x50, 0x4B, 0x03, 0x04]], // DOCX (ZIP)
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': [[0x50, 0x4B, 0x03, 0x04]], // XLSX (ZIP)
  'application/msword': [[0xD0, 0xCF, 0x11, 0xE0]], // DOC
  'application/vnd.ms-excel': [[0xD0, 0xCF, 0x11, 0xE0]], // XLS
};

// Dangerous file extensions that should never be allowed
const DANGEROUS_EXTENSIONS = [
  'exe', 'bat', 'cmd', 'com', 'pif', 'scr', 'vbs', 'js', 'jar',
  'sh', 'app', 'deb', 'rpm', 'dmg', 'pkg', 'run', 'bin',
  'ps1', 'psm1', 'psd1', 'ps1xml', 'vb', 'reg', 'msi', 'msp'
];

// Suspicious patterns in file content (basic script detection)
const MALICIOUS_PATTERNS = [
  /<script[^>]*>/i,
  /javascript:/i,
  /on\w+\s*=/i, // onclick=, onerror=, etc.
  /<iframe[^>]*>/i,
  /<embed[^>]*>/i,
  /<object[^>]*>/i,
  /eval\s*\(/i,
  /Function\s*\(/i,
];

export interface FileValidationResult {
  valid: boolean;
  error?: string;
  warnings?: string[];
}

/**
 * Validates file signature matches the declared MIME type
 */
export async function validateFileSignature(file: File): Promise<FileValidationResult> {
  try {
    // Check for dangerous extensions
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    if (fileExtension && DANGEROUS_EXTENSIONS.includes(fileExtension)) {
      return {
        valid: false,
        error: `File type .${fileExtension} is not allowed for security reasons`,
      };
    }

    // Read first 8 bytes of file for signature validation
    const arrayBuffer = await file.slice(0, 8).arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);

    // Get expected signatures for this MIME type
    const expectedSignatures = FILE_SIGNATURES[file.type];
    
    if (!expectedSignatures) {
      // If we don't have a signature for this type, warn but don't block
      return {
        valid: true,
        warnings: [`Unknown file type: ${file.type}. Proceed with caution.`],
      };
    }

    // Check if any of the expected signatures match
    const signatureMatches = expectedSignatures.some(signature => 
      signature.every((byte, index) => bytes[index] === byte)
    );

    if (!signatureMatches) {
      return {
        valid: false,
        error: `File signature does not match declared type (${file.type}). File may be corrupted or masquerading as a different type.`,
      };
    }

    return { valid: true };
  } catch (error) {
    return {
      valid: false,
      error: `Failed to validate file signature: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
}

/**
 * Scans file content for embedded scripts and malicious patterns
 */
export async function scanForMaliciousContent(file: File): Promise<FileValidationResult> {
  try {
    // Only scan text-based files and images (where scripts could be embedded)
    const shouldScan = file.type.includes('text') || 
                       file.type.includes('image') || 
                       file.type.includes('html') ||
                       file.type.includes('xml') ||
                       file.type.includes('svg');

    if (!shouldScan) {
      return { valid: true };
    }

    // Read file as text
    const text = await file.text();
    const warnings: string[] = [];

    // Check for malicious patterns
    for (const pattern of MALICIOUS_PATTERNS) {
      if (pattern.test(text)) {
        warnings.push(`Suspicious pattern detected: ${pattern.source}`);
      }
    }

    if (warnings.length > 0) {
      return {
        valid: false,
        error: 'File contains potentially malicious content',
        warnings,
      };
    }

    return { valid: true };
  } catch (error) {
    // If we can't read the file as text (binary files), that's okay
    return { valid: true };
  }
}

/**
 * Validates file size against limit
 */
export function validateFileSize(file: File, maxSizeMB: number = 5): FileValidationResult {
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  
  if (file.size > maxSizeBytes) {
    return {
      valid: false,
      error: `File size (${(file.size / 1024 / 1024).toFixed(2)}MB) exceeds maximum allowed size of ${maxSizeMB}MB`,
    };
  }

  return { valid: true };
}

/**
 * Comprehensive file validation
 */
export async function validateFile(file: File, maxSizeMB: number = 5): Promise<FileValidationResult> {
  // Check file size
  const sizeValidation = validateFileSize(file, maxSizeMB);
  if (!sizeValidation.valid) {
    return sizeValidation;
  }

  // Validate file signature
  const signatureValidation = await validateFileSignature(file);
  if (!signatureValidation.valid) {
    return signatureValidation;
  }

  // Scan for malicious content
  const contentValidation = await scanForMaliciousContent(file);
  if (!contentValidation.valid) {
    return contentValidation;
  }

  // Combine warnings if any
  const warnings = [
    ...(signatureValidation.warnings || []),
    ...(contentValidation.warnings || []),
  ];

  return {
    valid: true,
    warnings: warnings.length > 0 ? warnings : undefined,
  };
}
