/**
 * Get the UTC offset in minutes for a given IANA timezone at a specific date.
 * Returns positive for east of UTC (e.g., +240 for UTC+4).
 */
export function getTimezoneOffsetMinutes(timezone: string, date: Date = new Date()): number {
  try {
    // Format the date in the target timezone and in UTC, then compute the difference
    const utcDate = new Date(date.toLocaleString("en-US", { timeZone: "UTC" }));
    const tzDate = new Date(date.toLocaleString("en-US", { timeZone: timezone }));
    return (tzDate.getTime() - utcDate.getTime()) / (1000 * 60);
  } catch {
    // Fallback: assume UTC+4 for Asia/Yerevan
    return 240;
  }
}

/**
 * Convert a local time string (HH:MM) in a given timezone to a UTC Date on the same calendar day as refDate.
 * refDate should be a UTC timestamp (e.g., clock-in time).
 */
export function localTimeToUTC(
  timeStr: string,
  timezone: string,
  refDate: Date
): Date {
  const [hours, minutes] = timeStr.split(":").map(Number);
  const offsetMinutes = getTimezoneOffsetMinutes(timezone, refDate);

  const result = new Date(refDate);
  // Set the local time in UTC by subtracting the timezone offset
  result.setUTCHours(hours, minutes, 0, 0);
  // Adjust for timezone: local 11:00 at UTC+4 = 07:00 UTC
  result.setUTCMinutes(result.getUTCMinutes() - offsetMinutes);

  return result;
}
