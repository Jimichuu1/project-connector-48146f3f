import { formatInTimeZone } from 'date-fns-tz';
import { getCountryFromPhone } from './phoneCountryCode';

// Canadian area code to province mapping
const canadianAreaCodeToProvince: Record<string, string> = {
  // Ontario
  '416': 'Ontario', '647': 'Ontario', '437': 'Ontario', // Toronto
  '905': 'Ontario', '289': 'Ontario', '365': 'Ontario', // Greater Toronto Area
  '519': 'Ontario', '226': 'Ontario', '548': 'Ontario', // Southwestern Ontario
  '613': 'Ontario', '343': 'Ontario', '680': 'Ontario', // Eastern Ontario
  '705': 'Ontario', '249': 'Ontario', // Northern Ontario
  '807': 'Ontario', // Northwestern Ontario (Thunder Bay - Central Time)
  
  // Quebec
  '514': 'Quebec', '438': 'Quebec', // Montreal
  '450': 'Quebec', '579': 'Quebec', // Greater Montreal
  '418': 'Quebec', '581': 'Quebec', '367': 'Quebec', // Quebec City
  '819': 'Quebec', '873': 'Quebec', // Western Quebec
  
  // British Columbia
  '604': 'British Columbia', '778': 'British Columbia', '236': 'British Columbia', // Vancouver
  '250': 'British Columbia', '672': 'British Columbia', // Rest of BC
  
  // Alberta
  '403': 'Alberta', '587': 'Alberta', '825': 'Alberta', // Calgary
  '780': 'Alberta', // Edmonton
  '368': 'Alberta', // Province-wide overlay
  
  // Manitoba
  '204': 'Manitoba', '431': 'Manitoba',
  
  // Saskatchewan
  '306': 'Saskatchewan', '639': 'Saskatchewan',
  
  // Nova Scotia (shares 902 with PEI)
  '902': 'Nova Scotia', '782': 'Nova Scotia',
  
  // New Brunswick
  '506': 'New Brunswick',
  
  // Newfoundland and Labrador
  '709': 'Newfoundland',
  
  // Northwest Territories, Yukon, Nunavut
  '867': 'Northern Territories',
};

// Province to timezone mapping
const provinceToTimezone: Record<string, string> = {
  'Ontario': 'America/Toronto',
  'Quebec': 'America/Montreal',
  'British Columbia': 'America/Vancouver',
  'Alberta': 'America/Edmonton',
  'Manitoba': 'America/Winnipeg',
  'Saskatchewan': 'America/Regina',
  'Nova Scotia': 'America/Halifax',
  'New Brunswick': 'America/Moncton',
  'Newfoundland': 'America/St_Johns',
  'Northern Territories': 'America/Yellowknife',
};

// Comprehensive country to timezone mapping
const countryToTimezone: Record<string, string> = {
  // North America
  'United States': 'America/New_York',
  'Canada': 'America/Toronto', // Default for Canada, overridden by province
  'Mexico': 'America/Mexico_City',
  
  // Caribbean
  'Bahamas': 'America/Nassau',
  'Barbados': 'America/Barbados',
  'Jamaica': 'America/Jamaica',
  'Puerto Rico': 'America/Puerto_Rico',
  'Dominican Republic': 'America/Santo_Domingo',
  'Trinidad and Tobago': 'America/Port_of_Spain',
  'Cuba': 'America/Havana',
  'Haiti': 'America/Port-au-Prince',
  'Bermuda': 'Atlantic/Bermuda',
  'Cayman Islands': 'America/Cayman',
  'Turks and Caicos': 'America/Grand_Turk',
  'Antigua and Barbuda': 'America/Antigua',
  'Saint Lucia': 'America/St_Lucia',
  'Grenada': 'America/Grenada',
  'Saint Vincent and the Grenadines': 'America/St_Vincent',
  'Dominica': 'America/Dominica',
  'Saint Kitts and Nevis': 'America/St_Kitts',
  'Anguilla': 'America/Anguilla',
  'British Virgin Islands': 'America/Tortola',
  'US Virgin Islands': 'America/St_Thomas',
  'Montserrat': 'America/Montserrat',
  'Aruba': 'America/Aruba',
  'Curacao': 'America/Curacao',
  'Sint Maarten': 'America/Lower_Princes',
  'Guadeloupe': 'America/Guadeloupe',
  'Martinique': 'America/Martinique',
  
  // Central America
  'Belize': 'America/Belize',
  'Guatemala': 'America/Guatemala',
  'El Salvador': 'America/El_Salvador',
  'Honduras': 'America/Tegucigalpa',
  'Nicaragua': 'America/Managua',
  'Costa Rica': 'America/Costa_Rica',
  'Panama': 'America/Panama',
  
  // South America
  'Brazil': 'America/Sao_Paulo',
  'Argentina': 'America/Buenos_Aires',
  'Chile': 'America/Santiago',
  'Colombia': 'America/Bogota',
  'Peru': 'America/Lima',
  'Venezuela': 'America/Caracas',
  'Ecuador': 'America/Guayaquil',
  'Bolivia': 'America/La_Paz',
  'Paraguay': 'America/Asuncion',
  'Uruguay': 'America/Montevideo',
  'Guyana': 'America/Guyana',
  'Suriname': 'America/Paramaribo',
  'French Guiana': 'America/Cayenne',
  
  // Europe
  'United Kingdom': 'Europe/London',
  'Germany': 'Europe/Berlin',
  'France': 'Europe/Paris',
  'Spain': 'Europe/Madrid',
  'Italy': 'Europe/Rome',
  'Netherlands': 'Europe/Amsterdam',
  'Belgium': 'Europe/Brussels',
  'Switzerland': 'Europe/Zurich',
  'Austria': 'Europe/Vienna',
  'Poland': 'Europe/Warsaw',
  'Portugal': 'Europe/Lisbon',
  'Ireland': 'Europe/Dublin',
  'Greece': 'Europe/Athens',
  'Sweden': 'Europe/Stockholm',
  'Norway': 'Europe/Oslo',
  'Denmark': 'Europe/Copenhagen',
  'Finland': 'Europe/Helsinki',
  'Russia': 'Europe/Moscow',
  'Ukraine': 'Europe/Kiev',
  'Turkey': 'Europe/Istanbul',
  'Czech Republic': 'Europe/Prague',
  'Romania': 'Europe/Bucharest',
  'Hungary': 'Europe/Budapest',
  'Bulgaria': 'Europe/Sofia',
  'Croatia': 'Europe/Zagreb',
  'Serbia': 'Europe/Belgrade',
  'Slovakia': 'Europe/Bratislava',
  'Slovenia': 'Europe/Ljubljana',
  'Lithuania': 'Europe/Vilnius',
  'Latvia': 'Europe/Riga',
  'Estonia': 'Europe/Tallinn',
  'Bosnia and Herzegovina': 'Europe/Sarajevo',
  'North Macedonia': 'Europe/Skopje',
  'Albania': 'Europe/Tirane',
  'Montenegro': 'Europe/Podgorica',
  'Kosovo': 'Europe/Belgrade',
  'Moldova': 'Europe/Chisinau',
  'Belarus': 'Europe/Minsk',
  'Iceland': 'Atlantic/Reykjavik',
  'Luxembourg': 'Europe/Luxembourg',
  'Malta': 'Europe/Malta',
  'Cyprus': 'Asia/Nicosia',
  'Monaco': 'Europe/Monaco',
  'Andorra': 'Europe/Andorra',
  'Liechtenstein': 'Europe/Vaduz',
  'San Marino': 'Europe/San_Marino',
  'Gibraltar': 'Europe/Gibraltar',
  'Faroe Islands': 'Atlantic/Faroe',
  
  // Asia Pacific
  'Japan': 'Asia/Tokyo',
  'China': 'Asia/Shanghai',
  'South Korea': 'Asia/Seoul',
  'North Korea': 'Asia/Pyongyang',
  'India': 'Asia/Kolkata',
  'Australia': 'Australia/Sydney',
  'New Zealand': 'Pacific/Auckland',
  'Singapore': 'Asia/Singapore',
  'Hong Kong': 'Asia/Hong_Kong',
  'Taiwan': 'Asia/Taipei',
  'Thailand': 'Asia/Bangkok',
  'Malaysia': 'Asia/Kuala_Lumpur',
  'Indonesia': 'Asia/Jakarta',
  'Philippines': 'Asia/Manila',
  'Vietnam': 'Asia/Ho_Chi_Minh',
  'Pakistan': 'Asia/Karachi',
  'Bangladesh': 'Asia/Dhaka',
  'Sri Lanka': 'Asia/Colombo',
  'Nepal': 'Asia/Kathmandu',
  'Myanmar': 'Asia/Yangon',
  'Cambodia': 'Asia/Phnom_Penh',
  'Laos': 'Asia/Vientiane',
  'Brunei': 'Asia/Brunei',
  'Mongolia': 'Asia/Ulaanbaatar',
  'Macau': 'Asia/Macau',
  'Afghanistan': 'Asia/Kabul',
  'Bhutan': 'Asia/Thimphu',
  'Maldives': 'Indian/Maldives',
  'East Timor': 'Asia/Dili',
  
  // Middle East
  'United Arab Emirates': 'Asia/Dubai',
  'Saudi Arabia': 'Asia/Riyadh',
  'Israel': 'Asia/Jerusalem',
  'Qatar': 'Asia/Qatar',
  'Kuwait': 'Asia/Kuwait',
  'Bahrain': 'Asia/Bahrain',
  'Jordan': 'Asia/Amman',
  'Lebanon': 'Asia/Beirut',
  'Oman': 'Asia/Muscat',
  'Yemen': 'Asia/Aden',
  'Iraq': 'Asia/Baghdad',
  'Iran': 'Asia/Tehran',
  'Syria': 'Asia/Damascus',
  'Palestine': 'Asia/Gaza',
  
  // Central Asia
  'Kazakhstan': 'Asia/Almaty',
  'Uzbekistan': 'Asia/Tashkent',
  'Turkmenistan': 'Asia/Ashgabat',
  'Tajikistan': 'Asia/Dushanbe',
  'Kyrgyzstan': 'Asia/Bishkek',
  'Georgia': 'Asia/Tbilisi',
  'Armenia': 'Asia/Yerevan',
  'Azerbaijan': 'Asia/Baku',
  
  // Africa
  'South Africa': 'Africa/Johannesburg',
  'Egypt': 'Africa/Cairo',
  'Nigeria': 'Africa/Lagos',
  'Kenya': 'Africa/Nairobi',
  'Morocco': 'Africa/Casablanca',
  'Algeria': 'Africa/Algiers',
  'Tunisia': 'Africa/Tunis',
  'Libya': 'Africa/Tripoli',
  'Ghana': 'Africa/Accra',
  'Ethiopia': 'Africa/Addis_Ababa',
  'Tanzania': 'Africa/Dar_es_Salaam',
  'Uganda': 'Africa/Kampala',
  'Sudan': 'Africa/Khartoum',
  'Senegal': 'Africa/Dakar',
  'Ivory Coast': 'Africa/Abidjan',
  'Cameroon': 'Africa/Douala',
  'Zimbabwe': 'Africa/Harare',
  'Zambia': 'Africa/Lusaka',
  'Botswana': 'Africa/Gaborone',
  'Namibia': 'Africa/Windhoek',
  'Mauritius': 'Indian/Mauritius',
  'Madagascar': 'Indian/Antananarivo',
  'Angola': 'Africa/Luanda',
  'Mozambique': 'Africa/Maputo',
  'Rwanda': 'Africa/Kigali',
  'Malawi': 'Africa/Blantyre',
  'Mali': 'Africa/Bamako',
  'Burkina Faso': 'Africa/Ouagadougou',
  'Niger': 'Africa/Niamey',
  'Chad': 'Africa/Ndjamena',
  'Guinea': 'Africa/Conakry',
  'Sierra Leone': 'Africa/Freetown',
  'Liberia': 'Africa/Monrovia',
  'Togo': 'Africa/Lome',
  'Benin': 'Africa/Porto-Novo',
  'Gabon': 'Africa/Libreville',
  'Republic of the Congo': 'Africa/Brazzaville',
  'Democratic Republic of the Congo': 'Africa/Kinshasa',
  'Somalia': 'Africa/Mogadishu',
  'Djibouti': 'Africa/Djibouti',
  'Eritrea': 'Africa/Asmara',
  'Burundi': 'Africa/Bujumbura',
  'Lesotho': 'Africa/Maseru',
  'Eswatini': 'Africa/Mbabane',
  'Comoros': 'Indian/Comoro',
  'Seychelles': 'Indian/Mahe',
  'Reunion': 'Indian/Reunion',
  'Mauritania': 'Africa/Nouakchott',
  'Gambia': 'Africa/Banjul',
  'Guinea-Bissau': 'Africa/Bissau',
  'Cape Verde': 'Atlantic/Cape_Verde',
  'Sao Tome and Principe': 'Africa/Sao_Tome',
  'Equatorial Guinea': 'Africa/Malabo',
  'Central African Republic': 'Africa/Bangui',
  
  // Pacific Islands
  'Fiji': 'Pacific/Fiji',
  'Papua New Guinea': 'Pacific/Port_Moresby',
  'Samoa': 'Pacific/Apia',
  'Tonga': 'Pacific/Tongatapu',
  'Vanuatu': 'Pacific/Efate',
  'Solomon Islands': 'Pacific/Guadalcanal',
  'New Caledonia': 'Pacific/Noumea',
  'French Polynesia': 'Pacific/Tahiti',
  'Guam': 'Pacific/Guam',
  'Northern Mariana Islands': 'Pacific/Saipan',
  'American Samoa': 'Pacific/Pago_Pago',
  'Kiribati': 'Pacific/Tarawa',
  'Marshall Islands': 'Pacific/Majuro',
  'Micronesia': 'Pacific/Pohnpei',
  'Palau': 'Pacific/Palau',
  'Nauru': 'Pacific/Nauru',
  'Tuvalu': 'Pacific/Funafuti',
  'Cook Islands': 'Pacific/Rarotonga',
  'Niue': 'Pacific/Niue',
  'Norfolk Island': 'Pacific/Norfolk',
  'Wallis and Futuna': 'Pacific/Wallis',
  'Tokelau': 'Pacific/Fakaofo',
  
  // Other territories
  'Greenland': 'America/Nuuk',
  'Saint Pierre and Miquelon': 'America/Miquelon',
  'Falkland Islands': 'Atlantic/Stanley',
  'Saint Helena': 'Atlantic/St_Helena',
  'Ascension Island': 'Atlantic/St_Helena',
  'British Indian Ocean Territory': 'Indian/Chagos',
};

/**
 * Extract Canadian area code from phone number
 */
function getCanadianAreaCode(phone: string): string | null {
  const digits = phone.replace(/[^\d]/g, '');
  
  // Canadian numbers start with 1 followed by area code
  if (digits.startsWith('1') && digits.length >= 4) {
    return digits.substring(1, 4);
  }
  
  // If no country code, assume first 3 digits are area code
  if (digits.length >= 3 && !digits.startsWith('1')) {
    return digits.substring(0, 3);
  }
  
  return null;
}

/**
 * Get province from Canadian phone number
 */
export function getProvinceFromPhone(phone: string | null | undefined): string | null {
  if (!phone) return null;
  
  const areaCode = getCanadianAreaCode(phone);
  if (!areaCode) return null;
  
  return canadianAreaCodeToProvince[areaCode] || null;
}

/**
 * Get timezone from phone number
 * For Canadian numbers, uses province-specific timezone
 */
export function getTimezoneFromPhone(phone: string | null | undefined): string | null {
  if (!phone) return null;
  
  const country = getCountryFromPhone(phone);
  if (!country) return null;
  
  // Special handling for Canada - use province-specific timezone
  if (country === 'Canada') {
    const province = getProvinceFromPhone(phone);
    if (province && provinceToTimezone[province]) {
      return provinceToTimezone[province];
    }
    // Fall back to Toronto timezone for Canada
    return 'America/Toronto';
  }
  
  return countryToTimezone[country] || null;
}

/**
 * Get formatted local time from phone number
 * Returns time in HH:mm format (e.g., "14:32")
 */
export function getLocalTimeFromPhone(phone: string | null | undefined): string | null {
  const timezone = getTimezoneFromPhone(phone);
  if (!timezone) return null;
  
  try {
    return formatInTimeZone(new Date(), timezone, 'HH:mm');
  } catch {
    return null;
  }
}

/**
 * Get timezone info object from phone number
 * Useful for displaying additional context
 */
export function getTimezoneInfoFromPhone(phone: string | null | undefined): { 
  timezone: string | null; 
  province: string | null;
  country: string | null;
} {
  const country = getCountryFromPhone(phone);
  const province = country === 'Canada' ? getProvinceFromPhone(phone) : null;
  const timezone = getTimezoneFromPhone(phone);
  
  return { timezone, province, country };
}
