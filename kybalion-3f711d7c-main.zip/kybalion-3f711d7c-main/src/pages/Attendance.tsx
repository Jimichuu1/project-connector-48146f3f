import { useState, useMemo, useEffect, useCallback } from "react";
import { format } from "date-fns";
import { Clock, Calendar, CheckCircle, XCircle, AlertCircle, Building2, DollarSign, User, RotateCcw, PartyPopper } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { TableX } from "@/components/ui/table-x";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ColumnDef } from "@tanstack/react-table";
import { useAttendance } from "@/hooks/useAttendance";
import { AttendanceDateFilter, DateRange } from "@/components/attendance/AttendanceDateFilter";
import { WorkingHoursSettings } from "@/components/attendance/WorkingHoursSettings";
import { TopTenantsBanner } from "@/components/attendance/TopTenantsBanner";
import { AgentMonthlyFeesSummary } from "@/components/attendance/AgentMonthlyFeesSummary";
import { BreakTimeCounter } from "@/components/attendance/BreakTimeCounter";
import type { Attendance, AttendanceWithProfile, TenantSettings } from "@/types/attendance";
import { SearchFilter } from "@/components/filters/SearchFilter";
import { MultiSelectFilter } from "@/components/filters/MultiSelectFilter";
import { useTenant } from "@/contexts/TenantContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { useUserData } from "@/contexts/UserDataContext";
import { useServerNow, getServerToday } from "@/hooks/useServerNow";
import { useUserPreferences } from "@/hooks/useUserPreferences";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

function ReleaseFeeDialog({
  open,
  onOpenChange,
  lateFee,
  breakFee,
  onRelease,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lateFee: number;
  breakFee: number;
  onRelease: (categories: ('late' | 'break')[]) => Promise<void>;
}) {
  const [selectedCategories, setSelectedCategories] = useState<('late' | 'break')[]>([]);
  const [isReleasing, setIsReleasing] = useState(false);

  const toggleCategory = (cat: 'late' | 'break') => {
    setSelectedCategories(prev =>
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const handleRelease = async () => {
    if (selectedCategories.length === 0) return;
    setIsReleasing(true);
    try {
      await onRelease(selectedCategories);
      onOpenChange(false);
      setSelectedCategories([]);
    } finally {
      setIsReleasing(false);
    }
  };

  // Reset selections when dialog opens
  useEffect(() => {
    if (open) setSelectedCategories([]);
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Release Fees</DialogTitle>
          <DialogDescription>
            Select which fees to release for this record.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-4">
          {lateFee > 0 && (
            <label className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors">
              <Checkbox
                checked={selectedCategories.includes('late')}
                onCheckedChange={() => toggleCategory('late')}
              />
              <div className="flex-1">
                <div className="font-medium text-sm">Late Fee</div>
                <div className="text-xs text-muted-foreground">Fee for late clock-in</div>
              </div>
              <span className="text-destructive font-medium">${lateFee}</span>
            </label>
          )}
          {breakFee > 0 && (
            <label className="flex items-center gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors">
              <Checkbox
                checked={selectedCategories.includes('break')}
                onCheckedChange={() => toggleCategory('break')}
              />
              <div className="flex-1">
                <div className="font-medium text-sm">Break Fee</div>
                <div className="text-xs text-muted-foreground">Fee for excessive break time</div>
              </div>
              <span className="text-destructive font-medium">${breakFee}</span>
            </label>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleRelease}
            disabled={selectedCategories.length === 0 || isReleasing}
          >
            <DollarSign className="h-4 w-4 mr-1" />
            {isReleasing ? "Releasing..." : `Release Selected ($${
              selectedCategories.reduce((sum, cat) => sum + (cat === 'late' ? lateFee : breakFee), 0)
            })`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ReleaseFeeButton({
  attendanceId,
  releaseFee,
  lateFee = 0,
  breakFee = 0,
}: {
  attendanceId: string;
  releaseFee: (id: string, categories?: ('late' | 'break')[]) => Promise<void>;
  lateFee?: number;
  breakFee?: number;
}) {
  const [isReleasing, setIsReleasing] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  const feeCount = (lateFee > 0 ? 1 : 0) + (breakFee > 0 ? 1 : 0);

  const handleClick = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();

    // Multiple fee categories → show dialog
    if (feeCount >= 2) {
      setDialogOpen(true);
      return;
    }

    // Single fee category → release directly
    setIsReleasing(true);
    try {
      await releaseFee(attendanceId);
    } catch (err) {
      console.error('[ReleaseFee Button] Error:', err);
    } finally {
      setIsReleasing(false);
    }
  }, [attendanceId, releaseFee, feeCount]);

  const handleDialogRelease = useCallback(async (categories: ('late' | 'break')[]) => {
    await releaseFee(attendanceId, categories);
  }, [attendanceId, releaseFee]);

  return (
    <>
      <Button 
        variant="outline" 
        size="sm" 
        disabled={isReleasing}
        onClick={handleClick}
        onPointerDown={(e) => e.stopPropagation()}
        className="bg-muted/50 hover:bg-muted relative z-10"
      >
        <DollarSign className="h-4 w-4 mr-1" />
        {isReleasing ? "Releasing..." : "Release Fee"}
      </Button>
      <ReleaseFeeDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        lateFee={lateFee}
        breakFee={breakFee}
        onRelease={handleDialogRelease}
      />
    </>
  );
}

function RestoreFeeButton({ attendanceId, restoreFee }: { attendanceId: string; restoreFee: (id: string) => Promise<void> }) {
  const [isRestoring, setIsRestoring] = useState(false);

  const handleClick = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsRestoring(true);
    try {
      await restoreFee(attendanceId);
    } catch (err) {
      console.error('[RestoreFee Button] Error:', err);
    } finally {
      setIsRestoring(false);
    }
  }, [attendanceId, restoreFee]);

  return (
    <Button 
      variant="ghost" 
      size="sm" 
      disabled={isRestoring}
      onClick={handleClick}
      onPointerDown={(e) => e.stopPropagation()}
      className="relative z-10 px-2"
    >
      <RotateCcw className="h-4 w-4 mr-1" />
      {isRestoring ? "Restoring..." : "Restore Fee"}
    </Button>
  );
}

export default function AttendancePage() {
  // Use server time instead of device time to ensure consistent "today" across devices
  const { serverNow, isLoading: isServerTimeLoading } = useServerNow();
  const { preferences } = useUserPreferences();
  
  // Get "today" based on server time and user's timezone preference
  const getServerBasedToday = useCallback(() => {
    return getServerToday(serverNow, preferences.timezone);
  }, [serverNow, preferences.timezone]);

  const [dateRange, setDateRange] = useState<DateRange>(() => {
    // Initial state defaults to current month (1st of month to today)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    startOfMonth.setHours(0, 0, 0, 0);
    return { from: startOfMonth, to: today };
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAgentIds, setSelectedAgentIds] = useState<string[]>([]);
  const { isSuperAdmin: isSuperAdminContext, effectiveTenantId } = useTenant();
  const { isManager, isTenantOwner, isSuperAdmin: isSuperAdminRole } = useUserData();
  const canReleaseFee = isSuperAdminRole || isTenantOwner || isManager;
  const { teamMemberIds, isLoading: isManagerTeamLoading } = useManagerTeam();
  
  const {
    attendance,
    allAttendance,
    tenantGroups,
    todayAttendance,
    loading,
    isAdmin,
    isSuperAdmin,
    settings,
    clockIn,
    clockOut,
    calculateWorkingHours,
    releaseFee,
    restoreFee,
  } = useAttendance(dateRange, {
    teamMemberIds: isManager ? teamMemberIds : undefined
  });
  const [isClockingIn, setIsClockingIn] = useState(false);
  const [isClockingOut, setIsClockingOut] = useState(false);
  const [holidayDates, setHolidayDates] = useState<Set<string>>(new Set());
  const [togglingHoliday, setTogglingHoliday] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch holiday dates from admin_settings
  useEffect(() => {
    if (!effectiveTenantId) return;
    const fetchHolidays = async () => {
      const { data } = await supabase
        .from("admin_settings")
        .select("holiday_dates")
        .eq("admin_id", effectiveTenantId)
        .maybeSingle();
      if (data) {
        setHolidayDates(new Set((data as any).holiday_dates || []));
      }
    };
    fetchHolidays();
  }, [effectiveTenantId]);

  const toggleHoliday = useCallback(async (date: string) => {
    if (!effectiveTenantId) return;
    setTogglingHoliday(date);
    try {
      const newSet = new Set(holidayDates);
      if (newSet.has(date)) {
        newSet.delete(date);
      } else {
        newSet.add(date);
      }
      const newArray = Array.from(newSet).sort();
      
      const { error } = await supabase
        .from("admin_settings")
        .update({ holiday_dates: newArray } as any)
        .eq("admin_id", effectiveTenantId);
      
      if (error) throw error;
      
      setHolidayDates(newSet);
      toast({ title: newSet.has(date) ? "Day marked as holiday" : "Holiday removed" });
      // Trigger attendance refetch by updating date range
      setDateRange(prev => ({ ...prev }));
    } catch (err) {
      console.error("Failed to toggle holiday:", err);
      toast({ title: "Failed to update holiday", variant: "destructive" });
    } finally {
      setTogglingHoliday(null);
    }
  }, [effectiveTenantId, holidayDates, toast]);

  // Sync dateRange to server time once it loads (fixes stale device clock)
  useEffect(() => {
    if (!serverNow) return;
    
    const serverToday = getServerBasedToday();
    const currentFrom = new Date(dateRange.from);
    currentFrom.setHours(0, 0, 0, 0);
    
    // Only update if viewing single day and date differs from server today
    if (serverToday.getTime() !== currentFrom.getTime() && 
        dateRange.from.toDateString() === dateRange.to.toDateString()) {
      console.log('[Attendance] Syncing to server time:', {
        deviceDate: currentFrom.toDateString(),
        serverDate: serverToday.toDateString()
      });
      setDateRange({ from: serverToday, to: serverToday });
    }
  }, [serverNow, preferences.timezone, getServerBasedToday]);

  // Auto-update date when tab becomes visible (uses server time)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && serverNow) {
        const today = getServerBasedToday();
        const currentFrom = new Date(dateRange.from);
        currentFrom.setHours(0, 0, 0, 0);
        
        // If the date has changed and we're viewing a single day, reset to actual today
        if (today.getTime() !== currentFrom.getTime() && 
            dateRange.from.toDateString() === dateRange.to.toDateString()) {
          setDateRange({ from: today, to: today });
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [dateRange.from, dateRange.to, serverNow, getServerBasedToday]);

  // Periodic check for midnight crossing (uses server time, every 60 seconds)
  useEffect(() => {
    const checkDateChange = () => {
      if (!serverNow) return;
      
      const today = getServerBasedToday();
      const currentFrom = new Date(dateRange.from);
      currentFrom.setHours(0, 0, 0, 0);
      
      // Only auto-update if showing single day (likely "today")
      if (today.getTime() !== currentFrom.getTime() && 
          dateRange.from.toDateString() === dateRange.to.toDateString()) {
        setDateRange({ from: today, to: today });
      }
    };

    const interval = setInterval(checkDateChange, 60000);
    return () => clearInterval(interval);
  }, [dateRange.from, dateRange.to, serverNow, getServerBasedToday]);

  const handleClockIn = async () => {
    setIsClockingIn(true);
    await clockIn();
    setIsClockingIn(false);
  };

  const handleClockOut = async () => {
    setIsClockingOut(true);
    await clockOut();
    setIsClockingOut(false);
  };

  const formatTime = (timestamp: string | null) => {
    if (!timestamp) return "-";
    const date = new Date(timestamp);
    if (isNaN(date.getTime())) return "-";
    return format(date, "h:mm a");
  };

  const formatDate = (date: string) => {
    return format(new Date(date), "MMM dd, yyyy");
  };

  // Agent View Columns
  const agentColumns: ColumnDef<Attendance>[] = [{
    accessorKey: "date",
    header: "Date",
    cell: ({ row }) => formatDate(row.original.date)
  }, {
    accessorKey: "clock_in",
    header: "Clock In",
    cell: ({ row }) => {
      if (row.original.notes?.includes("Day off") || row.original.notes === "Weekend") {
        return <span className="text-muted-foreground">-</span>;
      }
      return formatTime(row.original.clock_in);
    }
  }, {
    accessorKey: "clock_out",
    header: "Clock Out",
    cell: ({ row }) => {
      if (row.original.notes?.includes("Day off") || row.original.notes === "Weekend") {
        return <span className="text-muted-foreground">-</span>;
      }
      return (
        <span className={row.original.clock_out ? "text-foreground" : "text-muted-foreground"}>
          {row.original.clock_out ? formatTime(row.original.clock_out) : "Not clocked out"}
        </span>
      );
    }
  }, {
    accessorKey: "working_hours",
    header: "Working Hours",
    cell: ({ row }) => {
      const hours = calculateWorkingHours(row.original.clock_in, row.original.clock_out);
      return hours ? `${hours.toFixed(2)} hrs` : "-";
    }
  }, {
    accessorKey: "notes",
    header: "Notes",
    cell: ({ row }) => <span className="text-muted-foreground">{row.original.notes || "-"}</span>
  }];

  // Admin View Columns (without tenant column for grouped view)
  const getAdminColumns = (showTenantColumn: boolean): ColumnDef<AttendanceWithProfile>[] => [
    ...(showTenantColumn ? [] : []),
    {
      accessorKey: "profiles.full_name",
      header: "Agent",
      cell: ({ row }: { row: { original: AttendanceWithProfile } }) => (
        <div>
          <div className="font-medium">{row.original.profiles.full_name || "N/A"}</div>
          <div className="text-xs text-muted-foreground">{row.original.profiles.email}</div>
        </div>
      )
    }, {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        if (row.original.notes === "Holiday") {
          return (
            <Badge variant="secondary" className="gap-1 bg-primary/10 text-primary border-primary/30">
              <Calendar className="h-3 w-3" />
              Holiday
            </Badge>
          );
        }
        if (row.original.notes?.includes("Day off")) {
          const isHonorable = row.original.notes?.includes("Honorable");
          return (
            <Badge variant={isHonorable ? "secondary" : "destructive"} className="gap-1">
              <AlertCircle className="h-3 w-3" />
              {isHonorable ? "Day Off (H)" : "Day Off"}
            </Badge>
          );
        }
        if (row.original.clock_out) {
          return <Badge variant="default">Completed</Badge>;
        }
        // Check if on break (clocked in, not clocked out, but working_started_at is null)
        if (!row.original.working_started_at) {
          return (
            <Badge variant="secondary" className="gap-1 bg-amber-500/20 text-amber-600 border-amber-500/30">
              <Clock className="h-3 w-3" />
              On Break
            </Badge>
          );
        }
        return <Badge variant="outline">Working</Badge>;
      }
    }, {
    accessorKey: "clock_in",
    header: "Clock In",
    cell: ({ row }) => {
      if (row.original.notes?.includes("Day off") || row.original.notes === "Weekend") {
        return <span className="text-muted-foreground">-</span>;
      }
      return (
        <div>
          <div>{formatTime(row.original.clock_in)}</div>
          {row.original.is_late && <div className="text-xs text-destructive">Late</div>}
        </div>
      );
    }
  }, {
    accessorKey: "clock_out",
    header: "Clock Out",
    cell: ({ row }) => {
      if (row.original.notes?.includes("Day off") || row.original.notes === "Weekend") {
        return <span className="text-muted-foreground">-</span>;
      }
      return (
        <span className={row.original.clock_out ? "text-foreground" : "text-muted-foreground"}>
          {row.original.clock_out ? formatTime(row.original.clock_out) : "Not clocked out"}
        </span>
      );
    }
    }, {
    accessorKey: "working_hours",
    header: "Working Hours",
    cell: ({ row }) => {
      if (row.original.notes?.includes("Day off") || row.original.notes === "Weekend") {
        return <span className="text-muted-foreground">-</span>;
      }
      const hours = calculateWorkingHours(row.original.clock_in, row.original.clock_out);
      return hours ? `${hours.toFixed(2)} hrs` : "-";
    }
    }, {
      accessorKey: "break_minutes",
      header: "Break Time",
      cell: ({ row }) => (
        <BreakTimeCounter
          clockIn={row.original.clock_in}
          clockOut={row.original.clock_out}
          workingStartedAt={row.original.working_started_at || null}
          workingPeriods={row.original.working_periods || null}
          breakMinutes={row.original.break_minutes || 0}
          isDayOff={!!row.original.notes?.includes("Day off")}
          maxBreakMinutes={settings?.max_break_minutes || 60}
        />
      )
    }, {
    id: "total_fees",
      header: "Fees",
      cell: ({ row }) => {
        const totalFees = row.original.total_fees || 0;
        const releasedFees = (row.original as AttendanceWithProfile & { released_fees?: number }).released_fees || 0;
        
        if (totalFees === 0 && releasedFees === 0) return <span className="text-muted-foreground">-</span>;
        
        return (
          <div className="space-y-0.5">
            {totalFees > 0 ? (
              <span className="text-destructive font-medium">${totalFees}</span>
            ) : null}
            {releasedFees > 0 && (
              <div className="text-xs text-muted-foreground">
                Released (${releasedFees})
              </div>
            )}
          </div>
        );
      }
    },
    ...(canReleaseFee ? [{
      id: "actions",
      header: "Actions",
      cell: ({ row }: { row: { original: AttendanceWithProfile } }) => {
        const hasFees = (row.original.total_fees || 0) > 0;
        const hasReleasedFees = ((row.original as AttendanceWithProfile & { released_fees?: number }).released_fees || 0) > 0;
        const isWeekend = row.original.id?.startsWith('weekend-');
        
        if (isWeekend || (!hasFees && !hasReleasedFees)) return <span></span>;
        
        return (
          <div className="flex gap-1">
            {hasFees && (
              <ReleaseFeeButton 
                attendanceId={row.original.id}
                releaseFee={releaseFee}
                lateFee={row.original.late_start_fee || 0}
                breakFee={row.original.break_time_fee || 0}
              />
            )}
            {hasReleasedFees && !hasFees && (
              <RestoreFeeButton 
                attendanceId={row.original.id}
                restoreFee={restoreFee}
              />
            )}
          </div>
        );
      }
    }] : [])
  ];

  const adminColumns = useMemo(() => getAdminColumns(false), [canReleaseFee, releaseFee, restoreFee, settings, calculateWorkingHours]);

  // Build unique agent options for the filter
  const agentOptions = useMemo(() => {
    const map = new Map<string, string>();
    allAttendance.forEach(record => {
      if (!map.has(record.user_id)) {
        map.set(record.user_id, record.profiles.full_name || record.profiles.email);
      }
    });
    return Array.from(map.entries())
      .map(([id, name]) => ({ value: id, label: name }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [allAttendance]);

  const toggleAgent = useCallback((agentId: string) => {
    setSelectedAgentIds(prev => 
      prev.includes(agentId) ? prev.filter(id => id !== agentId) : [...prev, agentId]
    );
  }, []);

  // Filter attendance by search query and selected agents
  const filteredAttendance = useMemo(() => {
    let filtered = allAttendance;
    if (selectedAgentIds.length > 0) {
      filtered = filtered.filter(record => selectedAgentIds.includes(record.user_id));
    }
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(record => 
        record.profiles.full_name?.toLowerCase().includes(query) || 
        record.profiles.email.toLowerCase().includes(query)
      );
    }
    return filtered;
  }, [allAttendance, searchQuery, selectedAgentIds]);

  // Group attendance by date for admin view
  const groupedAttendance = filteredAttendance.reduce((acc, record) => {
    const date = record.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(record);
    return acc;
  }, {} as Record<string, AttendanceWithProfile[]>);

  const sortedDates = Object.keys(groupedAttendance).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  );

  const isSingleDay = dateRange.from.toDateString() === dateRange.to.toDateString();

  const normalizeTimeValue = (value: unknown): string | null => {
    if (typeof value !== "string") return null;
    const [hours, minutes] = value.split(":");
    if (hours == null || minutes == null) return null;
    const h = Number(hours);
    const m = Number(minutes);
    if (!Number.isFinite(h) || !Number.isFinite(m)) return null;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  };

  const snapshotToSettings = (snapshot: Attendance["rule_snapshot"] | null | undefined): TenantSettings | null => {
    if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) return null;
    const source = snapshot as Record<string, unknown>;
    const workStart = normalizeTimeValue(source.work_start_time);
    const workEnd = normalizeTimeValue(source.work_end_time);
    if (!workStart || !workEnd) return null;

    return {
      work_start_time: workStart,
      work_end_time: workEnd,
      late_start_fee: Number(source.late_start_fee) || 0,
      excessive_break_fee: Number(source.excessive_break_fee) || 0,
      day_off_fee: Number(source.day_off_fee) || 0,
      max_break_minutes: Number(source.max_break_minutes) || 60,
      monthly_honorable_absences: Number(source.monthly_honorable_absences) || 0,
    };
  };

  const getAppliedSettingsForRecords = (records: AttendanceWithProfile[]): TenantSettings => {
    for (const record of records) {
      const parsed = snapshotToSettings(record.rule_snapshot);
      if (parsed) return parsed;
    }
    return settings;
  };

  // Render settings bar
  const renderSettingsBar = (tenantSettings: TenantSettings) => (
    <div className="p-2.5 bg-muted/50 rounded-md">
      <div className="text-xs font-medium mb-1.5">Applied Rules</div>
      <div className="grid grid-cols-4 gap-3 text-xs">
        <div>
          <span className="text-muted-foreground">Working Hours:</span>
          <span className="ml-1.5 font-medium">{tenantSettings.work_start_time} - {tenantSettings.work_end_time}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Late Fee:</span>
          <span className="ml-1.5 font-medium text-destructive">${tenantSettings.late_start_fee}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Break Fee:</span>
          <span className="ml-1.5 font-medium text-destructive">${tenantSettings.excessive_break_fee}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Day Off Fee:</span>
          <span className="ml-1.5 font-medium text-destructive">${tenantSettings.day_off_fee}</span>
        </div>
      </div>
    </div>
  );

  // Wait for manager team data to load before rendering
  if (loading || (isManager && isManagerTeamLoading)) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  return (
    <div className="pb-8 space-y-6">
      <div className="space-y-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Attendance</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {isAdmin ? "View all agents' attendance records" : "Track your daily working hours"}
          </p>
        </div>
        {isAdmin && !isSuperAdmin && <WorkingHoursSettings />}
        {isSuperAdmin && <TopTenantsBanner />}
        {isAdmin && !isSuperAdmin && <AgentMonthlyFeesSummary attendance={filteredAttendance} dateRange={dateRange} monthlyHonorableAbsences={settings.monthly_honorable_absences} />}
      </div>

      {!isAdmin && (
        <>
          {/* Today's Status Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Today's Status
              </CardTitle>
              <CardDescription>{format(getServerBasedToday(), "EEEE, MMMM dd, yyyy")}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!todayAttendance ? (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>You haven't clocked in today yet.</AlertDescription>
                </Alert>
              ) : (
                <div className="grid gap-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <div>
                        <div className="font-medium">Clocked In</div>
                        <div className="text-sm text-muted-foreground">
                          {formatTime(todayAttendance.clock_in)}
                        </div>
                      </div>
                    </div>
                  </div>

                  {todayAttendance.clock_out ? (
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <XCircle className="h-5 w-5 text-red-500" />
                        <div>
                          <div className="font-medium">Clocked Out</div>
                          <div className="text-sm text-muted-foreground">
                            {formatTime(todayAttendance.clock_out)}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground">Working Hours</div>
                        <div className="text-xl font-bold">
                          {calculateWorkingHours(todayAttendance.clock_in, todayAttendance.clock_out)?.toFixed(2)} hrs
                        </div>
                      </div>
                    </div>
                  ) : (
                    <Alert>
                      <Clock className="h-4 w-4" />
                      <AlertDescription>You are currently clocked in.</AlertDescription>
                    </Alert>
                  )}
                </div>
              )}

              <div className="flex gap-2">
                {!todayAttendance && (
                  <Button size="sm" onClick={handleClockIn} disabled={isClockingIn} className="flex-1">
                    {isClockingIn ? "Clocking In..." : "Clock In"}
                  </Button>
                )}
                {todayAttendance && !todayAttendance.clock_out && (
                  <Button size="sm" variant="destructive" onClick={handleClockOut} disabled={isClockingOut} className="flex-1">
                    {isClockingOut ? "Clocking Out..." : "Clock Out"}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Agent's History */}
          <Card>
            <CardHeader>
              <CardTitle>My Attendance History</CardTitle>
              <CardDescription>View your past attendance records</CardDescription>
            </CardHeader>
            <CardContent>
              <DataTable columns={agentColumns} data={attendance} searchKey="date" />
            </CardContent>
          </Card>
        </>
      )}

      {isAdmin && (
        <TableX 
          toolbar={
            <div className="flex items-center justify-between py-4">
              <div className="text-sm text-muted-foreground">
                {isSuperAdmin 
                  ? `${tenantGroups.length} tenant${tenantGroups.length !== 1 ? 's' : ''}`
                  : isSingleDay 
                    ? `${formatDate(sortedDates[0] || format(dateRange.from, "yyyy-MM-dd"))} - ${filteredAttendance.length} agent${filteredAttendance.length !== 1 ? 's' : ''}`
                    : `${sortedDates.length} day${sortedDates.length !== 1 ? 's' : ''} - ${filteredAttendance.length} total records`
                }
              </div>
              <div className="flex items-center gap-2">
                <MultiSelectFilter
                  icon={User}
                  label="Agent"
                  options={agentOptions}
                  selectedValues={selectedAgentIds}
                  onToggle={toggleAgent}
                />
                <SearchFilter value={searchQuery} onChange={setSearchQuery} placeholder="Search agents..." />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const today = getServerBasedToday();
                    setDateRange({ from: today, to: today });
                  }}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Today
                </Button>
                <AttendanceDateFilter value={dateRange} onChange={setDateRange} serverNow={serverNow} timezone={preferences.timezone} />
              </div>
            </div>
          }
        >
          {/* Super Admin View - Grouped by Tenant */}
          {isSuperAdmin && tenantGroups.length > 0 && (
            <div className="space-y-8">
              {tenantGroups.map(group => {
                // Filter group attendance by search query and selected agents
                let filteredGroupAttendance = group.attendance;
                if (selectedAgentIds.length > 0) {
                  filteredGroupAttendance = filteredGroupAttendance.filter(record => 
                    selectedAgentIds.includes(record.user_id)
                  );
                }
                if (searchQuery.trim()) {
                  filteredGroupAttendance = filteredGroupAttendance.filter(record => 
                    record.profiles.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) || 
                    record.profiles.email.toLowerCase().includes(searchQuery.toLowerCase())
                  );
                }

                if (filteredGroupAttendance.length === 0 && (searchQuery.trim() || selectedAgentIds.length > 0)) return null;

                return (
                  <div key={group.tenantId} className="space-y-4 border rounded-lg p-4">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-primary" />
                      <h2 className="text-lg font-semibold">{group.tenantName}</h2>
                      <Badge variant="secondary" className="ml-2">
                        {filteredGroupAttendance.length} record{filteredGroupAttendance.length !== 1 ? 's' : ''}
                      </Badge>
                    </div>
                    
                    {renderSettingsBar(isSingleDay ? getAppliedSettingsForRecords(filteredGroupAttendance) : group.settings)}
                    
                    <div className="rounded-md">
                      <DataTable 
                        columns={adminColumns} 
                        data={filteredGroupAttendance} 
                        hideColumnFilter 
                        hidePagination 
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Regular Admin/Tenant Owner View */}
          {!isSuperAdmin && (
            <>
              {isSingleDay ? (
                <div className="space-y-4">
                  {isTenantOwner && (
                    <div className="flex items-center justify-end gap-2">
                      <label className="flex items-center gap-2 cursor-pointer text-sm">
                        <Switch
                          checked={holidayDates.has(format(dateRange.from, "yyyy-MM-dd"))}
                          onCheckedChange={() => toggleHoliday(format(dateRange.from, "yyyy-MM-dd"))}
                          disabled={togglingHoliday === format(dateRange.from, "yyyy-MM-dd")}
                        />
                        <span className="text-muted-foreground">Holiday</span>
                      </label>
                      {holidayDates.has(format(dateRange.from, "yyyy-MM-dd")) && (
                        <Badge variant="secondary" className="gap-1 bg-primary/10 text-primary border-primary/30">
                          <PartyPopper className="h-3 w-3" />
                          Holiday
                        </Badge>
                      )}
                    </div>
                  )}
                  {renderSettingsBar(getAppliedSettingsForRecords(filteredAttendance))}
                  <div className="rounded-md">
                    <DataTable columns={adminColumns} data={filteredAttendance} hideColumnFilter hidePagination />
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {sortedDates.map(date => {
                    const dayRecords = groupedAttendance[date];
                    const hasFees = dayRecords.some(r => (r.total_fees || 0) > 0);
                    
                    const handleReleaseAllFees = async () => {
                      // Include day-off records, exclude only weekend records
                      const recordsWithFees = dayRecords.filter(r => 
                        (r.total_fees || 0) > 0 && 
                        !r.id?.startsWith('weekend-')
                      );
                      for (const record of recordsWithFees) {
                        await releaseFee(record.id);
                      }
                    };
                    
                    return (
                      <div key={date} className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div>
                              <h2 className="text-lg font-semibold">{formatDate(date)}</h2>
                              <p className="text-xs text-muted-foreground mt-0.5">
                                {dayRecords.length} agent{dayRecords.length !== 1 ? 's' : ''}
                              </p>
                            </div>
                            {holidayDates.has(date) && (
                              <Badge variant="secondary" className="gap-1 bg-primary/10 text-primary border-primary/30">
                                <PartyPopper className="h-3 w-3" />
                                Holiday
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            {isTenantOwner && (
                              <label className="flex items-center gap-2 cursor-pointer text-sm">
                                <Switch
                                  checked={holidayDates.has(date)}
                                  onCheckedChange={() => toggleHoliday(date)}
                                  disabled={togglingHoliday === date}
                                />
                                <span className="text-muted-foreground">Holiday</span>
                              </label>
                            )}
                            {canReleaseFee && hasFees && !holidayDates.has(date) && (
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={handleReleaseAllFees}
                                className="bg-muted/50 hover:bg-muted"
                              >
                                <DollarSign className="h-4 w-4 mr-1" />
                                Release All Fees
                              </Button>
                            )}
                          </div>
                        </div>
                        {renderSettingsBar(getAppliedSettingsForRecords(dayRecords))}
                        <div className="rounded-md">
                          <DataTable columns={adminColumns} data={dayRecords} hideColumnFilter hidePagination />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {((isSuperAdmin && tenantGroups.length === 0) || (!isSuperAdmin && sortedDates.length === 0)) && (
            <div className="py-8 text-center">
              <p className="text-muted-foreground">No attendance records found</p>
            </div>
          )}
        </TableX>
      )}
    </div>
  );
}
