import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { ReportsFilterBar } from "@/components/reports/ReportsFilterBar";
import { SalesReport } from "@/components/reports/SalesReport";
import { PipelineReport } from "@/components/reports/PipelineReport";
import { ConversionReport } from "@/components/reports/ConversionReport";
import { DepositsReport } from "@/components/reports/DepositsReport";
import { AgentReportView } from "@/components/reports/AgentReportView";
import { SuperAgentReportView } from "@/components/reports/SuperAgentReportView";
import { DailySummaryCards } from "@/components/reports/DailySummaryCards";
import { MonthlySummaryCards } from "@/components/reports/MonthlySummaryCards";
import { Download, FileText, FileSpreadsheet } from "lucide-react";
import { DateRange, ReportType } from "@/types/reports";
import { startOfMonth, endOfMonth } from "date-fns";
import { useReportsData } from "@/hooks/useReportsData";
import { useUserData } from "@/contexts/UserDataContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { toast } from "sonner";
import { exportConversionReportToCSV, exportConversionReportToExcel } from "@/lib/exportCsv";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";

export default function Reports() {
  const [dateRange, setDateRange] = useState<DateRange>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  });
  const [activeTab, setActiveTab] = useState<ReportType>("deposits");
  const { isAgent, isSuperAgent, isManager, isTeamLeader, isTenantOwner, isSuperAdmin, loading: roleLoading } = useUserData();
  const { 
    hasSuperAgents, 
    hasAgents, 
    teamMemberIds,
    isLoading: managerTeamLoading 
  } = useManagerTeam();
  
  const { 
    salesData, 
    salesLoading,
    pipelineData,
    pipelineLoading,
    conversionData,
    conversionLoading,
  } = useReportsData(dateRange.from, dateRange.to);

  // Determine what tabs manager can see
  const managerCanSeeSales = isManager && hasSuperAgents;
  const managerCanSeePipeline = isManager && hasSuperAgents;
  const managerCanSeeConversion = isManager && (hasAgents || hasSuperAgents);
  const managerCanSeeDeposits = isManager && hasSuperAgents;

  // Set default tab based on role and team
  useEffect(() => {
    if (!roleLoading && !managerTeamLoading) {
      if (isAgent || isSuperAgent || isTeamLeader) {
        setActiveTab("deposits");
      } else if (isManager) {
        // For managers, set default tab based on what they can see
        if (managerCanSeeDeposits) {
          setActiveTab("deposits");
        } else if (managerCanSeeConversion) {
          setActiveTab("conversion");
        } else {
          setActiveTab("deposits"); // Will show empty state
        }
      } else {
        setActiveTab("sales");
      }
    }
  }, [isAgent, isSuperAgent, isTeamLeader, isManager, roleLoading, managerTeamLoading, hasSuperAgents, hasAgents]);

  const handleExport = (format: 'pdf' | 'excel' | 'csv') => {
    if (activeTab === 'conversion' && conversionData) {
      if (format === 'csv') {
        exportConversionReportToCSV(conversionData);
      } else if (format === 'excel') {
        exportConversionReportToExcel(conversionData);
      } else {
        toast.info("PDF export coming soon");
      }
    } else {
      toast.info(`Export for ${activeTab} report coming soon`);
    }
  };

  if (roleLoading || managerTeamLoading) {
    return (
      <div className="pb-8 space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-6 w-96" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  // Agent view - own performance + team conversion metrics
  if (isAgent) {
    return (
      <div className="pb-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Reports</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Your deposit performance and team conversion metrics
          </p>
        </div>

        <ReportsFilterBar dateRange={dateRange} onDateRangeChange={setDateRange} />

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as ReportType)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="deposits">My Performance</TabsTrigger>
            <TabsTrigger value="conversion">Conversion Metrics</TabsTrigger>
          </TabsList>

          <TabsContent value="deposits" className="mt-6">
            <AgentReportView startDate={dateRange.from} endDate={dateRange.to} />
          </TabsContent>

          <TabsContent value="conversion" className="mt-6">
            <ConversionReport data={conversionData} isLoading={conversionLoading} />
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  // Team Leader view - own performance + team reports
  if (isTeamLeader) {
    const tlHasTeam = teamMemberIds.length > 0;

    return (
      <div className="pb-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Reports</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Your deposit performance and team overview
          </p>
        </div>

        <ReportsFilterBar dateRange={dateRange} onDateRangeChange={setDateRange} />

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as ReportType)}>
          <TabsList className={`grid w-full ${tlHasTeam ? "grid-cols-2" : "grid-cols-1"}`}>
            <TabsTrigger value="deposits">My Performance</TabsTrigger>
            {tlHasTeam && <TabsTrigger value="conversion">Team Conversions</TabsTrigger>}
          </TabsList>

          <TabsContent value="deposits" className="mt-6">
            <AgentReportView startDate={dateRange.from} endDate={dateRange.to} />
          </TabsContent>

          {tlHasTeam && (
            <TabsContent value="conversion" className="mt-6">
              <ConversionReport data={conversionData} isLoading={conversionLoading} />
            </TabsContent>
          )}

        </Tabs>
      </div>
    );
  }

  // Super Agent view - deposits and pipeline only
  if (isSuperAgent) {
    return (
      <div className="pb-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Reports</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Your deposit performance, earnings, and pipeline analysis
          </p>
        </div>

        <ReportsFilterBar dateRange={dateRange} onDateRangeChange={setDateRange} />

        <SuperAgentReportView startDate={dateRange.from} endDate={dateRange.to} />
      </div>
    );
  }

  // Manager view - show limited reports based on team composition
  if (isManager) {
    // Manager with no team at all
    if (!hasAgents && !hasSuperAgents) {
      return (
        <div className="pb-8 space-y-6">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Reports & Analytics</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Team performance insights and metrics
            </p>
          </div>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              No team members assigned. Add agents or super agents to your team to view reports.
            </AlertDescription>
          </Alert>
        </div>
      );
    }

    // Manager with team - show available tabs
    const availableTabs = [];
    if (managerCanSeeDeposits) availableTabs.push({ value: "deposits", label: "Deposits" });
    if (managerCanSeeSales) availableTabs.push({ value: "sales", label: "Sales Performance" });
    if (managerCanSeePipeline) availableTabs.push({ value: "pipeline", label: "Pipeline Analysis" });
    if (managerCanSeeConversion) availableTabs.push({ value: "conversion", label: "Conversion Metrics" });

    return (
      <div className="pb-8 space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Team Reports</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Performance insights for your team members
            </p>
          </div>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => handleExport('csv')}>
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </ButtonGroup>
        </div>

        <ReportsFilterBar dateRange={dateRange} onDateRangeChange={setDateRange} />

        {availableTabs.length > 0 ? (
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as ReportType)}>
            <TabsList className={`grid w-full grid-cols-${availableTabs.length}`}>
              {availableTabs.map(tab => (
                <TabsTrigger key={tab.value} value={tab.value}>{tab.label}</TabsTrigger>
              ))}
            </TabsList>

            {managerCanSeeSales && (
              <TabsContent value="sales" className="mt-6">
                <SalesReport data={salesData} isLoading={salesLoading} />
              </TabsContent>
            )}

            {managerCanSeePipeline && (
              <TabsContent value="pipeline" className="mt-6">
                <PipelineReport data={pipelineData} isLoading={pipelineLoading} />
              </TabsContent>
            )}

            {managerCanSeeConversion && (
              <TabsContent value="conversion" className="mt-6">
                <ConversionReport 
                  data={conversionData} 
                  isLoading={conversionLoading} 
                  showAgentConversions={hasAgents}
                />
              </TabsContent>
            )}

            {managerCanSeeDeposits && (
              <TabsContent value="deposits" className="mt-6">
                <DepositsReport startDate={dateRange.from} endDate={dateRange.to} />
              </TabsContent>
            )}
          </Tabs>
        ) : (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Add super agents to your team to access sales, pipeline and deposit reports.
            </AlertDescription>
          </Alert>
        )}
      </div>
    );
  }

  // Admin/Tenant Owner/Super Admin view - full reports
  const showDailySummary = isTenantOwner || isSuperAdmin;

  return (
    <div className="pb-8 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports & Analytics</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Comprehensive insights into sales performance and business metrics
          </p>
        </div>
        <ButtonGroup>
          <Button size="sm" variant="outline" onClick={() => handleExport('pdf')}>
            <FileText className="mr-2 h-4 w-4" />
            Export PDF
          </Button>
          <Button size="sm" variant="outline" onClick={() => handleExport('excel')}>
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Export Excel
          </Button>
          <Button size="sm" variant="outline" onClick={() => handleExport('csv')}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </ButtonGroup>
      </div>

      {showDailySummary && (
        <>
          <MonthlySummaryCards />
          <DailySummaryCards />
        </>
      )}

      <ReportsFilterBar dateRange={dateRange} onDateRangeChange={setDateRange} />

      <Tabs value={activeTab === "pipeline" || activeTab === "sales" ? "deposits" : activeTab} onValueChange={(v) => setActiveTab(v as ReportType)}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="deposits">Deposits</TabsTrigger>
          <TabsTrigger value="conversion">Conversion Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="conversion" className="mt-6">
          <ConversionReport data={conversionData} isLoading={conversionLoading} isTenantOwner={isTenantOwner} />
        </TabsContent>

        <TabsContent value="deposits" className="mt-6">
          <DepositsReport startDate={dateRange.from} endDate={dateRange.to} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
