import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { supabase } from "@/integrations/supabase/client";
import { useUserData } from "@/contexts/UserDataContext";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Users, Shield, UserCog, UserCheck, Building2, GripVertical, ArrowRight, Star } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { DroppableManagerColumn } from "@/components/team/DroppableManagerColumn";
import { UnassignedPool } from "@/components/team/UnassignedPool";
import { DragOverlayContent } from "@/components/team/DraggableTeamMember";

interface TeamMember {
  id: string;
  full_name: string | null;
  username: string | null;
  email: string;
  avatar_url: string | null;
  role: string;
  created_by: string | null;
  admin_id: string | null;
}

interface TeamHierarchy {
  admins: TeamMember[];
  managers: TeamMember[];
  teamLeaders: TeamMember[];
  superAgents: TeamMember[];
  agents: TeamMember[];
}

const getRoleBadgeColor = (role: string) => {
  switch (role) {
    case "SUPER_ADMIN":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    case "TENANT_OWNER":
      return "bg-red-500/20 text-red-400 border-red-500/30";
    case "MANAGER":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    case "TEAM_LEADER":
      return "bg-cyan-500/20 text-cyan-400 border-cyan-500/30";
    case "SUPER_AGENT":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "AGENT":
      return "bg-green-500/20 text-green-400 border-green-500/30";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

export default function TeamManagement() {
  const { user } = useAuth();
  const { isSuperAdmin, isTenantOwner, loading: roleLoading } = useUserData();
  const queryClient = useQueryClient();
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const { data: teamData, isLoading } = useQuery({
    queryKey: ["team-hierarchy", user?.id, isSuperAdmin, isTenantOwner],
    queryFn: async (): Promise<TeamHierarchy> => {
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, username, email, avatar_url, created_by, admin_id");

      if (profilesError) throw profilesError;

      const { data: roles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role");

      if (rolesError) throw rolesError;

      const roleMap = new Map(roles?.map((r) => [r.user_id, r.role]) || []);
      
      const members: TeamMember[] = (profiles || []).map((p) => ({
        ...p,
        role: roleMap.get(p.id) || "AGENT",
      }));

      if (isSuperAdmin) {
        return {
          admins: members.filter((m) => m.role === "TENANT_OWNER"),
          managers: members.filter((m) => m.role === "MANAGER"),
          teamLeaders: members.filter((m) => m.role === "TEAM_LEADER"),
          superAgents: members.filter((m) => m.role === "SUPER_AGENT"),
          agents: members.filter((m) => m.role === "AGENT"),
        };
      } else if (isTenantOwner && user?.id) {
        const tenantOwnerId = user.id;
        const tenantMembers = members.filter((m) => m.admin_id === tenantOwnerId);
        
        return {
          admins: [],
          managers: tenantMembers.filter((m) => m.role === "MANAGER"),
          teamLeaders: tenantMembers.filter((m) => m.role === "TEAM_LEADER"),
          superAgents: tenantMembers.filter((m) => m.role === "SUPER_AGENT"),
          agents: tenantMembers.filter((m) => m.role === "AGENT"),
        };
      }

      return { admins: [], managers: [], teamLeaders: [], superAgents: [], agents: [] };
    },
    enabled: !!user && !roleLoading && (isSuperAdmin || isTenantOwner),
  });

  const assignMutation = useMutation({
    mutationFn: async ({ memberId, managerId }: { memberId: string; managerId: string | null }) => {
      const { error } = await supabase
        .from("profiles")
        .update({ created_by: managerId })
        .eq("id", memberId);

      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      const action = variables.managerId ? "assigned" : "unassigned";
      toast.success(`Team member ${action} successfully`);
      queryClient.invalidateQueries({ queryKey: ["team-hierarchy"] });
      // Also invalidate manager-team queries so managers see updated lists
      queryClient.invalidateQueries({ queryKey: ["manager-team"] });
    },
    onError: (error) => {
      toast.error("Failed to update assignment: " + error.message);
    },
  });

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) return;

    const memberId = active.id as string;
    const member = active.data.current?.member as TeamMember;
    
    if (!member) return;

    const overId = over.id as string;

    // Dropping on unassigned pool
    if (overId === "unassigned-pool") {
      if (member.created_by) {
        assignMutation.mutate({ memberId, managerId: null });
      }
      return;
    }

    // Dropping on a team leader group
    if (overId.startsWith("team-leader-")) {
      const teamLeaderId = overId.replace("team-leader-", "");
      
      if (member.role !== "AGENT" && member.role !== "SUPER_AGENT") {
        toast.error("Only agents and super agents can be assigned to team leaders");
        return;
      }
      
      if (member.created_by === teamLeaderId) return;
      
      assignMutation.mutate({ memberId, managerId: teamLeaderId });
      return;
    }

    // Dropping on a manager column
    if (overId.startsWith("manager-")) {
      const managerId = overId.replace("manager-", "");
      
      // Allow agents, super agents, AND team leaders to be assigned to managers
      if (member.role !== "AGENT" && member.role !== "SUPER_AGENT" && member.role !== "TEAM_LEADER") {
        toast.error("Only agents, super agents, and team leaders can be assigned to managers");
        return;
      }
      
      if (member.created_by === managerId) return;
      
      assignMutation.mutate({ memberId, managerId });
    }
  }, [assignMutation]);

  const activeMember = teamData
    ? [...teamData.managers, ...teamData.teamLeaders, ...teamData.superAgents, ...teamData.agents].find(
        (m) => m.id === activeId
      )
    : null;

  if (roleLoading || isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Team Management</h1>
          <p className="text-muted-foreground">View and manage your team hierarchy</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-5 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!isSuperAdmin && !isTenantOwner) {
    return (
      <div className="flex items-center justify-center h-[50vh]">
        <p className="text-muted-foreground">You don't have permission to view this page.</p>
      </div>
    );
  }

  const { admins = [], managers = [], teamLeaders = [], superAgents = [], agents = [] } = teamData || {};

  // Get direct team members for each manager (excluding TL sub-teams)
  const getTeamForManager = (managerId: string) => {
    return [...superAgents, ...agents].filter((m) => m.created_by === managerId);
  };

  // Get team leaders under a manager
  const getTeamLeadersForManager = (managerId: string) => {
    return teamLeaders.filter((tl) => tl.created_by === managerId);
  };

  // All assignable members
  const allAssignableMembers = [...superAgents, ...agents];

  // Get unassigned members (not under any manager or team leader)
  const managerIds = new Set(managers.map((m) => m.id));
  const teamLeaderIds = new Set(teamLeaders.map((tl) => tl.id));
  const unassignedMembers = [...teamLeaders, ...superAgents, ...agents].filter(
    (m) => !m.created_by || (!managerIds.has(m.created_by) && !teamLeaderIds.has(m.created_by))
  );

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Team Management</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Drag and drop team members to assign them to managers
            </p>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 rounded-lg px-4 py-2">
            <GripVertical className="h-4 w-4" />
            <span>Drag members</span>
            <ArrowRight className="h-4 w-4" />
            <span>Drop on manager</span>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
          {isSuperAdmin && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{admins.length}</div>
                    <p className="text-sm text-muted-foreground">Admins</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <UserCog className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{managers.length}</div>
                  <p className="text-sm text-muted-foreground">Managers</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-accent">
                  <UserCheck className="h-5 w-5 text-accent-foreground" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{teamLeaders.length}</div>
                  <p className="text-sm text-muted-foreground">Team Leaders</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-chart-4/10">
                  <Star className="h-5 w-5 text-chart-4" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{superAgents.length}</div>
                  <p className="text-sm text-muted-foreground">Super Agents</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-chart-2/10">
                  <Users className="h-5 w-5 text-chart-2" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{agents.length}</div>
                  <p className="text-sm text-muted-foreground">Agents</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Unassigned Pool */}
        <UnassignedPool members={unassignedMembers} />

        {/* Manager Columns */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <UserCog className="h-5 w-5 text-blue-400" />
            Manager Teams
          </h2>
          
          {managers.length === 0 ? (
            <Card className="p-8">
              <p className="text-center text-muted-foreground">
                No managers found. Create managers in User Management first.
              </p>
            </Card>
          ) : (
            <ScrollArea className="w-full">
              <div className="flex gap-4 pb-4">
                {managers.map((manager) => (
                  <DroppableManagerColumn
                    key={manager.id}
                    manager={manager}
                    teamMembers={getTeamForManager(manager.id)}
                    teamLeaders={getTeamLeadersForManager(manager.id)}
                    allMembers={allAssignableMembers}
                  />
                ))}
              </div>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          )}
        </div>

        {/* Super Admin: Show Admins */}
        {isSuperAdmin && admins.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Building2 className="h-5 w-5 text-red-400" />
              Tenant Owners
            </h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {admins.map((admin) => {
                const adminManagers = managers.filter((m) => m.created_by === admin.id);
                const totalTeam = adminManagers.reduce((acc, manager) => {
                  return acc + getTeamForManager(manager.id).length;
                }, 0);

                return (
                  <Card key={admin.id} className="bg-gradient-to-br from-card to-red-500/5 border-red-500/20">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-14 w-14 ring-2 ring-red-500/30">
                          <AvatarImage src={admin.avatar_url || ""} />
                          <AvatarFallback className="bg-red-500/20 text-red-400 font-semibold">
                            {getInitials(admin.full_name || admin.username || "A")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <p className="font-semibold">{admin.full_name || admin.username}</p>
                          <p className="text-sm text-muted-foreground">@{admin.username}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <Badge variant="outline" className={getRoleBadgeColor(admin.role)}>
                              Admin
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {adminManagers.length} managers · {totalTeam} team
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Drag Overlay */}
      <DragOverlay>
        {activeMember && <DragOverlayContent member={activeMember} />}
      </DragOverlay>
    </DndContext>
  );
}
