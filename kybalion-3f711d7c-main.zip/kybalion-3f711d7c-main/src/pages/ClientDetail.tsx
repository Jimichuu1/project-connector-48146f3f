import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useClient } from "@/hooks/useClient";
import { useUserData } from "@/contexts/UserDataContext";
import { useDocuments } from "@/hooks/useDocuments";
import { useClientGroupMembership } from "@/hooks/useClientGroupMembership";
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { useBreadcrumb } from "@/contexts/BreadcrumbContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CreateBankDialog } from "@/components/kyc/CreateBankDialog";
import { CreateNoteDialog } from "@/components/kyc/CreateNoteDialog";
import { ClientKYCBanks } from "@/components/kyc/ClientKYCBanks";
import { ClientKYCNotes } from "@/components/kyc/ClientKYCNotes";

import { EditClientDialog } from "@/components/clients/EditClientDialog";
import { DocumentsDialog } from "@/components/clients/DocumentsDialog";
import { ClientStatusDropdown } from "@/components/clients/ClientStatusDropdown";
import { TransferringAgentDropdown } from "@/components/clients/TransferringAgentDropdown";

import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ClientStatus } from "@/types/clients";

import { 
  ArrowLeft, Pencil, FileText, Globe, 
  Phone, TrendingUp, DollarSign, Activity, Users, Calendar, Layers
} from "lucide-react";
import { LeadGroupName } from "@/components/leads/LeadGroupName";
import { ClientGroupDisplay } from "@/components/clients/ClientGroupDisplay";
import { ActivityLog } from "@/components/activity/ActivityLog";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { formatCurrency, formatPhone } from "@/lib/utils";
import { format } from "date-fns";

import { decodeId } from "@/lib/idCipher";

export default function ClientDetail() {
  const { id: idParam } = useParams();
  const id = decodeId(idParam) ?? undefined;
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [bankDialogOpen, setBankDialogOpen] = useState(false);
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [documentsDialogOpen, setDocumentsDialogOpen] = useState(false);
  
  const [transferringAgentId, setTransferringAgentId] = useState<string | null>(null);
  const [transferringAgentName, setTransferringAgentName] = useState<string | null>(null);
  const [assignedSuperAgentId, setAssignedSuperAgentId] = useState<string | null>(null);
  const [availableSuperAgents, setAvailableSuperAgents] = useState<Array<{ id: string; name: string }>>([]);
  const { user } = useAuth();
  const { data: client, isLoading } = useClient(id);
  
  const { 
    isSuperAdmin, isTenantOwner: isAdmin, isManager, isAgent, isSuperAgent,
    canViewPhone, canViewEmail 
  } = useUserData();
  const { documents } = useDocuments(id || '', 'client');
  const { setCustomLabel } = useBreadcrumb();
  const { isInLiveGroup } = useClientGroupMembership(id || '');

  

  // Fetch open trades sum from sale_branches (UPCOMING_SALE and STUCK only)
  const { data: openTradesSum = 0 } = useQuery({
    queryKey: ['client-open-trades', id],
    queryFn: async () => {
      if (!id) return 0;
      const { data, error } = await supabase
        .from('sale_branches')
        .select('value')
        .eq('client_id', id)
        .in('status', ['UPCOMING_SALE', 'STUCK']);
      
      if (error) {
        console.error('Error fetching open trades:', error);
        return 0;
      }
      
      return data?.reduce((sum, branch) => sum + (branch.value || 0), 0) || 0;
    },
    enabled: !!id,
  });

  // Fetch total approved deposits for this client
  const { data: totalDeposits = 0 } = useQuery({
    queryKey: ['client-total-deposits', id],
    queryFn: async () => {
      if (!id) return 0;
      const { data, error } = await supabase
        .from('deposits')
        .select('amount')
        .eq('client_id', id)
        .eq('status', 'approved');
      
      if (error) {
        console.error('Error fetching deposits:', error);
        return 0;
      }
      
      return data?.reduce((sum, deposit) => sum + Number(deposit.amount || 0), 0) || 0;
    },
    enabled: !!id,
  });

  // Set breadcrumb label to client name
  useEffect(() => {
    if (client?.name) {
      setCustomLabel(client.name);
    }
    return () => setCustomLabel(null);
  }, [client?.name, setCustomLabel]);

  // Derived permissions (using centralized user data)
  const canFullEdit = isSuperAdmin || isAdmin || isManager;
  const canEditBalanceOnly = isSuperAgent && isInLiveGroup;
  const canEdit = canFullEdit || canEditBalanceOnly;
  const canChangeStatus = isSuperAdmin || isAdmin || isManager || isSuperAgent;
  const canManageAssignments = isSuperAdmin || isAdmin || isManager;
  const isFieldAgent = isAgent || isSuperAgent;

  // Fetch super agents and assignment info for admins
  useEffect(() => {
    const fetchAgentInfo = async () => {
      if (!client || !canManageAssignments) return;

      // Get SUPER_AGENT role users for Assigned Super Agent dropdown
      const { data: superAgentRoles } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "SUPER_AGENT");

      if (superAgentRoles) {
        const superAgentIds = superAgentRoles.map((r) => r.user_id);
        const { data: superAgents } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", superAgentIds);

        if (superAgents) {
          setAvailableSuperAgents(
            superAgents.map((a) => ({
              id: a.id,
              name: a.full_name || a.email,
            }))
          );
        }
      }

      // Set current assigned super agent
      if (client.assigned_to) {
        setAssignedSuperAgentId(client.assigned_to);
      }

      // Get transferring agent directly from client and fetch their profile
      let agentId: string | null = null;
      
      if ((client as any).transferring_agent) {
        agentId = (client as any).transferring_agent;
      } else if (client.converted_from_lead_id) {
        // Fallback 1: Get from original lead if client doesn't have it set
        const { data: lead } = await supabase
          .from("leads")
          .select("created_by")
          .eq("id", client.converted_from_lead_id)
          .maybeSingle();

        if (lead) {
          agentId = lead.created_by;
        }

        // Fallback 2: Get from conversion audit log
        if (!agentId) {
          const { data: auditLog } = await supabase
            .from("audit_logs")
            .select("details, user_id")
            .eq("entity_id", client.id)
            .eq("action_type", "conversion_confirmed")
            .maybeSingle();

          if (auditLog?.details) {
            const details = auditLog.details as Record<string, unknown>;
            agentId = (details.transferring_agent as string) || null;
          }
        }
      }
      
      if (agentId) {
        setTransferringAgentId(agentId);
        // Fetch the agent's profile to get their name
        const { data: agentProfile } = await supabase
          .from("profiles")
          .select("full_name, email")
          .eq("id", agentId)
          .maybeSingle();
        
        if (agentProfile) {
          setTransferringAgentName(agentProfile.full_name || agentProfile.email);
        } else {
          // Profile was deleted — show as "Deleted User"
          setTransferringAgentName("Deleted User");
        }
      }
    };

    fetchAgentInfo();
  }, [client, canManageAssignments]);

  const handleTransferringAgentChange = async (newAgentId: string) => {
    if (!client) return;
    
    try {
      const { error } = await supabase
        .from("clients")
        .update({ transferring_agent: newAgentId })
        .eq("id", client.id);

      if (error) throw error;
      setTransferringAgentId(newAgentId);
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      toast.success("Transferring agent updated");
    } catch (error) {
      console.error("Error updating transferring agent:", error);
      toast.error("Failed to update transferring agent");
    }
  };

  const handleAssignedSuperAgentChange = async (newAgentId: string) => {
    if (!client) return;
    
    try {
      const { error } = await supabase
        .from("clients")
        .update({ assigned_to: newAgentId })
        .eq("id", client.id);

      if (error) throw error;

      // Send CLIENT_ASSIGNED notification to the new super agent
      if (newAgentId !== assignedSuperAgentId) {
        await supabase.from("notifications").insert({
          user_id: newAgentId,
          type: "CLIENT_ASSIGNED" as const,
          message: `Client "${client.name}" has been assigned to you`,
          related_entity_type: "client",
          related_entity_id: client.id,
          admin_id: (client as any).admin_id || null,
        });
      }

      setAssignedSuperAgentId(newAgentId);
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      toast.success("Assigned super agent updated");
    } catch (error) {
      console.error("Error updating assigned super agent:", error);
      toast.error("Failed to update assigned super agent");
    }
  };

  // Computed visibility based on role settings (from centralized user data)
  const shouldShowEmail = canViewEmail;
  const shouldShowPhone = canViewPhone;

  // Email/call handlers removed with integrations cleanup

  if (isLoading) {
    return <div className="py-8">Loading...</div>;
  }

  if (!client) {
    return (
      <div className="py-8">
        <Card>
          <CardContent className="p-6 text-center">
            Client not found
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="pb-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate('/clients')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Clients
        </Button>
        <div className="flex gap-2">
          {canEdit && (
            <Button size="sm" variant="outline" onClick={() => setEditDialogOpen(true)}>
              <Pencil className="h-4 w-4 mr-2" />
              {canEditBalanceOnly && !canFullEdit ? "Edit Balance" : "Edit"}
            </Button>
          )}
        </div>
      </div>

      {/* Main Content - 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Client Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Client Header Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl font-bold">{client.name}</h1>
                    <ClientStatusDropdown 
                      status={client.status}
                      disabled={!canChangeStatus}
                      onStatusChange={async (newStatus: ClientStatus) => {
                        try {
                          const { error } = await supabase
                            .from("clients")
                            .update({ status: newStatus })
                            .eq("id", client.id);
                          if (error) throw error;
                          queryClient.invalidateQueries({ queryKey: ["clients"] });
                          toast.success("Status updated");
                        } catch (error) {
                          console.error("Error updating status:", error);
                          toast.error("Failed to update status");
                        }
                      }}
                    />
                  </div>
                  {shouldShowEmail && (
                    <p className="text-muted-foreground mt-1">{client.email}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="relative">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <DollarSign className="h-4 w-4" />
                    <span className="text-xs">Init. Balance</span>
                  </div>
                  {(canEditBalanceOnly || canFullEdit) && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => setEditDialogOpen(true)}
                    >
                      <Pencil className="h-3 w-3" />
                    </Button>
                  )}
                </div>
                <p className="text-lg font-semibold text-success">{formatCurrency(client.balance)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <DollarSign className="h-4 w-4" />
                  <span className="text-xs">Init. Amt</span>
                </div>
                <p className="text-lg font-semibold">{formatCurrency(client.equity)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-xs">Total Deposits</span>
                </div>
                <p className="text-lg font-semibold text-success">{formatCurrency(totalDeposits)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <Activity className="h-4 w-4" />
                  <span className="text-xs">Open Trades</span>
                </div>
                <p className="text-lg font-semibold">{formatCurrency(openTradesSum)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Assignment Information - Admin/Manager Only */}
          {canManageAssignments && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  Assignment
                </CardTitle>
              </CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Transferring Agent (History)</Label>
                  {transferringAgentName ? (
                    <div className="h-9 px-3 py-2 rounded-md border border-input bg-muted/50 text-sm flex items-center">
                      {transferringAgentName}
                    </div>
                  ) : (isSuperAdmin || isAdmin) ? (
                    <TransferringAgentDropdown
                      clientId={client.id}
                      currentTransferringAgent={transferringAgentId}
                      onAssignmentChange={() => {
                        queryClient.invalidateQueries({ queryKey: ["clients"] });
                      }}
                    />
                  ) : (
                    <div className="h-9 px-3 py-2 rounded-md border border-input bg-muted/50 text-sm flex items-center">
                      <span className="text-muted-foreground">No transferring agent</span>
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Assigned Super Agent</Label>
                  <Select value={assignedSuperAgentId || undefined} onValueChange={handleAssignedSuperAgentChange}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Select super agent" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableSuperAgents.map((agent) => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Client Details */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Globe className="h-3.5 w-3.5" />
                    <span className="text-xs">Country</span>
                  </div>
                  <p className="text-sm font-medium">{client.country || '-'}</p>
                </div>
                {shouldShowPhone && client.home_phone && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-3.5 w-3.5" />
                      <span className="text-xs">Phone</span>
                    </div>
                    <p className="text-sm font-medium">{formatPhone(client.home_phone)}</p>
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    <span className="text-xs">Join Date</span>
                  </div>
                  <p className="text-sm font-medium">{format(new Date(client.join_date), 'MMM d, yyyy')}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Activity className="h-3.5 w-3.5" />
                    <span className="text-xs">Pipeline Status</span>
                  </div>
                  <p className="text-sm font-medium capitalize">{client.pipeline_status.replace(/_/g, ' ').toLowerCase()}</p>
                </div>
                {client.converted_from_lead_id && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Layers className="h-3.5 w-3.5" />
                      <span className="text-xs">Lead Group</span>
                    </div>
                    <LeadGroupName leadId={client.converted_from_lead_id} />
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Users className="h-3.5 w-3.5" />
                    <span className="text-xs">Client Group</span>
                  </div>
                  <ClientGroupDisplay clientId={client.id} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Activity Log - Admin/Manager Only */}
          {(isAdmin || isManager) && (
            <ActivityLog entityType="client" entityId={client.id} />
          )}
        </div>

        {/* Right Column - KYC */}
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6 space-y-6">
              <ClientKYCBanks 
                entityId={client.id} 
                entityType="client" 
                onAddBank={() => setBankDialogOpen(true)}
              />
              <Separator />
              <ClientKYCNotes 
                entityId={client.id} 
                entityType="client" 
                onAddNote={() => setNoteDialogOpen(true)}
              />
              <Separator />
              <div 
                className="flex items-center justify-between cursor-pointer hover:bg-muted/30 rounded-lg p-3 -m-3 transition-colors" 
                onClick={() => setDocumentsDialogOpen(true)}
              >
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">Documents</p>
                    <p className="text-xs text-muted-foreground">{documents?.length || 0} files uploaded</p>
                  </div>
                </div>
                <Badge variant="outline" className="font-medium text-foreground">{documents?.length || 0}</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Dialogs */}
      <CreateBankDialog
        entityId={client.id}
        entityType="client"
        open={bankDialogOpen}
        onOpenChange={setBankDialogOpen}
      />

      <CreateNoteDialog
        entityId={client.id}
        entityType="client"
        open={noteDialogOpen}
        onOpenChange={setNoteDialogOpen}
      />

      <EditClientDialog
        client={client}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        restrictedMode={canEditBalanceOnly && !canFullEdit}
        editableFields={canEditBalanceOnly && !canFullEdit ? ['balance'] : undefined}
      />

      <DocumentsDialog
        open={documentsDialogOpen}
        onOpenChange={setDocumentsDialogOpen}
        entityId={client.id}
        entityType="client"
      />


    </div>
  );
}
