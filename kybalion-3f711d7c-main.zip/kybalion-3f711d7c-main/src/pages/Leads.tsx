import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { downloadLeadsTemplate } from "@/lib/exportCsv";
import { exportAllLeadsWithKycData, exportAllLeadsCCFormat } from "@/lib/exportAllData";
import { Badge } from "@/components/ui/badge";
import { useTenant } from "@/contexts/TenantContext";
import { AssignGroupDialog } from "@/components/leads/AssignGroupDialog";
import { useLeadsPaginated } from "@/hooks/useLeadsPaginated";
import { CreateLeadDialog } from "@/components/leads/CreateLeadDialog";
import { LeadStatus } from "@/types/leads";
import { toast } from "sonner";
import { LeadsTableToolbar, LeadsTableFilters, FilterValues } from "@/components/leads/LeadsTableToolbar";
import { CreateBankDialog } from "@/components/kyc/CreateBankDialog";
import { CreateNoteDialog } from "@/components/kyc/CreateNoteDialog";
import { ConvertLeadDialog } from "@/components/leads/ConvertLeadDialog";
import { ImportLeadsDialog } from "@/components/leads/ImportLeadsDialog";
import { LeadsBoardView } from "@/components/leads/LeadsBoardView";
import { LeadGroupsView } from "@/components/leads/LeadGroupsView";
import { TableX } from "@/components/ui/table-x";
import { useTableSort } from "@/components/ui/sortable-table-head";
import { LeadsTableContent } from "@/components/leads/LeadsTableContent";
import { useLeadActions } from "@/hooks/useLeadActions";
import { LeadsFloatingBar } from "@/components/leads/LeadsFloatingBar";
import { PaginationControls } from "@/components/ui/pagination-controls";
import { LEADS_PAGE_SIZE_OPTIONS, LEADS_PAGE_SIZE_OPTIONS_EXTENDED, LEADS_MAX_PAGE_SIZE } from "@/types/pagination";
import { ShuffleAssigneeDialog } from "@/components/leads/ShuffleAssigneeDialog";
import { CompareLeadsDialog } from "@/components/leads/CompareLeadsDialog";
import { CreateUserDepositDialog } from "@/components/app-integration/CreateUserDepositDialog";
import { supabase } from "@/integrations/supabase/client";

const Leads = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const {
    isSuperAdmin, isTenantOwner, isManager, isTeamLeader, isAgent, isSuperAgent,
    hasManagerAccess, canViewPhone, canViewEmail, loading: roleLoading
  } = useUserData();
  const { teamMemberIds, isLoading: teamLoading } = useManagerTeam();
  const { effectiveTenantId } = useTenant();

  const [viewMode, setViewMode] = useState<"table" | "board" | "groups">("table");
  const [search, setSearch] = useState("");
  const [selectedStatuses, setSelectedStatuses] = useState<LeadStatus[]>([]);
  const [filterValues, setFilterValues] = useState<FilterValues>({
    assignedTo: [],
    country: [],
    groupIds: [],
    createdAt: null,
    unassigned: false,
  });

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(LEADS_MAX_PAGE_SIZE);

  const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showCompareDialog, setShowCompareDialog] = useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [assignDialogMode, setAssignDialogMode] = useState<"assign" | "group" | "move">("assign");

  const [shuffleDialogOpen, setShuffleDialogOpen] = useState(false);
  const [shuffleMode, setShuffleMode] = useState<"bulk" | "group">("bulk");
  const [shuffleGroupId, setShuffleGroupId] = useState<string | undefined>();
  const [shuffleLeadIds, setShuffleLeadIds] = useState<string[]>([]);

  const { sort, handleSort } = useTableSort();

  const leadActions = useLeadActions(user?.id);

  const isManagerDataReady = !isManager || !teamLoading;

  const {
    leads,
    totalCount,
    isLoading: leadsLoading,
    error,
    updateLead,
    bulkDeleteLeads,
    bulkUpdateLeadStatus,
    pagination
  } = useLeadsPaginated(
    {
      search: search || undefined,
      statuses: selectedStatuses.length > 0 ? selectedStatuses : undefined,
      assignedToList: filterValues.assignedTo.length > 0 ? filterValues.assignedTo : undefined,
      unassigned: filterValues.unassigned || undefined,
      countries: filterValues.country.length > 0 ? filterValues.country : undefined,
      groupIds: filterValues.groupIds.length > 0 ? filterValues.groupIds : undefined,
      dateFrom: filterValues.createdAt?.from || undefined,
      dateTo: filterValues.createdAt?.to || undefined,
      teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
    },
    { page: currentPage, pageSize },
    isManagerDataReady
  );

  const isLoading = roleLoading || (isManager && teamLoading) || leadsLoading;

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    setSelectedLeads([]);
  };

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize);
    setCurrentPage(1);
    setSelectedLeads([]);
  };

  const handleFiltersChange = (newFilters: FilterValues) => {
    setFilterValues(newFilters);
    setCurrentPage(1);
  };

  const handleSearchChange = (newSearch: string) => {
    setSearch(newSearch);
    setCurrentPage(1);
  };

  const handleStatusesChange = (newStatuses: LeadStatus[]) => {
    setSelectedStatuses(newStatuses);
    setCurrentPage(1);
  };

  const isRestrictedRole = isAgent || isSuperAgent || isTeamLeader;
  const canConvert = true;
  const shouldShowEmail = canViewEmail;
  const shouldShowPhone = canViewPhone;

  const handleSelectAll = (checked: boolean) => {
    setSelectedLeads(checked && leads ? leads.map((l) => l.id) : []);
  };

  const handleSelectLead = (leadId: string, checked: boolean) => {
    setSelectedLeads(checked ? [...selectedLeads, leadId] : selectedLeads.filter((id) => id !== leadId));
  };

  const handleStatusChange = async (leadId: string, newStatus: LeadStatus) => {
    try {
      await updateLead.mutateAsync({ id: leadId, status: newStatus });
      toast.success("Lead status updated");
    } catch {
      toast.error("Failed to update lead status");
    }
  };

  const handleReorder = async (leadId: string, newPosition: number) => {
    try {
      await updateLead.mutateAsync({ id: leadId, position: newPosition });
    } catch (error) {
      console.error("Failed to update lead position", error);
    }
  };

  const handleShuffleBulk = () => {
    setShuffleMode("bulk");
    setShuffleLeadIds([...selectedLeads]);
    setShuffleGroupId(undefined);
    setShuffleDialogOpen(true);
  };

  const handleShuffleGroup = async (groupId: string, _groupName: string) => {
    let allUnassignedLeadIds: string[] = [];
    let hasMore = true;
    let offset = 0;
    const batchSize = 1000;

    while (hasMore) {
      const { data, error } = await supabase
        .from("lead_group_members")
        .select("lead_id, leads!inner(id, assigned_to)")
        .eq("group_id", groupId)
        .is("leads.assigned_to", null)
        .range(offset, offset + batchSize - 1);

      if (error) {
        toast.error("Failed to fetch group leads");
        return;
      }

      const leadIds = (data || []).map((m: any) => m.lead_id);
      allUnassignedLeadIds = [...allUnassignedLeadIds, ...leadIds];

      hasMore = leadIds.length === batchSize;
      offset += batchSize;
    }

    if (allUnassignedLeadIds.length === 0) {
      toast.info("No unassigned leads in this group");
      return;
    }

    setShuffleMode("group");
    setShuffleLeadIds(allUnassignedLeadIds);
    setShuffleGroupId(groupId);
    setShuffleDialogOpen(true);
  };

  return (
    <div className="flex flex-col bg-background">
      <div className="pb-8 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight">Leads</h1>
              <Badge variant="default" className="text-sm h-6 px-2">{totalCount.toLocaleString()}</Badge>
            </div>
            <p className="text-muted-foreground text-sm mt-1">Manage and track your sales leads</p>
          </div>
          <CreateUserDepositDialog />
        </div>

        <TableX
          toolbar={
            <LeadsTableToolbar
              search={search}
              onSearchChange={handleSearchChange}
              selectedStatuses={selectedStatuses}
              onStatusesChange={handleStatusesChange}
              onExport={() => exportAllLeadsWithKycData({
                search: search || undefined,
                statuses: selectedStatuses.length > 0 ? selectedStatuses : undefined,
                assignedToList: filterValues.assignedTo.length > 0 ? filterValues.assignedTo : undefined,
                unassigned: filterValues.unassigned || undefined,
                countries: filterValues.country.length > 0 ? filterValues.country : undefined,
                groupIds: filterValues.groupIds.length > 0 ? filterValues.groupIds : undefined,
                dateFrom: filterValues.createdAt?.from || undefined,
                dateTo: filterValues.createdAt?.to || undefined,
                teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
                adminId: effectiveTenantId || undefined,
              })}
              onCCExport={() => exportAllLeadsCCFormat({
                search: search || undefined,
                statuses: selectedStatuses.length > 0 ? selectedStatuses : undefined,
                assignedToList: filterValues.assignedTo.length > 0 ? filterValues.assignedTo : undefined,
                unassigned: filterValues.unassigned || undefined,
                countries: filterValues.country.length > 0 ? filterValues.country : undefined,
                groupIds: filterValues.groupIds.length > 0 ? filterValues.groupIds : undefined,
                dateFrom: filterValues.createdAt?.from || undefined,
                dateTo: filterValues.createdAt?.to || undefined,
                teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
                adminId: effectiveTenantId || undefined,
              })}
              onDownloadTemplate={downloadLeadsTemplate}
              onImport={() => setShowImportDialog(true)}
              onAddLead={() => setShowCreateDialog(true)}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              isRestrictedRole={isRestrictedRole}
              isAdmin={isSuperAdmin || isTenantOwner}
              onCompare={() => setShowCompareDialog(true)}
            />
          }
          filters={
            <LeadsTableFilters
              selectedStatuses={selectedStatuses}
              onStatusesChange={handleStatusesChange}
              filterValues={filterValues}
              onFilterValuesChange={handleFiltersChange}
              isAgent={isAgent}
            />
          }
        >
          {viewMode === "board" ? (
            <div className="animate-fade-in p-4">
              <LeadsBoardView
                leads={leads || []}
                onStatusChange={handleStatusChange}
                onReorder={handleReorder}
                isAgent={isAgent}
                onAddBank={leadActions.handleAddBank}
                onAddNote={leadActions.handleAddNote}
                onCreateAccount={leadActions.handleCreateAccount}
              />
            </div>
          ) : viewMode === "groups" ? (
            <div className="animate-fade-in p-4 px-0">
              <LeadGroupsView
                onGroupSelect={(groupId) => {
                  setFilterValues({ ...filterValues, groupIds: groupId ? [groupId] : [] });
                  setViewMode("table");
                }}
                onShuffleGroup={handleShuffleGroup}
              />
            </div>
          ) : (
            <>
              <LeadsTableContent
                leads={leads || []}
                isLoading={isLoading}
                error={error}
                sort={sort}
                onSort={handleSort}
                selectedLeads={selectedLeads}
                onSelectAll={handleSelectAll}
                onSelectLead={handleSelectLead}
                shouldShowEmail={shouldShowEmail}
                shouldShowPhone={shouldShowPhone}
                isSuperAdmin={isSuperAdmin}
                isTenantOwner={isTenantOwner}
                isManager={isManager}
                onAddBank={leadActions.handleAddBank}
                onAddNote={leadActions.handleAddNote}
                onCreateAccount={leadActions.handleCreateAccount}
                onConvert={leadActions.handleConvert}
                canConvert={canConvert}
                onStatusChange={handleStatusChange}
              />
              {pagination && (
                <PaginationControls
                  pagination={pagination}
                  onPageChange={handlePageChange}
                  onPageSizeChange={handlePageSizeChange}
                  itemLabel="leads"
                  pageSizeOptions={isTenantOwner ? LEADS_PAGE_SIZE_OPTIONS_EXTENDED : LEADS_PAGE_SIZE_OPTIONS}
                />
              )}
            </>
          )}
        </TableX>
      </div>

      <CreateLeadDialog open={showCreateDialog} onOpenChange={setShowCreateDialog} />
      <ImportLeadsDialog open={showImportDialog} onOpenChange={setShowImportDialog} />
      <CompareLeadsDialog open={showCompareDialog} onOpenChange={setShowCompareDialog} />

      {leadActions.leadToConvert && (
        <ConvertLeadDialog
          lead={leadActions.leadToConvert}
          open={leadActions.convertDialogOpen}
          onOpenChange={leadActions.setConvertDialogOpen}
        />
      )}

      {leadActions.selectedLeadForAction && (
        <>
          <CreateBankDialog
            entityId={leadActions.selectedLeadForAction.id}
            entityType="lead"
            open={leadActions.showBankDialog}
            onOpenChange={leadActions.setShowBankDialog}
          />
          <CreateNoteDialog
            entityId={leadActions.selectedLeadForAction.id}
            entityType="lead"
            open={leadActions.showNoteDialog}
            onOpenChange={leadActions.setShowNoteDialog}
          />
        </>
      )}

      <LeadsFloatingBar
        selectedLeads={selectedLeads}
        onClear={() => setSelectedLeads([])}
        isAdmin={isSuperAdmin || isTenantOwner}
        hasManagerAccess={hasManagerAccess}
        bulkUpdateStatus={bulkUpdateLeadStatus}
        bulkDeleteLeads={bulkDeleteLeads}
        onAssign={() => {
          setAssignDialogMode("assign");
          setAssignDialogOpen(true);
        }}
        onAddToGroup={() => {
          setAssignDialogMode("group");
          setAssignDialogOpen(true);
        }}
        onMoveToGroup={() => {
          setAssignDialogMode("move");
          setAssignDialogOpen(true);
        }}
        onShuffle={handleShuffleBulk}
      />

      <AssignGroupDialog
        open={assignDialogOpen}
        onOpenChange={(open) => {
          setAssignDialogOpen(open);
          if (!open) setSelectedLeads([]);
        }}
        selectedLeadIds={selectedLeads}
        defaultMode={assignDialogMode}
      />

      <ShuffleAssigneeDialog
        open={shuffleDialogOpen}
        onOpenChange={setShuffleDialogOpen}
        leadIds={shuffleLeadIds}
        mode={shuffleMode}
        groupId={shuffleGroupId}
        onComplete={() => setSelectedLeads([])}
      />
    </div>
  );
};

export default Leads;
