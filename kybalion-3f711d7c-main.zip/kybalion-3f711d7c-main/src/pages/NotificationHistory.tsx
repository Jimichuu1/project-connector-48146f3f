import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Check, CheckCheck, Archive, AlertTriangle } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { cn } from "@/lib/utils";
import { NotificationType } from "@/types/notifications";
import { toast } from "sonner";
import { clientHref, leadHref } from "@/lib/idCipher";

const getNotificationIcon = (type: NotificationType) => {
  switch (type) {
    case 'NEW_LEAD': return '🆕';
    case 'WITHDRAWAL_REQUEST': return '💰';
    case 'LEAD_ASSIGNED': return '📋';
    case 'CLIENT_CONVERTED': return '🎉';
    case 'TASK_DUE': return '⏰';
    case 'TICKET_CREATED': return '🎫';
    case 'CONVERSION_APPROVED': return '✅';
    case 'CONVERSION_REJECTED': return '❌';
    case 'DEPOSIT_APPROVED': return '✅💰';
    case 'DEPOSIT_REJECTED': return '❌💰';
    case 'DEPOSIT_SPLIT_RECEIVED': return '🤝💰';
    case 'CLIENT_ASSIGNED': return '👤';
    default: return '🔔';
  }
};

const getNotificationLabel = (type: NotificationType) => {
  switch (type) {
    case 'NEW_LEAD': return 'New Lead';
    case 'WITHDRAWAL_REQUEST': return 'Withdrawal';
    case 'LEAD_ASSIGNED': return 'Lead Assigned';
    case 'CLIENT_CONVERTED': return 'Converted';
    case 'TASK_DUE': return 'Task Due';
    case 'TICKET_CREATED': return 'Ticket';
    case 'CONVERSION_APPROVED': return 'Approved';
    case 'CONVERSION_REJECTED': return 'Rejected';
    case 'DEPOSIT_APPROVED': return 'Deposit Approved';
    case 'DEPOSIT_REJECTED': return 'Deposit Rejected';
    case 'DEPOSIT_SPLIT_RECEIVED': return 'Split Received';
    case 'CLIENT_ASSIGNED': return 'Client Assigned';
    default: return 'Notification';
  }
};

const renderNotificationMessage = (
  message: string,
  entityType: string | null | undefined,
  entityId: string | null | undefined
) => {
  if (!entityType || !entityId) return <span>{message}</span>;
  const match = message.match(/"([^"]+)"/);
  if (!match) return <span>{message}</span>;
  const name = match[1];
  const route = entityType === 'client' ? clientHref(entityId) : leadHref(entityId);
  const parts = message.split(`"${name}"`);
  return (
    <span>
      {parts[0]}
      <Link to={route} className="text-primary hover:underline font-medium">"{name}"</Link>
      {parts[1]}
    </span>
  );
};

interface Notification {
  id: string;
  type: NotificationType;
  message: string;
  is_read: boolean;
  created_at: string;
  archived_at: string | null;
  related_entity_type: string | null;
  related_entity_id: string | null;
}

const NotificationHistory = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<"recent" | "unread" | "archived">("recent");

  const { data: recentNotifications, isLoading: loadingRecent } = useQuery({
    queryKey: ['notification-history-recent', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .is('archived_at', null)
        .gte('created_at', oneMonthAgo.toISOString())
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as Notification[];
    },
    enabled: !!user,
    staleTime: 30 * 1000,
  });

  const { data: archivedNotifications, isLoading: loadingArchived } = useQuery({
    queryKey: ['notification-history-archived', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .not('archived_at', 'is', null)
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;
      return data as Notification[];
    },
    enabled: !!user && activeTab === 'archived',
    staleTime: 60 * 1000,
  });

  const markAsRead = useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-history-recent'] });
      queryClient.invalidateQueries({ queryKey: ['notification-history-archived'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsRead = useMutation({
    mutationFn: async () => {
      if (!user) return;
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notification-history-recent'] });
      queryClient.invalidateQueries({ queryKey: ['notification-history-archived'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
      toast.success('All notifications marked as read');
    },
  });

  const getDisplayedNotifications = () => {
    if (activeTab === 'archived') return archivedNotifications || [];
    if (activeTab === 'unread') return (recentNotifications || []).filter(n => !n.is_read);
    return recentNotifications || [];
  };

  const displayedNotifications = getDisplayedNotifications();
  const unreadCount = (recentNotifications || []).filter(n => !n.is_read).length;
  const isLoading = activeTab === 'archived' ? loadingArchived : loadingRecent;

  const groupedNotifications = displayedNotifications.reduce((groups, notification) => {
    const date = format(new Date(notification.created_at), 'yyyy-MM-dd');
    if (!groups[date]) groups[date] = [];
    groups[date].push(notification);
    return groups;
  }, {} as Record<string, Notification[]>);

  const formatDateHeader = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (format(date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')) return 'Today';
    if (format(date, 'yyyy-MM-dd') === format(yesterday, 'yyyy-MM-dd')) return 'Yesterday';
    return format(date, 'MMMM d, yyyy');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Notification History</h1>
          <p className="text-muted-foreground text-sm mt-1">View and manage all your notifications</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "recent" | "unread" | "archived")}>
              <TabsList>
                <TabsTrigger value="recent">
                  Recent
                  <Badge className="ml-2 bg-muted text-foreground border border-border">
                    {recentNotifications?.length || 0}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="unread">
                  Unread
                  {unreadCount > 0 && (
                    <Badge variant="destructive" className="ml-2">{unreadCount}</Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="archived">
                  <Archive className="h-4 w-4 mr-1" />
                  Archived
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {unreadCount > 0 && activeTab !== 'archived' && (
              <Button variant="outline" size="sm" onClick={() => markAllAsRead.mutate()} disabled={markAllAsRead.isPending}>
                <CheckCheck className="h-4 w-4 mr-2" />
                Mark all as read
              </Button>
            )}
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex gap-4 p-4 rounded-lg border">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : displayedNotifications.length === 0 ? (
            <div className="py-16 text-center">
              {activeTab === 'archived' ? (
                <>
                  <Archive className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
                  <h3 className="text-lg font-medium text-muted-foreground">No archived notifications</h3>
                  <p className="text-sm text-muted-foreground mt-1">Notifications older than 1 month will be automatically archived here.</p>
                </>
              ) : (
                <>
                  <Bell className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
                  <h3 className="text-lg font-medium text-muted-foreground">
                    {activeTab === 'unread' ? 'No unread notifications' : 'No recent notifications'}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {activeTab === 'unread'
                      ? 'All caught up! Check the "Recent" tab for your notification history.'
                      : 'When you receive notifications, they will appear here.'}
                  </p>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(groupedNotifications).map(([date, notifs]) => (
                <div key={date}>
                  <h4 className="text-sm font-medium text-muted-foreground mb-3">{formatDateHeader(date)}</h4>
                  <div className="space-y-2">
                    {notifs.map((notification) => {
                      return (
                        <div
                          key={notification.id}
                          className={cn(
                            "flex items-start gap-4 p-4 rounded-lg border transition-colors",
                            !notification.is_read && !notification.archived_at && "bg-primary/5 border-primary/20",
                            (notification.is_read || notification.archived_at) && "bg-card hover:bg-muted/50",
                            notification.archived_at && "opacity-75"
                          )}
                        >
                          <div className="text-2xl flex-shrink-0">
                            {notification.related_entity_type === 'page_access_denied' ? (
                              <AlertTriangle className="h-6 w-6 text-destructive" />
                            ) : (
                              getNotificationIcon(notification.type)
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant={notification.related_entity_type === 'page_access_denied' ? 'destructive' : 'outline'} className="text-xs">
                                {notification.related_entity_type === 'page_access_denied' ? 'Access Denied' : getNotificationLabel(notification.type)}
                              </Badge>
                              {!notification.is_read && !notification.archived_at && (
                                <div className="w-2 h-2 rounded-full bg-primary" />
                              )}
                              {notification.archived_at && (
                                <Badge variant="secondary" className="text-xs">
                                  <Archive className="h-3 w-3 mr-1" />
                                  Archived
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm">
                              {renderNotificationMessage(notification.message, notification.related_entity_type, notification.related_entity_id)}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <p className="text-xs text-muted-foreground">
                                {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                              </p>
                            </div>
                          </div>
                          {!notification.is_read && !notification.archived_at && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => markAsRead.mutate(notification.id)}
                              disabled={markAsRead.isPending}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default NotificationHistory;
