import { useState, useMemo, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { Button } from "@/components/ui/button";
import { DollarSign, TrendingUp, Minus, Calculator, Info, Settings, User, Shield, Wallet, Percent, Receipt, Banknote, Plus, Pencil, Download, Lock, Unlock } from "lucide-react";
import { exportSalaryToExcel } from "@/lib/salaryExport";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { format, startOfMonth, endOfMonth, subMonths } from "date-fns";
import { SalaryRulesDialog } from "@/components/salary/SalaryRulesDialog";
import { useCommissionTierSettings, type AgentTierLevel, type AgentCommissionTierLevel, type TierLevel } from "@/hooks/useCommissionTierSettings";
import { CustomSalaryDialog } from "@/components/salary/CustomSalaryDialog";
import { useCustomSalaryEntries, type CustomSalaryEntry } from "@/hooks/useCustomSalaryEntries";
import { AdvancePaymentDialog } from "@/components/salary/AdvancePaymentDialog";
import { useAdvancePayments } from "@/hooks/useAdvancePayments";
import { useSalaryMonthLock } from "@/hooks/useSalaryMonthLock";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AgentDepositApprovalsTab } from "@/components/salary/AgentDepositApprovalsTab";
import { useUserData } from "@/contexts/UserDataContext";

// Helper function to find the matching agent transfer tier based on conversions
function findAgentTransferTier(conversions: number, tiers: AgentTierLevel[]): AgentTierLevel {
  const sortedTiers = [...tiers].sort((a, b) => b.minConversions - a.minConversions);
  for (const tier of sortedTiers) {
    if (conversions >= tier.minConversions) {
      return tier;
    }
  }
  return tiers[0] || { minConversions: 0, baseSalary: 800, singleTransferValue: 0 };
}

// Helper function to find the matching agent commission tier.
// Basis selects which threshold field to compare against:
//   - 'deposit'   -> totalDeposits vs tier.minDeposit
//   - 'transfers' -> conversions vs (tier.minTransfers ?? 0)
function findAgentCommissionTier(
  totalDeposits: number,
  conversions: number,
  tiers: AgentCommissionTierLevel[],
  basis: "deposit" | "transfers" = "deposit"
): AgentCommissionTierLevel {
  if (basis === "transfers") {
    const sorted = [...tiers].sort(
      (a, b) => (b.minTransfers ?? 0) - (a.minTransfers ?? 0)
    );
    for (const tier of sorted) {
      if (conversions >= (tier.minTransfers ?? 0)) return tier;
    }
    return tiers[0] || { minDeposit: 0, minTransfers: 0, commissionPercent: 5 };
  }
  const sortedTiers = [...tiers].sort((a, b) => b.minDeposit - a.minDeposit);
  for (const tier of sortedTiers) {
    if (totalDeposits >= tier.minDeposit) {
      return tier;
    }
  }
  return tiers[0] || { minDeposit: 0, commissionPercent: 5 };
}

// Helper function to find the matching super agent tier based on deposits
function findSuperAgentTier(totalDeposits: number, tiers: TierLevel[]): TierLevel {
  // Sort tiers by minDeposit descending to find the highest matching tier
  const sortedTiers = [...tiers].sort((a, b) => b.minDeposit - a.minDeposit);
  for (const tier of sortedTiers) {
    if (totalDeposits >= tier.minDeposit) {
      return tier;
    }
  }
  // Return first tier as fallback
  return tiers[0] || { minDeposit: 0, commissionPercent: 8, baseSalary: 1000 };
}

// Helper function to find the matching manager tier based on team deposits
function findManagerTier(teamDeposits: number, tiers: TierLevel[]): TierLevel {
  // Sort tiers by minDeposit descending to find the highest matching tier
  const sortedTiers = [...tiers].sort((a, b) => b.minDeposit - a.minDeposit);
  for (const tier of sortedTiers) {
    if (teamDeposits >= tier.minDeposit) {
      return tier;
    }
  }
  // Return first tier as fallback
  return tiers[0] || { minDeposit: 0, commissionPercent: 3, baseSalary: 1500 };
}

// Find a manager/TL tier honoring the per-person basis (deposit OR transfer count).
function findManagerTierByBasis(
  teamDeposits: number,
  teamTransfers: number,
  tiers: TierLevel[],
  basis: "deposit" | "transfers"
): TierLevel {
  if (basis === "transfers") {
    const sorted = [...tiers].sort(
      (a, b) => (b.minTransfers ?? 0) - (a.minTransfers ?? 0)
    );
    for (const tier of sorted) {
      if (teamTransfers >= (tier.minTransfers ?? 0)) return tier;
    }
    return tiers[0] || { minDeposit: 0, commissionPercent: 3, baseSalary: 1500 };
  }
  return findManagerTier(teamDeposits, tiers);
}

interface DepositDetail {
  id: string;
  amount: number;
  creditedAmount: number;
  clientName: string;
  date: string;
  isSplit: boolean;
}

interface FeeDetail {
  date: string;
  lateStartFee: number;
  breakTimeFee: number;
  totalFee: number;
}

interface TeamDepositDetail {
  memberName: string;
  amount: number;
  clientName: string;
  date: string;
}

interface SalaryData {
  userId: string;
  fullName: string;
  username: string;
  role: string;
  baseSalary: number;
  totalDeposits: number;
  commission: number;
  commissionRate: number;
  transferValue: number;
  singleTransferPrice: number;
  totalFees: number;
  lateStartFees: number;
  breakTimeFees: number;
  advanceAmount: number;
  netSalary: number;
  depositDetails: DepositDetail[];
  feeDetails: FeeDetail[];
  
  conversions?: number;
  teamCommission: number;
  teamCommissionRate: number;
  teamDeposits: number;
  teamDepositDetails: TeamDepositDetail[];
  isCloser?: boolean;
}

// Holiday dates are fetched dynamically from admin_settings per tenant

// Generate month options for the last 12 months
const getMonthOptions = () => {
  const options = [];
  for (let i = 0; i < 12; i++) {
    const date = subMonths(new Date(), i);
    options.push({
      value: format(date, "yyyy-MM"),
      label: format(date, "MMMM yyyy"),
    });
  }
  return options;
};

export default function Salary() {
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();
  const { isTenantOwner, isSuperAdmin } = useUserData();
  const canManageApprovals = isTenantOwner || isSuperAdmin;
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), "yyyy-MM"));
  const [activeTab, setActiveTab] = useState<"salary" | "approvals">("salary");
  const [rulesDialogOpen, setRulesDialogOpen] = useState(false);
  const [customDialogOpen, setCustomDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<CustomSalaryEntry | null>(null);
  const [advanceDialogOpen, setAdvanceDialogOpen] = useState(false);
  const [advanceTarget, setAdvanceTarget] = useState<{ userId: string; fullName: string } | null>(null);
  const monthOptions = useMemo(() => getMonthOptions(), []);
  
  // Get tier settings
  const { tierSettings, managerSettings } = useCommissionTierSettings(selectedMonth);

  // Custom salary entries
  const { entries: customEntries, createEntry, updateEntry, deleteEntry } = useCustomSalaryEntries(effectiveTenantId, selectedMonth);

  // Advance payments
  const { advances, getAdvanceForUser, upsertAdvance, deleteAdvance } = useAdvancePayments(effectiveTenantId, selectedMonth);
  const { isLocked, isAutoLocked, canToggle: canToggleLock, toggle: toggleLock } = useSalaryMonthLock(selectedMonth);

  // Parse selected month to get date range
  const { startDate, endDate } = useMemo(() => {
    const [year, month] = selectedMonth.split("-").map(Number);
    const date = new Date(year, month - 1, 1);
    return {
      startDate: startOfMonth(date).toISOString(),
      endDate: endOfMonth(date).toISOString(),
    };
  }, [selectedMonth]);

  // Fetch users with AGENT or SUPER_AGENT roles
  const { data: salaryData, isLoading } = useQuery({
    queryKey: ["salary-data", effectiveTenantId, selectedMonth, tierSettings, managerSettings, advances],
    enabled: !!effectiveTenantId && !!tierSettings,
    queryFn: async () => {
      console.log('[Salary] Query starting, effectiveTenantId:', effectiveTenantId, 'tierSettings:', !!tierSettings);
      // Get all users for this tenant with team assignment info
      // Includes soft-deleted users so they still appear in months they worked.
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, username, created_by, created_at, deleted_at, is_closer")
        .eq("admin_id", effectiveTenantId);

      if (profilesError) throw profilesError;
      if (!profiles || profiles.length === 0) return [];

      // Get roles for these users (including managers)
      const userIds = profiles.map((p) => p.id);
      const { data: roles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("user_id", userIds)
        .in("role", ["AGENT", "SUPER_AGENT", "MANAGER", "TEAM_LEADER"]);

      if (rolesError) throw rolesError;
      // (Soft-deleted users have their roles removed, so they won't appear here.
      //  That's the correct behaviour going forward — past attendance/deposit rows
      //  attributed to them via *historical* user-id columns are still counted.)

      // Filter to only agents, super agents, and managers AND
      // only users active during the selected month:
      //   created_at <= endDate AND (deleted_at IS NULL OR deleted_at >= startDate)
      const roleMap = new Map(roles.map((r) => [r.user_id, r.role]));
      const rosterMonthStart = new Date(startDate);
      const rosterMonthEnd = new Date(endDate);
      const eligibleUsers = profiles.filter((p) => {
        if (!roleMap.has(p.id)) return false;
        const created = p.created_at ? new Date(p.created_at) : null;
        if (created && created > rosterMonthEnd) return false;
        if (p.deleted_at) {
          const del = new Date(p.deleted_at);
          if (del < rosterMonthStart) return false;
        }
        return true;
      });
      
      // Create a map of manager settings by manager_id
      const managerSettingsMap = new Map(
        (managerSettings || []).map((m) => [m.manager_id, m])
      );
      
      // Build team membership map: manager_id -> array of team member ids
      const teamByManager = new Map<string, string[]>();
      profiles.forEach(p => {
        if (p.created_by) {
          const team = teamByManager.get(p.created_by) || [];
          team.push(p.id);
          teamByManager.set(p.created_by, team);
        }
      });

      // Expand manager teams to include two-level depth (TL sub-teams)
      for (const [managerId, directReports] of teamByManager.entries()) {
        if (roleMap.get(managerId) === 'MANAGER') {
          const expandedTeam = [...directReports];
          for (const memberId of directReports) {
            if (roleMap.get(memberId) === 'TEAM_LEADER') {
              const tlSubTeam = teamByManager.get(memberId) || [];
              for (const subMemberId of tlSubTeam) {
                if (!expandedTeam.includes(subMemberId)) {
                  expandedTeam.push(subMemberId);
                }
              }
            }
          }
          teamByManager.set(managerId, expandedTeam);
        }
      }

      // Get deposits for the month with client info
      const { data: deposits, error: depositsError } = await supabase
        .from("deposits")
        .select("id, agent_id, super_agent_id, split_super_agent_id, closer_agent_id, amount, status, created_at, client_id, counts_for_agent")
        .eq("admin_id", effectiveTenantId)
        .eq("status", "approved")
        .gte("created_at", startDate)
        .lte("created_at", endDate);

      if (depositsError) throw depositsError;

      const clientIds = [...new Set((deposits || []).map(d => d.client_id).filter(Boolean))];
      const { data: clients } = await supabase
        .from("clients")
        .select("id, name, assigned_to, transferring_agent, closer_agent_id, conversion_super_agent_id, conversion_manager_id, converted_from_lead_id")
        .in("id", clientIds);
      
      const clientMap = new Map((clients || []).map(c => [c.id, c.name]));
      // Map of client conversion attribution for manager/TL team roll-ups
      const clientConversionMap = new Map<string, {
        transferring: string | null;
        closer: string | null;
        convSA: string | null;
        convMgr: string | null;
        assigned: string | null;
        isConverted: boolean;
      }>(
        (clients || []).map(c => [c.id, {
          transferring: (c as any).transferring_agent || null,
          closer: (c as any).closer_agent_id || null,
          convSA: (c as any).conversion_super_agent_id || null,
          convMgr: (c as any).conversion_manager_id || null,
          assigned: (c as any).assigned_to || null,
          isConverted: !!(c as any).converted_from_lead_id,
        }])
      );
      const profileNameMap = new Map(profiles.map(p => [p.id, p.full_name || p.username || 'Unknown']));

      // Count monthly conversions (transfers) per agent - only clients converted this month
      const { data: monthlyClients } = await supabase
        .from("clients")
        .select("id, assigned_to, transferring_agent")
        .eq("admin_id", effectiveTenantId)
        .gte("created_at", startDate)
        .lte("created_at", endDate);
      
      const conversionsByAgent = new Map<string, number>();
      (monthlyClients || []).forEach(c => {
        // Count by transferring_agent (the agent who transferred/converted the lead)
        const agentId = c.transferring_agent || c.assigned_to;
        if (agentId) {
          conversionsByAgent.set(agentId, (conversionsByAgent.get(agentId) || 0) + 1);
        }
      });

      // Get attendance/fees for the month - use proper end of month date
      const monthEndDate = format(endOfMonth(new Date(startDate)), 'yyyy-MM-dd');
      const monthStartDate = format(startOfMonth(new Date(startDate)), 'yyyy-MM-dd');
      const { data: attendance, error: attendanceError } = await supabase
        .from("attendance")
        .select("user_id, date, late_start_fee, break_time_fee, total_fees, released_fees, rule_snapshot, notes")
        .eq("admin_id", effectiveTenantId)
        .gte("date", monthStartDate)
        .lte("date", monthEndDate);

      if (attendanceError) throw attendanceError;

      const filteredAttendance = (attendance || []).filter(
        (record) => !((record.notes as string | null)?.includes("Holiday"))
      );

      // --- Day-Off Fee Calculation (matches useAttendance virtual records) ---
      // Build historical rules timeline from rule_snapshots in attendance records
      const historicalRules: Array<{ date: string; day_off_fee: number }> = [];
      filteredAttendance.forEach((a) => {
        if (a.rule_snapshot && typeof a.rule_snapshot === 'object' && !Array.isArray(a.rule_snapshot)) {
          const snap = a.rule_snapshot as Record<string, unknown>;
          const dayOffFee = Number(snap.day_off_fee) || 0;
          historicalRules.push({ date: a.date, day_off_fee: dayOffFee });
        }
      });
      // Sort by date ascending and deduplicate
      historicalRules.sort((a, b) => a.date.localeCompare(b.date));

      // Also fetch current tenant settings as fallback for day_off_fee and honorable absences
      const { data: tenantSettingsForFees } = await supabase
        .from("admin_settings")
        .select("day_off_fee, monthly_honorable_absences, holiday_dates")
        .eq("admin_id", effectiveTenantId!)
        .maybeSingle();
      const fallbackDayOffFee = Number(tenantSettingsForFees?.day_off_fee) || 0;
      const monthlyHonorableAbsences = Number(tenantSettingsForFees?.monthly_honorable_absences) || 0;
      const salaryHolidayDates = new Set<string>((tenantSettingsForFees as any)?.holiday_dates || []);

      // Resolve day_off_fee for a given date from historical snapshots
      const resolveDayOffFee = (date: string): number => {
        for (let i = historicalRules.length - 1; i >= 0; i--) {
          if (historicalRules[i].date <= date) {
            return historicalRules[i].day_off_fee;
          }
        }
        return fallbackDayOffFee;
      };

      // Generate all weekdays in the month up to today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const monthStart = new Date(startDate);
      const monthEnd = endOfMonth(monthStart);
      const weekdays: string[] = [];
      const cursor = new Date(monthStart);
      while (cursor <= monthEnd && cursor <= today) {
        const dow = cursor.getDay();
        const dateKey = format(cursor, 'yyyy-MM-dd');
        if (dow !== 0 && dow !== 6 && !salaryHolidayDates.has(dateKey)) { // skip weekends and holidays
          weekdays.push(dateKey);
        }
        cursor.setDate(cursor.getDate() + 1);
      }

      // Build attendance date sets per user (exclude "Day off" records — they're still absences)
      const attendanceDatesByUser = new Map<string, Set<string>>();
      // Track day-off records with their total_fees so we know if they were released
      const dayOffRecordFees = new Map<string, Map<string, number>>();
      filteredAttendance.forEach((a) => {
        if (a.notes?.includes("Day off")) {
          // Track day-off records with their current total_fees value
          const userMap = dayOffRecordFees.get(a.user_id) || new Map();
          userMap.set(a.date, Number(a.total_fees) || 0);
          dayOffRecordFees.set(a.user_id, userMap);
          return; // day-off records don't count as "present"
        }
        const set = attendanceDatesByUser.get(a.user_id) || new Set();
        set.add(a.date);
        attendanceDatesByUser.set(a.user_id, set);
      });

      // Get user creation dates to avoid charging day-off before they joined
      const userCreatedMap = new Map(profiles.map(p => [p.id, p.created_at || '']));

      // Calculate virtual day-off fees per user (only AGENT and SUPER_AGENT)
      const dayOffFeesByUser = new Map<string, { totalDayOffFees: number; dayOffDetails: FeeDetail[] }>();
      eligibleUsers.forEach((user) => {
        const role = roleMap.get(user.id);
        if (role !== 'AGENT' && role !== 'SUPER_AGENT' && role !== 'TEAM_LEADER') return;

        const userDates = attendanceDatesByUser.get(user.id) || new Set();
        const createdAt = userCreatedMap.get(user.id);
        const userCreatedDate = createdAt ? new Date(createdAt) : null;
        if (userCreatedDate) userCreatedDate.setHours(0, 0, 0, 0);

        let totalDayOff = 0;
        const details: FeeDetail[] = [];
        let dayOffCount = 0;

        const userDayOffFees = dayOffRecordFees.get(user.id) || new Map<string, number>();

        weekdays.forEach((wd) => {
          // Skip days before user was created
          if (userCreatedDate && new Date(wd + 'T00:00:00') < userCreatedDate) return;
          if (!userDates.has(wd)) {
            dayOffCount++;
            // First N day-offs are honorable (no fee) — matches attendance logic
            if (dayOffCount <= monthlyHonorableAbsences) return;
            // If a real day-off record exists in DB, use its current total_fees
            // (already reflects any releases done on attendance page)
            if (userDayOffFees.has(wd)) {
              const existingFee = userDayOffFees.get(wd)!;
              if (existingFee > 0) {
                totalDayOff += existingFee;
                details.push({
                  date: format(new Date(wd), "MMM dd"),
                  lateStartFee: 0,
                  breakTimeFee: 0,
                  totalFee: existingFee,
                });
              }
              return;
            }
            // No real record — compute virtual fee from settings/snapshots
            const fee = resolveDayOffFee(wd);
            if (fee > 0) {
              totalDayOff += fee;
              details.push({
                date: format(new Date(wd), "MMM dd"),
                lateStartFee: 0,
                breakTimeFee: 0,
                totalFee: fee,
              });
            }
          }
        });

        if (totalDayOff > 0) {
          dayOffFeesByUser.set(user.id, { totalDayOffFees: totalDayOff, dayOffDetails: details });
        }
      });

      // Calculate salary for each user using dynamic tiers
      // Map of which agent profiles are flagged as Closer Agents.
      const closerSet = new Set(
        profiles.filter((p) => (p as { is_closer?: boolean }).is_closer).map((p) => p.id)
      );

      const salaryResults: SalaryData[] = eligibleUsers.map((user) => {
        const role = roleMap.get(user.id) || "AGENT";
        const isAgent = role === "AGENT";
        const isManager = role === "MANAGER";
        const isSuperAgent = role === "SUPER_AGENT";
        const isTeamLeader = role === "TEAM_LEADER";
        const isCloserAgent = isAgent && closerSet.has(user.id);

        // Determine TL's effective role based on team composition
        // If TL has super agents → acts like super agent; otherwise like agent
        let tlActsAsSuperAgent = false;
        if (isTeamLeader) {
          const teamMemberIds = teamByManager.get(user.id) || [];
          tlActsAsSuperAgent = teamMemberIds.some(id => roleMap.get(id) === 'SUPER_AGENT');
        }

        // Calculate deposits for this user with details
        let totalDeposits = 0;
        const depositDetails: DepositDetail[] = [];
        
        // For TLs, also calculate team deposits separately for team commission
        let teamDeposits = 0;
        const teamDepositDetails: TeamDepositDetail[] = [];
        if (deposits) {
          deposits.forEach((d) => {
            const depositAmount = Number(d.amount) || 0;
            // Agent / Closer Agent / Manager / TL-personal earnings only count
            // when the Tenant Owner has flipped this deposit ON. SA branches
            // below are unaffected.
            const countsForAgent = (d as any).counts_for_agent === true;

            if ((isAgent || (isTeamLeader && !tlActsAsSuperAgent)) && d.agent_id === user.id && countsForAgent) {
              // Agent-style: own deposits as agent
              // If there's a closer agent, split 50/50
              const hasCloser = !!(d as any).closer_agent_id;
              const creditedAmount = hasCloser ? depositAmount / 2 : depositAmount;
              totalDeposits += creditedAmount;
              depositDetails.push({
                id: d.id,
                amount: depositAmount,
                creditedAmount,
                clientName: clientMap.get(d.client_id) || "Unknown",
                date: format(new Date(d.created_at), "MMM dd"),
                isSplit: hasCloser,
              });
            } else if ((isAgent || (isTeamLeader && !tlActsAsSuperAgent)) && (d as any).closer_agent_id === user.id && countsForAgent) {
              // Agent-style: closer agent gets 50% of the deposit
              const creditedAmount = depositAmount / 2;
              totalDeposits += creditedAmount;
              depositDetails.push({
                id: d.id,
                amount: depositAmount,
                creditedAmount,
                clientName: clientMap.get(d.client_id) || "Unknown",
                date: format(new Date(d.created_at), "MMM dd"),
                isSplit: true,
              });
            } else if ((isSuperAgent || (isTeamLeader && tlActsAsSuperAgent))) {
              // Super agent style: own deposits (NOT gated by counts_for_agent)
              const hasSplit = d.split_super_agent_id && d.split_super_agent_id !== d.super_agent_id;
              
              if (d.super_agent_id === user.id) {
                const creditedAmount = hasSplit ? depositAmount / 2 : depositAmount;
                totalDeposits += creditedAmount;
                depositDetails.push({
                  id: d.id,
                  amount: depositAmount,
                  creditedAmount,
                  clientName: clientMap.get(d.client_id) || "Unknown",
                  date: format(new Date(d.created_at), "MMM dd"),
                  isSplit: hasSplit,
                });
              } else if (d.split_super_agent_id === user.id) {
                const creditedAmount = depositAmount / 2;
                totalDeposits += creditedAmount;
                depositDetails.push({
                  id: d.id,
                  amount: depositAmount,
                  creditedAmount,
                  clientName: clientMap.get(d.client_id) || "Unknown",
                  date: format(new Date(d.created_at), "MMM dd"),
                  isSplit: true,
                });
              }
            } else if (isManager && countsForAgent) {
              // Managers earn commission only on deposits from clients that were
              // converted while THIS manager was the responsible manager. We rely on
              // the historical snapshot stored on clients.conversion_manager_id so
              // moving agents to a new manager does not retroactively shift credit.
              const conv = clientConversionMap.get(d.client_id);
              if (conv?.isConverted && conv.convMgr === user.id) {
                totalDeposits += depositAmount;
                depositDetails.push({
                  id: d.id,
                  amount: depositAmount,
                  creditedAmount: depositAmount,
                  clientName: clientMap.get(d.client_id) || "Unknown",
                  date: format(new Date(d.created_at), "MMM dd"),
                  isSplit: false,
                });
              }
            }

            // For TLs: calculate team deposits for additional team commission.
            // Use the historical conversion attribution snapshot (transferring /
            // closer / conv super agent / assigned at conversion time) so that
            // moving members between TL teams does not retroactively shift credit.
            if (isTeamLeader && countsForAgent) {
              const teamMemberIds = teamByManager.get(user.id) || [];
              const depositAmount2 = Number(d.amount) || 0;
              const conv = clientConversionMap.get(d.client_id);

              // Historical attribution first (matches manager logic).
              let contributorId: string | null = null;
              if (conv?.isConverted) {
                contributorId =
                  (conv.transferring && teamMemberIds.includes(conv.transferring)) ? conv.transferring
                  : (conv.closer && teamMemberIds.includes(conv.closer)) ? conv.closer
                  : (conv.convSA && teamMemberIds.includes(conv.convSA)) ? conv.convSA
                  : (conv.assigned && teamMemberIds.includes(conv.assigned)) ? conv.assigned
                  : null;
              }
              // Fallback: deposit-level contributor on current team (covers
              // non-converted clients and edge cases without a snapshot).
              if (!contributorId) {
                contributorId =
                  d.agent_id && teamMemberIds.includes(d.agent_id) ? d.agent_id
                  : (d as any).closer_agent_id && teamMemberIds.includes((d as any).closer_agent_id) ? (d as any).closer_agent_id
                  : d.super_agent_id && teamMemberIds.includes(d.super_agent_id) ? d.super_agent_id
                  : (d as any).split_super_agent_id && teamMemberIds.includes((d as any).split_super_agent_id) ? (d as any).split_super_agent_id
                  : null;
              }
              if (contributorId) {
                teamDeposits += depositAmount2;
                teamDepositDetails.push({
                  memberName: profileNameMap.get(contributorId) || 'Unknown',
                  amount: depositAmount2,
                  clientName: clientMap.get(d.client_id) || 'Unknown',
                  date: format(new Date(d.created_at), "MMM dd"),
                });
              }
            }
          });
        }

        // Find the matching tier and calculate commission dynamically
        let baseSalary: number;
        let commissionRate: number;
        let conversions: number | undefined;
        let transferValue = 0;
        let singleTransferPrice = 0;
        let teamCommission = 0;
        let teamCommissionRate = 0;

        if (isAgent || (isTeamLeader && !tlActsAsSuperAgent)) {
          // Agent-style salary: two independent tier lookups.
          // Closer Agents use the dedicated closer_agent_* tier set; everyone else uses agent_*.
          conversions = conversionsByAgent.get(user.id) || 0;
          const transferTiers = isCloserAgent
            ? (tierSettings?.closer_agent_tiers || [])
            : (tierSettings?.agent_tiers || []);
          const commissionTiers = isCloserAgent
            ? (tierSettings?.closer_agent_commission_tiers || [])
            : (tierSettings?.agent_commission_tiers || []);
          const commissionBasis = isCloserAgent
            ? (tierSettings?.closer_agent_commission_tier_basis ?? "deposit")
            : (tierSettings?.agent_commission_tier_basis ?? "deposit");

          const transferTier = findAgentTransferTier(conversions, transferTiers);
          baseSalary = transferTier.baseSalary;
          singleTransferPrice = transferTier.singleTransferValue || 0;
          transferValue = conversions * singleTransferPrice;
          const commissionTier = findAgentCommissionTier(
            totalDeposits,
            conversions,
            commissionTiers,
            commissionBasis
          );
          commissionRate = commissionTier.commissionPercent / 100;
        } else if (isTeamLeader && tlActsAsSuperAgent) {
          // Super agent-style salary
          const superAgentTier = findSuperAgentTier(totalDeposits, tierSettings?.super_agent_tiers || []);
          baseSalary = superAgentTier.baseSalary;
          commissionRate = superAgentTier.commissionPercent / 100;
        } else if (isManager) {
          // For managers: use tier-based calculation from base_salary_tiers if available.
          // Tier basis (deposit amount vs team transfer count) is per-manager.
          const managerSetting = managerSettingsMap.get(user.id);
          const managerTiers = managerSetting?.base_salary_tiers as TierLevel[] | undefined;
          const managerBasis = (managerSetting as { tier_basis?: "deposit" | "transfers" } | undefined)?.tier_basis ?? "deposit";
          const teamMemberIds = teamByManager.get(user.id) || [];
          const teamTransfers = teamMemberIds.reduce(
            (sum, id) => sum + (conversionsByAgent.get(id) || 0),
            0
          );
          const teamSize = teamMemberIds.length;
          const avgTeamTransfers = teamSize > 0 ? teamTransfers / teamSize : 0;

          if (managerTiers && managerTiers.length > 0) {
            const managerTier = findManagerTierByBasis(
              totalDeposits,
              avgTeamTransfers,
              managerTiers,
              managerBasis
            );
            baseSalary = managerTier.baseSalary;
            commissionRate = managerTier.commissionPercent / 100;
          } else {
            baseSalary = managerSetting?.base_salary ?? 1500;
            commissionRate = (managerSetting?.commission_percentage ?? 3) / 100;
          }
        } else {
          // For super agents: tier based on total deposits
          const superAgentTier = findSuperAgentTier(totalDeposits, tierSettings?.super_agent_tiers || []);
          baseSalary = superAgentTier.baseSalary;
          commissionRate = superAgentTier.commissionPercent / 100;
        }

        // For TLs: team commission from team deposits, and base salary
        // sourced from Managers & TLs config when configured (replaces the
        // agent/SA personal base). When no TL config exists, fall back to
        // the agent/SA-style personal base computed above.
        if (isTeamLeader) {
          const tlSetting = managerSettingsMap.get(user.id);
          const tlTiers = tlSetting?.base_salary_tiers as TierLevel[] | undefined;
          const tlBasis = (tlSetting as { tier_basis?: "deposit" | "transfers" } | undefined)?.tier_basis ?? "deposit";
          const tlTeamMemberIds = teamByManager.get(user.id) || [];
          const tlTeamTransfers = tlTeamMemberIds.reduce(
            (sum, id) => sum + (conversionsByAgent.get(id) || 0),
            0
          );
          const tlTeamSize = tlTeamMemberIds.length;
          const avgTlTeamTransfers = tlTeamSize > 0 ? tlTeamTransfers / tlTeamSize : 0;

          if (tlTiers && tlTiers.length > 0) {
            const tlTier = findManagerTierByBasis(
              teamDeposits,
              avgTlTeamTransfers,
              tlTiers,
              tlBasis
            );
            baseSalary = tlTier.baseSalary; // replace personal base with TL config
            if (teamDeposits > 0) {
              teamCommissionRate = tlTier.commissionPercent;
              teamCommission = teamDeposits * (tlTier.commissionPercent / 100);
            }
          } else if (tlSetting) {
            baseSalary = tlSetting.base_salary; // replace with flat TL base salary
            if (teamDeposits > 0) {
              teamCommissionRate = tlSetting.commission_percentage;
              teamCommission = teamDeposits * (tlSetting.commission_percentage / 100);
            }
          }
          // else: no TL config → keep agent/SA-style base computed above
        }

        const commission = totalDeposits * commissionRate;

        // Calculate fees for this user with details
        let lateStartFees = 0;
        let breakTimeFees = 0;
        let totalFees = 0;
        const feeDetails: FeeDetail[] = [];
        
        if (filteredAttendance.length > 0) {
          filteredAttendance
            .filter((a) => a.user_id === user.id)
            .forEach((a) => {
              // Skip day-off records — they are handled in the virtual day-off loop
              if (a.notes?.includes("Day off")) return;
              
              // Skip holiday records — attendance page shows $0 for holidays
              const recordDate = typeof a.date === 'string' ? a.date : format(new Date(a.date), 'yyyy-MM-dd');
              if (salaryHolidayDates.has(recordDate)) return;
              
              // Skip weekend records
              const dow = new Date(recordDate).getDay();
              if (dow === 0 || dow === 6) return;
              
              // total_fees is already net (reduced when fees are released on Attendance page)
              const lateFee = Math.max(0, Number(a.late_start_fee) || 0);
              const breakFee = Math.max(0, Number(a.break_time_fee) || 0);
              const total = Math.max(0, Number(a.total_fees) || 0);
              
              lateStartFees += lateFee;
              breakTimeFees += breakFee;
              totalFees += total;
              
              if (total > 0) {
                feeDetails.push({
                  date: format(new Date(a.date), "MMM dd"),
                  lateStartFee: lateFee,
                  breakTimeFee: breakFee,
                  totalFee: total,
                });
              }
            });
        }

        // Add virtual day-off fees (matching attendance page logic)
        const dayOffData = dayOffFeesByUser.get(user.id);
        if (dayOffData) {
          totalFees += dayOffData.totalDayOffFees;
          feeDetails.push(...dayOffData.dayOffDetails);
        }

        const advanceEntry = getAdvanceForUser(user.id);
        const advanceAmount = advanceEntry ? Number(advanceEntry.amount) : 0;
        const netSalary = baseSalary + commission + teamCommission + transferValue - totalFees - advanceAmount;

        return {
          userId: user.id,
          fullName: user.full_name || user.username || "Unknown",
          username: user.username || "",
          role,
          baseSalary,
          totalDeposits,
          commission,
          commissionRate: commissionRate * 100,
          transferValue,
          singleTransferPrice,
          lateStartFees,
          breakTimeFees,
          totalFees,
          advanceAmount,
          netSalary,
          depositDetails,
          feeDetails,
          conversions,
          teamCommission,
          teamCommissionRate,
          teamDeposits,
          teamDepositDetails,
          isCloser: isCloserAgent,
        };
      });

      // Sort by net salary descending
      return salaryResults.sort((a, b) => b.netSalary - a.netSalary);
    },
  });

  // Realtime: refetch salary data when attendance records change
  useEffect(() => {
    if (!effectiveTenantId) return;
    const channel = supabase
      .channel('salary-attendance-sync')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'attendance' },
        () => {
          queryClient.invalidateQueries({ queryKey: ["salary-data", effectiveTenantId, selectedMonth] });
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [effectiveTenantId, selectedMonth, queryClient]);

  // Calculate totals
  const totals = useMemo(() => {
    const fromSalary = (salaryData || []).reduce(
      (acc, row) => ({
        totalBase: acc.totalBase + row.baseSalary,
        totalCommission: acc.totalCommission + row.commission,
        totalTeamCommission: acc.totalTeamCommission + row.teamCommission,
        totalTransferValue: acc.totalTransferValue + row.transferValue,
        totalFees: acc.totalFees + row.totalFees,
        totalAdvances: acc.totalAdvances + row.advanceAmount,
        totalNet: acc.totalNet + row.netSalary,
      }),
      { totalBase: 0, totalCommission: 0, totalTeamCommission: 0, totalTransferValue: 0, totalFees: 0, totalAdvances: 0, totalNet: 0 }
    );
    // Add custom entries
    customEntries.forEach((e) => {
      const adv = Number(e.advance) || 0;
      fromSalary.totalBase += Number(e.base_salary);
      fromSalary.totalCommission += Number(e.commission);
      fromSalary.totalAdvances += adv;
      fromSalary.totalNet += Number(e.base_salary) + Number(e.commission) - adv;
    });
    return fromSalary;
  }, [salaryData, customEntries]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(amount);
  };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Salary Calculator</h1>
        <p className="text-muted-foreground text-sm mt-1">Monthly salary calculations for agents and super agents</p>
      </div>

      <Tabs value={canManageApprovals ? activeTab : "salary"} onValueChange={(v) => setActiveTab(v as "salary" | "approvals")}>
        {canManageApprovals && (
          <TabsList>
            <TabsTrigger value="salary">Salary</TabsTrigger>
            <TabsTrigger value="approvals">Agent Deposit Approvals</TabsTrigger>
          </TabsList>
        )}
        {canManageApprovals && (
          <TabsContent value="approvals" className="mt-6">
            <AgentDepositApprovalsTab selectedMonth={selectedMonth} />
          </TabsContent>
        )}
        <TabsContent value="salary" className="mt-6 space-y-6">
            {/* Month Selector and Rules Button */}
            <div className="flex flex-wrap items-center gap-4">
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Select month" />
          </SelectTrigger>
          <SelectContent>
            {monthOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={() => setRulesDialogOpen(true)} disabled={isLocked}>
          <Settings className="h-4 w-4 mr-2" />
          Configure Rules
        </Button>
        <Button variant="outline" onClick={() => { setEditingEntry(null); setCustomDialogOpen(true); }} disabled={isLocked}>
          <Plus className="h-4 w-4 mr-2" />
          Add Custom Salary
        </Button>
        {salaryData && salaryData.length > 0 && (
          <Button
            variant="outline"
            onClick={() => {
              const monthLabel = monthOptions.find(o => o.value === selectedMonth)?.label || selectedMonth;
              exportSalaryToExcel(
                salaryData,
                customEntries.map(e => ({
                  id: e.id,
                  name: e.name,
                  base_salary: Number(e.base_salary),
                  commission: Number(e.commission),
                  advance: Number(e.advance) || 0,
                })),
                monthLabel
              );
            }}
          >
            <Download className="h-4 w-4 mr-2" />
            Export Excel
          </Button>
        )}
        {canToggleLock && (
          <Button
            variant={isLocked ? "default" : "outline"}
            onClick={() => toggleLock.mutate(!isLocked)}
            disabled={toggleLock.isPending}
          >
            {isLocked ? <Unlock className="h-4 w-4 mr-2" /> : <Lock className="h-4 w-4 mr-2" />}
            {isLocked ? "Unlock month" : "Lock month"}
          </Button>
        )}
      </div>

      {isLocked && (
        <Alert>
          <Lock className="h-4 w-4" />
          <AlertDescription>
            <strong>{monthOptions.find(o => o.value === selectedMonth)?.label || selectedMonth} is locked.</strong>{" "}
            {isAutoLocked
              ? "This month was automatically locked because it has ended."
              : "Rules, advances, and custom entries can't be edited so historical salary records stay frozen."}
            {canToggleLock && " Use 'Unlock month' to make changes."}
          </AlertDescription>
        </Alert>
      )}

      <SalaryRulesDialog open={rulesDialogOpen} onOpenChange={setRulesDialogOpen} />
      <CustomSalaryDialog
        open={customDialogOpen}
        onOpenChange={setCustomDialogOpen}
        entry={editingEntry}
        isPending={createEntry.isPending || updateEntry.isPending || deleteEntry.isPending}
        onSave={(data) => {
          if (editingEntry) {
            updateEntry.mutate({ id: editingEntry.id, ...data }, { onSuccess: () => setCustomDialogOpen(false) });
          } else {
            createEntry.mutate({ admin_id: effectiveTenantId!, month: selectedMonth, ...data }, { onSuccess: () => setCustomDialogOpen(false) });
          }
        }}
        onDelete={editingEntry ? () => {
          deleteEntry.mutate(editingEntry.id, { onSuccess: () => setCustomDialogOpen(false) });
        } : undefined}
      />
      <AdvancePaymentDialog
        open={advanceDialogOpen}
        onOpenChange={setAdvanceDialogOpen}
        userName={advanceTarget?.fullName || ""}
        currentAmount={advanceTarget ? getAdvanceForUser(advanceTarget.userId)?.amount : undefined}
        currentNote={advanceTarget ? getAdvanceForUser(advanceTarget.userId)?.note || "" : ""}
        isPending={upsertAdvance.isPending || deleteAdvance.isPending}
        onSave={(amount, note) => {
          if (advanceTarget && effectiveTenantId) {
            upsertAdvance.mutate(
              { admin_id: effectiveTenantId, user_id: advanceTarget.userId, month: selectedMonth, amount, note },
              { onSuccess: () => setAdvanceDialogOpen(false) }
            );
          }
        }}
        onDelete={advanceTarget && getAdvanceForUser(advanceTarget.userId) ? () => {
          const adv = getAdvanceForUser(advanceTarget!.userId);
          if (adv) deleteAdvance.mutate(adv.id, { onSuccess: () => setAdvanceDialogOpen(false) });
        } : undefined}
      />

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Base Salaries</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-bold">{formatCurrency(totals.totalBase)}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Commissions</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-bold text-green-600">{formatCurrency(totals.totalCommission)}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Transfers Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-bold text-green-600">{formatCurrency(totals.totalTransferValue)}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Advances</CardTitle>
            <Banknote className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-bold text-destructive">{formatCurrency(totals.totalAdvances)}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deductions</CardTitle>
            <Minus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-bold text-destructive">{formatCurrency(totals.totalFees)}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Net Salaries</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-2xl font-bold text-primary">{formatCurrency(totals.totalNet)}</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Salary Table */}
      <Card>
        <CardHeader>
          <CardTitle>Salary Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          {!effectiveTenantId ? (
            <div className="text-center py-8 text-muted-foreground">
              Please select a tenant to view salary data
            </div>
          ) : isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : (salaryData && salaryData.length > 0) || customEntries.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      Name
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-muted-foreground" />
                      Role
                    </div>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <DollarSign className="h-4 w-4 text-muted-foreground" />
                      Base Salary
                    </div>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Wallet className="h-4 w-4 text-muted-foreground" />
                      Deposits
                    </div>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Percent className="h-4 w-4 text-muted-foreground" />
                      Commission
                    </div>
                   </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      Team Comm.
                    </div>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <TrendingUp className="h-4 w-4 text-muted-foreground" />
                      Transfer Value
                     </div>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Receipt className="h-4 w-4 text-muted-foreground" />
                      Fees
                    </div>
                   </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Banknote className="h-4 w-4 text-muted-foreground" />
                      Advance
                    </div>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Calculator className="h-4 w-4 text-muted-foreground" />
                      Net Salary
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(salaryData || []).map((row) => (
                  <TableRow key={row.userId}>
                    <TableCell className="font-medium">{row.fullName}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <Badge 
                          variant="outline" 
                          className={
                            row.role === "MANAGER"
                              ? "bg-purple-500/20 text-purple-400 border-purple-500/30"
                              : row.role === "TEAM_LEADER"
                                ? "bg-blue-500/20 text-blue-400 border-blue-500/30"
                                : row.role === "SUPER_AGENT" 
                                  ? "bg-amber-500/20 text-amber-400 border-amber-500/30" 
                                  : "bg-green-500/20 text-green-400 border-green-500/30"
                          }
                        >
                          {row.role === "MANAGER" ? "Manager" : row.role === "TEAM_LEADER" ? "Team Leader" : row.role === "SUPER_AGENT" ? "Super Agent" : "Agent"}
                        </Badge>
                        {row.isCloser && (
                          <Badge variant="outline" className="bg-pink-500/20 text-pink-400 border-pink-500/30">
                            Closer
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(row.baseSalary)}</TableCell>
                    
                    {/* Deposits with Hover */}
                    <TableCell className="text-right">
                      <HoverCard>
                        <HoverCardTrigger asChild>
                          <span className="cursor-help inline-flex items-center gap-1 underline decoration-dotted underline-offset-2">
                            <span className="flex flex-col items-end">
                              <span>{formatCurrency(row.totalDeposits)}</span>
                              {row.role === "TEAM_LEADER" && row.teamDeposits > 0 && (
                                <span className="text-[10px] text-muted-foreground">
                                  Team: {formatCurrency(row.teamDeposits)}
                                </span>
                              )}
                            </span>
                            {row.depositDetails.length > 0 && (
                              <Info className="h-3 w-3 text-muted-foreground" />
                            )}
                          </span>
                        </HoverCardTrigger>
                        <HoverCardContent className="w-80" align="end">
                          <div className="space-y-2">
                            <h4 className="font-semibold text-sm">Deposit Details ({row.depositDetails.length})</h4>
                            {row.depositDetails.length > 0 ? (
                              <div className="max-h-48 overflow-y-auto space-y-1">
                                {row.depositDetails.map((dep, idx) => (
                                  <div key={idx} className="text-xs py-1 border-b border-border/50 last:border-0">
                                    <div className="flex items-center gap-2">
                                      <span className="text-muted-foreground">{dep.date}</span>
                                      <span className="font-medium">{dep.clientName}</span>
                                    </div>
                                    <div className="text-green-600 mt-0.5">
                                      <span>{formatCurrency(dep.creditedAmount)}</span>
                                      {dep.isSplit && (
                                        <Badge variant="outline" className="ml-1 text-[9px] px-1 py-0">50%</Badge>
                                      )}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-xs text-muted-foreground">No deposits this month</p>
                            )}
                            <div className="border-t pt-2 flex justify-between font-semibold text-sm">
                              <span>Total</span>
                              <span className="text-green-600">{formatCurrency(row.totalDeposits)}</span>
                            </div>
                            {row.role === "TEAM_LEADER" && row.teamDepositDetails.length > 0 && (
                              <div className="border-t pt-2 mt-2 space-y-1">
                                <h4 className="font-semibold text-sm">Team Deposits ({row.teamDepositDetails.length})</h4>
                                <div className="max-h-48 overflow-y-auto space-y-1">
                                  {row.teamDepositDetails.map((td, idx) => (
                                    <div key={idx} className="text-xs py-1 border-b border-border/50 last:border-0">
                                      <div className="flex items-center gap-2">
                                        <span className="text-muted-foreground">{td.date}</span>
                                        <span className="font-medium">{td.memberName}</span>
                                      </div>
                                      <div className="flex items-center gap-2 mt-0.5">
                                        <span className="text-muted-foreground">{td.clientName}</span>
                                        <span className="text-blue-500">{formatCurrency(td.amount)}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                <div className="border-t pt-1 flex justify-between font-semibold text-xs">
                                  <span>Team Total</span>
                                  <span className="text-blue-500">{formatCurrency(row.teamDeposits)}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </HoverCardContent>
                      </HoverCard>
                    </TableCell>
                    
                    <TableCell className="text-right text-green-600">
                      +{formatCurrency(row.commission)}
                      <span className="text-xs text-muted-foreground ml-1">
                        ({row.commissionRate}%)
                      </span>
                    </TableCell>
                    
                    {/* Team Commission (TLs only) */}
                    <TableCell className="text-right">
                      {row.teamCommission > 0 ? (
                        <span className="text-green-600">
                          +{formatCurrency(row.teamCommission)}
                          <span className="text-xs text-muted-foreground ml-1">
                            ({row.teamCommissionRate}%)
                          </span>
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    
                    {/* Transfer Value (agents only) */}
                    <TableCell className="text-right">
                      {row.transferValue > 0 ? (
                        <span className="text-green-600">
                          +{formatCurrency(row.transferValue)}
                          {row.conversions !== undefined && row.singleTransferPrice > 0 && (
                            <span className="text-xs text-muted-foreground ml-1">
                              ({row.conversions}×{row.singleTransferPrice})
                            </span>
                          )}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    
                    <TableCell className="text-right text-destructive">
                      <HoverCard>
                        <HoverCardTrigger asChild>
                          <span className="cursor-help inline-flex items-center gap-1 underline decoration-dotted underline-offset-2">
                            {row.totalFees > 0 ? `-${formatCurrency(row.totalFees)}` : formatCurrency(0)}
                            {row.feeDetails.length > 0 && (
                              <Info className="h-3 w-3 text-muted-foreground" />
                            )}
                          </span>
                        </HoverCardTrigger>
                        <HoverCardContent className="w-72" align="end">
                          <div className="space-y-2">
                            <h4 className="font-semibold text-sm">Fee Details ({row.feeDetails.length} days)</h4>
                            {row.feeDetails.length > 0 ? (
                              <>
                                <div className="max-h-48 overflow-y-auto space-y-1">
                                  {row.feeDetails.map((fee, idx) => (
                                    <div key={idx} className="text-xs py-1 border-b border-border/50 last:border-0">
                                      <div className="flex justify-between font-medium">
                                        <span>{fee.date}</span>
                                        <span className="text-destructive">-{formatCurrency(fee.totalFee)}</span>
                                      </div>
                                      <div className="flex justify-between text-muted-foreground pl-2">
                                        {fee.lateStartFee > 0 && (
                                          <span>Late: -{formatCurrency(fee.lateStartFee)}</span>
                                        )}
                                        {fee.breakTimeFee > 0 && (
                                          <span>Break: -{formatCurrency(fee.breakTimeFee)}</span>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                <div className="border-t pt-2 space-y-1 text-xs">
                                  <div className="flex justify-between text-muted-foreground">
                                    <span>Late Start Fees</span>
                                    <span>-{formatCurrency(row.lateStartFees)}</span>
                                  </div>
                                  <div className="flex justify-between text-muted-foreground">
                                    <span>Break Time Fees</span>
                                    <span>-{formatCurrency(row.breakTimeFees)}</span>
                                  </div>
                                  <div className="flex justify-between font-semibold text-sm pt-1 border-t">
                                    <span>Total</span>
                                    <span className="text-destructive">-{formatCurrency(row.totalFees)}</span>
                                  </div>
                                </div>
                              </>
                            ) : (
                              <p className="text-xs text-muted-foreground">No fees this month</p>
                            )}
                          </div>
                        </HoverCardContent>
                      </HoverCard>
                    </TableCell>
                    
                    {/* Advance Payment */}
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={isLocked}
                        title={isLocked ? "Month is locked" : undefined}
                        className={row.advanceAmount > 0 ? "text-destructive" : "text-muted-foreground"}
                        onClick={() => {
                          setAdvanceTarget({ userId: row.userId, fullName: row.fullName });
                          setAdvanceDialogOpen(true);
                        }}
                      >
                        {row.advanceAmount > 0 ? `-${formatCurrency(row.advanceAmount)}` : "—"}
                      </Button>
                    </TableCell>

                    <TableCell className="text-right font-bold">{formatCurrency(row.netSalary)}</TableCell>
                  </TableRow>
                ))}
                {/* Custom salary entries */}
                {customEntries.map((entry) => (
                  <TableRow key={`custom-${entry.id}`}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {entry.name}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          disabled={isLocked}
                          title={isLocked ? "Month is locked" : undefined}
                          onClick={() => { setEditingEntry(entry); setCustomDialogOpen(true); }}
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-muted text-muted-foreground border-border">
                        Custom
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(Number(entry.base_salary))}</TableCell>
                    <TableCell className="text-right text-muted-foreground">—</TableCell>
                    <TableCell className="text-right text-green-600">+{formatCurrency(Number(entry.commission))}</TableCell>
                    <TableCell className="text-right text-muted-foreground">—</TableCell>
                    <TableCell className="text-right text-muted-foreground">—</TableCell>
                    <TableCell className="text-right text-muted-foreground">{formatCurrency(0)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={isLocked}
                        title={isLocked ? "Month is locked" : undefined}
                        className={Number(entry.advance) > 0 ? "text-destructive" : "text-muted-foreground"}
                        onClick={() => { setEditingEntry(entry); setCustomDialogOpen(true); }}
                      >
                        {Number(entry.advance) > 0 ? `-${formatCurrency(Number(entry.advance))}` : "—"}
                      </Button>
                    </TableCell>
                    <TableCell className="text-right font-bold">{formatCurrency(Number(entry.base_salary) + Number(entry.commission) - (Number(entry.advance) || 0))}</TableCell>
                  </TableRow>
                ))}
                {/* Totals Footer Row */}
                {((salaryData && salaryData.length > 0) || customEntries.length > 0) && (
                  <TableRow className="bg-muted/50 font-bold border-t-2">
                    <TableCell>TOTAL</TableCell>
                    <TableCell></TableCell>
                    <TableCell className="text-right">{formatCurrency(totals.totalBase)}</TableCell>
                    <TableCell className="text-right">—</TableCell>
                    <TableCell className="text-right text-green-600">+{formatCurrency(totals.totalCommission)}</TableCell>
                    <TableCell className="text-right text-green-600">{totals.totalTeamCommission > 0 ? `+${formatCurrency(totals.totalTeamCommission)}` : "—"}</TableCell>
                    <TableCell className="text-right text-green-600">{totals.totalTransferValue > 0 ? `+${formatCurrency(totals.totalTransferValue)}` : "—"}</TableCell>
                    <TableCell className="text-right text-destructive">{totals.totalFees > 0 ? `-${formatCurrency(totals.totalFees)}` : formatCurrency(0)}</TableCell>
                    <TableCell className="text-right text-destructive">{totals.totalAdvances > 0 ? `-${formatCurrency(totals.totalAdvances)}` : "—"}</TableCell>
                    <TableCell className="text-right">{formatCurrency(totals.totalNet)}</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No agents or super agents found for this month
            </div>
          )}
        </CardContent>
      </Card>

      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Calculation Formula</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>
            <strong>Agent:</strong> Base salary (transfer tier) + commission % (deposit tier) of own deposits + (conversions × single transfer value) - attendance fees - advance
          </p>
          <p>
            <strong>Super Agent:</strong> Base salary (tier-based) + commission % of own deposits (based on total deposit amount) - attendance fees - advance
          </p>
          <p>
            <strong>Team Leader:</strong> Base salary from Managers & TLs rules (when configured; otherwise Agent/Super Agent base based on team composition) + personal commission on own deposits (Agent/SA rules) + team commission % of team's total deposits (Managers & TLs rules) - attendance fees - advance
          </p>
          <p>
            <strong>Manager:</strong> Base salary (tier-based) + commission % of team's total deposits - advance
          </p>
          <p className="text-xs italic">
            Note: Split deposits are divided 50/50 between primary and split super agents. Commission rates and base salaries are configured in the Rules dialog.
          </p>
        </CardContent>
      </Card>
          </TabsContent>
      </Tabs>
    </div>
  );
}
