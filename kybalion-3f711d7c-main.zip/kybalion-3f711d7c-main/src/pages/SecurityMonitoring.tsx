import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Shield, Activity, Building2, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useSecurityMonitoring } from "@/hooks/useSecurityMonitoring";
import { TenantSessionsCard } from "@/components/security/TenantSessionsCard";
import { TenantLoginHistoryCard } from "@/components/security/TenantLoginHistoryCard";
import { ActiveUsersSessionsCard } from "@/components/security/ActiveUsersSessionsCard";
import { PageAccessByUser } from "@/components/security/PageAccessByUser";

export default function SecurityMonitoring() {
  const {
    sessionData,
    loginHistoryData,
    loadingSessions,
    loadingHistory,
    isSuperAdminRole,
    effectiveTenantId,
  } = useSecurityMonitoring();

  const showTenantGroupedView = isSuperAdminRole && !effectiveTenantId;

  return (
    <div className="pb-3 space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Security Monitoring</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {showTenantGroupedView
              ? "Real-time security monitoring across all tenants"
              : "Real-time security alerts and monitoring"}
          </p>
        </div>
        <Badge variant="outline" className="gap-1.5 text-xs">
          <Activity className="h-3 w-3" />
          Live
        </Badge>
      </div>

      <Card className="bg-primary text-primary-foreground border-0">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-4 w-4" />
            Active Sessions
          </CardTitle>
          <CardDescription className="text-xs text-primary-foreground/70">Current</CardDescription>
        </CardHeader>
        <CardContent className="pb-3">
          <div className="text-2xl font-bold">{sessionData?.totalSessions || 0}</div>
          {showTenantGroupedView && sessionData?.tenantGroups && (
            <div className="text-xs text-primary-foreground/70 mt-1">
              Across {sessionData.tenantGroups.length} tenant{sessionData.tenantGroups.length !== 1 ? "s" : ""}
            </div>
          )}
        </CardContent>
      </Card>

      <div>
        <h2 className="text-lg font-semibold mb-1">Page Access by User</h2>
        <p className="text-xs text-muted-foreground mb-3">
          Unique pages each user has reached or attempted (last 30 days). Click a card for details.
        </p>
        <PageAccessByUser />
      </div>


      {/* Tenant-grouped session monitoring for Super Admin */}
      {showTenantGroupedView ? (
        <>
          <Separator className="my-4" />
          <div className="flex items-center gap-2 mb-3">
            <Building2 className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Sessions by Tenant</h2>
          </div>
          
          {loadingSessions ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : sessionData?.tenantGroups && sessionData.tenantGroups.length > 0 ? (
            <div className="space-y-4">
              {sessionData.tenantGroups.map((tenantGroup) => (
                <TenantSessionsCard key={tenantGroup.tenantId} tenantGroup={tenantGroup} />
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              No active sessions across tenants
            </div>
          )}

          <Separator className="my-4" />
          <div className="flex items-center gap-2 mb-3">
            <Building2 className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Login History by Tenant</h2>
          </div>
          
          {loadingHistory ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : loginHistoryData?.tenantGroups && loginHistoryData.tenantGroups.length > 0 ? (
            <div className="grid gap-3 md:grid-cols-2">
              {loginHistoryData.tenantGroups.map((tenantGroup) => (
                <TenantLoginHistoryCard key={tenantGroup.tenantId} tenantGroup={tenantGroup} />
              ))}
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              No login history across tenants
            </div>
          )}
        </>
      ) : (
        /* Single tenant view */
        <div className="grid gap-3 md:grid-cols-2">
          <ActiveUsersSessionsCard />

          <Card className="bg-muted/30 border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Login Sessions History</CardTitle>
              <CardDescription className="text-xs">Complete login history by IP and device</CardDescription>
            </CardHeader>
            <CardContent className="pb-3">
              <ScrollArea className="h-[320px]">
                <div className="space-y-1.5">
                  {loginHistoryData?.sessions?.map((session) => {
                    const isExpired = new Date(session.expires_at) < new Date();
                    const deviceInfo = session.user_agent 
                      ? session.user_agent.includes('Mobile') 
                        ? 'Mobile' 
                        : session.user_agent.includes('Windows') 
                          ? 'Windows'
                          : session.user_agent.includes('Mac')
                            ? 'Mac'
                            : session.user_agent.includes('Linux')
                              ? 'Linux'
                              : 'Unknown'
                      : 'Unknown';

                    return (
                      <div
                        key={session.id}
                        className="flex items-start justify-between p-2.5 bg-muted/50 rounded-md hover:bg-muted/70 transition-colors text-sm"
                      >
                        <div className="space-y-1.5 flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <div className="font-medium truncate">
                              {session.profile?.full_name || session.profile?.email || 'Unknown User'}
                            </div>
                            {session.is_active && !isExpired && (
                              <Badge variant="default" className="text-[10px] h-4 px-1">Active</Badge>
                            )}
                            {isExpired && (
                              <Badge variant="destructive" className="text-[10px] h-4 px-1">Expired</Badge>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-muted-foreground">
                            <div className="truncate">
                              <span className="font-medium">IP:</span> {session.ip_address || 'Unknown'}
                            </div>
                            <div className="truncate">
                              <span className="font-medium">Device:</span> {deviceInfo}
                            </div>
                            <div className="truncate">
                              <span className="font-medium">Login:</span>{" "}
                              {formatDistanceToNow(new Date(session.created_at), { addSuffix: true })}
                            </div>
                            <div className="truncate">
                              <span className="font-medium">Activity:</span>{" "}
                              {formatDistanceToNow(new Date(session.last_activity), { addSuffix: true })}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  {loginHistoryData?.sessions?.length === 0 && (
                    <div className="text-center text-sm text-muted-foreground py-6">
                      No login history
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
