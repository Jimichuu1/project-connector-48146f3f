import { useParams, useNavigate } from "react-router-dom";
import { useLead } from "@/hooks/useLead";
import { useUserData } from "@/contexts/UserDataContext";
import { useDocuments } from "@/hooks/useDocuments";
import { useQueryClient } from "@tanstack/react-query";
import { useBreadcrumb } from "@/contexts/BreadcrumbContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, Phone, Globe, 
  Pencil, FileText, Users, Calendar, DollarSign, TrendingUp, Layers
} from "lucide-react";
import { LeadGroupName } from "@/components/leads/LeadGroupName";
import { LeadStatusDropdown } from "@/components/leads/LeadStatusDropdown";
import { ActivityLog } from "@/components/activity/ActivityLog";
import { CreateBankDialog } from "@/components/kyc/CreateBankDialog";
import { CreateNoteDialog } from "@/components/kyc/CreateNoteDialog";
import { ClientKYCBanks } from "@/components/kyc/ClientKYCBanks";
import { ClientKYCNotes } from "@/components/kyc/ClientKYCNotes";
import { DocumentsDialog } from "@/components/clients/DocumentsDialog";
import { EditLeadDialog } from "@/components/leads/EditLeadDialog";

import { useState, useEffect } from "react";
import { format } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils";

import { decodeId } from "@/lib/idCipher";

export default function LeadDetail() {
  const { id: idParam } = useParams<{ id: string }>();
  const id = decodeId(idParam) ?? undefined;
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: lead, isLoading } = useLead(id);
  const { 
    isSuperAdmin, isTenantOwner: isAdmin, isManager, isAgent, isSuperAgent,
    canViewPhone, canViewEmail 
  } = useUserData();
  const { documents } = useDocuments(id || '', 'lead');
  const [bankDialogOpen, setBankDialogOpen] = useState(false);
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [documentsDialogOpen, setDocumentsDialogOpen] = useState(false);
  
  const [assignedAgentId, setAssignedAgentId] = useState<string | null>(null);
  const [availableAgents, setAvailableAgents] = useState<Array<{ id: string; name: string }>>([]);

  const { setCustomLabel } = useBreadcrumb();

  // Set breadcrumb label to lead name
  useEffect(() => {
    if (lead?.name) {
      setCustomLabel(lead.name);
    }
    return () => setCustomLabel(null);
  }, [lead?.name, setCustomLabel]);

  // Email/call handlers removed with integrations cleanup

  // Derived permissions (using centralized user data)
  const canEdit = isSuperAdmin || isAdmin || isManager;
  const canChangeStatus = isSuperAdmin || isAdmin || isManager || isSuperAgent;
  const canManageAssignments = isSuperAdmin || isAdmin || isManager;
  const isFieldAgent = isAgent || isSuperAgent;

  // Fetch agents for assignment dropdowns (admin/manager only)
  useEffect(() => {
    const fetchAgents = async () => {
      if (!lead || !canManageAssignments) return;

      // Get AGENT role users for assignment dropdown
      const { data: agentRoles } = await supabase
        .from("user_roles")
        .select("user_id")
        .in("role", ["AGENT", "SUPER_AGENT"]);

      if (agentRoles) {
        const agentIds = agentRoles.map((r) => r.user_id);
        const { data: agents } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", agentIds);

        if (agents) {
          setAvailableAgents(
            agents.map((a) => ({
              id: a.id,
              name: a.full_name || a.email,
            }))
          );
        }
      }

      // Set current values
      setAssignedAgentId(lead.assigned_to || null);
    };

    fetchAgents();
  }, [lead, canManageAssignments]);

  const handleAssignedAgentChange = async (newAgentId: string) => {
    if (!lead) return;
    
    try {
      const { error } = await supabase
        .from("leads")
        .update({ assigned_to: newAgentId })
        .eq("id", lead.id);

      if (error) throw error;
      setAssignedAgentId(newAgentId);
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      toast.success("Assigned agent updated");
    } catch (error) {
      console.error("Error updating assigned agent:", error);
      toast.error("Failed to update assigned agent");
    }
  };


  // Computed visibility based on role settings (from centralized user data)
  const shouldShowEmail = canViewEmail;
  const shouldShowPhone = canViewPhone;

  if (isLoading) {
    return <div className="py-8">Loading...</div>;
  }

  if (!lead) {
    return (
      <div className="py-8">
        <Card>
          <CardContent className="p-6 text-center">
            Lead not found
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate('/leads')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Leads
        </Button>
        <div className="flex gap-2">
          {canEdit && (
            <Button size="sm" variant="outline" onClick={() => setEditDialogOpen(true)}>
              <Pencil className="h-4 w-4 mr-2" />
              Edit
            </Button>
          )}
        </div>
      </div>

      {/* Main Content - 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Lead Info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Lead Header Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl font-bold">{lead.name}</h1>
                    <LeadStatusDropdown 
                      status={lead.status}
                      disabled={!canChangeStatus}
                      onStatusChange={async (newStatus) => {
                        try {
                          const { error } = await supabase
                            .from("leads")
                            .update({ status: newStatus })
                            .eq("id", lead.id);
                          if (error) throw error;
                          queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
                          toast.success("Status updated");
                        } catch (error) {
                          console.error("Error updating status:", error);
                          toast.error("Failed to update status");
                        }
                      }}
                    />
                  </div>
                  {shouldShowEmail && (
                    <p className="text-muted-foreground mt-1">{lead.email}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Summary */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <DollarSign className="h-4 w-4" />
                  <span className="text-xs">Initial Balance</span>
                </div>
                <p className="text-lg font-semibold text-success">{formatCurrency((lead as any).balance)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <DollarSign className="h-4 w-4" />
                  <span className="text-xs">Initial Amt</span>
                </div>
                <p className="text-lg font-semibold">{formatCurrency((lead as any).equity)}</p>
              </CardContent>
            </Card>
          </div>


          {/* Lead Details */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {lead.country && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Globe className="h-3.5 w-3.5" />
                      <span className="text-xs">Country</span>
                    </div>
                    <p className="text-sm font-medium">{lead.country}</p>
                  </div>
                )}
                {shouldShowPhone && lead.phone && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-3.5 w-3.5" />
                      <span className="text-xs">Phone</span>
                    </div>
                    <button
                      onClick={() => {
                        const formattedPhone = lead.phone?.replace(/[^\d+]/g, "") || "";
                        navigator.clipboard.writeText(formattedPhone);
                        toast.success("Phone number copied to clipboard");
                      }}
                      className="text-sm font-medium hover:text-primary transition-colors cursor-pointer"
                    >
                      {lead.phone?.replace(/[^\d+]/g, "") || ""}
                    </button>
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Layers className="h-3.5 w-3.5" />
                    <span className="text-xs">Group</span>
                  </div>
                  <LeadGroupName leadId={lead.id} />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    <span className="text-xs">Created</span>
                  </div>
                  <p className="text-sm font-medium">{format(new Date(lead.created_at), 'MMM d, yyyy')}</p>
                </div>
                {lead.estimated_close_date && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calendar className="h-3.5 w-3.5" />
                      <span className="text-xs">Est. Close</span>
                    </div>
                    <p className="text-sm font-medium">{format(new Date(lead.estimated_close_date), 'MMM d, yyyy')}</p>
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <FileText className="h-3.5 w-3.5" />
                    <span className="text-xs">Documents</span>
                  </div>
                  <Button
                    variant="link"
                    size="sm"
                    className="h-auto p-0 text-sm font-medium"
                    onClick={() => setDocumentsDialogOpen(true)}
                  >
                    {documents?.length || 0} files
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - KYC Information */}
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6 space-y-6">
              <ClientKYCBanks 
                entityId={lead.id} 
                entityType="lead" 
                onAddBank={() => setBankDialogOpen(true)} 
              />
              <Separator />
              <ClientKYCNotes 
                entityId={lead.id} 
                entityType="lead" 
                onAddNote={() => setNoteDialogOpen(true)} 
              />
            </CardContent>
          </Card>

          {/* Activity Log - Admin/Manager Only */}
          {(isSuperAdmin || isAdmin || isManager) && (
            <ActivityLog entityType="lead" entityId={lead.id} />
          )}
        </div>
      </div>

      {/* Dialogs */}
      <CreateBankDialog
        entityId={lead.id}
        entityType="lead"
        open={bankDialogOpen}
        onOpenChange={setBankDialogOpen}
      />

      <CreateNoteDialog
        entityId={lead.id}
        entityType="lead"
        open={noteDialogOpen}
        onOpenChange={setNoteDialogOpen}
      />

      <EditLeadDialog
        lead={lead}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
      />

      <DocumentsDialog
        open={documentsDialogOpen}
        onOpenChange={setDocumentsDialogOpen}
        entityId={lead.id}
        entityType="lead"
      />


    </div>
  );
}
