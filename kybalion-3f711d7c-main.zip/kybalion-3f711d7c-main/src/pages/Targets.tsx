import { useMemo, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import { Target, Plus, ChevronLeft, ChevronRight, Trophy, Percent, Target as TargetIcon } from "lucide-react";
import { TargetCard, HistoryCard } from "@/components/targets/TargetCard";
import { HistoryTable } from "@/components/targets/HistoryTable";
import { UserSuccessSummaryCards } from "@/components/targets/UserSuccessSummaryCards";
import { useTenant } from "@/contexts/TenantContext";
import {
  useTargetProgress,
  useDeleteTarget,
  useTargetHistory,
  type TargetPeriod,
  type TargetProgress,
  type TargetHistoryRow,
} from "@/hooks/useTargets";
import { CreateTargetDialog } from "@/components/targets/CreateTargetDialog";
import { EditTargetDialog } from "@/components/targets/EditTargetDialog";
import { addMonths, subMonths, startOfMonth, format } from "date-fns";

function formatValue(target_type: "deposits" | "transfers", v: number) {
  return target_type === "deposits"
    ? `$${Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : String(v);
}

function CardGrid({
  targets,
  emptyText,
  onEdit,
  onDelete,
  avatarMap,
}: {
  targets: TargetProgress[];
  emptyText: string;
  onEdit: (t: TargetProgress) => void;
  onDelete: (id: string) => void;
  avatarMap: Map<string, string | null>;
}) {
  if (!targets.length) {
    return <div className="text-sm text-muted-foreground p-6 text-center">{emptyText}</div>;
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
      {targets.map(t => (
        <TargetCard key={t.id} target={t} avatarUrl={avatarMap.get(t.user_id)} onEdit={onEdit} onDelete={onDelete} />
      ))}
    </div>
  );
}

function HistoryGrid({
  rows,
  emptyText,
  avatarMap,
}: {
  rows: TargetHistoryRow[];
  emptyText: string;
  avatarMap: Map<string, string | null>;
}) {
  if (!rows.length) {
    return <div className="text-sm text-muted-foreground p-6 text-center">{emptyText}</div>;
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
      {rows.map(r => (
        <HistoryCard key={r.id} row={r} avatarUrl={avatarMap.get(r.user_id)} />
      ))}
    </div>
  );
}

function GroupedHistory({
  rows,
  emptyText,
  avatarMap,
  mode,
}: {
  rows: TargetHistoryRow[];
  emptyText: string;
  avatarMap: Map<string, string | null>;
  mode: "daily" | "weekly";
}) {
  if (!rows.length) {
    return <div className="text-sm text-muted-foreground p-6 text-center">{emptyText}</div>;
  }
  const groups = new Map<string, { start: string; end: string; rows: TargetHistoryRow[] }>();
  for (const r of rows) {
    const key = r.period_start;
    if (!groups.has(key)) groups.set(key, { start: r.period_start, end: r.period_end, rows: [] });
    groups.get(key)!.rows.push(r);
  }
  const sorted = Array.from(groups.values()).sort(
    (a, b) => new Date(b.start).getTime() - new Date(a.start).getTime()
  );
  return (
    <div className="space-y-6">
      {sorted.map(g => {
        const label =
          mode === "daily"
            ? format(new Date(g.start), "EEE, MMM d, yyyy")
            : `${format(new Date(g.start), "MMM d")} – ${format(new Date(g.end), "MMM d, yyyy")}`;
        return (
          <div key={g.start} className="space-y-3">
            <div className="flex items-center gap-2 border-b pb-2">
              <h3 className="text-sm font-semibold">{label}</h3>
              <span className="text-xs text-muted-foreground">· {g.rows.length} target{g.rows.length === 1 ? "" : "s"}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {g.rows.map(r => (
                <HistoryCard key={r.id} row={r} avatarUrl={avatarMap.get(r.user_id)} />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

type ViewMode = "current" | "history";

export default function TargetsPage() {
  const { effectiveTenantId } = useTenant();
  const [view, setView] = useState<ViewMode>("current");
  const [period, setPeriod] = useState<TargetPeriod>("monthly");
  const [createOpen, setCreateOpen] = useState(false);
  const [editing, setEditing] = useState<TargetProgress | null>(null);
  const [historyMonth, setHistoryMonth] = useState(() => startOfMonth(new Date()));
  const deleteMutation = useDeleteTarget();

  const { data: targets = [], isLoading } = useTargetProgress(effectiveTenantId, period);
  const { data: historyRows = [], isLoading: historyLoading } = useTargetHistory(effectiveTenantId, historyMonth);
  const { data: agents = [] } = useAgentsCache();
  const avatarMap = useMemo(() => new Map(agents.map(a => [a.id, a.avatar])), [agents]);

  const sortByProgress = (a: TargetProgress, b: TargetProgress) => {
    const pa = Number(a.target_value) > 0 ? Number(a.current_value) / Number(a.target_value) : 0;
    const pb = Number(b.target_value) > 0 ? Number(b.current_value) / Number(b.target_value) : 0;
    return pb - pa;
  };
  const agentTargets = targets.filter(t => t.target_type === "transfers").sort(sortByProgress);
  const tlTeamTargets = targets.filter(t => t.target_type === "team_transfers").sort(sortByProgress);

  const computeStats = (list: TargetProgress[]) => {
    const today = new Date();
    let achieved = 0;
    let atRisk = 0;
    for (const t of list) {
      const tv = Number(t.target_value) || 0;
      const cv = Number(t.current_value) || 0;
      const isAchieved = tv > 0 && cv >= tv;
      if (isAchieved) { achieved++; continue; }
      const start = new Date(t.period_start);
      const end = new Date(t.period_end);
      const totalMs = Math.max(1, end.getTime() - start.getTime());
      const elapsedMs = Math.min(totalMs, Math.max(0, today.getTime() - start.getTime()));
      const expectedPct = elapsedMs / totalMs;
      const progressPct = tv > 0 ? cv / tv : 0;
      if (progressPct < expectedPct - 0.1) atRisk++;
    }
    return { total: list.length, achieved, atRisk };
  };

  const agentStats = computeStats(agentTargets);
  const tlStats = computeStats(tlTeamTargets);

  const historyByPeriod = useMemo(() => {
    const map: Record<TargetPeriod, TargetHistoryRow[]> = { daily: [], weekly: [], monthly: [] };
    for (const r of historyRows) map[r.period].push(r);
    const sortHist = (a: TargetHistoryRow, b: TargetHistoryRow) => {
      const pa = Number(a.target_value) > 0 ? Number(a.current_value) / Number(a.target_value) : 0;
      const pb = Number(b.target_value) > 0 ? Number(b.current_value) / Number(b.target_value) : 0;
      return pb - pa;
    };
    map.daily.sort(sortHist); map.weekly.sort(sortHist); map.monthly.sort(sortHist);
    return map;
  }, [historyRows]);

  const total = historyRows.length;
  const achieved = historyRows.filter(r => r.achieved).length;
  const rate = total > 0 ? Math.round((achieved / total) * 100) : 0;

  const handleDelete = (id: string) => {
    if (confirm("Delete this target?")) deleteMutation.mutate(id);
  };

  return (
    <div className="container max-w-[1600px] mx-auto px-6 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Target className="h-6 w-6 text-primary" />
            Targets
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Track agent and team leader transfer targets.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Tabs value={view} onValueChange={(v) => setView(v as ViewMode)}>
            <TabsList>
              <TabsTrigger value="current">Current</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
          </Tabs>
          {view === "current" && (
            <>
              <Tabs value={period} onValueChange={(v) => setPeriod(v as TargetPeriod)}>
                <TabsList>
                  <TabsTrigger value="daily">Today</TabsTrigger>
                  <TabsTrigger value="weekly">This Week</TabsTrigger>
                  <TabsTrigger value="monthly">This Month</TabsTrigger>
                </TabsList>
              </Tabs>
              <Button onClick={() => setCreateOpen(true)} className="gap-2">
                <Plus className="h-4 w-4" /> New Target
              </Button>
            </>
          )}
        </div>
      </div>

      {view === "current" ? (
        <>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Targets Overview</CardTitle>
              <CardDescription>{format(new Date(), "MMMM yyyy")} · {period} · totals, achieved and at-risk per group</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  { label: "Agents", stats: agentStats },
                  { label: "Team Leaders", stats: tlStats },
                ].map(({ label, stats }) => (
                  <div key={label} className="rounded-md border p-3">
                    <div className="text-sm font-medium mb-2">{label}</div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <div className="text-xl font-bold">{stats.total}</div>
                        <div className="text-[11px] text-muted-foreground uppercase tracking-wide">Total</div>
                      </div>
                      <div>
                        <div className="text-xl font-bold text-emerald-600">{stats.achieved}</div>
                        <div className="text-[11px] text-muted-foreground uppercase tracking-wide">Achieved</div>
                      </div>
                      <div>
                        <div className="text-xl font-bold text-destructive">{stats.atRisk}</div>
                        <div className="text-[11px] text-muted-foreground uppercase tracking-wide">At Risk</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Agents — Transfer Targets</CardTitle>
              <CardDescription>{format(new Date(), "MMMM yyyy")} · {period}</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-sm text-muted-foreground p-4">Loading...</div>
              ) : (
                <CardGrid
                  targets={agentTargets}
                  emptyText="No agent transfer targets set for this period."
                  onEdit={setEditing}
                  onDelete={handleDelete}
                  avatarMap={avatarMap}
                />
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Team Leaders — Team Transfer Targets</CardTitle>
              <CardDescription>{format(new Date(), "MMMM yyyy")} · {period} · aggregated across each TL's team</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-sm text-muted-foreground p-4">Loading...</div>
              ) : (
                <CardGrid
                  targets={tlTeamTargets}
                  emptyText="No team-aggregate targets set for this period."
                  onEdit={setEditing}
                  onDelete={handleDelete}
                  avatarMap={avatarMap}
                />
              )}
            </CardContent>
          </Card>

        </>
      ) : (
        <>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setHistoryMonth(d => subMonths(d, 1))}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="px-4 py-2 rounded-md bg-muted text-sm font-medium min-w-[160px] text-center">
              {format(historyMonth, "MMMM yyyy")}
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setHistoryMonth(d => addMonths(d, 1))}
              disabled={startOfMonth(addMonths(historyMonth, 1)) > startOfMonth(new Date())}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-muted-foreground">Total Targets</CardTitle>
                <TargetIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent><div className="text-2xl font-bold">{total}</div></CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-muted-foreground">Achieved</CardTitle>
                <Trophy className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent><div className="text-2xl font-bold text-emerald-600">{achieved}</div></CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm text-muted-foreground">Achievement Rate</CardTitle>
                <Percent className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent><div className="text-2xl font-bold">{rate}%</div></CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Targets in {format(historyMonth, "MMMM yyyy")}</CardTitle>
              <CardDescription>Daily, weekly and monthly targets that started in this month.</CardDescription>
            </CardHeader>
            <CardContent>
              {historyLoading ? (
                <div className="text-sm text-muted-foreground p-4">Loading...</div>
              ) : (
                <Tabs defaultValue="daily">
                  <TabsList>
                    <TabsTrigger value="daily">Daily ({historyByPeriod.daily.length})</TabsTrigger>
                    <TabsTrigger value="weekly">Weekly ({historyByPeriod.weekly.length})</TabsTrigger>
                    <TabsTrigger value="monthly">Monthly ({historyByPeriod.monthly.length})</TabsTrigger>
                  </TabsList>
                  <TabsContent value="daily" className="mt-4 space-y-4">
                    <UserSuccessSummaryCards
                      rows={historyByPeriod.daily}
                      avatarMap={avatarMap}
                      emptyText="No daily targets in this month."
                    />
                    <HistoryTable rows={historyByPeriod.daily} emptyText="No daily targets in this month." avatarMap={avatarMap} mode="daily" />
                  </TabsContent>
                  <TabsContent value="weekly" className="mt-4 space-y-4">
                    <UserSuccessSummaryCards
                      rows={historyByPeriod.weekly}
                      avatarMap={avatarMap}
                      emptyText="No weekly targets in this month."
                    />
                    <HistoryTable rows={historyByPeriod.weekly} emptyText="No weekly targets in this month." avatarMap={avatarMap} mode="weekly" />
                  </TabsContent>
                  <TabsContent value="monthly" className="mt-4">
                    <HistoryTable rows={historyByPeriod.monthly} emptyText="No monthly targets in this month." avatarMap={avatarMap} mode="monthly" />
                  </TabsContent>
                </Tabs>
              )}
            </CardContent>
          </Card>
        </>
      )}

      <CreateTargetDialog open={createOpen} onOpenChange={setCreateOpen} />
      <EditTargetDialog target={editing} open={!!editing} onOpenChange={(o) => !o && setEditing(null)} />
    </div>
  );
}
