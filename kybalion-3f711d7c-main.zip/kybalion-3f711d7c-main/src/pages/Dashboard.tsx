import { useState, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Users, TrendingUp, DollarSign, Building2, UserCheck, 
  BarChart3, Clock, Shield, ArrowUpRight, FileSpreadsheet, Eye
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, subDays, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { useNavigate } from "react-router-dom";
import { useUserData } from "@/contexts/UserDataContext";
import { useAuth } from "@/contexts/AuthContext";
import { exportDashboardToExcel } from "@/lib/dashboardExport";
import { ExcelMergeExport } from "@/components/dashboard/ExcelMergeExport";
import { TenantOwnerHub } from "@/components/dashboard/TenantOwnerHub";

// Generate month options for the last 12 months
const getMonthOptions = () => {
  const options = [];
  for (let i = 0; i < 12; i++) {
    const date = subMonths(new Date(), i);
    options.push({
      value: format(date, "yyyy-MM"),
      label: format(date, "MMMM yyyy"),
    });
  }
  return options;
};

const Dashboard = () => {
  const navigate = useNavigate();
  const { isSuperAdmin, isTenantOwner, loading: roleLoading } = useUserData();
  const { user } = useAuth();
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), "yyyy-MM"));
  const [isExporting, setIsExporting] = useState(false);
  
  const monthOptions = useMemo(() => getMonthOptions(), []);

  // For TENANT_OWNER, use their own ID as tenant filter
  const tenantFilter = !roleLoading && isTenantOwner && !isSuperAdmin ? user?.id : null;
  const roleReady = !roleLoading && (isSuperAdmin || isTenantOwner);

  // Fetch all tenants (only for SUPER_ADMIN)
  const { data: tenants, isLoading: tenantsLoading } = useQuery({
    queryKey: ["dashboard-tenants"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, full_name, username, created_at")
        .in("id", (
          await supabase
            .from("user_roles")
            .select("user_id")
            .eq("role", "TENANT_OWNER")
        ).data?.map(r => r.user_id) || []);
      
      if (error) throw error;
      return data || [];
    },
    enabled: roleReady && isSuperAdmin,
  });

  // Fetch stats - tenant-scoped for TENANT_OWNER, global for SUPER_ADMIN
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["dashboard-stats", tenantFilter, roleReady, selectedMonth],
    queryFn: async () => {
      // Compute month bounds from selectedMonth
      const [year, month] = selectedMonth.split('-').map(Number);
      const monthStart = startOfMonth(new Date(year, month - 1));
      const monthEnd = endOfMonth(new Date(year, month - 1));
      const monthStartISO = monthStart.toISOString();
      const monthEndISO = monthEnd.toISOString();

      // Build queries with optional tenant filter and month filter
      let leadsQuery = supabase.from("leads").select("id", { count: "exact", head: true }).gte("created_at", monthStartISO).lte("created_at", monthEndISO);
      let clientsQuery = supabase.from("clients").select("id", { count: "exact", head: true }).gte("created_at", monthStartISO).lte("created_at", monthEndISO);
      let depositsQuery = supabase.from("deposits").select("amount").eq("status", "approved").gte("created_at", monthStartISO).lte("created_at", monthEndISO);
      let pendingConversionsQuery = supabase.from("leads").select("id", { count: "exact", head: true }).eq("pending_conversion", true);
      let todayLeadsQuery = supabase.from("leads").select("id", { count: "exact", head: true }).gte("created_at", format(new Date(), "yyyy-MM-dd"));
      let todayClientsQuery = supabase.from("clients").select("id", { count: "exact", head: true }).gte("created_at", format(new Date(), "yyyy-MM-dd"));
      let weekLeadsQuery = supabase.from("leads").select("id", { count: "exact", head: true }).gte("created_at", format(subDays(new Date(), 7), "yyyy-MM-dd"));
      let weekClientsQuery = supabase.from("clients").select("id", { count: "exact", head: true }).gte("created_at", format(subDays(new Date(), 7), "yyyy-MM-dd"));

      // Apply tenant filter for TENANT_OWNER
      if (tenantFilter) {
        leadsQuery = leadsQuery.eq("admin_id", tenantFilter);
        clientsQuery = clientsQuery.eq("admin_id", tenantFilter);
        depositsQuery = depositsQuery.eq("admin_id", tenantFilter);
        pendingConversionsQuery = pendingConversionsQuery.eq("admin_id", tenantFilter);
        todayLeadsQuery = todayLeadsQuery.eq("admin_id", tenantFilter);
        todayClientsQuery = todayClientsQuery.eq("admin_id", tenantFilter);
        weekLeadsQuery = weekLeadsQuery.eq("admin_id", tenantFilter);
        weekClientsQuery = weekClientsQuery.eq("admin_id", tenantFilter);
      }

      // Get users count
      let usersCount = 0;
      if (tenantFilter) {
        // For tenant owner, count users in their tenant
        const { count } = await supabase
          .from("profiles")
          .select("id", { count: "exact", head: true })
          .eq("admin_id", tenantFilter);
        usersCount = count || 0;
      } else {
        // For super admin, count all users
        const { count } = await supabase
          .from("profiles")
          .select("id", { count: "exact", head: true });
        usersCount = count || 0;
      }

      const [
        leadsRes,
        clientsRes,
        depositsRes,
        pendingConversionsRes,
        todayLeadsRes,
        todayClientsRes,
        weekLeadsRes,
        weekClientsRes,
      ] = await Promise.all([
        leadsQuery,
        clientsQuery,
        depositsQuery,
        pendingConversionsQuery,
        todayLeadsQuery,
        todayClientsQuery,
        weekLeadsQuery,
        weekClientsQuery,
      ]);

      const totalDeposits = depositsRes.data?.reduce((sum, d) => sum + Number(d.amount), 0) || 0;
      const conversionRate = leadsRes.count && clientsRes.count 
        ? ((clientsRes.count / (leadsRes.count + clientsRes.count)) * 100).toFixed(1)
        : "0";

      return {
        totalLeads: leadsRes.count || 0,
        totalClients: clientsRes.count || 0,
        totalUsers: usersCount,
        totalDeposits,
        pendingConversions: pendingConversionsRes.count || 0,
        todayLeads: todayLeadsRes.count || 0,
        todayClients: todayClientsRes.count || 0,
        weekLeads: weekLeadsRes.count || 0,
        weekClients: weekClientsRes.count || 0,
        conversionRate,
      };
    },
    enabled: roleReady,
  });

  // Fetch tenant-specific stats (only for SUPER_ADMIN)
  const { data: tenantStats, isLoading: tenantStatsLoading } = useQuery({
    queryKey: ["dashboard-tenant-stats", tenants],
    queryFn: async () => {
      if (!tenants?.length) return [];

      const statsPromises = tenants.map(async (tenant) => {
        const [leadsRes, clientsRes, depositsRes, usersRes] = await Promise.all([
          supabase.from("leads").select("id", { count: "exact", head: true }).eq("admin_id", tenant.id),
          supabase.from("clients").select("id", { count: "exact", head: true }).eq("admin_id", tenant.id),
          supabase.from("deposits").select("amount").eq("admin_id", tenant.id).eq("status", "approved"),
          supabase.from("profiles").select("id", { count: "exact", head: true }).eq("admin_id", tenant.id),
        ]);

        const totalDeposits = depositsRes.data?.reduce((sum, d) => sum + Number(d.amount), 0) || 0;

        return {
          tenantId: tenant.id,
          tenantName: tenant.full_name || tenant.username || "Unknown Tenant",
          createdAt: tenant.created_at,
          leads: leadsRes.count || 0,
          clients: clientsRes.count || 0,
          deposits: totalDeposits,
          users: usersRes.count || 0,
        };
      });

      return Promise.all(statsPromises);
    },
    enabled: isSuperAdmin && !!tenants?.length,
  });

  // Fetch active sessions count - tenant-scoped
  const { data: activeSessions } = useQuery({
    queryKey: ["dashboard-sessions", tenantFilter],
    queryFn: async () => {
      if (tenantFilter) {
        // For tenant owner: get user IDs in tenant, then count their sessions
        const { data: tenantUsers } = await supabase
          .from("profiles")
          .select("id")
          .eq("admin_id", tenantFilter);
        const userIds = tenantUsers?.map(u => u.id) || [];
        if (userIds.length === 0) return 0;
        const { count } = await supabase
          .from("user_sessions")
          .select("id", { count: "exact", head: true })
          .gt("expires_at", new Date().toISOString())
          .in("user_id", userIds);
        return count || 0;
      }
      
      const { count } = await supabase
        .from("user_sessions")
        .select("id", { count: "exact", head: true })
        .gt("expires_at", new Date().toISOString());
      return count || 0;
    },
    enabled: roleReady,
  });

  const isLoading = roleLoading || statsLoading || (isSuperAdmin && tenantsLoading);

  if (roleLoading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="text-center space-y-4">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  // Tenant Owners get the Hub experience; Super Admin keeps System Overview
  if (isTenantOwner && !isSuperAdmin) {
    return <TenantOwnerHub />;
  }

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await exportDashboardToExcel({
        tenantId: tenantFilter,
        month: selectedMonth,
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="pb-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isSuperAdmin ? "System Overview" : "Dashboard"}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {isSuperAdmin 
              ? "Super Admin Dashboard - All Tenants Overview"
              : "Your Organization Overview"
            }
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Select month" />
            </SelectTrigger>
            <SelectContent>
              {monthOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {isTenantOwner && !isSuperAdmin && <ExcelMergeExport />}
          <Button 
            variant="outline" 
            onClick={handleExport}
            disabled={isExporting}
            className="gap-2"
          >
            <FileSpreadsheet className="h-4 w-4" />
            {isExporting ? "Exporting..." : "Export Excel"}
          </Button>
          {(isTenantOwner || isSuperAdmin) && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate("/access-denied-preview")}
              className="gap-2"
            >
              <Eye className="h-4 w-4" />
              IP Block Page
            </Button>
          )}
          <Badge variant="secondary" className="text-xs">
            <Shield className="h-3 w-3 mr-1" />
            {isSuperAdmin ? "Super Admin" : "Tenant Owner"}
          </Badge>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${isSuperAdmin ? "lg:grid-cols-4" : "lg:grid-cols-3"}`}>
        {/* Only show Total Tenants for Super Admin */}
        {isSuperAdmin && (
          <Card className="bg-gradient-to-br from-card to-card/80 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Tenants</CardTitle>
              <div className="p-2 rounded-lg bg-primary/10">
                <Building2 className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <>
                  <div className="text-3xl font-bold">{tenants?.length || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">Active organizations</p>
                </>
              )}
            </CardContent>
          </Card>
        )}

        <Card className="bg-gradient-to-br from-card to-card/80 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {isSuperAdmin ? "Total Users" : "Team Members"}
            </CardTitle>
            <div className="p-2 rounded-lg bg-blue-500/10">
              <Users className="h-4 w-4 text-blue-500" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-3xl font-bold">{stats?.totalUsers || 0}</div>
                <div className="flex items-center text-xs text-muted-foreground mt-1">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-green-500/10 text-green-600 dark:text-green-400">
                    <UserCheck className="h-3 w-3 mr-1" />
                    {activeSessions || 0} active
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-card to-card/80 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {isSuperAdmin ? "Total Leads" : "Your Leads"}
            </CardTitle>
            <div className="p-2 rounded-lg bg-amber-500/10">
              <TrendingUp className="h-4 w-4 text-amber-500" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-3xl font-bold">{stats?.totalLeads || 0}</div>
                <div className="flex items-center text-xs mt-1">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-green-500/10 text-green-600 dark:text-green-400">
                    <ArrowUpRight className="h-3 w-3 mr-0.5" />
                    +{stats?.todayLeads || 0} today
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-card to-card/80 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {isSuperAdmin ? "Total Clients" : "Your Clients"}
            </CardTitle>
            <div className="p-2 rounded-lg bg-green-500/10">
              <UserCheck className="h-4 w-4 text-green-500" />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-3xl font-bold">{stats?.totalClients || 0}</div>
                <div className="flex items-center text-xs mt-1">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-green-500/10 text-green-600 dark:text-green-400">
                    <ArrowUpRight className="h-3 w-3 mr-0.5" />
                    +{stats?.todayClients || 0} today
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {isSuperAdmin ? "Total Deposits" : "Your Deposits"}
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  ${stats?.totalDeposits?.toLocaleString() || 0}
                </div>
                <p className="text-xs text-muted-foreground">Approved deposits</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{stats?.conversionRate}%</div>
                <p className="text-xs text-muted-foreground">Leads to Clients</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Conversions</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{stats?.pendingConversions || 0}</div>
                <p className="text-xs text-muted-foreground">Awaiting approval</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>


      {/* Tenant Overview - Only for Super Admin */}
      {isSuperAdmin && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Tenant Overview
            </CardTitle>
            <CardDescription>Performance breakdown by organization</CardDescription>
          </CardHeader>
          <CardContent>
            {tenantStatsLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : tenantStats?.length ? (
              <div className="space-y-3">
                {tenantStats.map((tenant) => (
                  <div
                    key={tenant.tenantId}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                    onClick={() => navigate(`/tenant-management`)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Building2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{tenant.tenantName}</p>
                        <p className="text-xs text-muted-foreground">
                          Created {format(new Date(tenant.createdAt), "MMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6 text-sm">
                      <div className="text-center">
                        <p className="font-semibold">{tenant.users}</p>
                        <p className="text-xs text-muted-foreground">Users</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">{tenant.leads}</p>
                        <p className="text-xs text-muted-foreground">Leads</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold">{tenant.clients}</p>
                        <p className="text-xs text-muted-foreground">Clients</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-green-600">${tenant.deposits.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">Deposits</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Building2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No tenants found</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Weekly Stats */}
      <div className="grid grid-cols-1 gap-6">

        {/* Weekly Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Weekly Summary
            </CardTitle>
            <CardDescription>Last 7 days performance</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(4)].map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-lg bg-amber-500/10">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="h-5 w-5 text-amber-500" />
                    <span className="font-medium">New Leads</span>
                  </div>
                  <span className="text-xl font-bold">{stats?.weekLeads || 0}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-green-500/10">
                  <div className="flex items-center gap-3">
                    <UserCheck className="h-5 w-5 text-green-500" />
                    <span className="font-medium">New Clients</span>
                  </div>
                  <span className="text-xl font-bold">{stats?.weekClients || 0}</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-blue-500/10">
                  <div className="flex items-center gap-3">
                    <Users className="h-5 w-5 text-blue-500" />
                    <span className="font-medium">Active Sessions</span>
                  </div>
                  <span className="text-xl font-bold">{activeSessions || 0}</span>
                </div>
                {isSuperAdmin && (
                  <div className="flex items-center justify-between p-3 rounded-lg bg-purple-500/10">
                    <div className="flex items-center gap-3">
                      <Building2 className="h-5 w-5 text-purple-500" />
                      <span className="font-medium">Total Tenants</span>
                    </div>
                    <span className="text-xl font-bold">{tenants?.length || 0}</span>
                  </div>
                )}
                {!isSuperAdmin && (
                  <div className="flex items-center justify-between p-3 rounded-lg bg-purple-500/10">
                    <div className="flex items-center gap-3">
                      <DollarSign className="h-5 w-5 text-purple-500" />
                      <span className="font-medium">Total Deposits</span>
                    </div>
                    <span className="text-xl font-bold">${stats?.totalDeposits?.toLocaleString() || 0}</span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
