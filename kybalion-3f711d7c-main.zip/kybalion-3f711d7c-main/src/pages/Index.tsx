import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { User, Lock, LogIn, AlertTriangle, ShieldAlert } from "lucide-react";
import { KybalionLogo } from "@/components/KybalionLogo";
import { CaptchaVerification } from "@/components/auth/CaptchaVerification";
import AnimatedBackground from "@/components/auth/AnimatedBackground";
const Index = () => {
  const {
    user,
    loading,
    signIn
  } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [needsCaptcha, setNeedsCaptcha] = useState(false);
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const [isBlocked, setIsBlocked] = useState(false);
  const [attemptsRemaining, setAttemptsRemaining] = useState<number | null>(null);
  useEffect(() => {
    if (!loading && user) {
      // Redirect based on role
      const redirectByRole = async () => {
        const { data: roles } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .limit(1);
        const role = roles?.[0]?.role;
        if (role === "SUPER_ADMIN" || role === "TENANT_OWNER") {
          navigate("/dashboard", { replace: true });
        } else {
          navigate("/leads", { replace: true });
        }
      };
      redirectByRole();
    }
  }, [user, loading, navigate]);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const result = await signIn(username, password, rememberMe, captchaToken || undefined);
      if (result.error) {
        if (result.ipBlocked) {
          navigate("/access-denied-preview", { replace: true });
          return;
        }
        if (result.needsCaptcha) {
          setNeedsCaptcha(true);
          setAttemptsRemaining(result.attemptsRemaining || 0);
        }
        if (result.isBlocked) {
          setIsBlocked(true);
        }
      } else {
        setUsername("");
        setPassword("");
        setRememberMe(false);
        setNeedsCaptcha(false);
        setCaptchaToken(null);
        setIsBlocked(false);
        setAttemptsRemaining(null);
      }
    } finally {
      setIsLoading(false);
    }
  };
  const handleCaptchaVerify = (token: string) => {
    setCaptchaToken(token);
  };
  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="animate-pulse space-y-4 text-center">
          <div className="h-12 w-12 rounded-full bg-primary/20 mx-auto"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>;
  }
  return <div className="min-h-screen flex bg-background">
      {/* Left Panel - Animated Background (hidden on mobile) */}
      <div className="hidden lg:block lg:w-1/2 relative">
        <AnimatedBackground />
      </div>

      {/* Right Panel - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center relative">
        {/* Mobile background - subtle gradient */}
        <div className="lg:hidden absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" style={{
        backgroundSize: "400% 400%",
        animation: "gradient-shift 15s ease infinite"
      }} />

        <div className="w-full max-w-md relative z-10 px-8 sm:px-12 lg:px-16 py-12" style={{
        animation: "fade-in 0.6s ease-out"
      }}>
          {/* Logo & Header */}
          <div className="mb-10">
            
            <h1 className="text-3xl font-bold text-foreground">Welcome Back</h1>
            <p className="text-muted-foreground mt-2">Sign in to continue to Kybalion CRM</p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {isBlocked && <Alert variant="destructive">
                <ShieldAlert className="h-4 w-4" />
                <AlertDescription>
                  Too many failed attempts. Blocked for 15 minutes.
                </AlertDescription>
              </Alert>}

            {attemptsRemaining !== null && attemptsRemaining <= 3 && attemptsRemaining > 0 && <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  {attemptsRemaining} attempt{attemptsRemaining !== 1 ? 's' : ''} remaining.
                </AlertDescription>
              </Alert>}

            <div className="space-y-2">
              <Label htmlFor="username" className="text-foreground/90">Username or Email</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input id="username" type="text" placeholder="Enter username or email" value={username} onChange={e => setUsername(e.target.value)} className="pl-9 h-11 border-border focus:border-primary/50" required disabled={isBlocked} />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground/90">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input id="password" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} className="pl-9 h-11 border-border focus:border-primary/50" required minLength={6} disabled={isBlocked} />
              </div>
            </div>

            {needsCaptcha && !isBlocked && <CaptchaVerification onVerify={handleCaptchaVerify} />}

            <div className="flex items-center space-x-2">
              <Checkbox id="remember" checked={rememberMe} onCheckedChange={checked => setRememberMe(checked === true)} disabled={isBlocked} />
              <Label htmlFor="remember" className="text-sm font-normal cursor-pointer text-muted-foreground">
                Remember me
              </Label>
            </div>

            <Button type="submit" className="w-full h-11 text-sm font-medium" disabled={isLoading || isBlocked || needsCaptcha && !captchaToken}>
              {isLoading ? <span className="flex items-center gap-2">
                  <span className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  Signing In...
                </span> : <>
                  <LogIn className="mr-2 h-4 w-4" />
                  Sign In
                </>}
            </Button>
          </form>

          <p className="mt-8 text-xs text-muted-foreground">
            Contact your administrator to create an account
          </p>
        </div>
      </div>
    </div>;
};
export default Index;