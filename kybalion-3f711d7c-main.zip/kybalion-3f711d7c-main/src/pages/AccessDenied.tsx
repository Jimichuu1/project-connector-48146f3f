import { useState, useEffect, useRef } from "react";
import { ShieldX } from "lucide-react";

const CLASSIFIED_LINES = [
  "AGENT_PROFILE: ██████████ [REDACTED]",
  "CLEARANCE_LEVEL: ALPHA-7 — REVOKED",
  "LOCATION_TRACE: lat:██.████ lon:██.████",
  "SERVER_NODE: ECHO-BRAVO-9 // LOCKED",
  "ENCRYPTION_KEY: 0xDEAD████████BEEF",
  "MISSION_STATUS: COMPROMISED",
  "OPERATIVE_ID: GHOST-████-PHANTOM",
  "LAST_KNOWN_SIGNAL: ████████████",
  "SATELLITE_UPLINK: TERMINATED",
  "FIREWALL: LEVEL-9 ENGAGED",
  "BIOMETRIC_MATCH: 0.00% — DENIED",
  "COUNTERMEASURE: PROTOCOL OMEGA ACTIVE",
  "DATA_WIPE: INITIATED T-MINUS ██:██",
  "HANDLER_CONTACT: [LINE DISCONNECTED]",
  "EXTRACTION_ROUTE: NONE AVAILABLE",
  "SURVEILLANCE_FEED: SCRAMBLED",
  "DECOY_DEPLOYED: AFFIRMATIVE",
  "INTEL_PACKAGE: SHREDDED",
  "SAFE_HOUSE: BURNED",
  "COMMS_CHANNEL: DARK",
];

const DESTRUCTION_WARNINGS = [
  { text: "⚠ MALWARE DETECTED: TROJAN.GHOST.X7", color: "text-red-500" },
  { text: "⚠ VIRUS SIGNATURE: W32.PHANTOM.WORM", color: "text-red-400" },
  { text: "█ MEMORY CORRUPTION AT 0x7FFF████", color: "text-yellow-500" },
  { text: "⚠ ROOTKIT DETECTED: KERNEL LEVEL ACCESS", color: "text-red-500" },
  { text: "█ DISK SECTORS OVERWRITTEN: 47%", color: "text-orange-500" },
  { text: "⚠ ENCRYPTION BREACH: AES-256 COMPROMISED", color: "text-red-400" },
  { text: "█ FILE SYSTEM CORRUPTION DETECTED", color: "text-yellow-500" },
  { text: "⚠ BACKDOOR IMPLANT: PORT 31337 ACTIVE", color: "text-red-500" },
  { text: "█ RAM OVERFLOW: STACK SMASHING DETECTED", color: "text-orange-500" },
  { text: "⚠ KEYLOGGER DETECTED: INPUT STREAM HIJACKED", color: "text-red-400" },
  { text: "█ BIOS FIRMWARE CORRUPTED", color: "text-yellow-500" },
  { text: "⚠ NETWORK ADAPTER: PACKET INJECTION ACTIVE", color: "text-red-500" },
  { text: "█ REGISTRY HIVE DESTROYED", color: "text-orange-500" },
  { text: "⚠ BOOTLOADER INFECTED: MBR WIPED", color: "text-red-400" },
  { text: "█ GPU MEMORY DUMP IN PROGRESS", color: "text-yellow-500" },
  { text: "⚠ CERTIFICATE CHAIN BROKEN", color: "text-red-500" },
  { text: "█ DISK SECTORS OVERWRITTEN: 78%", color: "text-orange-500" },
  { text: "⚠ SPYWARE MODULE: CAMERA ACCESS GRANTED", color: "text-red-500" },
  { text: "█ THERMAL THROTTLE: CPU @ 99°C", color: "text-yellow-500" },
  { text: "⚠ SELF-DESTRUCT PAYLOAD DEPLOYED", color: "text-red-500" },
  { text: "█ DISK SECTORS OVERWRITTEN: 100%", color: "text-red-600" },
  { text: "████████ TOTAL SYSTEM FAILURE ████████", color: "text-red-600" },
];

const AccessDenied = ({ countryName }: { countryName?: string | null }) => {
  const [countdown, setCountdown] = useState(10);
  const [glitchActive, setGlitchActive] = useState(false);
  const [visibleLines, setVisibleLines] = useState<string[]>([]);
  const [destructionPhase, setDestructionPhase] = useState(false);
  const [warningLines, setWarningLines] = useState<typeof DESTRUCTION_WARNINGS>([]);
  const [screenShake, setScreenShake] = useState(false);
  const [staticOverlay, setStaticOverlay] = useState(false);
  const [corruptionLevel, setCorruptionLevel] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Block right-click and devtools shortcuts
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === "F12" ||
        (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "i")) ||
        (e.ctrlKey && (e.key === "U" || e.key === "u"))
      ) {
        e.preventDefault();
      }
    };
    document.addEventListener("contextmenu", handleContextMenu);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("contextmenu", handleContextMenu);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  // Countdown timer
  useEffect(() => {
    if (countdown <= 0) {
      setDestructionPhase(true);
      return;
    }
    const timer = setInterval(() => setCountdown((c) => c - 1), 1000);
    return () => clearInterval(timer);
  }, [countdown]);

  // Destruction phase — warnings, shaking, static — CONTINUOUS LOOP
  useEffect(() => {
    if (!destructionPhase) return;
    let idx = 0;
    const warningInterval = setInterval(() => {
      const warning = DESTRUCTION_WARNINGS[idx % DESTRUCTION_WARNINGS.length];
      setWarningLines((prev) => {
        const next = [...prev, warning];
        return next.slice(-40);
      });
      // Fill to 100% steadily, then stay there
      setCorruptionLevel((prev) => Math.min(prev + 5, 100));
      // Screen shake on every warning
      setScreenShake(true);
      setTimeout(() => setScreenShake(false), 150 + Math.random() * 150);
      // Random static flashes
      if (Math.random() > 0.3) {
        setStaticOverlay(true);
        setTimeout(() => setStaticOverlay(false), 80 + Math.random() * 200);
      }
      idx++;
    }, 350 + Math.random() * 200);
    return () => clearInterval(warningInterval);
  }, [destructionPhase]);

  // Faster glitch after destruction
  useEffect(() => {
    const speed = destructionPhase ? 500 + Math.random() * 800 : 2000 + Math.random() * 3000;
    const duration = destructionPhase ? 200 + Math.random() * 300 : 150 + Math.random() * 200;
    const glitchInterval = setInterval(() => {
      setGlitchActive(true);
      setTimeout(() => setGlitchActive(false), duration);
    }, speed);
    return () => clearInterval(glitchInterval);
  }, [destructionPhase]);

  // Scrolling classified text
  useEffect(() => {
    let idx = 0;
    const lineInterval = setInterval(() => {
      setVisibleLines((prev) => {
        const next = [...prev, CLASSIFIED_LINES[idx % CLASSIFIED_LINES.length]];
        idx++;
        return next.slice(-30);
      });
    }, 600);
    return () => clearInterval(lineInterval);
  }, []);

  // Auto-scroll classified feed
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [visibleLines]);

  return (
    <div
      className={`relative min-h-screen bg-black overflow-hidden font-mono select-none ${
        screenShake ? "animate-[shake_0.15s_ease-in-out]" : ""
      }`}
      style={{
        animation: screenShake
          ? "shake 0.15s ease-in-out"
          : undefined,
      }}
    >
      {/* Scanline overlay */}
      <div
        className="pointer-events-none fixed inset-0 z-50"
        style={{
          background:
            "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,65,0.03) 2px, rgba(0,255,65,0.03) 4px)",
        }}
      />

      {/* CRT vignette */}
      <div
        className="pointer-events-none fixed inset-0 z-40"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.7) 100%)",
        }}
      />

      {/* Static/noise overlay during destruction */}
      {staticOverlay && (
        <div
          className="pointer-events-none fixed inset-0 z-[55] opacity-30"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.5'/%3E%3C/svg%3E")`,
            mixBlendMode: "overlay",
          }}
        />
      )}

      {/* Red danger flash during destruction */}
      {destructionPhase && screenShake && (
        <div className="pointer-events-none fixed inset-0 z-[45] bg-red-900/20" />
      )}

      {/* Corruption progress bar */}
      {destructionPhase && corruptionLevel > 0 && (
        <div className="fixed top-0 left-0 right-0 z-[60] h-1">
          <div
            className="h-full bg-red-500 transition-all duration-300"
            style={{
              width: `${corruptionLevel}%`,
              boxShadow: "0 0 10px rgba(239,68,68,0.8), 0 0 20px rgba(239,68,68,0.4)",
            }}
          />
        </div>
      )}

      {/* Background classified text feed */}
      <div
        ref={scrollRef}
        className={`absolute inset-0 overflow-hidden text-green-500 text-xs leading-5 p-4 whitespace-pre-wrap break-all z-0 ${
          destructionPhase ? "opacity-[0.15]" : "opacity-[0.07]"
        }`}
      >
        {visibleLines.map((line, i) => (
          <div key={i} className="animate-fade-in">
            {`> ${line}`}
          </div>
        ))}
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Glitchy icon */}
        <div
          className={`mb-8 transition-transform ${
            glitchActive
              ? "translate-x-[3px] skew-x-[2deg] opacity-70"
              : ""
          }`}
        >
          <div className="relative">
            <div className="p-5 rounded-full border-2 border-red-500/60 bg-red-500/10 shadow-[0_0_40px_rgba(239,68,68,0.3)]">
              <ShieldX className="h-16 w-16 text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]" />
            </div>
            {glitchActive && (
              <div className="absolute inset-0 p-5 rounded-full border-2 border-cyan-400/40 bg-cyan-400/5 translate-x-[4px] -translate-y-[2px]">
                <ShieldX className="h-16 w-16 text-cyan-400 opacity-60" />
              </div>
            )}
          </div>
        </div>

        {/* Satellite emoji */}
        <div className="text-4xl mb-4">🛰️</div>

        {/* Title with glitch */}
        <h1
          className={`text-4xl md:text-5xl font-black tracking-widest mb-6 text-red-500 uppercase transition-all ${
            glitchActive
              ? "text-cyan-400 translate-x-[-2px] skew-x-[-1deg]"
              : ""
          }`}
          style={{
            textShadow: glitchActive
              ? "3px 0 #ff0000, -3px 0 #00ffff"
              : "0 0 20px rgba(239,68,68,0.5), 0 0 40px rgba(239,68,68,0.2)",
          }}
        >
          Mission Failed
        </h1>

        {/* Messages */}
        <div className="max-w-lg text-center space-y-4 mb-10">
          <p className="text-green-400 text-lg">
            Agent, your location has been{" "}
            <span className="text-red-400 font-bold">compromised</span>.
          </p>
          <p className="text-green-500/80 text-sm">
            This server only accepts{" "}
            <span className="text-green-300 font-semibold">
              trusted operatives
            </span>
            .
          </p>
          {countryName && (
            <p className="text-yellow-500/70 text-xs mt-2 tracking-wide">
              ⚠ DETECTED REGION:{" "}
              <span className="font-bold text-yellow-400 uppercase">
                {countryName}
              </span>{" "}
              — NOT AUTHORIZED
            </p>
          )}
        </div>

        {/* Self-destruct countdown */}
        <div className="mb-8">
          {countdown > 0 ? (
            <div className="flex flex-col items-center gap-2">
              <p className="text-red-400/80 text-sm tracking-[0.3em] uppercase">
                Self-destructing access in
              </p>
              <div
                className={`text-6xl font-black tabular-nums ${
                  countdown <= 3
                    ? "text-red-500 animate-pulse"
                    : "text-red-400"
                }`}
                style={{
                  textShadow:
                    "0 0 30px rgba(239,68,68,0.8), 0 0 60px rgba(239,68,68,0.4)",
                }}
              >
                {countdown}
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <div
                className="text-red-500 text-2xl font-black tracking-[0.5em] uppercase animate-pulse"
                style={{
                  textShadow:
                    "0 0 20px rgba(239,68,68,0.9), 0 0 40px rgba(239,68,68,0.5)",
                }}
              >
                ██ ACCESS TERMINATED ██
              </div>
              <p className="text-green-600/60 text-xs">
                Initiating system purge...
              </p>
            </div>
          )}
        </div>

        {/* Destruction warnings feed */}
        {destructionPhase && warningLines.length > 0 && (
          <div className="w-full max-w-lg mb-6 border border-red-900/60 rounded bg-black/90 p-3 max-h-48 overflow-y-auto">
            <div className="flex items-center gap-2 mb-2 border-b border-red-900/40 pb-2">
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span className="text-red-500/80 text-xs tracking-wider font-bold">
                ⚠ THREAT DETECTION — LIVE FEED
              </span>
              <div className="ml-auto text-red-400/60 text-xs">
                SEVERITY: CRITICAL
              </div>
            </div>
            <div className="space-y-1">
              {warningLines.map((warning, i) => (
                <div
                  key={i}
                  className={`text-xs ${warning.color} animate-fade-in font-mono`}
                  style={{
                    textShadow: warning.color.includes("red-500")
                      ? "0 0 8px rgba(239,68,68,0.5)"
                      : warning.color.includes("red-600")
                      ? "0 0 12px rgba(220,38,38,0.7)"
                      : undefined,
                  }}
                >
                  {`[${String(i).padStart(3, "0")}] ${warning.text}`}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Corruption meter */}
        {destructionPhase && corruptionLevel > 0 && (
          <div className="w-full max-w-sm mb-6">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-red-400/80 tracking-wider">SYSTEM CORRUPTION</span>
              <span className={`font-bold ${corruptionLevel >= 80 ? "text-red-500 animate-pulse" : "text-red-400/80"}`}>
                {corruptionLevel}%
              </span>
            </div>
            <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden border border-red-900/30">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{
                  width: `${corruptionLevel}%`,
                  background: corruptionLevel >= 80
                    ? "linear-gradient(90deg, #dc2626, #ef4444, #f87171)"
                    : corruptionLevel >= 50
                    ? "linear-gradient(90deg, #f97316, #ef4444)"
                    : "linear-gradient(90deg, #eab308, #f97316)",
                  boxShadow: `0 0 ${corruptionLevel / 5}px rgba(239,68,68,0.6)`,
                }}
              />
            </div>
          </div>
        )}

        {/* Terminal-style box */}
        <div className="w-full max-w-md border border-green-900/50 rounded bg-black/80 p-4 text-xs text-green-600/70">
          <div className="flex items-center gap-2 mb-3 border-b border-green-900/30 pb-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-green-700/80 tracking-wider">
              TERMINAL — SECURITY BREACH LOG
            </span>
          </div>
          <div className="space-y-1 leading-5">
            <p>
              <span className="text-green-700">$</span> verify_clearance
              --agent ████
            </p>
            <p className="text-red-500/70">
              ERROR: Clearance level INSUFFICIENT
            </p>
            <p>
              <span className="text-green-700">$</span> trace_origin
              --ip [CLASSIFIED]
            </p>
            <p className="text-yellow-600/70">
              WARN: Untrusted network detected
            </p>
            <p>
              <span className="text-green-700">$</span> initiate_lockdown
              --protocol OMEGA
            </p>
            <p className="text-red-500/70">
              LOCKDOWN ENGAGED. All ports sealed.
            </p>
          </div>
        </div>

        {/* Footer */}
        <p className="mt-10 text-green-900/50 text-xs tracking-widest">
          SECURITY DIVISION — CLASSIFIED
        </p>
      </div>

      {/* CSS keyframe for screen shake */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translate(0, 0) rotate(0deg); }
          10% { transform: translate(-3px, -2px) rotate(-0.5deg); }
          20% { transform: translate(3px, 1px) rotate(0.5deg); }
          30% { transform: translate(-2px, 3px) rotate(-0.3deg); }
          40% { transform: translate(2px, -1px) rotate(0.3deg); }
          50% { transform: translate(-1px, 2px) rotate(-0.2deg); }
          60% { transform: translate(3px, -2px) rotate(0.5deg); }
          70% { transform: translate(-3px, 1px) rotate(-0.5deg); }
          80% { transform: translate(1px, -3px) rotate(0.3deg); }
          90% { transform: translate(-2px, 2px) rotate(-0.3deg); }
        }
      `}</style>
    </div>
  );
};

export default AccessDenied;
