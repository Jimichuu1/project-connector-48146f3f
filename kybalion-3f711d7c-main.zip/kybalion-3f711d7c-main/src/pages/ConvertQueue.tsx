import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { TableX } from "@/components/ui/table-x";
import { Badge } from "@/components/ui/badge";
import { ConvertedClientsToolbar } from "@/components/convert-queue/ConvertedClientsToolbar";
import { ConvertedClientsFilters, ConvertedFilterValues } from "@/components/convert-queue/ConvertedClientsFilters";
import { PendingLeadsToolbar } from "@/components/convert-queue/PendingLeadsToolbar";
import { PendingLeadsTable, PendingLead } from "@/components/convert-queue/PendingLeadsTable";
import { ConvertedClientsTable } from "@/components/convert-queue/ConvertedClientsTable";
import { LeadGroupTransferCards } from "@/components/convert-queue/LeadGroupTransferCards";
import { CancelRequestDialog } from "@/components/convert-queue/CancelRequestDialog";
import { ConvertDialog } from "@/components/convert-queue/ConvertDialog";
import { useConvertQueue } from "@/hooks/useConvertQueue";
import { useUserData } from "@/contexts/UserDataContext";
import { clientHref } from "@/lib/idCipher";
import { useManagerTeam } from "@/hooks/useManagerTeam";

export default function ConvertQueue() {
  const navigate = useNavigate();
  const { isSuperAdmin, isTenantOwner, isManager, isTeamLeader, isAgent: isAgentRole, isSuperAgent: isSuperAgentRole, canViewPhone, canViewEmail } = useUserData();
  const { canAccessClients: managerHasSuperAgents } = useManagerTeam();
  
  // Computed visibility based on role settings (from centralized user data)
  const shouldShowEmail = canViewEmail;
  const shouldShowPhone = canViewPhone;
  const [pendingSearch, setPendingSearch] = useState("");
  const [convertedSearch, setConvertedSearch] = useState("");
  const [convertedFilterValues, setConvertedFilterValues] = useState<ConvertedFilterValues>({
    agentIds: [],
    convertedByIds: [],
    superAgentIds: [],
    convertedDate: null,
  });
  const [viewMode, setViewMode] = useState<"pending" | "converted">("pending");
  const [selectedLead, setSelectedLead] = useState<PendingLead | null>(null);
  const [showConvertDialog, setShowConvertDialog] = useState(false);
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState("");
  const [isConverting, setIsConverting] = useState(false);

  const {
    leads,
    convertedClients,
    deposits,
    superAgents,
    isLoading,
    isAgent,
    isSuperAgent,
    isTeamLeader: isTeamLeaderFromHook,
    isAdmin,
    currentUser,
    fetchSuperAgents,
    handleCancelRequest,
    handleConvertToClient,
  } = useConvertQueue();

  // SUPER_AGENT should only see converted view
  useEffect(() => {
    if (isSuperAgent) {
      setViewMode("converted");
    }
  }, [isSuperAgent]);

  // Filter converted clients based on search and filters
  const filteredConvertedClients = convertedClients.filter((client) => {
    if (convertedSearch) {
      const searchLower = convertedSearch.toLowerCase();
      const matchesSearch =
        (client.name ?? "").toLowerCase().includes(searchLower) ||
        (client.email ?? "").toLowerCase().includes(searchLower);
      if (!matchesSearch) return false;
    }

    if (convertedFilterValues.agentIds.length > 0) {
      if (!client.created_by || !convertedFilterValues.agentIds.includes(client.created_by)) {
        return false;
      }
    }

    if (convertedFilterValues.superAgentIds.length > 0) {
      if (!client.assigned_to || !convertedFilterValues.superAgentIds.includes(client.assigned_to)) {
        return false;
      }
    }

    if (convertedFilterValues.convertedByIds.length > 0) {
      if (!client.created_by || !convertedFilterValues.convertedByIds.includes(client.created_by)) {
        return false;
      }
    }

    if (convertedFilterValues.convertedDate) {
      const joinDate = new Date(client.join_date);
      const { from, to } = convertedFilterValues.convertedDate;
      if (from && joinDate < from) return false;
      if (to && joinDate > to) return false;
    }

    return true;
  });

  // Filter pending leads based on search
  const filteredPendingLeads = leads.filter((lead) => {
    if (!pendingSearch) return true;
    const searchLower = pendingSearch.toLowerCase();
    return (
      (lead.name ?? "").toLowerCase().includes(searchLower) ||
      (lead.email ?? "").toLowerCase().includes(searchLower) ||
      (lead.phone && lead.phone.toLowerCase().includes(searchLower))
    );
  });

  const onCancelRequest = async () => {
    if (!selectedLead) return;
    try {
      await handleCancelRequest(selectedLead.id);
      setShowCancelDialog(false);
      setSelectedLead(null);
    } catch {
      toast.error("Failed to cancel request");
    }
  };

  const onConvert = async () => {
    if (!selectedLead || !selectedAgent) {
      toast.error("Please select a user to assign");
      return;
    }
    setIsConverting(true);
    try {
      const clientId = await handleConvertToClient(selectedLead, selectedAgent);
      setShowConvertDialog(false);
      setSelectedAgent("");
      setSelectedLead(null);
      if (clientId) {
        navigate(clientHref(clientId));
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to convert lead";
      toast.error(message);
      console.error("Convert lead error:", error);
    } finally {
      setIsConverting(false);
    }
  };

  return (
    <div className="pb-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">
              {viewMode === "pending" ? "Pending Conversions" : "Converted Clients"}
            </h1>
            <Badge variant="default" className="text-sm h-6 px-2">
              {viewMode === "pending" ? filteredPendingLeads.length : filteredConvertedClients.length}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-1">
            {viewMode === "pending"
              ? isAgent ? "Your conversion requests awaiting admin approval" : "Review and convert leads to clients"
              : isAgent ? "Clients converted from your leads" : "Successfully converted clients"}
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {isTenantOwner && (
          <LeadGroupTransferCards clients={filteredConvertedClients} deposits={deposits} />
        )}

        {viewMode === "pending" && (
          <TableX
            toolbar={
              <PendingLeadsToolbar
                search={pendingSearch}
                onSearchChange={setPendingSearch}
                viewMode={viewMode}
                onViewModeChange={setViewMode}
              />
            }
          >
            <PendingLeadsTable
              leads={filteredPendingLeads}
              isLoading={isLoading}
              isAgent={isAgent || isTeamLeaderFromHook}
              isSuperAdmin={isSuperAdmin}
              shouldShowEmail={shouldShowEmail}
              shouldShowPhone={shouldShowPhone}
              canConvert={!isManager || managerHasSuperAgents}
              onConvert={async (lead) => {
                setSelectedLead(lead);
                setSelectedAgent("");
                // Fetch super agents from the lead's tenant (important for SUPER_ADMIN viewing all tenants)
                // Await the fetch to ensure agents are loaded before showing dialog
                await fetchSuperAgents(lead.admin_id || null);
                setShowConvertDialog(true);
              }}
              onCancelRequest={(lead) => {
                setSelectedLead(lead);
                setShowCancelDialog(true);
              }}
            />
          </TableX>
        )}

        {viewMode === "converted" && (
          <TableX
            toolbar={
              <ConvertedClientsToolbar
                search={convertedSearch}
                onSearchChange={setConvertedSearch}
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                clients={filteredConvertedClients}
                deposits={deposits}
              />
            }
            filters={
              <ConvertedClientsFilters
                isAdmin={isAdmin}
                filterValues={convertedFilterValues}
                onFilterValuesChange={setConvertedFilterValues}
              />
            }
          >
            <ConvertedClientsTable
              clients={filteredConvertedClients}
              deposits={deposits}
              isAdmin={isAdmin}
              isAgent={isAgent}
              isSuperAgent={isSuperAgent}
              isSuperAdminView={isSuperAdmin}
              isTenantOwner={isTenantOwner}
              isManager={isManager}
              shouldShowEmail={shouldShowEmail}
              shouldShowPhone={shouldShowPhone}
            />
          </TableX>
        )}
      </div>

      <CancelRequestDialog
        open={showCancelDialog}
        onOpenChange={setShowCancelDialog}
        leadName={selectedLead?.name || ""}
        onConfirm={onCancelRequest}
      />

      <ConvertDialog
        open={showConvertDialog}
        onOpenChange={setShowConvertDialog}
        leadName={selectedLead?.name || ""}
        superAgents={superAgents}
        selectedAgent={selectedAgent}
        onSelectAgent={setSelectedAgent}
        onConfirm={onConvert}
        isConverting={isConverting}
      />
    </div>
  );
}