import { useEffect, useMemo } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useUserData } from "@/contexts/UserDataContext";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import { useBreadcrumb } from "@/contexts/BreadcrumbContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft, Mail, Phone, Globe, Calendar, Link2, ExternalLink, UserCheck,
  ShieldAlert, DollarSign, Clock, FileText,
} from "lucide-react";
import { format } from "date-fns";
import { formatCurrency } from "@/lib/utils";
import type { LiveSubmission, LiveSubmissionStatus } from "@/hooks/useLiveTrafficSubmissions";
import { LiveSubmissionNotes } from "@/components/live-traffic/LiveSubmissionNotes";
import { decodeId, clientHref } from "@/lib/idCipher";

export default function LiveSubmissionDetail() {
  const { id: idParam } = useParams<{ id: string }>();
  const id = decodeId(idParam) ?? undefined;
  const navigate = useNavigate();
  const { setCustomLabel } = useBreadcrumb();
  const { hasTenantOwnerAccess, isSuperAgent } = useUserData();
  const { data: agents } = useAgentsCache();

  const { data: submission, isLoading } = useQuery({
    queryKey: ["live-submission", id],
    enabled: !!id,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("live_traffic_submissions")
        .select("*")
        .eq("id", id!)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as LiveSubmission | null;
    },
  });

  useEffect(() => {
    if (submission?.name) setCustomLabel(submission.name);
    return () => setCustomLabel(null);
  }, [submission?.name, setCustomLabel]);

  const agentName = useMemo(() => {
    if (!submission?.assigned_to || !agents) return null;
    return agents.find((a) => a.id === submission.assigned_to)?.name || null;
  }, [agents, submission?.assigned_to]);

  if (isLoading) return <div className="py-8">Loading...</div>;

  if (!submission) {
    return (
      <div className="py-8">
        <Card>
          <CardContent className="p-6 text-center">Submission not found</CardContent>
        </Card>
      </div>
    );
  }

  const allowed = hasTenantOwnerAccess || (isSuperAgent && submission.assigned_to);
  if (!allowed) {
    return (
      <div className="py-8">
        <Card>
          <CardContent className="p-6 text-center">You don't have access to this submission.</CardContent>
        </Card>
      </div>
    );
  }

  const meta = (submission.metadata || {}) as Record<string, unknown>;
  const scamType = (meta.scam_type as string) || "";
  const lostAmount = meta.lost_amount as number | string | undefined;
  const timeFrame = (meta.time_frame as string) || "";
  const description = (meta.description as string) || "";

  const statusBadge = (s: LiveSubmissionStatus, isDup: boolean) => {
    if (s === "converted") return <Badge variant="default">Converted</Badge>;
    if (s === "assigned") return <Badge variant="secondary">Assigned</Badge>;
    if (s === "dismissed") return <Badge variant="outline">Dismissed</Badge>;
    if (s === "moved") return <Badge variant="default">Moved</Badge>;
    if (isDup) return <Badge variant="destructive">Duplicate</Badge>;
    return <Badge variant="secondary">New</Badge>;
  };

  return (
    <div className="py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={() => navigate("/live-traffic")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Live Traffic
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-2xl font-bold">{submission.name}</h1>
                    {statusBadge(submission.status, submission.is_duplicate)}
                  </div>
                  {submission.email && (
                    <p className="text-muted-foreground mt-1">{submission.email}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Scam summary tiles */}
          {(scamType || lostAmount !== undefined || timeFrame) && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {scamType && (
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <ShieldAlert className="h-4 w-4" />
                      <span className="text-xs">Type of Scam</span>
                    </div>
                    <p className="text-lg font-semibold">{scamType}</p>
                  </CardContent>
                </Card>
              )}
              {lostAmount !== undefined && lostAmount !== "" && (
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <DollarSign className="h-4 w-4" />
                      <span className="text-xs">Lost Amount</span>
                    </div>
                    <p className="text-lg font-semibold text-destructive">
                      {typeof lostAmount === "number" ? formatCurrency(lostAmount) : String(lostAmount)}
                    </p>
                  </CardContent>
                </Card>
              )}
              {timeFrame && (
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Clock className="h-4 w-4" />
                      <span className="text-xs">Time Frame</span>
                    </div>
                    <p className="text-lg font-semibold">{timeFrame}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Details */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {submission.country && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Globe className="h-3.5 w-3.5" />
                      <span className="text-xs">Country</span>
                    </div>
                    <p className="text-sm font-medium">{submission.country}</p>
                  </div>
                )}
                {submission.phone && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-3.5 w-3.5" />
                      <span className="text-xs">Phone</span>
                    </div>
                    <p className="text-sm font-medium">{submission.phone}</p>
                  </div>
                )}
                {submission.email && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="h-3.5 w-3.5" />
                      <span className="text-xs">Email</span>
                    </div>
                    <p className="text-sm font-medium break-all">{submission.email}</p>
                  </div>
                )}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    <span className="text-xs">Received</span>
                  </div>
                  <p className="text-sm font-medium">
                    {format(new Date(submission.created_at), "MMM d, yyyy HH:mm")}
                  </p>
                </div>
                {submission.source_url && (
                  <div className="space-y-1 col-span-2 md:col-span-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Link2 className="h-3.5 w-3.5" />
                      <span className="text-xs">Source</span>
                    </div>
                    <a
                      href={submission.source_url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm font-medium text-primary hover:underline inline-flex items-center gap-1"
                    >
                      {(() => {
                        try { return new URL(submission.source_url!).hostname; }
                        catch { return submission.source_url; }
                      })()}
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                )}
                {submission.assigned_to && (
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <UserCheck className="h-3.5 w-3.5" />
                      <span className="text-xs">Assigned SA</span>
                    </div>
                    <p className="text-sm font-medium">{agentName || "—"}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {submission.status === "converted" && submission.converted_client_id && (
            <Card>
              <CardContent className="p-4">
                <Link
                  to={clientHref(submission.converted_client_id)}
                  className="text-sm text-primary hover:underline inline-flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" /> View converted client
                </Link>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right - KYC info from submission metadata */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Submission KYC
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {scamType && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Type of Scam</div>
                  <div className="text-sm font-medium mt-1">{scamType}</div>
                </div>
              )}
              {lostAmount !== undefined && lostAmount !== "" && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Lost Amount</div>
                  <div className="text-sm font-medium mt-1">
                    {typeof lostAmount === "number" ? formatCurrency(lostAmount) : String(lostAmount)}
                  </div>
                </div>
              )}
              {timeFrame && (
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">Time Frame</div>
                  <div className="text-sm font-medium mt-1">{timeFrame}</div>
                </div>
              )}
              {description && (
                <>
                  <Separator />
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Description</div>
                    <p className="text-sm whitespace-pre-wrap">{description}</p>
                  </div>
                </>
              )}
              {!scamType && lostAmount === undefined && !timeFrame && !description && (
                <p className="text-sm text-muted-foreground">No additional info submitted.</p>
              )}
            </CardContent>
          </Card>

          <LiveSubmissionNotes submissionId={submission.id} adminId={submission.admin_id} />
        </div>
      </div>
    </div>
  );
}
