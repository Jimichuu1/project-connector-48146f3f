import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { useUserData } from "@/contexts/UserDataContext";

const NotFound = () => {
  const location = useLocation();
  const { profile } = useUserData();

  const agentName =
    profile?.full_name?.split(" ")[0] || profile?.username || "someone";

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-muted">
      <div className="text-center px-6">
        <h1 className="mb-4 text-4xl font-bold">404</h1>
        <p className="mb-3 text-muted-foreground" style={{ fontSize: "21px" }}>
          There's nothing here. Go talk to Well !
        </p>
        <p className="text-muted-foreground/80 italic" style={{ fontSize: "14px" }}>
          it was at this moment {agentName} knew, {agentName} fucked up ...
        </p>
        <a href="/" className="mt-6 inline-block text-primary underline hover:text-primary/90">
          Return to Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;
