import { useMemo, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { clientHref, liveSubmissionHref } from "@/lib/idCipher";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Radio,
  ExternalLink,
  ArrowRightCircle,
  X,
  User,
  Mail,
  Phone,
  Globe,
  Activity,
  UserCheck,
  Calendar,
  Settings,
  Link2,
  Send,
  Info,
  Trash2,
  Plus,
  Upload,
  Shuffle,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { SortableTableHead, SortState, sortData } from "@/components/ui/sortable-table-head";
import { SearchFilter } from "@/components/filters/SearchFilter";
import { toast } from "sonner";
import { useUserData } from "@/contexts/UserDataContext";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import {
  useLiveTrafficSubmissions,
  type LiveSubmission,
  type LiveSubmissionStatus,
} from "@/hooks/useLiveTrafficSubmissions";
import { ConvertSubmissionDialog } from "@/components/live-traffic/ConvertSubmissionDialog";
import { InlineAssignSADropdown } from "@/components/live-traffic/InlineAssignSADropdown";
import { LiveSubmissionInfoPopover } from "@/components/live-traffic/LiveSubmissionInfoPopover";
import { CreateLiveSubmissionDialog } from "@/components/live-traffic/CreateLiveSubmissionDialog";
import { ImportLiveSubmissionsDialog } from "@/components/live-traffic/ImportLiveSubmissionsDialog";
import { ShuffleLiveSubmissionsDialog } from "@/components/live-traffic/ShuffleLiveSubmissionsDialog";
import { format, formatDistanceToNow } from "date-fns";
import { Calendar as CalendarComp } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { getCountryFlag } from "@/lib/countryFlags";
import { cn } from "@/lib/utils";

const STATUS_OPTIONS: { value: LiveSubmissionStatus; label: string }[] = [
  { value: "new", label: "New" },
  { value: "assigned", label: "Assigned" },
  { value: "converted", label: "Converted" },
  { value: "dismissed", label: "Dismissed" },
];

export default function LiveTraffic() {
  const { hasTenantOwnerAccess, isSuperAgent, loading } = useUserData();
  const { data: submissions, isLoading, dismiss, remove } = useLiveTrafficSubmissions();
  const { data: agents } = useAgentsCache();
  const [search, setSearch] = useState("");
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [countrySearch, setCountrySearch] = useState("");
  const [selectedAssignees, setSelectedAssignees] = useState<string[]>([]);
  const [assigneeSearch, setAssigneeSearch] = useState("");
  const [receivedRange, setReceivedRange] = useState<{ from: Date | null; to: Date | null }>({ from: null, to: null });
  const [saMonth, setSaMonth] = useState<string>(() => format(new Date(), "yyyy-MM"));
  const [tab, setTab] = useState<"inbox" | "duplicates">("inbox");
  const [sort, setSort] = useState<SortState>({ key: "created_at", direction: "desc" });
  const [convertTarget, setConvertTarget] = useState<LiveSubmission | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<LiveSubmission | null>(null);
  const [showCreateLead, setShowCreateLead] = useState(false);
  const [showImportLeads, setShowImportLeads] = useState(false);
  const [showShuffle, setShowShuffle] = useState(false);

  const canAdmin = hasTenantOwnerAccess; // TO + SA
  const allowed = canAdmin || isSuperAgent;

  if (!loading && !allowed) {
    return <Navigate to="/access-denied-preview" replace />;
  }

  const list = submissions || [];

  const copyToClipboard = async (value: string, label: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(`${label} copied`);
    } catch {
      toast.error(`Failed to copy ${label.toLowerCase()}`);
    }
  };

  const agentNameById = useMemo(() => {
    const m = new Map<string, string>();
    (agents || []).forEach((a) => m.set(a.id, a.name));
    return m;
  }, [agents]);

  // A submission is a "duplicate copy" only if an EARLIER submission with the
  // same normalized phone exists in this tenant. The first/original stays in Inbox.
  const duplicateCopyIds = useMemo(() => {
    const firstByPhone = new Map<string, string>(); // phone -> earliest submission id
    // Walk oldest -> newest so the first occurrence wins
    const ordered = [...list].sort(
      (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime(),
    );
    const dupIds = new Set<string>();
    for (const s of ordered) {
      const key = s.phone_normalized || "";
      if (!key) continue;
      if (!firstByPhone.has(key)) {
        firstByPhone.set(key, s.id);
      } else {
        dupIds.add(s.id);
      }
    }
    return dupIds;
  }, [list]);

  const counts = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
      today: list.filter((s) => new Date(s.created_at) >= today).length,
      new: list.filter((s) => s.status === "new" && !duplicateCopyIds.has(s.id)).length,
      assigned: list.filter((s) => s.status === "assigned").length,
      converted: list.filter((s) => s.status === "converted").length,
      duplicates: duplicateCopyIds.size,
    };
  }, [list, duplicateCopyIds]);

  const filtered = useMemo(() => {
    // Split by tab: only later copies go to Duplicates; the original stays in Inbox
    let rows = tab === "duplicates"
      ? list.filter((s) => duplicateCopyIds.has(s.id))
      : list.filter((s) => !duplicateCopyIds.has(s.id));

    if (selectedStatuses.length > 0) {
      rows = rows.filter((s) => selectedStatuses.includes(s.status));
    }
    if (selectedCountries.length > 0) {
      rows = rows.filter((s) => s.country && selectedCountries.includes(s.country));
    }
    if (selectedAssignees.length > 0) {
      rows = rows.filter((s) => {
        if (selectedAssignees.includes("__unassigned__")) {
          if (!s.assigned_to) return true;
        }
        return s.assigned_to && selectedAssignees.includes(s.assigned_to);
      });
    }
    if (receivedRange.from || receivedRange.to) {
      const fromTs = receivedRange.from ? new Date(receivedRange.from).setHours(0, 0, 0, 0) : null;
      const toTs = receivedRange.to ? new Date(receivedRange.to).setHours(23, 59, 59, 999) : null;
      rows = rows.filter((s) => {
        const t = new Date(s.created_at).getTime();
        if (fromTs !== null && t < fromTs) return false;
        if (toTs !== null && t > toTs) return false;
        return true;
      });
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      rows = rows.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          (s.phone || "").toLowerCase().includes(q) ||
          (s.email || "").toLowerCase().includes(q),
      );
    }
    return rows;
  }, [list, tab, selectedStatuses, selectedCountries, selectedAssignees, receivedRange, search, duplicateCopyIds]);

  const availableCountries = useMemo(() => {
    const set = new Set<string>();
    list.forEach((s) => { if (s.country) set.add(s.country); });
    return Array.from(set).sort();
  }, [list]);

  const availableAssignees = useMemo(() => {
    const ids = new Set<string>();
    list.forEach((s) => { if (s.assigned_to) ids.add(s.assigned_to); });
    return Array.from(ids)
      .map((id) => ({ id, name: agentNameById.get(id) || "Unknown" }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [list, agentNameById]);

  const sorted = useMemo(() => sortData(filtered, sort.key, sort.direction), [filtered, sort]);

  const handleSort = (key: string) => {
    setSort((prev) => ({
      key,
      direction: prev.key === key && prev.direction === "asc" ? "desc" : "asc",
    }));
  };

  const toggleStatus = (value: string) => {
    setSelectedStatuses((prev) =>
      prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value],
    );
  };

  const statusBadge = (s: LiveSubmissionStatus, isDup: boolean) => {
    if (s === "converted") return <Badge variant="default">Converted</Badge>;
    if (s === "assigned") return <Badge variant="secondary">Assigned</Badge>;
    if (s === "dismissed") return <Badge variant="outline">Dismissed</Badge>;
    if (s === "moved") return <Badge variant="default">Moved</Badge>;
    if (isDup) return <Badge variant="destructive">Duplicate</Badge>;
    return <Badge variant="secondary">New</Badge>;
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <Radio className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Live Traffic</h1>
          <p className="text-sm text-muted-foreground">
            Real-time inbox of submissions from your external landing pages.
          </p>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <KpiTile label="Today" value={counts.today} />
        <KpiTile label="New" value={counts.new} />
        <KpiTile label="Assigned" value={counts.assigned} />
        <KpiTile label="Converted" value={counts.converted} />
        <KpiTile label="Duplicates" value={counts.duplicates} />
      </div>

      {canAdmin && (
        <SAReceivedCards
          submissions={list}
          agentNameById={agentNameById}
          month={saMonth}
          onMonthChange={setSaMonth}
        />
      )}

      <Card className="rounded-xl text-card-foreground transition-shadow duration-200 bg-transparent">
        <CardContent className="p-4 space-y-0 px-0 py-0 bg-transparent">
          {/* Inbox vs Duplicates view switcher */}
          <div className="flex items-center pb-3">
            <ToggleGroup
              type="single"
              value={tab}
              onValueChange={(value) => value && setTab(value as "inbox" | "duplicates")}
            >
              <ToggleGroupItem value="inbox" aria-label="Inbox" size="sm" className="gap-2">
                Inbox
                <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">
                  {list.length - duplicateCopyIds.size}
                </Badge>
              </ToggleGroupItem>
              <ToggleGroupItem value="duplicates" aria-label="Duplicates" size="sm" className="gap-2">
                Duplicates
                <Badge variant="destructive" className="ml-1 h-5 px-1.5 text-[10px]">
                  {counts.duplicates}
                </Badge>
              </ToggleGroupItem>
            </ToggleGroup>
          </div>

          {/* Filter pills + search */}
          <div className="flex items-center gap-2 pb-3">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={`gap-2 rounded-full ${
                    selectedStatuses.length > 0
                      ? "bg-primary/10 border-primary/50 pr-2"
                      : "bg-background"
                  }`}
                >
                  <Activity className="h-4 w-4" />
                  <span
                    className={
                      selectedStatuses.length > 0
                        ? "text-primary-foreground font-medium"
                        : "text-muted-foreground"
                    }
                  >
                    Status
                  </span>
                  {selectedStatuses.length > 0 && (
                    <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                      {selectedStatuses.length}
                    </Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-48 p-0">
                <div className="border-b border-border p-2">
                  <span className="font-medium text-sm">Status</span>
                </div>
                <div className="p-1 max-h-64 overflow-y-auto">
                  {STATUS_OPTIONS.map((opt) => (
                    <label
                      key={opt.value}
                      className="flex items-center gap-2 px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedStatuses.includes(opt.value)}
                        onChange={() => toggleStatus(opt.value)}
                        className="h-4 w-4 rounded border-border"
                      />
                      <span className="text-sm">{opt.label}</span>
                    </label>
                  ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Country filter */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={`gap-2 rounded-full ${
                    selectedCountries.length > 0 ? "bg-primary/10 border-primary/50 pr-2" : "bg-background"
                  }`}
                >
                  <Globe className="h-4 w-4" />
                  <span className={selectedCountries.length > 0 ? "text-primary-foreground font-medium" : "text-muted-foreground"}>
                    Country
                  </span>
                  {selectedCountries.length > 0 && (
                    <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">{selectedCountries.length}</Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-72 p-0">
                <div className="border-b border-border p-2">
                  <Input
                    placeholder="Search countries..."
                    value={countrySearch}
                    onChange={(e) => setCountrySearch(e.target.value)}
                    className="h-8"
                  />
                </div>
                <div className="p-1 max-h-64 overflow-y-auto">
                  {availableCountries.length === 0 && (
                    <div className="text-xs text-muted-foreground p-3 text-center">No countries</div>
                  )}
                  {availableCountries
                    .filter((c) => c.toLowerCase().includes(countrySearch.toLowerCase()))
                    .map((c) => (
                      <label key={c} className="flex items-center gap-2 px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer">
                        <Checkbox
                          checked={selectedCountries.includes(c)}
                          onCheckedChange={() =>
                            setSelectedCountries((prev) =>
                              prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c],
                            )
                          }
                        />
                        <span className="text-base">{getCountryFlag(c)}</span>
                        <span className="text-sm">{c}</span>
                      </label>
                    ))}
                </div>
              </PopoverContent>
            </Popover>

            {/* Assigned to filter (admins only) */}
            {canAdmin && (
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={`gap-2 rounded-full ${
                      selectedAssignees.length > 0 ? "bg-primary/10 border-primary/50 pr-2" : "bg-background"
                    }`}
                  >
                    <UserCheck className="h-4 w-4" />
                    <span className={selectedAssignees.length > 0 ? "text-primary-foreground font-medium" : "text-muted-foreground"}>
                      Assigned to
                    </span>
                    {selectedAssignees.length > 0 && (
                      <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">{selectedAssignees.length}</Badge>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="start" className="w-72 p-0">
                  <div className="border-b border-border p-2">
                    <Input
                      placeholder="Search assignees..."
                      value={assigneeSearch}
                      onChange={(e) => setAssigneeSearch(e.target.value)}
                      className="h-8"
                    />
                  </div>
                  <div className="p-1 max-h-64 overflow-y-auto">
                    <label className="flex items-center gap-2 px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer">
                      <Checkbox
                        checked={selectedAssignees.includes("__unassigned__")}
                        onCheckedChange={() =>
                          setSelectedAssignees((prev) =>
                            prev.includes("__unassigned__")
                              ? prev.filter((x) => x !== "__unassigned__")
                              : [...prev, "__unassigned__"],
                          )
                        }
                      />
                      <span className="text-sm italic text-muted-foreground">Unassigned</span>
                    </label>
                    {availableAssignees.length === 0 && (
                      <div className="text-xs text-muted-foreground p-3 text-center">No assignees yet</div>
                    )}
                    {availableAssignees
                      .filter((a) => a.name.toLowerCase().includes(assigneeSearch.toLowerCase()))
                      .map((a) => (
                        <label key={a.id} className="flex items-center gap-2 px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer">
                          <Checkbox
                            checked={selectedAssignees.includes(a.id)}
                            onCheckedChange={() =>
                              setSelectedAssignees((prev) =>
                                prev.includes(a.id) ? prev.filter((x) => x !== a.id) : [...prev, a.id],
                              )
                            }
                          />
                          <span className="text-sm">{a.name}</span>
                        </label>
                      ))}
                  </div>
                </PopoverContent>
              </Popover>
            )}

            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className={`gap-2 rounded-full ${
                    receivedRange.from || receivedRange.to ? "bg-primary/10 border-primary/50" : "bg-background"
                  }`}
                >
                  <Calendar className="h-4 w-4" />
                  <span className={receivedRange.from || receivedRange.to ? "text-primary-foreground font-medium" : "text-muted-foreground"}>
                    Received
                  </span>
                  {(receivedRange.from || receivedRange.to) && (
                    <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                      {receivedRange.from && receivedRange.to
                        ? `${format(receivedRange.from, "MMM d")} – ${format(receivedRange.to, "MMM d")}`
                        : receivedRange.from
                          ? `From ${format(receivedRange.from, "MMM d")}`
                          : `Until ${format(receivedRange.to!, "MMM d")}`}
                    </Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent align="start" className="w-auto p-0">
                <div className="p-3 grid grid-cols-2 gap-3">
                  <div>
                    <div className="text-xs font-medium mb-1">From</div>
                    <CalendarComp
                      mode="single"
                      selected={receivedRange.from || undefined}
                      onSelect={(d) => setReceivedRange((r) => ({ ...r, from: d || null }))}
                      className={cn("p-2 pointer-events-auto")}
                    />
                  </div>
                  <div>
                    <div className="text-xs font-medium mb-1">To</div>
                    <CalendarComp
                      mode="single"
                      selected={receivedRange.to || undefined}
                      onSelect={(d) => setReceivedRange((r) => ({ ...r, to: d || null }))}
                      disabled={(date) => (receivedRange.from ? date < receivedRange.from : false)}
                      className={cn("p-2 pointer-events-auto")}
                    />
                  </div>
                </div>
                {(receivedRange.from || receivedRange.to) && (
                  <div className="border-t border-border p-2 flex justify-end">
                    <Button variant="ghost" size="sm" onClick={() => setReceivedRange({ from: null, to: null })}>
                      Clear dates
                    </Button>
                  </div>
                )}
              </PopoverContent>
            </Popover>

            {(selectedStatuses.length > 0 || selectedCountries.length > 0 || selectedAssignees.length > 0 || receivedRange.from || receivedRange.to) && (
              <Button
                variant="ghost"
                size="sm"
                className="gap-2 rounded-full text-muted-foreground"
                onClick={() => {
                  setSelectedStatuses([]);
                  setSelectedCountries([]);
                  setSelectedAssignees([]);
                  setReceivedRange({ from: null, to: null });
                }}
              >
                <X className="h-4 w-4" />
                Clear filters
              </Button>
            )}

            <div className="ml-auto flex items-center gap-2">
              <SearchFilter
                value={search}
                onChange={setSearch}
                placeholder="Search name, phone, email..."
              />
              {hasTenantOwnerAccess && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowImportLeads(true)}
                  >
                    <Upload className="h-4 w-4 mr-1" />
                    Import
                  </Button>
                  <Button size="sm" onClick={() => setShowCreateLead(true)} className="gap-2">
                    Create Lead
                    <Plus className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() => setShowShuffle(true)}
                    className="gap-2"
                  >
                    <Shuffle className="h-4 w-4" />
                    Shuffle
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Table — matches Leads/Clients design */}
          <div className="border-y border-x-0 overflow-x-auto">
            <Table className="text-xs">
              <TableHeader>
                <TableRow className="border-b border-border hover:bg-transparent">
                  <SortableTableHead
                    sortKey="name"
                    currentSort={sort}
                    onSort={handleSort}
                    icon={<User className="h-3 w-3 text-muted-foreground" />}
                    className="py-2 px-2"
                  >
                    Name
                  </SortableTableHead>
                  <SortableTableHead
                    sortKey="phone"
                    currentSort={sort}
                    onSort={handleSort}
                    icon={<Phone className="h-3 w-3 text-muted-foreground" />}
                    className="py-2 px-2"
                  >
                    Phone
                  </SortableTableHead>
                  <SortableTableHead
                    sortKey="email"
                    currentSort={sort}
                    onSort={handleSort}
                    icon={<Mail className="h-3 w-3 text-muted-foreground" />}
                    className="py-2 px-2"
                  >
                    Email
                  </SortableTableHead>
                  <SortableTableHead
                    sortKey="country"
                    currentSort={sort}
                    onSort={handleSort}
                    icon={<Globe className="h-3 w-3 text-muted-foreground" />}
                    className="py-2 px-2"
                  >
                    Country
                  </SortableTableHead>
                  <TableHead className="py-2 px-2">
                    <div className="flex items-center gap-1.5">
                      <Link2 className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Source</span>
                    </div>
                  </TableHead>
                  <TableHead className="py-2 px-2 w-[60px]">
                    <div className="flex items-center gap-1.5">
                      <Info className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Info</span>
                    </div>
                  </TableHead>
                  <TableHead className="py-2 px-2 min-w-[200px]">
                    <div className="flex items-center gap-1.5">
                      <UserCheck className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Assigned SA</span>
                    </div>
                  </TableHead>
                  <SortableTableHead
                    sortKey="status"
                    currentSort={sort}
                    onSort={handleSort}
                    icon={<Activity className="h-3 w-3 text-muted-foreground" />}
                    className="py-2 px-2"
                  >
                    Status
                  </SortableTableHead>
                  <SortableTableHead
                    sortKey="created_at"
                    currentSort={sort}
                    onSort={handleSort}
                    icon={<Calendar className="h-3 w-3 text-muted-foreground" />}
                    className="py-2 px-2"
                  >
                    Received
                  </SortableTableHead>
                  <TableHead
                    className="sticky right-0 w-[120px] shadow-[-4px_0_8px_rgba(0,0,0,0.1)] py-2 px-2 bg-background text-right"
                  >
                    <div className="flex items-center gap-1.5">
                      <Settings className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Actions</span>
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 8 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-28" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-24" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-36" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-20" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-24" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-24" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-6 w-6" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-7 w-40" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-20" /></TableCell>
                      <TableCell className="py-1.5 px-2"><Skeleton className="h-6 w-6" /></TableCell>
                    </TableRow>
                  ))
                ) : sorted.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="h-20 text-center text-muted-foreground">
                      No submissions yet.{" "}
                      {canAdmin && (
                        <>
                          Create an API key in{" "}
                          <Link to="/settings/live" className="underline">
                            Live Settings
                          </Link>{" "}
                          to get started.
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                ) : (
                  sorted.map((s) => {
                    const canConvert =
                      s.status === "assigned" && (canAdmin || (isSuperAgent && !!s.assigned_to));
                    const showActions =
                      canConvert ||
                      (canAdmin && s.status !== "converted" && s.status !== "dismissed") ||
                      canAdmin;
                    return (
                      <TableRow
                        key={s.id}
                        className="border-b border-border hover:bg-muted/50"
                      >
                        <TableCell className="font-medium py-1.5 px-2">
                          <Link
                            to={liveSubmissionHref(s.id)}
                            className="font-semibold text-xs hover:text-primary hover:underline"
                          >
                            {s.name}
                          </Link>
                        </TableCell>
                        <TableCell className="py-1.5 px-2">
                          {s.phone ? (
                            <button
                              type="button"
                              onClick={() => copyToClipboard(s.phone!, "Phone")}
                              className="text-xs hover:text-primary hover:underline cursor-pointer"
                              title="Click to copy"
                            >
                              {s.phone}
                            </button>
                          ) : (
                            <span className="text-xs text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="py-1.5 px-2 max-w-[200px] truncate">
                          {s.email ? (
                            <button
                              type="button"
                              onClick={() => copyToClipboard(s.email!, "Email")}
                              className="text-xs hover:text-primary hover:underline cursor-pointer truncate text-left max-w-full"
                              title="Click to copy"
                            >
                              {s.email}
                            </button>
                          ) : (
                            <span className="text-xs text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="py-1.5 px-2">
                          {s.country ? (
                            <span className="text-xs">{s.country}</span>
                          ) : (
                            <span className="text-xs text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="py-1.5 px-2 max-w-[180px] truncate text-xs text-muted-foreground">
                          {s.source_url ? (
                            <a
                              href={s.source_url}
                              target="_blank"
                              rel="noreferrer"
                              className="hover:underline inline-flex items-center gap-1"
                            >
                              {(() => {
                                try {
                                  return new URL(s.source_url).hostname;
                                } catch {
                                  return s.source_url;
                                }
                              })()}
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          ) : (
                            "-"
                          )}
                        </TableCell>
                        <TableCell className="py-1.5 px-2 w-[60px]">
                          <LiveSubmissionInfoPopover metadata={s.metadata} />
                        </TableCell>
                        <TableCell className="py-1.5 px-2 min-w-[200px]">
                          {canAdmin && s.status !== "converted" && s.status !== "dismissed" ? (
                            <InlineAssignSADropdown
                              submissionId={s.id}
                              currentAssignedTo={s.assigned_to || null}
                            />
                          ) : s.assigned_to ? (
                            <span className="text-xs">{agentNameById.get(s.assigned_to) || "—"}</span>
                          ) : (
                            <span className="text-xs text-muted-foreground">Unassigned</span>
                          )}
                        </TableCell>
                        <TableCell className="py-1.5 px-2">
                          {statusBadge(s.status, duplicateCopyIds.has(s.id))}
                          {s.status === "converted" && s.converted_client_id && (
                            <Link
                              to={clientHref(s.converted_client_id)}
                              className="block text-[10px] text-muted-foreground hover:underline mt-0.5"
                            >
                              View client
                            </Link>
                          )}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground py-1.5 px-2 whitespace-nowrap">
                          <div>{format(new Date(s.created_at), "MMM d, yyyy")}</div>
                          <div className="text-[10px]">
                            {formatDistanceToNow(new Date(s.created_at), { addSuffix: true })}
                          </div>
                        </TableCell>
                        <TableCell className="py-1.5 px-2 sticky right-0 bg-background w-[80px]">
                          {showActions ? (
                            <TooltipProvider>
                              <div className="flex items-center gap-0.5 justify-end">
                                {canConvert && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="default"
                                        className="h-7 w-7 p-0 [&_svg]:size-3.5"
                                        onClick={() => setConvertTarget(s)}
                                      >
                                        <Send className="rotate-45" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Convert</TooltipContent>
                                  </Tooltip>
                                )}
                                {canAdmin && s.status !== "converted" && s.status !== "dismissed" && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="secondary"
                                        className="h-7 w-7 p-0 [&_svg]:size-3.5"
                                        onClick={() => dismiss.mutate(s.id)}
                                      >
                                        <X />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Dismiss</TooltipContent>
                                  </Tooltip>
                                )}
                                {canAdmin && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        className="h-7 w-7 p-0 [&_svg]:size-3.5 text-destructive hover:text-destructive hover:bg-destructive/10"
                                        onClick={() => setDeleteTarget(s)}
                                      >
                                        <Trash2 />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Delete</TooltipContent>
                                  </Tooltip>
                                )}
                              </div>
                            </TooltipProvider>
                          ) : (
                            <span className="text-muted-foreground text-xs">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <ConvertSubmissionDialog
        submission={convertTarget}
        open={!!convertTarget}
        onOpenChange={(o) => !o && setConvertTarget(null)}
      />

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete submission?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the submission from{" "}
              <span className="font-semibold">{deleteTarget?.name}</span>. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (deleteTarget) remove.mutate(deleteTarget.id);
                setDeleteTarget(null);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <CreateLiveSubmissionDialog open={showCreateLead} onOpenChange={setShowCreateLead} />
      <ImportLiveSubmissionsDialog open={showImportLeads} onOpenChange={setShowImportLeads} />
      <ShuffleLiveSubmissionsDialog open={showShuffle} onOpenChange={setShowShuffle} />
    </div>
  );
}

function KpiTile({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-2xl font-semibold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}

function SAReceivedCards({
  submissions,
  agentNameById,
  month,
  onMonthChange,
}: {
  submissions: LiveSubmission[];
  agentNameById: Map<string, string>;
  month: string;
  onMonthChange: (m: string) => void;
}) {
  // Build last 12 months options
  const monthOptions = useMemo(() => {
    const opts: { value: string; label: string }[] = [];
    const now = new Date();
    for (let i = 0; i < 12; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      opts.push({ value: format(d, "yyyy-MM"), label: format(d, "MMMM yyyy") });
    }
    return opts;
  }, []);

  const counts = useMemo(() => {
    const [y, m] = month.split("-").map(Number);
    const start = new Date(y, m - 1, 1).getTime();
    const end = new Date(y, m, 1).getTime();
    const map = new Map<string, number>();
    for (const s of submissions) {
      if (!s.assigned_to) continue;
      const ts = s.assigned_at ? new Date(s.assigned_at).getTime() : new Date(s.created_at).getTime();
      if (ts < start || ts >= end) continue;
      map.set(s.assigned_to, (map.get(s.assigned_to) || 0) + 1);
    }
    return Array.from(map.entries())
      .map(([id, count]) => ({ id, count, name: agentNameById.get(id) || "Unknown" }))
      .sort((a, b) => b.count - a.count);
  }, [submissions, month, agentNameById]);

  const total = counts.reduce((a, b) => a + b.count, 0);

  return (
    <Card className="rounded-xl bg-transparent">
      <CardContent className="p-4 space-y-3 px-0 py-0">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-sm font-semibold">Leads received per Super Agent</div>
            <div className="text-xs text-muted-foreground">
              {total} total assigned in selected month
            </div>
          </div>
          <select
            value={month}
            onChange={(e) => onMonthChange(e.target.value)}
            className="h-8 rounded-md border border-input bg-background px-2 text-sm"
          >
            {monthOptions.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>

        {counts.length === 0 ? (
          <div className="text-sm text-muted-foreground py-6 text-center">
            No leads assigned in this month.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {counts.map((c) => (
              <Card key={c.id} className="bg-muted/30">
                <CardContent className="p-3">
                  <div className="text-xs text-muted-foreground truncate" title={c.name}>{c.name}</div>
                  <div className="text-2xl font-semibold mt-1">{c.count}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
