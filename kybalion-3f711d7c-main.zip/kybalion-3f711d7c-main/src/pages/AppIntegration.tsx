import { useState } from "react";
import { Navigate } from "react-router-dom";
import { Plug, KeyRound, Loader2, CheckCircle2, XCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUserData } from "@/contexts/UserDataContext";
import { usePartnerApiCall } from "@/hooks/usePartnerApi";
import { CreateUserForm } from "@/components/app-integration/CreateUserForm";
import { CreateTransactionForm } from "@/components/app-integration/CreateTransactionForm";
import { IntegrationGuide } from "@/components/app-integration/IntegrationGuide";
import { RecentCallsTable } from "@/components/app-integration/RecentCallsTable";
import { toast } from "sonner";

export default function AppIntegration() {
  const { hasTenantOwnerAccess, loading } = useUserData();
  const ping = usePartnerApiCall();
  const [pingResult, setPingResult] = useState<{ ok: boolean; status?: number; baseUrl?: string } | null>(null);

  if (!loading && !hasTenantOwnerAccess) {
    return <Navigate to="/access-denied-preview" replace />;
  }

  const handleTest = async () => {
    const res = await ping.mutateAsync({ endpoint: "ping", payload: {} });
    const ok = res.status >= 200 && res.status < 300 && res.body?.reachable;
    setPingResult({
      ok,
      status: res.body?.partner_status,
      baseUrl: res.body?.partner_base_url,
    });
    if (ok) toast.success("Partner reachable");
    else toast.error("Partner not reachable");
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <Plug className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">App Integration</h1>
          <p className="text-sm text-muted-foreground">
            Push users and transactions to your partner site without exposing the API key.
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <KeyRound className="h-4 w-4" /> Connection
          </CardTitle>
          <CardDescription>
            The API key is stored as a backend secret. It is never sent to the browser. To rotate it,
            ask Lovable to update the <code>PARTNER_API_KEY</code> secret.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm text-muted-foreground">Status:</span>
            {pingResult == null ? (
              <Badge variant="secondary">Unknown</Badge>
            ) : pingResult.ok ? (
              <Badge className="bg-emerald-500 hover:bg-emerald-500/90"><CheckCircle2 className="h-3 w-3 mr-1" /> Connected</Badge>
            ) : (
              <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Not reachable</Badge>
            )}
            {pingResult?.baseUrl && (
              <span className="text-xs text-muted-foreground font-mono">{pingResult.baseUrl}</span>
            )}
            <div className="ml-auto">
              <Button onClick={handleTest} disabled={ping.isPending} variant="outline" size="sm">
                {ping.isPending ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : null}
                Test connection
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="create-user" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="create-user">Create user</TabsTrigger>
          <TabsTrigger value="create-transaction">Create transaction</TabsTrigger>
          <TabsTrigger value="create-user-with-deposit">User + deposit</TabsTrigger>
        </TabsList>
        <TabsContent value="create-user">
          <CreateUserForm endpoint="create-user" />
        </TabsContent>
        <TabsContent value="create-transaction">
          <CreateTransactionForm />
        </TabsContent>
        <TabsContent value="create-user-with-deposit">
          <CreateUserForm endpoint="create-user-with-deposit" withDeposit />
        </TabsContent>
      </Tabs>

      <RecentCallsTable />
      <IntegrationGuide />
    </div>
  );
}
