import { useState, useMemo } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useClientsPaginated } from "@/hooks/useClientsPaginated";

import { exportAllClientsWithKycData } from "@/lib/exportAllData";
import { useUserData } from "@/contexts/UserDataContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserPlus, TrendingUp, DollarSign } from "lucide-react";
import { CreateBankDialog } from "@/components/kyc/CreateBankDialog";
import { CreateNoteDialog } from "@/components/kyc/CreateNoteDialog";
import { Client, ClientStatus } from "@/types/clients";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { TableX } from "@/components/ui/table-x";
import { ClientsTableToolbar } from "@/components/clients/ClientsTableToolbar";
import { ClientsTableFilters, ClientFilterValues } from "@/components/clients/ClientsTableFilters";
import { ClientsBoardView } from "@/components/clients/ClientsBoardView";
import { ClientsTableView } from "@/components/clients/ClientsTableView";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";
import { useTableSort, sortData } from "@/components/ui/sortable-table-head";
import { ClientsFloatingBar } from "@/components/clients/ClientsFloatingBar";
import { BulkAssignClientsDialog } from "@/components/clients/BulkAssignClientsDialog";
import { AssignClientGroupDialog } from "@/components/clients/AssignClientGroupDialog";
import { ImportClientsDialog } from "@/components/clients/ImportClientsDialog";
import { CreateClientDialog } from "@/components/clients/CreateClientDialog";
import { PaginationControls } from "@/components/ui/pagination-controls";
import { DEFAULT_PAGE_SIZE } from "@/types/pagination";

export default function Clients() {
  const { isAgent, isSuperAgent, isTeamLeader, isSuperAdmin, isTenantOwner, isManager, canViewPhone, canViewEmail } = useUserData();
  const isAdmin = isTenantOwner;
  const canDeleteExport = isSuperAdmin || isTenantOwner;
  useQueryClient();
  const { teamMemberIds } = useManagerTeam();

  const [search, setSearch] = useState("");
  const [viewMode, setViewMode] = useState<"table" | "board">("table");
  const [selectedStatuses, setSelectedStatuses] = useState<ClientStatus[]>([]);
  const [filterValues, setFilterValues] = useState<ClientFilterValues>({
    assignedTo: [],
    country: [],
    tenant: [],
    group: []
  });
  const [selectedClients, setSelectedClients] = useState<string[]>([]);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [unassignDialogOpen, setUnassignDialogOpen] = useState(false);
  const [groupDialogOpen, setGroupDialogOpen] = useState(false);
  const [createClientDialogOpen, setCreateClientDialogOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(DEFAULT_PAGE_SIZE);

  const { sort, handleSort } = useTableSort('updated_at', 'desc');

  const { clients, totalCount, isLoading, pagination, bulkUpdateStatus, bulkDeleteClients, depositedClientIds } = useClientsPaginated(
    {
      search,
      statuses: selectedStatuses.length > 0 ? selectedStatuses : undefined,
      assignedToList: filterValues.assignedTo.length > 0 ? filterValues.assignedTo : undefined,
      countries: filterValues.country.length > 0 ? filterValues.country : undefined,
      teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
      groupIds: filterValues.group.length > 0 ? filterValues.group : undefined,
      hasDeposited: filterValues.hasDeposited,
    },
    { page: currentPage, pageSize }
  );

  const [showBankDialog, setShowBankDialog] = useState(false);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    setSelectedClients([]);
  };

  const handlePageSizeChange = (newSize: number) => {
    setPageSize(newSize);
    setCurrentPage(1);
    setSelectedClients([]);
  };

  const handleAddBank = (client: Client) => {
    setSelectedClient(client);
    setShowBankDialog(true);
  };

  const handleAddNote = (client: Client) => {
    setSelectedClient(client);
    setShowNoteDialog(true);
  };

  const handleCreateAccount = (_client: Client) => {
    // No-op: integration removed.
  };

  const shouldShowEmail = canViewEmail;
  const shouldShowPhone = canViewPhone;
  const isRestrictedRole = isAgent || isSuperAgent || isTeamLeader;

  const stats = {
    totalClients: totalCount,
    totalBalance: clients?.reduce((sum, c) => sum + Number(c.balance), 0) || 0,
    totalEquity: clients?.reduce((sum, c) => sum + Number(c.equity), 0) || 0
  };

  const handleExport = async () => {
    exportAllClientsWithKycData({
      search: search || undefined,
      statuses: selectedStatuses.length > 0 ? selectedStatuses : undefined,
      assignedToList: filterValues.assignedTo.length > 0 ? filterValues.assignedTo : undefined,
      countries: filterValues.country.length > 0 ? filterValues.country : undefined,
      groupIds: filterValues.group.length > 0 ? filterValues.group : undefined,
      teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
      hasDeposited: filterValues.hasDeposited,
    });
  };

  const handleAddClient = () => {
    setCreateClientDialogOpen(true);
  };

  const handleStatusChange = async (clientId: string, newStatus: ClientStatus) => {
    try {
      const { error } = await supabase.from("clients").update({ status: newStatus }).eq("id", clientId);
      if (error) throw error;
      toast.success("Client status updated");
    } catch {
      toast.error("Failed to update client status");
    }
  };

  const sortedClients = useMemo(() => {
    return sortData(clients || [], sort.key, sort.direction);
  }, [clients, sort.key, sort.direction]);

  return (
    <div className="flex flex-col bg-background">
      <div className="pb-8 space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Clients</h1>
            <Badge variant="default" className="text-sm h-6 px-2">
              {totalCount.toLocaleString()}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-1">Track and manage your active clients</p>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card className="bg-primary text-primary-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
              <UserPlus className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalClients.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card className="bg-primary text-primary-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
              <DollarSign className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats.totalBalance)}</div>
            </CardContent>
          </Card>
          <Card className="bg-primary text-primary-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Initial Amt</CardTitle>
              <TrendingUp className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(stats.totalEquity)}</div>
            </CardContent>
          </Card>
        </div>

        <TableX
          toolbar={
            <ClientsTableToolbar
              search={search}
              onSearchChange={(val) => { setSearch(val); setCurrentPage(1); }}
              onExport={handleExport}
              onAddClient={handleAddClient}
              onImport={() => setImportDialogOpen(true)}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
              isRestrictedRole={isRestrictedRole}
              isAdmin={canDeleteExport}
            />
          }
          filters={
            <ClientsTableFilters
              selectedStatuses={selectedStatuses}
              onStatusesChange={(val) => { setSelectedStatuses(val); setCurrentPage(1); }}
              filterValues={filterValues}
              onFilterValuesChange={(val) => { setFilterValues(val); setCurrentPage(1); }}
              isAgent={isAgent}
              isSuperAdmin={isSuperAdmin}
            />
          }
        >
          {viewMode === "board" ? (
            <div className="p-4">
              <ClientsBoardView
                clients={clients || []}
                onStatusChange={handleStatusChange}
                isAgent={isAgent}
                isSuperAgent={isSuperAgent}
                onAddBank={handleAddBank}
                onAddNote={handleAddNote}
                onCreateAccount={handleCreateAccount}
              />
            </div>
          ) : (
            <>
              <ClientsTableView
                clients={sortedClients}
                isLoading={isLoading}
                selectedClients={selectedClients}
                onSelectAll={(checked) => {
                  if (checked) {
                    setSelectedClients(sortedClients.map(c => c.id));
                  } else {
                    setSelectedClients([]);
                  }
                }}
                onSelectClient={(clientId, checked) => {
                  if (checked) {
                    setSelectedClients(prev => [...prev, clientId]);
                  } else {
                    setSelectedClients(prev => prev.filter(id => id !== clientId));
                  }
                }}
                sort={sort}
                onSort={handleSort}
                isSuperAdmin={isSuperAdmin}
                shouldShowEmail={shouldShowEmail}
                shouldShowPhone={shouldShowPhone}
                isAdmin={isAdmin}
                isManager={isManager}
                onAddBank={handleAddBank}
                onAddNote={handleAddNote}
                onCreateAccount={handleCreateAccount}
                depositedClientIds={depositedClientIds}
              />
              {pagination && (
                <PaginationControls
                  pagination={pagination}
                  onPageChange={handlePageChange}
                  onPageSizeChange={handlePageSizeChange}
                  itemLabel="clients"
                />
              )}
            </>
          )}
        </TableX>
      </div>

      {selectedClient && (
        <>
          <CreateBankDialog entityId={selectedClient.id} entityType="client" open={showBankDialog} onOpenChange={setShowBankDialog} />
          <CreateNoteDialog entityId={selectedClient.id} entityType="client" open={showNoteDialog} onOpenChange={setShowNoteDialog} />
        </>
      )}

      {selectedClients.length > 0 && (
        <ClientsFloatingBar
          selectedClients={selectedClients}
          onClear={() => setSelectedClients([])}
          isAdmin={isAdmin}
          isManager={isManager}
          canDelete={canDeleteExport}
          onAssign={() => setAssignDialogOpen(true)}
          onUnassign={() => setUnassignDialogOpen(true)}
          onAssignToGroup={() => setGroupDialogOpen(true)}
          bulkUpdateStatus={bulkUpdateStatus}
          bulkDeleteClients={bulkDeleteClients}
        />
      )}

      <BulkAssignClientsDialog
        open={assignDialogOpen}
        onOpenChange={(open) => {
          setAssignDialogOpen(open);
          if (!open) setSelectedClients([]);
        }}
        selectedClientIds={selectedClients}
      />

      <BulkAssignClientsDialog
        open={unassignDialogOpen}
        onOpenChange={(open) => {
          setUnassignDialogOpen(open);
          if (!open) setSelectedClients([]);
        }}
        selectedClientIds={selectedClients}
        mode="unassign"
      />

      <AssignClientGroupDialog
        open={groupDialogOpen}
        onOpenChange={(open) => {
          setGroupDialogOpen(open);
          if (!open) setSelectedClients([]);
        }}
        selectedClientIds={selectedClients}
      />

      <CreateClientDialog
        open={createClientDialogOpen}
        onOpenChange={setCreateClientDialogOpen}
      />

      <ImportClientsDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
      />
    </div>
  );
}
