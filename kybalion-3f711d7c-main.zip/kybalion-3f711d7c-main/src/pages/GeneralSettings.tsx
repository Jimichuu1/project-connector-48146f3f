import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Settings, Upload, Music, Shield, X, Tags, ShieldCheck } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { PhoneVisibilitySettings } from "@/components/settings/PhoneVisibilitySettingsDialog";
import { StatusManagementPanel } from "@/components/settings/StatusManagementPanel";
import { PasswordProtectionSettings } from "@/components/settings/PasswordProtectionSettings";
import { TenantSettingsSelector } from "@/components/settings/TenantSettingsSelector";
import { useTenantSettings } from "@/hooks/useTenantSettings";
import { logger } from "@/utils/logger";

export default function GeneralSettings() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { isSuperAdmin: isSA, isTenantOwner, loading: userLoading } = useUserData();
  const {
    settings,
    isLoading,
    updateSettings,
    isUpdating,
    managingTenantId,
    setManagingTenantId,
    availableTenants,
    isSuperAdmin,
    refetch
  } = useTenantSettings();
  
  const [uploading, setUploading] = useState(false);
  const [uploadedSounds, setUploadedSounds] = useState<Array<{
    name: string;
    url: string;
  }>>([]);
  const [soundToDelete, setSoundToDelete] = useState<{
    name: string;
    url: string;
  } | null>(null);

  // Access check — only after user data has loaded
  useEffect(() => {
    if (userLoading) return;
    if (!user) return; // ProtectedPageRoute handles unauthenticated
    if (!isSA && !isTenantOwner) {
      toast.error("Access denied. Tenant owner privileges required.");
      navigate("/leads");
    }
  }, [user, navigate, userLoading, isSA, isTenantOwner]);

  useEffect(() => {
    fetchUploadedSounds();
  }, []);

  const fetchUploadedSounds = async () => {
    try {
      const { data, error } = await supabase.storage
        .from('celebration-sounds')
        .list('', { limit: 100, offset: 0 });
      
      if (error) throw error;
      
      if (data) {
        const sounds = data
          .filter(file => file.name !== '.emptyFolderPlaceholder' && file.id)
          .map(file => {
            const { data: { publicUrl } } = supabase.storage
              .from('celebration-sounds')
              .getPublicUrl(file.name);
            return { name: file.name, url: publicUrl };
          });
        setUploadedSounds(sounds);
      }
    } catch (error) {
      logger.error('Error fetching sounds', error instanceof Error ? error : undefined);
    }
  };

  const handleSoundUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !settings) return;

    if (!file.type.startsWith('audio/')) {
      toast.error('Please upload an audio file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size must be less than 5MB');
      return;
    }

    setUploading(true);
    try {
      // Delete ALL existing sounds before uploading new one (only 1 sound allowed)
      if (uploadedSounds.length > 0) {
        const soundsToDelete = uploadedSounds.map(s => s.name);
        await supabase.storage.from('celebration-sounds').remove(soundsToDelete);
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `celebration-sound-${Date.now()}.${fileExt}`;
      const { error: uploadError } = await supabase.storage
        .from('celebration-sounds')
        .upload(fileName, file);
      
      if (uploadError) {
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('celebration-sounds')
        .getPublicUrl(fileName);

      updateSettings({ celebration_sound_url: publicUrl });
      toast.success('Celebration sound uploaded successfully');
      fetchUploadedSounds();
    } catch (error) {
      logger.error('Error uploading sound', error instanceof Error ? error : undefined);
      toast.error('Failed to upload sound');
    } finally {
      setUploading(false);
      if (event.target) {
        event.target.value = '';
      }
    }
  };

  const activateSound = async (soundUrl: string) => {
    if (!settings) return;
    updateSettings({ celebration_sound_url: soundUrl });
    toast.success('Celebration sound activated');
  };

  const getActiveFileName = () => {
    if (!settings?.celebration_sound_url) return null;
    return settings.celebration_sound_url.split('/').pop() || null;
  };

  const handleDeleteSound = async (sound: { name: string; url: string }) => {
    if (!settings) return;
    try {
      await supabase.storage.from('celebration-sounds').remove([sound.name]);

      if (settings.celebration_sound_url === sound.url) {
        updateSettings({ celebration_sound_url: null });
      }
      toast.success('Sound removed');
      fetchUploadedSounds();
    } catch (error) {
      logger.error('Error deleting sound', error instanceof Error ? error : undefined);
      toast.error('Failed to delete sound');
    } finally {
      setSoundToDelete(null);
    }
  };

  const playTestSound = () => {
    if (settings?.celebration_sound_url) {
      const audio = new Audio(settings.celebration_sound_url);
      audio.volume = 0.7;
      audio.play().catch(() => { /* Audio playback failed silently */ });
    } else {
      toast.info('No custom sound uploaded. Using default bell sound.');
    }
  };

  if (isLoading) {
    return (
      <div className="pb-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="pb-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Settings className="h-6 w-6" />
            General Settings
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Configure settings for the system
          </p>
        </div>
      </div>

      {/* Tenant Selector for Super Admin */}
      {isSuperAdmin && setManagingTenantId && (
        <TenantSettingsSelector
          tenants={availableTenants}
          selectedTenantId={managingTenantId}
          onTenantChange={setManagingTenantId}
        />
      )}

      {!managingTenantId && isSuperAdmin ? (
        <Card className="bg-muted/30 border-0">
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground">
              Select a tenant above to manage their settings
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Privacy & Access Settings */}
            <Card className="bg-muted/30 border-0">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Shield className="h-4 w-4" />
                  Privacy & Access Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <PhoneVisibilitySettings 
                    settings={settings} 
                    onUpdate={updateSettings}
                    isLoading={isUpdating}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Reports Settings Card */}
            <Card className="bg-muted/30 border-0">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Settings className="h-4 w-4" />
                  Reports
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <Label htmlFor="conversion-target" className="text-sm">
                    Conversion target per agent (100%)
                  </Label>
                  <Input
                    id="conversion-target"
                    type="number"
                    min={1}
                    className="max-w-[160px]"
                    value={(settings as { conversion_target_per_agent?: number } | null)?.conversion_target_per_agent ?? 28}
                    onChange={(e) => {
                      const value = Math.max(1, parseInt(e.target.value, 10) || 1);
                      updateSettings({ conversion_target_per_agent: value } as never);
                    }}
                    disabled={isUpdating}
                  />
                  <p className="text-xs text-muted-foreground">
                    Used as the goal for each agent's conversion progress card.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Celebration Sound Card */}
            <Card className="bg-muted/30 border-0">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Music className="h-4 w-4" />
                  Celebration Media
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Input
                      id="sound-upload"
                      type="file"
                      accept="audio/*"
                      onChange={handleSoundUpload}
                      disabled={uploading}
                      className="hidden"
                    />
                    <Label
                      htmlFor="sound-upload"
                      className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md cursor-pointer border-2 border-dashed transition-colors ${
                        uploading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-muted'
                      }`}
                    >
                      <Upload className="h-3 w-3" />
                      {uploading ? 'Uploading...' : 'Upload Sound'}
                    </Label>
                    
                    {settings?.celebration_sound_url && (
                      <Button size="sm" variant="outline" onClick={playTestSound} className="h-7 text-xs">
                        <Music className="h-3 w-3 mr-1" />
                        Test
                      </Button>
                    )}
                  </div>

                  {/* Current Sound */}
                  <div className="space-y-1.5">
                    <p className="text-xs text-muted-foreground">Current Sound:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {uploadedSounds.length > 0 ? (
                        <Badge
                          variant="default"
                          className="bg-primary text-primary-foreground pr-1 text-xs py-0.5"
                        >
                          <Music className="h-2.5 w-2.5 mr-1" />
                          {uploadedSounds[0].name.replace(/\.[^/.]+$/, "")}
                          <button
                            onClick={() => setSoundToDelete(uploadedSounds[0])}
                            className="ml-1 p-0.5 rounded-full hover:bg-destructive/20 transition-colors"
                          >
                            <X className="h-2.5 w-2.5" />
                          </button>
                        </Badge>
                      ) : (
                        <p className="text-xs text-muted-foreground">No sound uploaded</p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Security Settings Card */}
            <Card className="bg-muted/30 border-0">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <ShieldCheck className="h-4 w-4" />
                  Security Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <PasswordProtectionSettings 
                  settings={settings} 
                  onUpdate={updateSettings}
                  isLoading={isUpdating}
                />
              </CardContent>
            </Card>

            {/* Status Management Card */}
            <Card className="bg-muted/30 border-0">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Tags className="h-4 w-4" />
                  Status Management
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <StatusManagementPanel />
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Delete Sound Confirmation Dialog */}
      <AlertDialog open={!!soundToDelete} onOpenChange={open => !open && setSoundToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Sound</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{soundToDelete?.name.replace(/\.[^/.]+$/, "")}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => soundToDelete && handleDeleteSound(soundToDelete)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
