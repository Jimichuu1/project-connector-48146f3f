import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, FileText, Pencil, Trash2, Eye, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { useUserData } from "@/contexts/UserDataContext";

interface Script {
  id: string;
  title: string;
  content: string;
  created_by: string;
  admin_id: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export default function Scripts() {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const { isTenantOwner, isSuperAdmin } = useUserData();
  const queryClient = useQueryClient();
  const canManage = isTenantOwner || isSuperAdmin;

  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingScript, setEditingScript] = useState<Script | null>(null);
  const [viewingScript, setViewingScript] = useState<Script | null>(null);
  const [deletingScript, setDeletingScript] = useState<Script | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const { data: scripts = [], isLoading } = useQuery({
    queryKey: ["scripts", effectiveTenantId, canManage],
    queryFn: async () => {
      let query = supabase
        .from("scripts")
        .select("*")
        .order("updated_at", { ascending: false });

      if (effectiveTenantId) {
        query = query.eq("admin_id", effectiveTenantId);
      }

      // Non-owners only see active scripts
      if (!canManage) {
        query = query.eq("is_active", true);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Script[];
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase.from("scripts").update({ is_active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["scripts"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const createMutation = useMutation({
    mutationFn: async ({ title, content }: { title: string; content: string }) => {
      if (!user) throw new Error("Not authenticated");
      const { error } = await supabase.from("scripts").insert({
        title,
        content,
        created_by: user.id,
        admin_id: effectiveTenantId || user.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["scripts"] });
      toast.success("Script created");
      resetForm();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, title, content }: { id: string; title: string; content: string }) => {
      const { error } = await supabase.from("scripts").update({ title, content }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["scripts"] });
      toast.success("Script updated");
      resetForm();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("scripts").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["scripts"] });
      toast.success("Script deleted");
      setDeletingScript(null);
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const resetForm = () => {
    setShowCreateDialog(false);
    setEditingScript(null);
    setTitle("");
    setContent("");
  };

  const openCreate = () => {
    setTitle("");
    setContent("");
    setShowCreateDialog(true);
  };

  const openEdit = (script: Script) => {
    setTitle(script.title);
    setContent(script.content);
    setEditingScript(script);
  };

  const handleSave = () => {
    if (!title.trim()) {
      toast.error("Title is required");
      return;
    }
    if (editingScript) {
      updateMutation.mutate({ id: editingScript.id, title: title.trim(), content });
    } else {
      createMutation.mutate({ title: title.trim(), content });
    }
  };

  const isSaving = createMutation.isPending || updateMutation.isPending;
  const isDialogOpen = showCreateDialog || !!editingScript;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Scripts</h1>
          <p className="text-sm text-muted-foreground">Manage scripts and documents for your team</p>
        </div>
        {canManage && (
          <Button onClick={openCreate} size="sm">
            <Plus className="h-4 w-4 mr-2" />
            New Script
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : scripts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <FileText className="h-12 w-12 mb-4 opacity-40" />
            <p className="text-lg font-medium">No scripts yet</p>
            {canManage && (
              <p className="text-sm mt-1">Create your first script for your team.</p>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {scripts.map((script) => (
            <Card
              key={script.id}
              className="cursor-pointer hover:border-primary/30 transition-colors"
              onClick={() => setViewingScript(script)}
            >
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base line-clamp-1">{script.title}</CardTitle>
                  {canManage && (
                    <div className="flex gap-1 ml-2 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0"
                        onClick={() => openEdit(script)}
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                        onClick={() => setDeletingScript(script)}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-3 whitespace-pre-wrap">
                  {script.content || "No content"}
                </p>
                <div className="flex items-center justify-between mt-3">
                  <Badge variant="outline" className="text-xs">
                    {format(new Date(script.updated_at), "MMM d, yyyy")}
                  </Badge>
                  {canManage && (
                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <Label htmlFor={`active-${script.id}`} className="text-xs text-muted-foreground">
                        {script.is_active ? "Visible" : "Hidden"}
                      </Label>
                      <Switch
                        id={`active-${script.id}`}
                        checked={script.is_active}
                        onCheckedChange={(checked) =>
                          toggleActiveMutation.mutate({ id: script.id, is_active: checked })
                        }
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create / Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={(open) => !open && resetForm()}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{editingScript ? "Edit Script" : "New Script"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 flex-1 overflow-y-auto">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Script title"
              />
            </div>
            <div className="space-y-2">
              <Label>Content</Label>
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your script content here..."
                rows={16}
                className="resize-none"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetForm}>Cancel</Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {editingScript ? "Save Changes" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog (read-only) */}
      <Dialog open={!!viewingScript} onOpenChange={(open) => !open && setViewingScript(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              {viewingScript?.title}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="flex-1 max-h-[60vh]">
            <div className="whitespace-pre-wrap text-sm leading-relaxed p-1">
              {viewingScript?.content || "No content"}
            </div>
          </ScrollArea>
          <DialogFooter>
            {canManage && viewingScript && (
              <Button
                variant="outline"
                onClick={() => {
                  const s = viewingScript;
                  setViewingScript(null);
                  openEdit(s);
                }}
              >
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}
            <Button onClick={() => setViewingScript(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingScript} onOpenChange={(open) => !open && setDeletingScript(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Script</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingScript?.title}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingScript && deleteMutation.mutate(deletingScript.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
