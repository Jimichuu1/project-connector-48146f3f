import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { Navigate } from "react-router-dom";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Users, UserPlus, Plus, DollarSign, Pencil, MoreHorizontal, KeyRound, Shield, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { CreateTenantDialog } from "@/components/tenant/CreateTenantDialog";
import { EditTenantDialog } from "@/components/tenant/EditTenantDialog";
import { ResetTenantPasswordDialog } from "@/components/tenant/ResetTenantPasswordDialog";
import { TenantIPWhitelistDialog } from "@/components/tenant/TenantIPWhitelistDialog";
import { DeleteTenantDialog } from "@/components/tenant/DeleteTenantDialog";
import { TableX } from "@/components/ui/table-x";
import { SearchFilter } from "@/components/filters/SearchFilter";

interface TenantStats {
  leadsCount: number;
  clientsCount: number;
  usersCount: number;
  depositsCount: number;
  depositsTotal: number;
}

interface Tenant {
  id: string;
  full_name: string | null;
  email: string;
  username: string | null;
  avatar_url: string | null;
  created_at: string;
  stats?: TenantStats;
}

export default function TenantManagement() {
  const { isSuperAdmin, loading: tenantLoading } = useTenant();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [resetPasswordDialogOpen, setResetPasswordDialogOpen] = useState(false);
  const [ipWhitelistDialogOpen, setIpWhitelistDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<Tenant | null>(null);
  const [search, setSearch] = useState("");

  // Fetch all TENANT_OWNERs as tenants
  const { data: tenants, isLoading, refetch } = useQuery({
    queryKey: ["tenants"],
    queryFn: async () => {
      // Get all TENANT_OWNER role users
      const { data: adminRoles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id")
        .eq("role", "TENANT_OWNER");

      if (rolesError) throw rolesError;
      if (!adminRoles || adminRoles.length === 0) return [];

      const adminIds = adminRoles.map((r) => r.user_id);

      // Get profiles for these admins
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, email, username, avatar_url, created_at")
        .in("id", adminIds);

      if (profilesError) throw profilesError;

      // Get stats for each tenant
      const tenantsWithStats: Tenant[] = await Promise.all(
        (profiles || []).map(async (profile) => {
          const [leadsRes, clientsRes, usersRes, depositsRes] = await Promise.all([
            supabase
              .from("leads")
              .select("id", { count: "exact", head: true })
              .eq("admin_id", profile.id),
            supabase
              .from("clients")
              .select("id", { count: "exact", head: true })
              .eq("admin_id", profile.id),
            supabase
              .from("profiles")
              .select("id", { count: "exact", head: true })
              .eq("created_by", profile.id),
            supabase
              .from("deposits")
              .select("id, amount")
              .eq("admin_id", profile.id)
              .eq("status", "approved"),
          ]);

          const depositsData = depositsRes.data || [];
          const depositsTotal = depositsData.reduce((sum, d) => sum + Number(d.amount || 0), 0);

          return {
            ...profile,
            stats: {
              leadsCount: leadsRes.count || 0,
              clientsCount: clientsRes.count || 0,
              usersCount: usersRes.count || 0,
              depositsCount: depositsData.length,
              depositsTotal,
            },
          };
        })
      );

      return tenantsWithStats;
    },
    enabled: isSuperAdmin,
  });

  // Only SUPER_ADMIN can access this page
  if (!tenantLoading && !isSuperAdmin) {
    return <Navigate to="/dashboard" replace />;
  }

  const getInitials = (name: string | null) => {
    if (!name) return "T";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);
  };

  const handleEditTenant = (tenant: Tenant) => {
    setSelectedTenant(tenant);
    setEditDialogOpen(true);
  };

  const handleResetPassword = (tenant: Tenant) => {
    setSelectedTenant(tenant);
    setResetPasswordDialogOpen(true);
  };

  const handleIPWhitelist = (tenant: Tenant) => {
    setSelectedTenant(tenant);
    setIpWhitelistDialogOpen(true);
  };

  const handleDeleteTenant = (tenant: Tenant) => {
    setSelectedTenant(tenant);
    setDeleteDialogOpen(true);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Filter tenants based on search
  const filteredTenants = tenants?.filter((tenant) => {
    if (!search) return true;
    const searchLower = search.toLowerCase();
    return (
      tenant.full_name?.toLowerCase().includes(searchLower) ||
      tenant.username?.toLowerCase().includes(searchLower) ||
      tenant.email?.toLowerCase().includes(searchLower)
    );
  });

  // Calculate totals
  const totalLeads = tenants?.reduce((acc, t) => acc + (t.stats?.leadsCount || 0), 0) || 0;
  const totalClients = tenants?.reduce((acc, t) => acc + (t.stats?.clientsCount || 0), 0) || 0;
  const totalDeposits = tenants?.reduce((acc, t) => acc + (t.stats?.depositsTotal || 0), 0) || 0;

  return (
    <div className="pb-8 space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Tenant Management</h1>
            <Badge variant="default" className="text-sm h-6 px-2">
              {tenants?.length || 0}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-1">Manage all tenant workspaces</p>
        </div>
        <Button size="sm" onClick={() => setCreateDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Create Tenant
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Tenants</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{tenants?.length || 0}</div>
            <p className="text-xs text-muted-foreground">Active workspaces</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
            <UserPlus className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalLeads}</div>
            <p className="text-xs text-muted-foreground">Across all tenants</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalClients}</div>
            <p className="text-xs text-muted-foreground">Across all tenants</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deposits</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalDeposits)}</div>
            <p className="text-xs text-muted-foreground">Across all tenants</p>
          </CardContent>
        </Card>
      </div>

      <CreateTenantDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onTenantCreated={() => refetch()}
      />

      <ResetTenantPasswordDialog
        open={resetPasswordDialogOpen}
        onOpenChange={setResetPasswordDialogOpen}
        tenant={selectedTenant}
      />

      <EditTenantDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        tenant={selectedTenant}
        onTenantUpdated={() => refetch()}
      />

      <TenantIPWhitelistDialog
        open={ipWhitelistDialogOpen}
        onOpenChange={setIpWhitelistDialogOpen}
        tenant={selectedTenant}
      />

      <DeleteTenantDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        tenant={selectedTenant}
        onTenantDeleted={() => refetch()}
      />

      {/* Tenants Table */}
      <TableX
        toolbar={
          <div className="flex items-center justify-between py-3">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                Each tenant has their own isolated data and team
              </span>
            </div>
            <SearchFilter value={search} onChange={setSearch} placeholder="Search tenants..." />
          </div>
        }
      >
        {isLoading ? (
          <div className="space-y-3 p-4">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tenant</TableHead>
                <TableHead>Username</TableHead>
                <TableHead className="text-center">Leads</TableHead>
                <TableHead className="text-center">Clients</TableHead>
                <TableHead className="text-center">Users</TableHead>
                <TableHead className="text-center">Deposits</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTenants && filteredTenants.length > 0 ? (
                filteredTenants.map((tenant) => (
                  <TableRow key={tenant.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={tenant.avatar_url || ""} />
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {getInitials(tenant.full_name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">
                            {tenant.full_name || "Unnamed Tenant"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            ID: {tenant.id.substring(0, 8)}...
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <code className="text-sm bg-muted px-2 py-1 rounded">
                        {tenant.username || tenant.email?.split("@")[0] || "-"}
                      </code>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="default" className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30">
                        {tenant.stats?.leadsCount || 0}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="default" className="bg-green-500/20 text-green-400 hover:bg-green-500/30">
                        {tenant.stats?.clientsCount || 0}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">
                        {tenant.stats?.usersCount || 0}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex flex-col items-center gap-0.5">
                        <Badge variant="default" className="bg-amber-500/20 text-amber-400 hover:bg-amber-500/30">
                          {tenant.stats?.depositsCount || 0}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatCurrency(tenant.stats?.depositsTotal || 0)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {format(new Date(tenant.created_at), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEditTenant(tenant)}>
                            <Pencil className="h-4 w-4 mr-2" />
                            Edit Tenant
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleResetPassword(tenant)}>
                            <KeyRound className="h-4 w-4 mr-2" />
                            Reset Password
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleIPWhitelist(tenant)}>
                            <Shield className="h-4 w-4 mr-2" />
                            IP Whitelist
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem 
                            onClick={() => handleDeleteTenant(tenant)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete Tenant
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    {search ? "No tenants match your search" : "No tenants found"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        )}
      </TableX>
    </div>
  );
}
