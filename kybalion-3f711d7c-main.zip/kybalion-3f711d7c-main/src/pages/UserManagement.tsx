import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Users, UserPlus } from "lucide-react";
import { Enums } from "@/integrations/supabase/types";
import { CreateUserDialog } from "@/components/user/CreateUserDialog";
import { TableX } from "@/components/ui/table-x";
import { SearchFilter } from "@/components/filters/SearchFilter";
import { UserManagementFilters, UserFilterValues } from "@/components/user/UserManagementFilters";
import { useTenant } from "@/contexts/TenantContext";
import { useUserManagement } from "@/hooks/useUserManagement";
import { UserTable } from "@/components/user/UserTable";
import { getErrorMessage } from "@/types/errors";
import { UserWithIpWhitelist } from "@/types/users";

const UserManagement = () => {
  const { user } = useAuth();
  const { isSuperAdmin } = useTenant();
  
  const {
    users,
    isLoading,
    currentUserRole,
    canDeleteUser,
    fetchUsers,
    handleSaveUser,
    handleResetPassword,
    handleDeleteUser,
    handleBulkPasswordReset,
    handleAddIp,
    handleRemoveIp,
  } = useUserManagement(user?.id);

  const [search, setSearch] = useState("");
  const [filterValues, setFilterValues] = useState<UserFilterValues>({ roles: [] });
  const [selectedUser, setSelectedUser] = useState<UserWithIpWhitelist | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Enums<"app_role">>("AGENT");
  const [isCloser, setIsCloser] = useState(false);
  const [editingIpUserId, setEditingIpUserId] = useState<string | null>(null);
  const [newIpAddress, setNewIpAddress] = useState("");
  const [showResetPasswordDialog, setShowResetPasswordDialog] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [userToResetPassword, setUserToResetPassword] = useState<UserWithIpWhitelist | null>(null);
  
  const [editedFullName, setEditedFullName] = useState("");
  const [editedUsername, setEditedUsername] = useState("");
  const [nameError, setNameError] = useState<string | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    userId: string;
    assignedClientsCount: number;
    assignedLeadsCount: number;
  } | null>(null);

  const handleEditUser = (u: UserWithIpWhitelist) => {
    setSelectedUser(u);
    setSelectedRole(u.role || "AGENT");
    setIsCloser(Boolean(u.is_closer));
    setEditedFullName(u.full_name || "");
    setEditedUsername(u.username || "");
    setNameError(null);
    setShowEditDialog(true);
  };

  const onSaveUser = async () => {
    if (!selectedUser) return;
    try {
      await handleSaveUser(selectedUser, editedFullName, editedUsername, selectedRole, isCloser);
      setShowEditDialog(false);
      setNameError(null);
    } catch (error) {
      if (error instanceof Error) {
        setNameError(error.message);
      }
    }
  };

  const onResetPassword = async () => {
    if (!userToResetPassword) return;
    try {
      await handleResetPassword(userToResetPassword, newPassword);
      setShowResetPasswordDialog(false);
      setNewPassword("");
      setUserToResetPassword(null);
      setShowEditDialog(false);
    } catch (error) {
      toast.error(getErrorMessage(error, "Failed to reset password"));
    }
  };

  const handleOpenResetPassword = (u: UserWithIpWhitelist) => {
    setUserToResetPassword(u);
    setNewPassword("");
    setShowResetPasswordDialog(true);
  };

  const onDeleteUser = async (userId: string, force: boolean = false) => {
    try {
      const result = await handleDeleteUser(userId, force);
      if (result.needsConfirmation) {
        setDeleteConfirmation({
          userId,
          assignedClientsCount: result.assignedClientsCount || 0,
          assignedLeadsCount: result.assignedLeadsCount || 0
        });
      }
    } catch (error) {
      toast.error(getErrorMessage(error, "Failed to delete user"));
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteConfirmation) return;
    setDeleteConfirmation(null);
    await onDeleteUser(deleteConfirmation.userId, true);
  };

  const onAddIp = async (userId: string) => {
    if (!newIpAddress.trim()) {
      toast.error("Please enter a valid IP address");
      return;
    }
    try {
      await handleAddIp(userId, newIpAddress);
      setNewIpAddress("");
      setEditingIpUserId(null);
    } catch (error) {
      toast.error(getErrorMessage(error, "Failed to add IP address"));
    }
  };

  const onRemoveIp = async (ipId: string) => {
    try {
      await handleRemoveIp(ipId);
    } catch (error) {
      toast.error(getErrorMessage(error, "Failed to remove IP address"));
    }
  };
  const filteredUsers = users.filter(u => {
    if (u.role === "TENANT_OWNER") return false;
    const matchesSearch = u.username?.toLowerCase().includes(search.toLowerCase()) || u.full_name?.toLowerCase().includes(search.toLowerCase());
    const matchesRole = filterValues.roles.length === 0 || (u.role && filterValues.roles.includes(u.role));
    return matchesSearch && matchesRole;
  });
  return <div className="pb-8 space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">User Management</h1>
            <Badge variant="default" className="text-sm h-6 px-2">
              {users.length}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-1">Manage user accounts, roles, and permissions</p>
        </div>
        <Button size="sm" onClick={() => setShowCreateDialog(true)}>
          <UserPlus className="h-4 w-4 mr-2" />
          Create New User
        </Button>
      </div>

      {/* Filters and Search */}
      <TableX toolbar={<div className="space-y-0">
              {/* Filter Bar */}
              <div className="flex items-center justify-between py-3 pr-0">
                <UserManagementFilters filterValues={filterValues} onFilterValuesChange={setFilterValues} />
                <div className="flex items-center gap-2">
                  <SearchFilter value={search} onChange={setSearch} placeholder="Search users..." />
                </div>
              </div>
            </div>}>
          <UserTable
            users={filteredUsers as UserWithIpWhitelist[]}
            isLoading={isLoading}
            editingIpUserId={editingIpUserId}
            newIpAddress={newIpAddress}
            currentUserRole={currentUserRole}
            isSuperAdmin={isSuperAdmin}
            onEdit={handleEditUser}
            onDelete={(userId) => onDeleteUser(userId)}
            onStartAddIp={setEditingIpUserId}
            onCancelAddIp={() => {
              setEditingIpUserId(null);
              setNewIpAddress("");
            }}
            onIpAddressChange={setNewIpAddress}
            onAddIp={onAddIp}
            onRemoveIp={onRemoveIp}
            canDeleteUser={canDeleteUser}
          />
        </TableX>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground mb-2">
                Username: {selectedUser?.username || "No username"}
              </p>
            </div>

            <div className="space-y-2">
              <Label>Full Name</Label>
              <Input placeholder="Enter full name" value={editedFullName} onChange={e => {
              setEditedFullName(e.target.value);
              setNameError(null);
            }} maxLength={100} />
              {nameError && <p className="text-xs text-destructive">{nameError}</p>}
            </div>

            <div className="space-y-2">
              <Label>Username</Label>
              <Input placeholder="Enter username" value={editedUsername} onChange={e => setEditedUsername(e.target.value)} maxLength={50} />
            </div>

            <div className="space-y-2">
              <Label>Role</Label>
              <Select 
                value={selectedRole} 
                onValueChange={(value: Enums<"app_role">) => {
                  setSelectedRole(value);
                  if (value !== "AGENT") setIsCloser(false);
                }}
                disabled={
                  selectedUser?.role === "SUPER_ADMIN" || 
                  (selectedUser?.role === "TENANT_OWNER" && currentUserRole !== "SUPER_ADMIN")
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {/* ADMIN role excluded - tenants are managed in Tenant Management */}
                  <SelectItem value="MANAGER">Manager</SelectItem>
                  <SelectItem value="TEAM_LEADER">Team Leader</SelectItem>
                  <SelectItem value="SUPER_AGENT">Super Agent</SelectItem>
                  <SelectItem value="AGENT">Agent</SelectItem>
                </SelectContent>
              </Select>
              {selectedUser?.role === "SUPER_ADMIN" && (
                <p className="text-xs text-muted-foreground">
                  SuperAdmin role cannot be changed
                </p>
              )}
            </div>

            {selectedRole === "AGENT" && (
              <div className="flex items-center justify-between rounded-md border p-3">
                <div className="space-y-0.5 pr-3">
                  <Label htmlFor="edit-user-is-closer" className="cursor-pointer text-sm font-medium">
                    Closer Agent
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Applies the dedicated Closer Agent salary tiers.
                  </p>
                </div>
                <Switch
                  id="edit-user-is-closer"
                  checked={isCloser}
                  onCheckedChange={setIsCloser}
                />
              </div>
            )}

            <p className="text-xs text-muted-foreground">
              Permissions are automatically assigned based on the selected role.
            </p>
          </div>

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button size="sm" variant="outline" onClick={() => {
            if (selectedUser) {
              handleOpenResetPassword(selectedUser);
            }
          }} className="w-full sm:w-auto sm:mr-auto">
              Reset Password
            </Button>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button size="sm" variant="outline" onClick={() => setShowEditDialog(false)}>
                Cancel
              </Button>
              <Button size="sm" onClick={onSaveUser}>Save Changes</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create User Dialog */}
      <CreateUserDialog open={showCreateDialog} onOpenChange={setShowCreateDialog} onUserCreated={fetchUsers} currentUserRole={currentUserRole} />

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirmation} onOpenChange={() => setDeleteConfirmation(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm User Deletion</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              This user has the following assignments that will be unassigned:
            </p>
            
            <div className="space-y-2">
              {deleteConfirmation && deleteConfirmation.assignedClientsCount > 0 && <div className="flex items-center gap-2 p-3 bg-muted rounded-md">
                  <Users className="h-4 w-4 text-primary" />
                  <span className="text-sm">
                    <strong>{deleteConfirmation.assignedClientsCount}</strong> client{deleteConfirmation.assignedClientsCount !== 1 ? 's' : ''}
                  </span>
                </div>}
              
              {deleteConfirmation && deleteConfirmation.assignedLeadsCount > 0 && <div className="flex items-center gap-2 p-3 bg-muted rounded-md">
                  <Users className="h-4 w-4 text-primary" />
                  <span className="text-sm">
                    <strong>{deleteConfirmation.assignedLeadsCount}</strong> lead{deleteConfirmation.assignedLeadsCount !== 1 ? 's' : ''}
                  </span>
                </div>}
            </div>

            <p className="text-sm text-destructive font-medium">
              These clients and leads will become unassigned. This action cannot be undone.
            </p>
          </div>

          <DialogFooter>
            <Button size="sm" variant="outline" onClick={() => setDeleteConfirmation(null)}>
              Cancel
            </Button>
            <Button size="sm" variant="destructive" onClick={handleConfirmDelete}>
              Delete User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={showResetPasswordDialog} onOpenChange={setShowResetPasswordDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Reset password for: <strong>{userToResetPassword?.full_name}</strong> (@{userToResetPassword?.username})
            </p>

            <div className="space-y-2">
              <Label>New Password</Label>
              <Input type="password" placeholder="Enter new password (min 6 characters)" value={newPassword} onChange={e => setNewPassword(e.target.value)} minLength={6} />
            </div>
          </div>

          <DialogFooter>
            <Button size="sm" variant="outline" onClick={() => {
            setShowResetPasswordDialog(false);
            setNewPassword("");
            setUserToResetPassword(null);
          }}>
              Cancel
            </Button>
            <Button size="sm" onClick={onResetPassword}>
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>;
};
export default UserManagement;