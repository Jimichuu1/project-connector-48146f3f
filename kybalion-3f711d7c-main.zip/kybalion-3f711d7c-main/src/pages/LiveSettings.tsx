import { useState } from "react";
import { Navigate } from "react-router-dom";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Plug, Copy, Trash2, KeyRound, AlertTriangle } from "lucide-react";
import { useUserData } from "@/contexts/UserDataContext";
import { useLiveFormApiKeys } from "@/hooks/useLiveFormApiKeys";
import { toast } from "sonner";
import { format } from "date-fns";

const ENDPOINT = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/submit-live-lead`;

export default function LiveSettings() {
  const { hasTenantOwnerAccess, loading } = useUserData();
  const { data: keys, isLoading, createKey, toggleActive, revokeKey } = useLiveFormApiKeys();
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [createdKey, setCreatedKey] = useState<string | null>(null);

  if (!loading && !hasTenantOwnerAccess) {
    return <Navigate to="/access-denied-preview" replace />;
  }

  const handleCreate = async () => {
    if (!name.trim()) return;
    try {
      const res = await createKey.mutateAsync({ name: name.trim(), defaultSource: "WEBSITE" });
      setCreatedKey(res.plainKey);
      setName("");
      toast.success("API key created");
    } catch {
      // toast handled in hook
    }
  };

  const copy = (txt: string) => {
    navigator.clipboard.writeText(txt);
    toast.success("Copied");
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center gap-3">
        <Plug className="h-6 w-6 text-primary" />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Live Settings</h1>
          <p className="text-sm text-muted-foreground">Manage API keys and learn how to send leads from your landing pages into Live Traffic.</p>
        </div>
      </div>

      {/* API Keys */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <KeyRound className="h-4 w-4" /> API Keys
            </CardTitle>
            <CardDescription>
              Each landing page should have its own key. The key is shown only once.
            </CardDescription>
          </div>
          <Button onClick={() => setCreateOpen(true)}>Create API key</Button>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Key prefix</TableHead>
                  <TableHead>Active</TableHead>
                  <TableHead>Last used</TableHead>
                  <TableHead>Requests</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">Loading...</TableCell>
                  </TableRow>
                )}
                {!isLoading && (!keys || keys.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">No API keys yet.</TableCell>
                  </TableRow>
                )}
                {(keys || []).map((k) => (
                  <TableRow key={k.id}>
                    <TableCell className="font-medium">{k.name}</TableCell>
                    <TableCell className="font-mono text-xs">{k.key_prefix}••••</TableCell>
                    <TableCell>
                      <Switch
                        checked={k.is_active}
                        onCheckedChange={(v) => toggleActive.mutate({ id: k.id, isActive: v })}
                      />
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {k.last_used_at ? format(new Date(k.last_used_at), "MMM d, HH:mm") : "Never"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{k.request_count}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm("Revoke this key? Landing pages using it will stop working.")) {
                            revokeKey.mutate(k.id);
                          }
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Integration guide */}
      <Card>
        <CardHeader>
          <CardTitle>Integration guide</CardTitle>
          <CardDescription>
            Send a POST request to the endpoint below from your landing page form.
            All submissions land in the <strong>Live Traffic</strong> page —
            from there you decide which group they go to.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Endpoint</Label>
            <CodeBlock value={ENDPOINT} onCopy={copy} />
          </div>
          <div>
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Required header</Label>
            <CodeBlock value={`x-api-key: <YOUR_API_KEY>`} onCopy={copy} />
          </div>

          <Accordion type="multiple" className="w-full">
            <AccordionItem value="schema">
              <AccordionTrigger>JSON body schema</AccordionTrigger>
              <AccordionContent>
                <CodeBlock
                  value={JSON.stringify(
                    {
                      name: "John Doe (Full name, required, max 200)",
                      phone: "+1 555 123 4567 (required)",
                      email: "john@example.com (required)",
                      scam_type: "Crypto investment (required)",
                      lost_amount: 12500,
                      time_frame: "3 months ago (required)",
                      description:
                        "Detailed description of what happened — must be at least 20 words long, otherwise the request is rejected with a 400 error.",
                      country: "Canada (optional — auto-mapped from +1)",
                      source_url: "https://your-landing-page.com/promo",
                      metadata: {
                        utm_source: "facebook",
                      },
                    },
                    null,
                    2,
                  )}
                  onCopy={copy}
                  multiline
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Required: <code>name</code>, <code>phone</code>, <code>email</code>,{" "}
                  <code>scam_type</code>, <code>lost_amount</code>, <code>time_frame</code>,{" "}
                  <code>description</code> (min 20 words). The <code>metadata</code> object is a
                  free-form bag for any extra fields.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="curl">
              <AccordionTrigger>curl example</AccordionTrigger>
              <AccordionContent>
                <CodeBlock
                  value={`curl -X POST '${ENDPOINT}' \\
  -H 'Content-Type: application/json' \\
  -H 'x-api-key: YOUR_API_KEY' \\
  -d '{
    "name": "John Doe",
    "phone": "+15551234567",
    "email": "john@example.com",
    "scam_type": "Crypto investment",
    "lost_amount": 12500,
    "time_frame": "3 months ago",
    "description": "I was contacted by someone claiming to be a broker who promised guaranteed returns on a crypto investment platform. I deposited funds over several weeks and was unable to withdraw any of my balance afterwards.",
    "source_url": "https://your-landing.com/promo"
  }'`}
                  onCopy={copy}
                  multiline
                />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="html">
              <AccordionTrigger>HTML form + fetch</AccordionTrigger>
              <AccordionContent>
                <CodeBlock
                  value={`<form id="lead-form">
  <input name="name" required placeholder="Full name" />
  <input name="phone" required placeholder="Phone number" />
  <input name="email" type="email" required placeholder="Email" />
  <input name="scam_type" required placeholder="Type of scam" />
  <input name="lost_amount" type="number" min="0" required placeholder="Lost amount" />
  <input name="time_frame" required placeholder="Time frame (e.g. 3 months ago)" />
  <textarea name="description" required minlength="150" placeholder="Description (min 20 words)"></textarea>
  <button type="submit">Submit</button>
</form>

<script>
  document.getElementById('lead-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    payload.lost_amount = Number(payload.lost_amount);
    payload.source_url = window.location.href;

    // Client-side: enforce 20-word minimum on description
    const words = (payload.description || '').trim().split(/\\s+/).filter(Boolean).length;
    if (words < 20) { alert('Description must be at least 20 words.'); return; }

    const res = await fetch('${ENDPOINT}', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': 'YOUR_API_KEY'
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok) alert('Thanks!');
    else alert('Error: ' + data.error);
  });
</script>`}
                  onCopy={copy}
                  multiline
                />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="react">
              <AccordionTrigger>React example</AccordionTrigger>
              <AccordionContent>
                <CodeBlock
                  value={`async function submitLead(form) {
  const res = await fetch('${ENDPOINT}', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.NEXT_PUBLIC_KYBALION_KEY
    },
    body: JSON.stringify({
      name: form.name,                 // Full name (required)
      phone: form.phone,               // required
      email: form.email,               // required
      scam_type: form.scamType,        // required
      lost_amount: Number(form.lostAmount), // required, numeric
      time_frame: form.timeFrame,      // required (e.g. "3 months ago")
      description: form.description,   // required, min 20 words
      source_url: window.location.href,
      metadata: { utm_source: form.utm_source }
    })
  });
  return res.json();
}`}
                  onCopy={copy}
                  multiline
                />
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="response">
              <AccordionTrigger>Response & errors</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2 text-sm">
                  <div><strong>200</strong> — <code>{`{ "ok": true, "submission_id": "...", "is_duplicate": false }`}</code></div>
                  <div><strong>400</strong> — invalid body (missing/oversized fields)</div>
                  <div><strong>401</strong> — missing or invalid <code>x-api-key</code></div>
                  <div><strong>429</strong> — rate limit (30 requests / 10 seconds per key)</div>
                  <div><strong>500</strong> — internal error</div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create API key</DialogTitle>
            <DialogDescription>Give the key a name so you can identify it later.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Name</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. CA Landing Page"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={!name.trim() || createKey.isPending}>
              {createKey.isPending ? "Creating..." : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* One-time key reveal dialog */}
      <Dialog open={!!createdKey} onOpenChange={(o) => !o && (setCreatedKey(null), setCreateOpen(false))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save your API key</DialogTitle>
            <DialogDescription>
              This is the <strong>only</strong> time you'll see this key. Store it somewhere safe.
            </DialogDescription>
          </DialogHeader>
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              We only store a hash. If you lose this key, you'll have to revoke it and create a new one.
            </AlertDescription>
          </Alert>
          {createdKey && <CodeBlock value={createdKey} onCopy={copy} multiline />}
          <DialogFooter>
            <Button onClick={() => { setCreatedKey(null); setCreateOpen(false); }}>I've saved it</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CodeBlock({
  value,
  onCopy,
  multiline,
}: {
  value: string;
  onCopy: (v: string) => void;
  multiline?: boolean;
}) {
  return (
    <div className="relative group mt-1">
      <pre
        className={`bg-muted/50 border rounded-md p-3 text-xs font-mono overflow-x-auto ${multiline ? "" : "whitespace-nowrap"}`}
      >
        {value}
      </pre>
      <Button
        size="sm"
        variant="ghost"
        className="absolute top-1.5 right-1.5 h-7 w-7 p-0"
        onClick={() => onCopy(value)}
      >
        <Copy className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
