import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useUserData } from "@/contexts/UserDataContext";
import { useFavouriteClients } from "@/hooks/useFavouriteClients";
import { Client, ClientStatus } from "@/types/clients";
import { supabase } from "@/integrations/supabase/client";
import { TableX } from "@/components/ui/table-x";
import { ClientsTableToolbar } from "@/components/clients/ClientsTableToolbar";
import { ClientsTableFilters, ClientFilterValues } from "@/components/clients/ClientsTableFilters";
import { ClientsTableView } from "@/components/clients/ClientsTableView";
import { Badge } from "@/components/ui/badge";
import { useTableSort, sortData } from "@/components/ui/sortable-table-head";
import { PaginationControls } from "@/components/ui/pagination-controls";
import { DEFAULT_PAGE_SIZE, calculatePagination } from "@/types/pagination";
import { CreateBankDialog } from "@/components/kyc/CreateBankDialog";
import { CreateNoteDialog } from "@/components/kyc/CreateNoteDialog";
import { Star } from "lucide-react";

export default function FavouriteClients() {
  const { isAgent, isSuperAgent, isSuperAdmin, isTenantOwner, isManager, canViewPhone, canViewEmail } = useUserData();
  const isAdmin = isTenantOwner;
  const { favourites, isLoading: favsLoading } = useFavouriteClients();

  const [search, setSearch] = useState("");
  const [selectedStatuses, setSelectedStatuses] = useState<ClientStatus[]>([]);
  const [filterValues, setFilterValues] = useState<ClientFilterValues>({
    assignedTo: [],
    country: [],
    tenant: [],
    group: []
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(DEFAULT_PAGE_SIZE);
  const { sort, handleSort } = useTableSort('updated_at', 'desc');

  const { data: clients = [], isLoading: clientsLoading } = useQuery({
    queryKey: ["favourite-clients-details", favourites, search, selectedStatuses, filterValues],
    enabled: favourites.length > 0,
    queryFn: async () => {
      let query = supabase.from("clients").select("*").in("id", favourites);

      if (search) {
        query = query.or(`name.ilike.%${search}%,email.ilike.%${search}%,home_phone.ilike.%${search}%`);
      }
      if (selectedStatuses.length > 0) {
        query = query.in("status", selectedStatuses);
      }
      if (filterValues.assignedTo.length > 0) {
        query = query.in("assigned_to", filterValues.assignedTo);
      }
      if (filterValues.country.length > 0) {
        query = query.in("country", filterValues.country);
      }

      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as Client[];
    },
  });

  const { data: depositedClientIds = new Set<string>() } = useQuery({
    queryKey: ["favourite-clients-deposited", favourites],
    enabled: favourites.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deposits")
        .select("client_id")
        .in("client_id", favourites)
        .eq("status", "approved");
      if (error) throw error;
      return new Set((data ?? []).map((d) => d.client_id));
    },
  });

  const sortedClients = useMemo(() => {
    return sortData(clients, sort.key, sort.direction);
  }, [clients, sort.key, sort.direction]);

  const totalCount = sortedClients.length;
  const pagination = useMemo(() => calculatePagination(totalCount, currentPage, pageSize), [totalCount, currentPage, pageSize]);
  const paginatedClients = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedClients.slice(start, start + pageSize);
  }, [sortedClients, currentPage, pageSize]);

  const [showBankDialog, setShowBankDialog] = useState(false);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  const handleAddBank = (client: Client) => { setSelectedClient(client); setShowBankDialog(true); };
  const handleAddNote = (client: Client) => { setSelectedClient(client); setShowNoteDialog(true); };
  const handleCreateAccount = (_client: Client) => { /* no-op */ };

  const isLoading = favsLoading || clientsLoading;

  return (
    <div className="flex flex-col bg-background">
      <div className="pb-8 space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
            <h1 className="text-2xl font-bold tracking-tight">Favourite Clients</h1>
            <Badge variant="default" className="text-sm h-6 px-2">{totalCount}</Badge>
          </div>
          <p className="text-muted-foreground text-sm mt-1">Your personally starred clients</p>
        </div>

        <TableX
          toolbar={
            <ClientsTableToolbar
              search={search}
              onSearchChange={(val) => { setSearch(val); setCurrentPage(1); }}
              onExport={() => {}}
              onAddClient={() => {}}
              onImport={() => {}}
              viewMode="table"
              onViewModeChange={() => {}}
              isRestrictedRole={true}
              isAdmin={false}
            />
          }
          filters={
            <ClientsTableFilters
              selectedStatuses={selectedStatuses}
              onStatusesChange={(val) => { setSelectedStatuses(val); setCurrentPage(1); }}
              filterValues={filterValues}
              onFilterValuesChange={(val) => { setFilterValues(val); setCurrentPage(1); }}
              isAgent={isAgent}
              isSuperAdmin={isSuperAdmin}
            />
          }
        >
          <ClientsTableView
            clients={paginatedClients}
            isLoading={isLoading}
            selectedClients={[]}
            onSelectAll={() => {}}
            onSelectClient={() => {}}
            sort={sort}
            onSort={handleSort}
            isSuperAdmin={isSuperAdmin}
            shouldShowEmail={canViewEmail}
            shouldShowPhone={canViewPhone}
            isAdmin={isAdmin}
            isManager={isManager}
            onAddBank={handleAddBank}
            onAddNote={handleAddNote}
            onCreateAccount={handleCreateAccount}
            depositedClientIds={depositedClientIds}
            showFavouriteColumn
          />
          {totalCount > pageSize && (
            <PaginationControls
              pagination={pagination}
              onPageChange={(p) => { setCurrentPage(p); }}
              onPageSizeChange={(s) => { setPageSize(s); setCurrentPage(1); }}
              itemLabel="clients"
            />
          )}
        </TableX>
      </div>

      {selectedClient && (
        <>
          <CreateBankDialog entityId={selectedClient.id} entityType="client" open={showBankDialog} onOpenChange={setShowBankDialog} />
          <CreateNoteDialog entityId={selectedClient.id} entityType="client" open={showNoteDialog} onOpenChange={setShowNoteDialog} />
        </>
      )}
    </div>
  );
}
