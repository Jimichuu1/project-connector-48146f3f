import { useMemo, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { DndContext, DragOverlay } from "@dnd-kit/core";
import { Badge } from "@/components/ui/badge";
import { useSaleBranches } from "@/hooks/useSaleBranches";
import { useClientsPaginated } from "@/hooks/useClientsPaginated";
import { useUserData } from "@/contexts/UserDataContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { PIPELINE_STAGES, SaleBranchWithClient } from "@/types/pipeline";
import { CreateOpportunityDialog } from "@/components/pipeline/CreateOpportunityDialog";
import { DepositDialog } from "@/components/pipeline/DepositDialog";
import { DepositInfoDialog } from "@/components/pipeline/DepositInfoDialog";
import { DepositApprovalDialog } from "@/components/pipeline/DepositApprovalDialog";
import { FlippedConfirmDialog } from "@/components/pipeline/FlippedConfirmDialog";
import { PipelineColumn } from "@/components/pipeline/PipelineColumn";
import { ClientsColumn } from "@/components/pipeline/ClientsColumn";
import { PipelineFilters } from "@/components/pipeline/PipelineFilters";
import { PipelineDragOverlay } from "@/components/pipeline/PipelineDragOverlay";

import { usePipelineFilters } from "@/hooks/usePipelineFilters";
import { usePipelineDragDrop } from "@/hooks/usePipelineDragDrop";
import { usePipelineDialogs } from "@/hooks/usePipelineDialogs";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function Pipeline() {
  const queryClient = useQueryClient();
  const { isTenantOwner, isManager, isSuperAgent, isSuperAdmin, profile, adminId, loading: roleLoading } = useUserData();
  const { teamMemberIds, isLoading: teamLoading } = useManagerTeam();
  const isAdmin = isTenantOwner;
  const isAdminOrManager = isSuperAdmin || isTenantOwner || isManager;
  // For deposit approval, only Tenant Owner and Super Admin can approve (not Manager)
  const canApproveDeposits = isSuperAdmin || isTenantOwner;

  // Wait for manager team data before fetching (prevents flash of all data)
  const isManagerDataReady = !isManager || !teamLoading;

  const handleDepositDeleted = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['sale-branches'] });
    queryClient.invalidateQueries({ queryKey: ['deposits'] });
  }, [queryClient]);

  const {
    branches,
    updateBranch,
    deleteBranch,
    isLoading: branchesLoading,
    error: branchesError,
  } = useSaleBranches({
    // For managers, filter by team members only
    teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
    enabled: isManagerDataReady,
  });

  const { clients, isLoading: clientsLoading, error: clientsError } = useClientsPaginated(
    {
      // For managers, filter by team members only
      teamMemberIds: isManager && teamMemberIds.length > 0 ? teamMemberIds : undefined,
    },
    { page: 1, pageSize: 500 } // Large page size for pipeline view
  );

  // Filter hook
  const {
    selectedClients,
    selectedSuperAgents,
    amountRange,
    isAmountFilterActive,
    depositRange,
    isDepositFilterActive,
    searchQuery,
    setSearchQuery,
    toggleClient,
    toggleSuperAgent,
    handleAmountRangeChange,
    clearAmountFilter,
    handleDepositRangeChange,
    clearDepositFilter,
    clearAllFilters,
    clientOptions,
    superAgentOptions,
    filterBranches,
    hasActiveFilters,
    activeFilterCount,
  } = usePipelineFilters(branches);

  // Dialog management hook
  const dialogs = usePipelineDialogs({
    updateBranch,
    onClearPendingDrop: () => dragDrop.clearPendingDrop(),
    branches,
  });

  // Drag & drop hook
  const dragDrop = usePipelineDragDrop({
    branches,
    clients,
    updateBranch,
    onDepositDrop: dialogs.openDepositDialog,
    onFlippedDrop: dialogs.openFlippedDialog,
  });

  // Handlers
  const handleEditValue = useCallback(
    (id: string, value: number) => {
      updateBranch.mutate({ id, value });
      toast.success("Value updated");
    },
    [updateBranch]
  );

  const handleDelete = useCallback(
    (id: string) => {
      deleteBranch.mutate(id);
      toast.success("Opportunity deleted");
    },
    [deleteBranch]
  );

  // Memoized values
  const totalBranches = useMemo(() => branches?.length || 0, [branches]);

  const filteredClients = useMemo(() => {
    return clients?.filter((client) => client.status !== "FLIPPED") || [];
  }, [clients]);

  const stagesBranches = useMemo(() => {
    return PIPELINE_STAGES.map((stage) => {
      const stageBranches = branches?.filter((b) => b.status === stage.value) || [];
      return {
        stage,
        branches: filterBranches(stageBranches),
      };
    });
  }, [branches, filterBranches]);

  // Include role/team loading in the overall loading state
  const isLoading = roleLoading || (isManager && teamLoading) || branchesLoading || clientsLoading;
  const hasError = branchesError || clientsError;

  return (
    <div className="pb-8 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight">Sales Pipeline</h1>
            {isLoading ? (
              <Skeleton className="h-6 w-12" />
            ) : (
              <Badge variant="default" className="text-sm h-6 px-2">
                {totalBranches}
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground text-sm mt-1">
            Manage your sales opportunities with drag-and-drop
          </p>
        </div>
      </div>

      <PipelineFilters
        clientOptions={clientOptions}
        selectedClients={selectedClients}
        onToggleClient={toggleClient}
        isAdmin={isAdmin}
        superAgentOptions={superAgentOptions}
        selectedSuperAgents={selectedSuperAgents}
        onToggleSuperAgent={toggleSuperAgent}
        amountRange={amountRange}
        isAmountFilterActive={isAmountFilterActive}
        onAmountRangeChange={handleAmountRangeChange}
        onClearAmountFilter={clearAmountFilter}
        depositRange={depositRange}
        isDepositFilterActive={isDepositFilterActive}
        onDepositRangeChange={handleDepositRangeChange}
        onClearDepositFilter={clearDepositFilter}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        hasActiveFilters={hasActiveFilters}
        activeFilterCount={activeFilterCount}
        onClearAllFilters={clearAllFilters}
      />


      {hasError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Failed to load pipeline data. Please refresh the page.
          </AlertDescription>
        </Alert>
      )}

      <DndContext
        sensors={dragDrop.sensors}
        onDragStart={dragDrop.handleDragStart}
        onDragEnd={dragDrop.handleDragEnd}
      >
        <div className="grid grid-cols-5 gap-3 overflow-x-hidden min-h-[calc(100vh-280px)]">
          <ClientsColumn
            clients={filteredClients}
            onAddOpportunity={dialogs.handleAddOpportunity}
            isLoading={clientsLoading}
            error={clientsError}
          />

          {stagesBranches.map(({ stage, branches: stageBranches }) => (
            <div key={stage.value}>
              <PipelineColumn
                stage={stage}
                branches={stageBranches}
                onEdit={handleEditValue}
                onDelete={handleDelete}
                onCardClick={(branch: SaleBranchWithClient) => dialogs.handleCardClick(branch, canApproveDeposits)}
                density="comfortable"
                isAdmin={isAdmin}
                isManager={isManager}
                isSuperAgent={isSuperAgent}
                isLoading={branchesLoading}
              />
            </div>
          ))}
        </div>

        <DragOverlay>
          <PipelineDragOverlay
            activeBranch={dragDrop.activeBranch}
            isAdmin={isAdmin}
          />
        </DragOverlay>
      </DndContext>

      {/* Dialogs */}
      {dialogs.selectedClient && (
        <CreateOpportunityDialog
          clientId={dialogs.selectedClient.id}
          clientName={dialogs.selectedClient.name}
          open={dialogs.createDialogOpen}
          onOpenChange={dialogs.setCreateDialogOpen}
        />
      )}

      {dialogs.depositBranchId && (
        <DepositDialog
          open={dialogs.depositDialogOpen}
          onOpenChange={(open) => {
            if (!open) {
              dialogs.handleDepositCancel();
            } else {
              dialogs.setDepositDialogOpen(open);
            }
          }}
          onConfirm={dialogs.handleDepositConfirm}
          leadId={dialogs.depositLeadId}
          branchId={dialogs.depositBranchId}
          clientId={
            branches?.find((b) => b.id === dialogs.depositBranchId)?.client_id || ""
          }
        />
      )}

      {dialogs.depositInfoBranchId && (
        <DepositInfoDialog
          open={dialogs.depositInfoDialogOpen}
          onOpenChange={dialogs.setDepositInfoDialogOpen}
          branchId={dialogs.depositInfoBranchId}
          onDepositDeleted={handleDepositDeleted}
        />
      )}

      {dialogs.pendingDepositInfo && (
        <DepositApprovalDialog
          open={dialogs.depositApprovalDialogOpen}
          onOpenChange={dialogs.setDepositApprovalDialogOpen}
          depositId={dialogs.pendingDepositInfo.depositId}
          amount={dialogs.pendingDepositInfo.amount}
          clientName={dialogs.pendingDepositInfo.clientName}
          agentName={dialogs.pendingDepositInfo.agentName}
          superAgentName={dialogs.pendingDepositInfo.superAgentName}
        />
      )}

      {dialogs.flippedBranchId && (
        <FlippedConfirmDialog
          open={dialogs.flippedDialogOpen}
          onOpenChange={(open) => {
            if (!open) {
              dialogs.setFlippedDialogOpen(false);
            }
          }}
          onConfirm={dialogs.handleFlippedConfirm}
          clientName={
            branches?.find((b) => b.id === dialogs.flippedBranchId)?.client?.name ||
            "Unknown Client"
          }
        />
      )}
    </div>
  );
}
