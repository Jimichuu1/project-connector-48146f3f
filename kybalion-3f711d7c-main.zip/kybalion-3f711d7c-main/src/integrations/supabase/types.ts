export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      admin_settings: {
        Row: {
          admin_id: string
          celebration_sound_url: string | null
          celebration_video_url: string | null
          conversion_target_per_agent: number
          created_at: string
          day_off_fee: number
          excessive_break_fee: number
          holiday_dates: string[]
          id: string
          late_grace_minutes: number
          late_start_fee: number
          max_break_minutes: number
          monthly_honorable_absences: number
          password_protection_config: Json | null
          show_phone_to_agents: boolean
          show_phone_to_super_agents: boolean | null
          timezone: string
          updated_at: string
          work_end_time: string
          work_start_time: string
        }
        Insert: {
          admin_id: string
          celebration_sound_url?: string | null
          celebration_video_url?: string | null
          conversion_target_per_agent?: number
          created_at?: string
          day_off_fee?: number
          excessive_break_fee?: number
          holiday_dates?: string[]
          id?: string
          late_grace_minutes?: number
          late_start_fee?: number
          max_break_minutes?: number
          monthly_honorable_absences?: number
          password_protection_config?: Json | null
          show_phone_to_agents?: boolean
          show_phone_to_super_agents?: boolean | null
          timezone?: string
          updated_at?: string
          work_end_time?: string
          work_start_time?: string
        }
        Update: {
          admin_id?: string
          celebration_sound_url?: string | null
          celebration_video_url?: string | null
          conversion_target_per_agent?: number
          created_at?: string
          day_off_fee?: number
          excessive_break_fee?: number
          holiday_dates?: string[]
          id?: string
          late_grace_minutes?: number
          late_start_fee?: number
          max_break_minutes?: number
          monthly_honorable_absences?: number
          password_protection_config?: Json | null
          show_phone_to_agents?: boolean
          show_phone_to_super_agents?: boolean | null
          timezone?: string
          updated_at?: string
          work_end_time?: string
          work_start_time?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_settings_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      advance_payments: {
        Row: {
          admin_id: string | null
          amount: number
          created_at: string
          id: string
          month: string
          note: string | null
          user_id: string | null
        }
        Insert: {
          admin_id?: string | null
          amount?: number
          created_at?: string
          id?: string
          month: string
          note?: string | null
          user_id?: string | null
        }
        Update: {
          admin_id?: string | null
          amount?: number
          created_at?: string
          id?: string
          month?: string
          note?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "advance_payments_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "advance_payments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      attendance: {
        Row: {
          admin_id: string | null
          break_minutes: number | null
          break_time_fee: number | null
          clock_in: string
          clock_out: string | null
          created_at: string
          date: string
          id: string
          is_late: boolean | null
          late_start_fee: number | null
          notes: string | null
          released_fees: number | null
          rule_snapshot: Json | null
          total_fees: number | null
          updated_at: string
          user_id: string
          working_periods: Json | null
          working_started_at: string | null
        }
        Insert: {
          admin_id?: string | null
          break_minutes?: number | null
          break_time_fee?: number | null
          clock_in?: string
          clock_out?: string | null
          created_at?: string
          date?: string
          id?: string
          is_late?: boolean | null
          late_start_fee?: number | null
          notes?: string | null
          released_fees?: number | null
          rule_snapshot?: Json | null
          total_fees?: number | null
          updated_at?: string
          user_id: string
          working_periods?: Json | null
          working_started_at?: string | null
        }
        Update: {
          admin_id?: string | null
          break_minutes?: number | null
          break_time_fee?: number | null
          clock_in?: string
          clock_out?: string | null
          created_at?: string
          date?: string
          id?: string
          is_late?: boolean | null
          late_start_fee?: number | null
          notes?: string | null
          released_fees?: number | null
          rule_snapshot?: Json | null
          total_fees?: number | null
          updated_at?: string
          user_id?: string
          working_periods?: Json | null
          working_started_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "attendance_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action_type: string
          admin_id: string | null
          created_at: string
          details: Json | null
          entity_id: string | null
          entity_type: string | null
          id: string
          ip_address: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          action_type: string
          admin_id?: string | null
          created_at?: string
          details?: Json | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          action_type?: string
          admin_id?: string | null
          created_at?: string
          details?: Json | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          ip_address?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      auth_attempts: {
        Row: {
          attempt_type: string
          blocked_until: string | null
          created_at: string
          failure_reason: string | null
          id: string
          ip_address: string
          success: boolean
          user_agent: string | null
          user_email: string | null
        }
        Insert: {
          attempt_type: string
          blocked_until?: string | null
          created_at?: string
          failure_reason?: string | null
          id?: string
          ip_address: string
          success?: boolean
          user_agent?: string | null
          user_email?: string | null
        }
        Update: {
          attempt_type?: string
          blocked_until?: string | null
          created_at?: string
          failure_reason?: string | null
          id?: string
          ip_address?: string
          success?: boolean
          user_agent?: string | null
          user_email?: string | null
        }
        Relationships: []
      }
      client_activities: {
        Row: {
          activity_type: string
          admin_id: string | null
          client_id: string
          created_at: string
          description: string
          id: string
          user_id: string
        }
        Insert: {
          activity_type: string
          admin_id?: string | null
          client_id: string
          created_at?: string
          description: string
          id?: string
          user_id: string
        }
        Update: {
          activity_type?: string
          admin_id?: string | null
          client_id?: string
          created_at?: string
          description?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_activities_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_activities_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_activities_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      client_comments: {
        Row: {
          client_id: string
          comment: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          client_id: string
          comment: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          client_id?: string
          comment?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_comments_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_comments_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      client_group_members: {
        Row: {
          added_at: string
          added_by: string | null
          client_id: string
          group_id: string
          id: string
        }
        Insert: {
          added_at?: string
          added_by?: string | null
          client_id: string
          group_id: string
          id?: string
        }
        Update: {
          added_at?: string
          added_by?: string | null
          client_id?: string
          group_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_group_members_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_group_members_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_group_members_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "client_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      client_groups: {
        Row: {
          admin_id: string | null
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_system: boolean | null
          name: string
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_system?: boolean | null
          name: string
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_system?: boolean | null
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_groups_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_groups_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      client_statuses: {
        Row: {
          color: string | null
          created_at: string
          id: string
          is_active: boolean | null
          is_default: boolean | null
          name: string
          position: number | null
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name: string
          position?: number | null
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name?: string
          position?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      client_tasks: {
        Row: {
          assigned_to: string
          client_id: string
          completed: boolean | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to: string
          client_id: string
          completed?: boolean | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string
          client_id?: string
          completed?: boolean | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_tasks_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_tasks_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      client_withdrawals: {
        Row: {
          amount: number
          approved_at: string | null
          approved_by: string | null
          client_id: string
          created_at: string
          id: string
          notes: string | null
          rejection_reason: string | null
          requested_at: string
          status: Database["public"]["Enums"]["withdrawal_status"]
          updated_at: string
        }
        Insert: {
          amount: number
          approved_at?: string | null
          approved_by?: string | null
          client_id: string
          created_at?: string
          id?: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          status?: Database["public"]["Enums"]["withdrawal_status"]
          updated_at?: string
        }
        Update: {
          amount?: number
          approved_at?: string | null
          approved_by?: string | null
          client_id?: string
          created_at?: string
          id?: string
          notes?: string | null
          rejection_reason?: string | null
          requested_at?: string
          status?: Database["public"]["Enums"]["withdrawal_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_withdrawals_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_withdrawals_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_withdrawals_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          actual_value: number | null
          admin_id: string | null
          assigned_to: string | null
          balance: number | null
          closer_agent_id: string | null
          conversion_manager_id: string | null
          conversion_super_agent_id: string | null
          converted_from_lead_id: string | null
          country: string | null
          created_at: string
          created_by: string
          deposits: number | null
          email: string | null
          equity: number | null
          home_phone: string | null
          id: string
          join_date: string
          kyc_status: Database["public"]["Enums"]["kyc_status"]
          lead_group_names: string[] | null
          live_traffic_submission_id: string | null
          margin_level: number | null
          name: string
          open_trades: number | null
          origin: string
          pipeline_status: Database["public"]["Enums"]["pipeline_status"]
          potential_value: number | null
          satisfaction_score: number | null
          seq_id: number
          source: Database["public"]["Enums"]["lead_source"] | null
          status: string
          transferring_agent: string | null
          updated_at: string
        }
        Insert: {
          actual_value?: number | null
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          closer_agent_id?: string | null
          conversion_manager_id?: string | null
          conversion_super_agent_id?: string | null
          converted_from_lead_id?: string | null
          country?: string | null
          created_at?: string
          created_by: string
          deposits?: number | null
          email?: string | null
          equity?: number | null
          home_phone?: string | null
          id?: string
          join_date?: string
          kyc_status?: Database["public"]["Enums"]["kyc_status"]
          lead_group_names?: string[] | null
          live_traffic_submission_id?: string | null
          margin_level?: number | null
          name: string
          open_trades?: number | null
          origin?: string
          pipeline_status?: Database["public"]["Enums"]["pipeline_status"]
          potential_value?: number | null
          satisfaction_score?: number | null
          seq_id?: never
          source?: Database["public"]["Enums"]["lead_source"] | null
          status?: string
          transferring_agent?: string | null
          updated_at?: string
        }
        Update: {
          actual_value?: number | null
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          closer_agent_id?: string | null
          conversion_manager_id?: string | null
          conversion_super_agent_id?: string | null
          converted_from_lead_id?: string | null
          country?: string | null
          created_at?: string
          created_by?: string
          deposits?: number | null
          email?: string | null
          equity?: number | null
          home_phone?: string | null
          id?: string
          join_date?: string
          kyc_status?: Database["public"]["Enums"]["kyc_status"]
          lead_group_names?: string[] | null
          live_traffic_submission_id?: string | null
          margin_level?: number | null
          name?: string
          open_trades?: number | null
          origin?: string
          pipeline_status?: Database["public"]["Enums"]["pipeline_status"]
          potential_value?: number | null
          satisfaction_score?: number | null
          seq_id?: never
          source?: Database["public"]["Enums"]["lead_source"] | null
          status?: string
          transferring_agent?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clients_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_closer_agent_id_fkey"
            columns: ["closer_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_conversion_manager_id_fkey"
            columns: ["conversion_manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_conversion_super_agent_id_fkey"
            columns: ["conversion_super_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_live_traffic_submission_id_fkey"
            columns: ["live_traffic_submission_id"]
            isOneToOne: true
            referencedRelation: "live_traffic_submissions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_transferring_agent_fkey"
            columns: ["transferring_agent"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      commission_tier_settings: {
        Row: {
          admin_id: string | null
          agent_base_salary: number
          agent_base_salary_tiers: Json
          agent_commission_tier_basis: string
          agent_commission_tiers: Json | null
          agent_tiers: Json
          closer_agent_base_salary: number
          closer_agent_base_salary_tiers: Json
          closer_agent_commission_tier_basis: string
          closer_agent_commission_tiers: Json
          closer_agent_tiers: Json
          created_at: string
          id: string
          manager_base_salary: number
          manager_base_salary_tiers: Json
          manager_tiers: Json
          month: string
          super_agent_base_salary: number
          super_agent_base_salary_tiers: Json
          super_agent_tiers: Json
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          agent_base_salary?: number
          agent_base_salary_tiers?: Json
          agent_commission_tier_basis?: string
          agent_commission_tiers?: Json | null
          agent_tiers?: Json
          closer_agent_base_salary?: number
          closer_agent_base_salary_tiers?: Json
          closer_agent_commission_tier_basis?: string
          closer_agent_commission_tiers?: Json
          closer_agent_tiers?: Json
          created_at?: string
          id?: string
          manager_base_salary?: number
          manager_base_salary_tiers?: Json
          manager_tiers?: Json
          month: string
          super_agent_base_salary?: number
          super_agent_base_salary_tiers?: Json
          super_agent_tiers?: Json
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          agent_base_salary?: number
          agent_base_salary_tiers?: Json
          agent_commission_tier_basis?: string
          agent_commission_tiers?: Json | null
          agent_tiers?: Json
          closer_agent_base_salary?: number
          closer_agent_base_salary_tiers?: Json
          closer_agent_commission_tier_basis?: string
          closer_agent_commission_tiers?: Json
          closer_agent_tiers?: Json
          created_at?: string
          id?: string
          manager_base_salary?: number
          manager_base_salary_tiers?: Json
          manager_tiers?: Json
          month?: string
          super_agent_base_salary?: number
          super_agent_base_salary_tiers?: Json
          super_agent_tiers?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "commission_tier_settings_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_salary_entries: {
        Row: {
          admin_id: string | null
          advance: number
          base_salary: number
          commission: number
          created_at: string
          id: string
          month: string
          name: string
          notes: string | null
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          advance?: number
          base_salary?: number
          commission?: number
          created_at?: string
          id?: string
          month: string
          name: string
          notes?: string | null
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          advance?: number
          base_salary?: number
          commission?: number
          created_at?: string
          id?: string
          month?: string
          name?: string
          notes?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "custom_salary_entries_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      deposits: {
        Row: {
          admin_id: string | null
          agent_amount: number
          agent_id: string | null
          agent_percentage: number
          amount: number
          approved_at: string | null
          approved_by: string | null
          client_id: string
          closer_agent_id: string | null
          counts_for_agent: boolean
          created_at: string
          created_by: string
          exchanges: string[] | null
          id: string
          lead_id: string | null
          rejection_reason: string | null
          sale_branch_id: string
          split_super_agent_amount: number | null
          split_super_agent_id: string | null
          status: string
          super_agent_amount: number
          super_agent_id: string | null
          super_agent_percentage: number
        }
        Insert: {
          admin_id?: string | null
          agent_amount: number
          agent_id?: string | null
          agent_percentage: number
          amount: number
          approved_at?: string | null
          approved_by?: string | null
          client_id: string
          closer_agent_id?: string | null
          counts_for_agent?: boolean
          created_at?: string
          created_by: string
          exchanges?: string[] | null
          id?: string
          lead_id?: string | null
          rejection_reason?: string | null
          sale_branch_id: string
          split_super_agent_amount?: number | null
          split_super_agent_id?: string | null
          status?: string
          super_agent_amount: number
          super_agent_id?: string | null
          super_agent_percentage: number
        }
        Update: {
          admin_id?: string | null
          agent_amount?: number
          agent_id?: string | null
          agent_percentage?: number
          amount?: number
          approved_at?: string | null
          approved_by?: string | null
          client_id?: string
          closer_agent_id?: string | null
          counts_for_agent?: boolean
          created_at?: string
          created_by?: string
          exchanges?: string[] | null
          id?: string
          lead_id?: string | null
          rejection_reason?: string | null
          sale_branch_id?: string
          split_super_agent_amount?: number | null
          split_super_agent_id?: string | null
          status?: string
          super_agent_amount?: number
          super_agent_id?: string | null
          super_agent_percentage?: number
        }
        Relationships: [
          {
            foreignKeyName: "deposits_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_sale_branch_id_fkey"
            columns: ["sale_branch_id"]
            isOneToOne: false
            referencedRelation: "sale_branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_split_super_agent_id_fkey"
            columns: ["split_super_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deposits_super_agent_id_fkey"
            columns: ["super_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          admin_id: string | null
          client_id: string | null
          created_at: string
          file_path: string
          id: string
          kyc_record_id: string | null
          lead_id: string | null
          name: string
          size: number
          type: Database["public"]["Enums"]["document_type"]
          uploaded_by: string
        }
        Insert: {
          admin_id?: string | null
          client_id?: string | null
          created_at?: string
          file_path: string
          id?: string
          kyc_record_id?: string | null
          lead_id?: string | null
          name: string
          size: number
          type: Database["public"]["Enums"]["document_type"]
          uploaded_by: string
        }
        Update: {
          admin_id?: string | null
          client_id?: string | null
          created_at?: string
          file_path?: string
          id?: string
          kyc_record_id?: string | null
          lead_id?: string | null
          name?: string
          size?: number
          type?: Database["public"]["Enums"]["document_type"]
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_kyc_record_id_fkey"
            columns: ["kyc_record_id"]
            isOneToOne: false
            referencedRelation: "kyc_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      favourite_clients: {
        Row: {
          client_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          client_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          client_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favourite_clients_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "favourite_clients_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      flipped_records: {
        Row: {
          admin_id: string | null
          agent_id: string | null
          client_id: string
          created_at: string
          flipped_at: string
          flipped_by: string | null
          id: string
          reason: string | null
          sale_branch_id: string
          super_agent_id: string | null
        }
        Insert: {
          admin_id?: string | null
          agent_id?: string | null
          client_id: string
          created_at?: string
          flipped_at?: string
          flipped_by?: string | null
          id?: string
          reason?: string | null
          sale_branch_id: string
          super_agent_id?: string | null
        }
        Update: {
          admin_id?: string | null
          agent_id?: string | null
          client_id?: string
          created_at?: string
          flipped_at?: string
          flipped_by?: string | null
          id?: string
          reason?: string | null
          sale_branch_id?: string
          super_agent_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "flipped_records_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "flipped_records_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "flipped_records_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "flipped_records_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "flipped_records_flipped_by_fkey"
            columns: ["flipped_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "flipped_records_sale_branch_id_fkey"
            columns: ["sale_branch_id"]
            isOneToOne: false
            referencedRelation: "sale_branches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "flipped_records_super_agent_id_fkey"
            columns: ["super_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      ip_whitelist: {
        Row: {
          admin_id: string | null
          created_at: string
          created_by: string
          description: string | null
          id: string
          ip_address: string
          is_active: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_id?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          ip_address: string
          is_active?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_id?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          ip_address?: string
          is_active?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ip_whitelist_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      kyc_records: {
        Row: {
          admin_id: string | null
          bank_name: string | null
          client_id: string | null
          created_at: string
          created_by: string
          id: string
          lead_id: string | null
          notes: string | null
          status: Database["public"]["Enums"]["kyc_status"]
          updated_at: string
          verified_by: string | null
          verified_date: string | null
        }
        Insert: {
          admin_id?: string | null
          bank_name?: string | null
          client_id?: string | null
          created_at?: string
          created_by: string
          id?: string
          lead_id?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["kyc_status"]
          updated_at?: string
          verified_by?: string | null
          verified_date?: string | null
        }
        Update: {
          admin_id?: string | null
          bank_name?: string | null
          client_id?: string | null
          created_at?: string
          created_by?: string
          id?: string
          lead_id?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["kyc_status"]
          updated_at?: string
          verified_by?: string | null
          verified_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "kyc_records_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kyc_records_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kyc_records_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kyc_records_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kyc_records_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "kyc_records_verified_by_fkey"
            columns: ["verified_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_activities: {
        Row: {
          activity_type: string
          admin_id: string | null
          created_at: string
          description: string
          id: string
          lead_id: string
          user_id: string
        }
        Insert: {
          activity_type: string
          admin_id?: string | null
          created_at?: string
          description: string
          id?: string
          lead_id: string
          user_id: string
        }
        Update: {
          activity_type?: string
          admin_id?: string | null
          created_at?: string
          description?: string
          id?: string
          lead_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_activities_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_activities_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_activities_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_comments: {
        Row: {
          comment: string
          created_at: string
          id: string
          lead_id: string
          user_id: string
        }
        Insert: {
          comment: string
          created_at?: string
          id?: string
          lead_id: string
          user_id: string
        }
        Update: {
          comment?: string
          created_at?: string
          id?: string
          lead_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_comments_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_comments_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_group_members: {
        Row: {
          added_at: string
          added_by: string
          group_id: string
          id: string
          lead_id: string
        }
        Insert: {
          added_at?: string
          added_by: string
          group_id: string
          id?: string
          lead_id: string
        }
        Update: {
          added_at?: string
          added_by?: string
          group_id?: string
          id?: string
          lead_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "lead_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_group_members_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_group_members_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_groups: {
        Row: {
          admin_id: string | null
          created_at: string
          created_by: string
          description: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_groups_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      lead_statuses: {
        Row: {
          color: string | null
          created_at: string
          id: string
          is_active: boolean | null
          is_default: boolean | null
          name: string
          position: number | null
          updated_at: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name: string
          position?: number | null
          updated_at?: string
        }
        Update: {
          color?: string | null
          created_at?: string
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name?: string
          position?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      lead_tasks: {
        Row: {
          assigned_to: string
          completed: boolean | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          lead_id: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to: string
          completed?: boolean | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          lead_id: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string
          completed?: boolean | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          lead_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lead_tasks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lead_tasks_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          admin_id: string | null
          assigned_to: string | null
          balance: number | null
          best_contact_time: string | null
          closer_agent_id: string | null
          company: string | null
          conversion_probability: number | null
          country: string | null
          created_at: string
          created_by: string
          email: string | null
          equity: number | null
          estimated_close_date: string | null
          id: string
          is_transferred: boolean | null
          job_title: string | null
          last_contacted_at: string | null
          name: string
          next_best_action: string | null
          pending_conversion: boolean | null
          phone: string | null
          position: number | null
          seq_id: number
          source: Database["public"]["Enums"]["lead_source"]
          status: string
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          best_contact_time?: string | null
          closer_agent_id?: string | null
          company?: string | null
          conversion_probability?: number | null
          country?: string | null
          created_at?: string
          created_by: string
          email?: string | null
          equity?: number | null
          estimated_close_date?: string | null
          id?: string
          is_transferred?: boolean | null
          job_title?: string | null
          last_contacted_at?: string | null
          name: string
          next_best_action?: string | null
          pending_conversion?: boolean | null
          phone?: string | null
          position?: number | null
          seq_id?: never
          source?: Database["public"]["Enums"]["lead_source"]
          status?: string
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          best_contact_time?: string | null
          closer_agent_id?: string | null
          company?: string | null
          conversion_probability?: number | null
          country?: string | null
          created_at?: string
          created_by?: string
          email?: string | null
          equity?: number | null
          estimated_close_date?: string | null
          id?: string
          is_transferred?: boolean | null
          job_title?: string | null
          last_contacted_at?: string | null
          name?: string
          next_best_action?: string | null
          pending_conversion?: boolean | null
          phone?: string | null
          position?: number | null
          seq_id?: never
          source?: Database["public"]["Enums"]["lead_source"]
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "leads_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_closer_agent_id_fkey"
            columns: ["closer_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      live_form_api_keys: {
        Row: {
          admin_id: string
          created_at: string
          created_by: string
          default_source: Database["public"]["Enums"]["lead_source"]
          id: string
          is_active: boolean
          key_hash: string
          key_prefix: string
          last_used_at: string | null
          name: string
          request_count: number
          updated_at: string
        }
        Insert: {
          admin_id: string
          created_at?: string
          created_by: string
          default_source?: Database["public"]["Enums"]["lead_source"]
          id?: string
          is_active?: boolean
          key_hash: string
          key_prefix: string
          last_used_at?: string | null
          name: string
          request_count?: number
          updated_at?: string
        }
        Update: {
          admin_id?: string
          created_at?: string
          created_by?: string
          default_source?: Database["public"]["Enums"]["lead_source"]
          id?: string
          is_active?: boolean
          key_hash?: string
          key_prefix?: string
          last_used_at?: string | null
          name?: string
          request_count?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_form_api_keys_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      live_traffic_submission_notes: {
        Row: {
          admin_id: string
          created_at: string
          id: string
          note: string
          submission_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_id: string
          created_at?: string
          id?: string
          note: string
          submission_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_id?: string
          created_at?: string
          id?: string
          note?: string
          submission_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_traffic_submission_notes_submission_id_fkey"
            columns: ["submission_id"]
            isOneToOne: false
            referencedRelation: "live_traffic_submissions"
            referencedColumns: ["id"]
          },
        ]
      }
      live_traffic_submissions: {
        Row: {
          admin_id: string
          api_key_id: string | null
          assigned_at: string | null
          assigned_by: string | null
          assigned_to: string | null
          converted_at: string | null
          converted_by: string | null
          converted_client_id: string | null
          country: string | null
          created_at: string
          dismissed_at: string | null
          dismissed_by: string | null
          duplicate_of_lead_id: string | null
          email: string | null
          id: string
          ip_address: string | null
          is_duplicate: boolean
          metadata: Json
          moved_at: string | null
          moved_by: string | null
          moved_lead_group_id: string | null
          moved_lead_id: string | null
          name: string
          phone: string | null
          phone_normalized: string | null
          source_url: string | null
          status: Database["public"]["Enums"]["live_submission_status"]
          user_agent: string | null
        }
        Insert: {
          admin_id: string
          api_key_id?: string | null
          assigned_at?: string | null
          assigned_by?: string | null
          assigned_to?: string | null
          converted_at?: string | null
          converted_by?: string | null
          converted_client_id?: string | null
          country?: string | null
          created_at?: string
          dismissed_at?: string | null
          dismissed_by?: string | null
          duplicate_of_lead_id?: string | null
          email?: string | null
          id?: string
          ip_address?: string | null
          is_duplicate?: boolean
          metadata?: Json
          moved_at?: string | null
          moved_by?: string | null
          moved_lead_group_id?: string | null
          moved_lead_id?: string | null
          name: string
          phone?: string | null
          phone_normalized?: string | null
          source_url?: string | null
          status?: Database["public"]["Enums"]["live_submission_status"]
          user_agent?: string | null
        }
        Update: {
          admin_id?: string
          api_key_id?: string | null
          assigned_at?: string | null
          assigned_by?: string | null
          assigned_to?: string | null
          converted_at?: string | null
          converted_by?: string | null
          converted_client_id?: string | null
          country?: string | null
          created_at?: string
          dismissed_at?: string | null
          dismissed_by?: string | null
          duplicate_of_lead_id?: string | null
          email?: string | null
          id?: string
          ip_address?: string | null
          is_duplicate?: boolean
          metadata?: Json
          moved_at?: string | null
          moved_by?: string | null
          moved_lead_group_id?: string | null
          moved_lead_id?: string | null
          name?: string
          phone?: string | null
          phone_normalized?: string | null
          source_url?: string | null
          status?: Database["public"]["Enums"]["live_submission_status"]
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "live_traffic_submissions_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "live_traffic_submissions_api_key_id_fkey"
            columns: ["api_key_id"]
            isOneToOne: false
            referencedRelation: "live_form_api_keys"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "live_traffic_submissions_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      manager_commission_settings: {
        Row: {
          admin_id: string | null
          base_salary: number
          base_salary_tiers: Json
          commission_percentage: number
          created_at: string
          id: string
          manager_id: string
          month: string
          tier_basis: string
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          base_salary?: number
          base_salary_tiers?: Json
          commission_percentage?: number
          created_at?: string
          id?: string
          manager_id: string
          month: string
          tier_basis?: string
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          base_salary?: number
          base_salary_tiers?: Json
          commission_percentage?: number
          created_at?: string
          id?: string
          manager_id?: string
          month?: string
          tier_basis?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "manager_commission_settings_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "manager_commission_settings_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          admin_id: string | null
          archived_at: string | null
          created_at: string
          id: string
          is_read: boolean
          message: string
          related_entity_id: string | null
          related_entity_type: string | null
          related_profile_id: string | null
          type: Database["public"]["Enums"]["notification_type"]
          user_id: string
        }
        Insert: {
          admin_id?: string | null
          archived_at?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          related_entity_id?: string | null
          related_entity_type?: string | null
          related_profile_id?: string | null
          type: Database["public"]["Enums"]["notification_type"]
          user_id: string
        }
        Update: {
          admin_id?: string | null
          archived_at?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          related_entity_id?: string | null
          related_entity_type?: string | null
          related_profile_id?: string | null
          type?: Database["public"]["Enums"]["notification_type"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      page_visits: {
        Row: {
          admin_id: string | null
          created_at: string
          hashed_path: string | null
          id: string
          path: string
          user_id: string
          was_denied: boolean
        }
        Insert: {
          admin_id?: string | null
          created_at?: string
          hashed_path?: string | null
          id?: string
          path: string
          user_id: string
          was_denied?: boolean
        }
        Update: {
          admin_id?: string | null
          created_at?: string
          hashed_path?: string | null
          id?: string
          path?: string
          user_id?: string
          was_denied?: boolean
        }
        Relationships: []
      }
      partner_api_call_log: {
        Row: {
          admin_id: string | null
          caller_user_id: string
          created_at: string
          endpoint: string
          id: string
          request_payload: Json | null
          response_body: Json | null
          response_status: number | null
        }
        Insert: {
          admin_id?: string | null
          caller_user_id: string
          created_at?: string
          endpoint: string
          id?: string
          request_payload?: Json | null
          response_body?: Json | null
          response_status?: number | null
        }
        Update: {
          admin_id?: string | null
          caller_user_id?: string
          created_at?: string
          endpoint?: string
          id?: string
          request_payload?: Json | null
          response_body?: Json | null
          response_status?: number | null
        }
        Relationships: []
      }
      performance_targets: {
        Row: {
          admin_id: string
          created_at: string
          created_by: string | null
          id: string
          notes: string | null
          period: string
          period_end: string
          period_start: string
          target_type: string
          target_value: number
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          notes?: string | null
          period: string
          period_end: string
          period_start: string
          target_type: string
          target_value: number
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          notes?: string | null
          period?: string
          period_end?: string
          period_start?: string
          target_type?: string
          target_value?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "performance_targets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          admin_id: string | null
          avatar_url: string | null
          created_at: string
          created_by: string | null
          deleted_at: string | null
          email: string
          full_name: string | null
          id: string
          is_closer: boolean
          last_name: string | null
          updated_at: string
          username: string | null
        }
        Insert: {
          admin_id?: string | null
          avatar_url?: string | null
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          email: string
          full_name?: string | null
          id: string
          is_closer?: boolean
          last_name?: string | null
          updated_at?: string
          username?: string | null
        }
        Update: {
          admin_id?: string | null
          avatar_url?: string | null
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          email?: string
          full_name?: string | null
          id?: string
          is_closer?: boolean
          last_name?: string | null
          updated_at?: string
          username?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      reminders: {
        Row: {
          admin_id: string | null
          completed: boolean
          completed_at: string | null
          created_at: string
          description: string | null
          due_date: string | null
          id: string
          priority: string
          related_entity_id: string | null
          related_entity_type: string | null
          timezone: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_id?: string | null
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          priority?: string
          related_entity_id?: string | null
          related_entity_type?: string | null
          timezone?: string | null
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_id?: string | null
          completed?: boolean
          completed_at?: string | null
          created_at?: string
          description?: string | null
          due_date?: string | null
          id?: string
          priority?: string
          related_entity_id?: string | null
          related_entity_type?: string | null
          timezone?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reminders_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      salary_month_locks: {
        Row: {
          admin_id: string
          id: string
          locked_at: string
          locked_by: string | null
          month: string
        }
        Insert: {
          admin_id: string
          id?: string
          locked_at?: string
          locked_by?: string | null
          month: string
        }
        Update: {
          admin_id?: string
          id?: string
          locked_at?: string
          locked_by?: string | null
          month?: string
        }
        Relationships: []
      }
      sale_branches: {
        Row: {
          admin_id: string | null
          client_id: string
          created_at: string
          created_by: string
          id: string
          name: string
          status: Database["public"]["Enums"]["pipeline_stage"]
          updated_at: string
          value: number
        }
        Insert: {
          admin_id?: string | null
          client_id: string
          created_at?: string
          created_by: string
          id?: string
          name: string
          status?: Database["public"]["Enums"]["pipeline_stage"]
          updated_at?: string
          value?: number
        }
        Update: {
          admin_id?: string | null
          client_id?: string
          created_at?: string
          created_by?: string
          id?: string
          name?: string
          status?: Database["public"]["Enums"]["pipeline_stage"]
          updated_at?: string
          value?: number
        }
        Relationships: [
          {
            foreignKeyName: "sale_branches_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sale_branches_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sale_branches_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients_secure"
            referencedColumns: ["id"]
          },
        ]
      }
      santos_sheet_imports: {
        Row: {
          admin_id: string
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          phone: string | null
          reason: string | null
          sheet_row_id: string
          status: string
          submission_id: string | null
        }
        Insert: {
          admin_id: string
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          reason?: string | null
          sheet_row_id: string
          status: string
          submission_id?: string | null
        }
        Update: {
          admin_id?: string
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          reason?: string | null
          sheet_row_id?: string
          status?: string
          submission_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "santos_sheet_imports_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "santos_sheet_imports_submission_id_fkey"
            columns: ["submission_id"]
            isOneToOne: false
            referencedRelation: "live_traffic_submissions"
            referencedColumns: ["id"]
          },
        ]
      }
      scripts: {
        Row: {
          admin_id: string | null
          content: string
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          title: string
          updated_at: string
        }
        Insert: {
          admin_id?: string | null
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          title: string
          updated_at?: string
        }
        Update: {
          admin_id?: string | null
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "scripts_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "scripts_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_integration_credentials: {
        Row: {
          admin_id: string | null
          created_at: string
          credentials: Json
          id: string
          is_active: boolean
          provider: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_id?: string | null
          created_at?: string
          credentials?: Json
          id?: string
          is_active?: boolean
          provider: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_id?: string | null
          created_at?: string
          credentials?: Json
          id?: string
          is_active?: boolean
          provider?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_integration_credentials_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_integration_credentials_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_permissions: {
        Row: {
          created_at: string
          id: string
          permission: Database["public"]["Enums"]["app_permission"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          permission: Database["public"]["Enums"]["app_permission"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          permission?: Database["public"]["Enums"]["app_permission"]
          user_id?: string
        }
        Relationships: []
      }
      user_preferences: {
        Row: {
          created_at: string
          group_last_read: Json | null
          id: string
          timezone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          group_last_read?: Json | null
          id?: string
          timezone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          group_last_read?: Json | null
          id?: string
          timezone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_sessions: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          ip_address: string | null
          is_active: boolean
          last_activity: string
          last_refresh_at: string | null
          refresh_count: number | null
          refresh_token_hash: string | null
          session_token: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          ip_address?: string | null
          is_active?: boolean
          last_activity?: string
          last_refresh_at?: string | null
          refresh_count?: number | null
          refresh_token_hash?: string | null
          session_token: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          ip_address?: string | null
          is_active?: boolean
          last_activity?: string
          last_refresh_at?: string | null
          refresh_count?: number | null
          refresh_token_hash?: string | null
          session_token?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      clients_secure: {
        Row: {
          actual_value: number | null
          admin_id: string | null
          assigned_to: string | null
          balance: number | null
          closer_agent_id: string | null
          conversion_manager_id: string | null
          conversion_super_agent_id: string | null
          converted_from_lead_id: string | null
          country: string | null
          created_at: string | null
          created_by: string | null
          deposits: number | null
          email: string | null
          equity: number | null
          home_phone: string | null
          id: string | null
          join_date: string | null
          kyc_status: Database["public"]["Enums"]["kyc_status"] | null
          lead_group_names: string[] | null
          margin_level: number | null
          name: string | null
          open_trades: number | null
          pipeline_status: Database["public"]["Enums"]["pipeline_status"] | null
          potential_value: number | null
          satisfaction_score: number | null
          seq_id: number | null
          source: Database["public"]["Enums"]["lead_source"] | null
          status: string | null
          transferring_agent: string | null
          updated_at: string | null
        }
        Insert: {
          actual_value?: number | null
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          closer_agent_id?: string | null
          conversion_manager_id?: string | null
          conversion_super_agent_id?: string | null
          converted_from_lead_id?: string | null
          country?: string | null
          created_at?: string | null
          created_by?: string | null
          deposits?: number | null
          email?: string | null
          equity?: number | null
          home_phone?: string | null
          id?: string | null
          join_date?: string | null
          kyc_status?: Database["public"]["Enums"]["kyc_status"] | null
          lead_group_names?: string[] | null
          margin_level?: number | null
          name?: string | null
          open_trades?: number | null
          pipeline_status?:
            | Database["public"]["Enums"]["pipeline_status"]
            | null
          potential_value?: number | null
          satisfaction_score?: number | null
          seq_id?: number | null
          source?: Database["public"]["Enums"]["lead_source"] | null
          status?: string | null
          transferring_agent?: string | null
          updated_at?: string | null
        }
        Update: {
          actual_value?: number | null
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          closer_agent_id?: string | null
          conversion_manager_id?: string | null
          conversion_super_agent_id?: string | null
          converted_from_lead_id?: string | null
          country?: string | null
          created_at?: string | null
          created_by?: string | null
          deposits?: number | null
          email?: string | null
          equity?: number | null
          home_phone?: string | null
          id?: string | null
          join_date?: string | null
          kyc_status?: Database["public"]["Enums"]["kyc_status"] | null
          lead_group_names?: string[] | null
          margin_level?: number | null
          name?: string | null
          open_trades?: number | null
          pipeline_status?:
            | Database["public"]["Enums"]["pipeline_status"]
            | null
          potential_value?: number | null
          satisfaction_score?: number | null
          seq_id?: number | null
          source?: Database["public"]["Enums"]["lead_source"] | null
          status?: string | null
          transferring_agent?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "clients_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_closer_agent_id_fkey"
            columns: ["closer_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_conversion_manager_id_fkey"
            columns: ["conversion_manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_conversion_super_agent_id_fkey"
            columns: ["conversion_super_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_transferring_agent_fkey"
            columns: ["transferring_agent"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      leads_secure: {
        Row: {
          admin_id: string | null
          assigned_to: string | null
          balance: number | null
          best_contact_time: string | null
          closer_agent_id: string | null
          company: string | null
          conversion_probability: number | null
          country: string | null
          created_at: string | null
          created_by: string | null
          email: string | null
          equity: number | null
          estimated_close_date: string | null
          id: string | null
          is_transferred: boolean | null
          job_title: string | null
          last_contacted_at: string | null
          name: string | null
          next_best_action: string | null
          pending_conversion: boolean | null
          phone: string | null
          position: number | null
          seq_id: number | null
          source: Database["public"]["Enums"]["lead_source"] | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          best_contact_time?: string | null
          closer_agent_id?: string | null
          company?: string | null
          conversion_probability?: number | null
          country?: string | null
          created_at?: string | null
          created_by?: string | null
          email?: never
          equity?: number | null
          estimated_close_date?: string | null
          id?: string | null
          is_transferred?: boolean | null
          job_title?: string | null
          last_contacted_at?: string | null
          name?: string | null
          next_best_action?: string | null
          pending_conversion?: boolean | null
          phone?: never
          position?: number | null
          seq_id?: number | null
          source?: Database["public"]["Enums"]["lead_source"] | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          admin_id?: string | null
          assigned_to?: string | null
          balance?: number | null
          best_contact_time?: string | null
          closer_agent_id?: string | null
          company?: string | null
          conversion_probability?: number | null
          country?: string | null
          created_at?: string | null
          created_by?: string | null
          email?: never
          equity?: number | null
          estimated_close_date?: string | null
          id?: string | null
          is_transferred?: boolean | null
          job_title?: string | null
          last_contacted_at?: string | null
          name?: string | null
          next_best_action?: string | null
          pending_conversion?: boolean | null
          phone?: never
          position?: number | null
          seq_id?: number | null
          source?: Database["public"]["Enums"]["lead_source"] | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "leads_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "leads_closer_agent_id_fkey"
            columns: ["closer_agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      archive_old_notifications: { Args: never; Returns: number }
      assert_bulk_authorization: {
        Args: {
          p_caller: string
          p_required_roles: string[]
          p_tenant_id: string
        }
        Returns: string
      }
      assign_lead_to_agent: {
        Args: {
          p_agent_id: string
          p_lead_id: string
          p_tenant_id?: string
          p_user_id: string
        }
        Returns: Json
      }
      assign_live_submission: {
        Args: { p_submission_id: string; p_super_agent_id: string }
        Returns: string
      }
      auto_lock_past_salary_months: { Args: never; Returns: undefined }
      bulk_assign_clients: {
        Args: {
          p_agent_id: string
          p_client_ids: string[]
          p_tenant_id?: string
          p_user_id: string
        }
        Returns: Json
      }
      bulk_assign_leads: {
        Args: {
          p_agent_id: string
          p_lead_ids: string[]
          p_tenant_id?: string
          p_user_id: string
        }
        Returns: Json
      }
      bulk_delete_clients: {
        Args: {
          p_client_ids: string[]
          p_tenant_id?: string
          p_user_id: string
        }
        Returns: Json
      }
      bulk_delete_leads: {
        Args: { p_lead_ids: string[]; p_tenant_id?: string; p_user_id: string }
        Returns: Json
      }
      bulk_update_client_status: {
        Args: {
          p_client_ids: string[]
          p_status: string
          p_tenant_id?: string
          p_user_id: string
        }
        Returns: Json
      }
      bulk_update_lead_status: {
        Args: {
          p_lead_ids: string[]
          p_status: string
          p_tenant_id?: string
          p_user_id: string
        }
        Returns: Json
      }
      calculate_working_hours: {
        Args: { p_clock_in: string; p_clock_out: string }
        Returns: number
      }
      can_access_lead: {
        Args: {
          _lead_admin_id: string
          _lead_assigned_to: string
          _lead_created_by: string
        }
        Returns: boolean
      }
      can_access_tenant: { Args: { _admin_id: string }; Returns: boolean }
      can_access_tenant_fast: {
        Args: {
          _record_admin_id: string
          _user_admin_id: string
          _user_role: string
        }
        Returns: boolean
      }
      can_delete_user: {
        Args: { _current_user_id: string; _target_user_id: string }
        Returns: boolean
      }
      can_view_email: { Args: never; Returns: boolean }
      can_view_phone: { Args: never; Returns: boolean }
      check_ip_whitelist: {
        Args: { p_ip_address: string; p_user_id: string }
        Returns: boolean
      }
      cleanup_expired_sessions: { Args: never; Returns: undefined }
      cleanup_user_sessions_on_login: {
        Args: { p_user_id: string }
        Returns: undefined
      }
      convert_lead_to_client_atomic: {
        Args: { p_assigned_super_agent: string; p_lead_id: string }
        Returns: Json
      }
      convert_lead_to_client_finalize: {
        Args: { p_client_id: string; p_lead_id: string }
        Returns: Json
      }
      convert_live_submission: {
        Args: { p_submission_id: string }
        Returns: string
      }
      count_failed_attempts: {
        Args: { p_ip_address: string; p_minutes?: number }
        Returns: number
      }
      country_from_phone: { Args: { p_phone: string }; Returns: string }
      decrypt_sensitive: { Args: { p_encrypted: string }; Returns: string }
      encrypt_sensitive: { Args: { p_data: string }; Returns: string }
      get_agent_conversion_count: {
        Args: {
          p_admin_id: string
          p_agent_id: string
          p_end_date: string
          p_start_date: string
        }
        Returns: {
          converted_count: number
          total_deposits: number
        }[]
      }
      get_agents_for_deposit: {
        Args: never
        Returns: {
          email: string
          full_name: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
        }[]
      }
      get_all_tenant_stats: { Args: never; Returns: Json }
      get_attributed_client_names: {
        Args: { p_client_ids: string[] }
        Returns: {
          id: string
          name: string
        }[]
      }
      get_client_related_profile_ids: {
        Args: { p_user_id: string }
        Returns: string[]
      }
      get_conversion_metrics:
        | {
            Args: {
              p_admin_id?: string
              p_end_date: string
              p_start_date: string
            }
            Returns: Json
          }
        | {
            Args: {
              p_admin_id?: string
              p_end_date: string
              p_start_date: string
              p_team_member_ids?: string[]
            }
            Returns: Json
          }
      get_current_user_context: {
        Args: never
        Returns: {
          admin_id: string
          created_by: string
          role: string
          user_id: string
        }[]
      }
      get_dashboard_stats: {
        Args: { p_admin_id?: string; p_user_id: string }
        Returns: Json
      }
      get_distinct_client_countries: {
        Args: { p_admin_id: string }
        Returns: {
          countries: string[]
          phone_prefixes: string[]
        }[]
      }
      get_distinct_lead_countries: {
        Args: { p_admin_id: string }
        Returns: {
          countries: string[]
          phone_prefixes: string[]
        }[]
      }
      get_encryption_key: { Args: never; Returns: string }
      get_leads_no_group: {
        Args: {
          p_include_group_ids?: string[]
          p_limit?: number
          p_offset?: number
          p_only_for_user?: string
          p_tenant: string
        }
        Returns: Json
      }
      get_managed_agent_ids: {
        Args: { _super_agent_id: string }
        Returns: string[]
      }
      get_manager_team_ids: { Args: { _manager_id: string }; Returns: string[] }
      get_or_create_client_system_groups: {
        Args: { p_admin_id: string; p_user_id: string }
        Returns: {
          converted_group_id: string
          live_group_id: string
          live_traffic_group_id: string
        }[]
      }
      get_or_create_general_settings: {
        Args: { p_tenant_id: string }
        Returns: string
      }
      get_or_create_tenant_settings: {
        Args: { p_tenant_id: string }
        Returns: string
      }
      get_profile_admin_id_direct: {
        Args: { p_user_id: string }
        Returns: string
      }
      get_server_time: { Args: never; Returns: string }
      get_target_history: {
        Args: { p_admin_id: string; p_month_end: string; p_month_start: string }
        Returns: {
          achieved: boolean
          current_value: number
          id: string
          notes: string
          period: string
          period_end: string
          period_start: string
          target_type: string
          target_value: number
          user_email: string
          user_id: string
          user_name: string
        }[]
      }
      get_target_progress: {
        Args: {
          p_admin_id: string
          p_period_end: string
          p_period_start: string
        }
        Returns: {
          current_value: number
          id: string
          notes: string
          period: string
          period_end: string
          period_start: string
          target_type: string
          target_value: number
          user_email: string
          user_id: string
          user_name: string
        }[]
      }
      get_team_leader_team_ids: { Args: { _tl_id: string }; Returns: string[] }
      get_tenant_super_agents: {
        Args: { p_tenant_id?: string }
        Returns: {
          email: string
          full_name: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }[]
      }
      get_tenant_user_ids: { Args: { _user_id: string }; Returns: string[] }
      get_top_agent_by_transfers: {
        Args: { p_admin_id: string; p_start_date: string }
        Returns: {
          agent_id: string
          agent_name: string
          transfer_count: number
        }[]
      }
      get_top_super_agent_by_deposits: {
        Args: { p_admin_id: string; p_start_date: string }
        Returns: {
          super_agent_id: string
          super_agent_name: string
          total_earnings: number
        }[]
      }
      get_user_admin_id: { Args: { p_user_id: string }; Returns: string }
      get_user_admin_id_safe: { Args: { p_user_id: string }; Returns: string }
      get_user_data: { Args: { p_user_id: string }; Returns: Json }
      get_user_role_direct: { Args: { check_user_id: string }; Returns: string }
      has_admin_access: { Args: { p_admin_id: string }; Returns: boolean }
      has_permission: {
        Args: {
          _permission: Database["public"]["Enums"]["app_permission"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hash_token: { Args: { p_token: string }; Returns: string }
      is_admin_or_tenant_owner: { Args: { _user_id: string }; Returns: boolean }
      is_in_manager_team: {
        Args: { _manager_id: string; _user_id: string }
        Returns: boolean
      }
      is_ip_blocked: { Args: { p_ip_address: string }; Returns: boolean }
      is_manager: { Args: { _user_id: string }; Returns: boolean }
      is_same_tenant: { Args: { p_record_admin_id: string }; Returns: boolean }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      log_audit_event: {
        Args: {
          p_action_type: string
          p_details?: Json
          p_entity_id?: string
          p_entity_type?: string
          p_ip_address?: string
          p_user_agent?: string
          p_user_id: string
        }
        Returns: string
      }
      lookup_email_by_username: {
        Args: { p_username: string }
        Returns: string
      }
      move_live_submission: {
        Args: {
          p_assignee_id?: string
          p_force?: boolean
          p_lead_group_id: string
          p_submission_id: string
        }
        Returns: string
      }
      notify_page_access_denied: {
        Args: { p_message: string; p_path: string }
        Returns: number
      }
      rotate_refresh_token: {
        Args: {
          p_new_token: string
          p_old_token_hash: string
          p_user_id: string
        }
        Returns: boolean
      }
      salary_health_check: { Args: { p_month?: string }; Returns: Json }
      unassign_live_submission: {
        Args: { p_submission_id: string }
        Returns: string
      }
      verify_live_form_api_key: {
        Args: { p_key_hash: string }
        Returns: {
          admin_id: string
          api_key_id: string
          default_source: Database["public"]["Enums"]["lead_source"]
        }[]
      }
    }
    Enums: {
      app_permission:
        | "CAN_VIEW_REPORTS"
        | "CAN_VIEW_SETTINGS"
        | "CAN_MANAGE_USERS"
        | "CAN_DELETE_LEADS"
        | "CAN_ASSIGN_ALL"
        | "CAN_TRANSFER_LEADS"
      app_role:
        | "ADMIN"
        | "MANAGER"
        | "SUPER_AGENT"
        | "AGENT"
        | "SUPER_ADMIN"
        | "TENANT_OWNER"
        | "TEAM_LEADER"
      churn_risk: "LOW" | "MEDIUM" | "HIGH"
      client_status: "ACTIVE" | "FLIPPED" | "FREELOADER" | "NO_ANSWER"
      document_type: "PDF" | "DOCX" | "XLSX" | "IMAGE" | "OTHER"
      kyc_status: "VERIFIED" | "PENDING" | "REJECTED"
      lead_source:
        | "WEBSITE"
        | "REFERRAL"
        | "SOCIAL_MEDIA"
        | "COLD_CALL"
        | "EMAIL_CAMPAIGN"
        | "PAID_ADS"
        | "WEBINAR"
        | "TRADE_SHOW"
        | "OTHER"
      lead_status:
        | "NEW"
        | "ACTIVE"
        | "CALLBACK"
        | "NOT_INTERESTED"
        | "READY_TO_TRANSFER"
        | "CALLED"
        | "DON'T_CALL"
      live_submission_status:
        | "new"
        | "moved"
        | "dismissed"
        | "assigned"
        | "converted"
      notification_type:
        | "NEW_LEAD"
        | "WITHDRAWAL_REQUEST"
        | "LEAD_ASSIGNED"
        | "CLIENT_CONVERTED"
        | "TASK_DUE"
        | "TICKET_CREATED"
        | "CONVERSION_APPROVED"
        | "CONVERSION_REJECTED"
        | "DEPOSIT_APPROVED"
        | "DEPOSIT_REJECTED"
        | "DEPOSIT_SPLIT_RECEIVED"
        | "CLIENT_ASSIGNED"
      pipeline_stage: "UPCOMING_SALE" | "STUCK" | "FLIPPED" | "DEPOSIT"
      pipeline_status:
        | "PROSPECT"
        | "QUALIFIED"
        | "NEGOTIATION"
        | "CLOSED_WON"
        | "CLOSED_LOST"
      risk_profile: "LOW" | "MEDIUM" | "HIGH"
      withdrawal_status: "PENDING" | "APPROVED" | "REJECTED" | "COMPLETED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_permission: [
        "CAN_VIEW_REPORTS",
        "CAN_VIEW_SETTINGS",
        "CAN_MANAGE_USERS",
        "CAN_DELETE_LEADS",
        "CAN_ASSIGN_ALL",
        "CAN_TRANSFER_LEADS",
      ],
      app_role: [
        "ADMIN",
        "MANAGER",
        "SUPER_AGENT",
        "AGENT",
        "SUPER_ADMIN",
        "TENANT_OWNER",
        "TEAM_LEADER",
      ],
      churn_risk: ["LOW", "MEDIUM", "HIGH"],
      client_status: ["ACTIVE", "FLIPPED", "FREELOADER", "NO_ANSWER"],
      document_type: ["PDF", "DOCX", "XLSX", "IMAGE", "OTHER"],
      kyc_status: ["VERIFIED", "PENDING", "REJECTED"],
      lead_source: [
        "WEBSITE",
        "REFERRAL",
        "SOCIAL_MEDIA",
        "COLD_CALL",
        "EMAIL_CAMPAIGN",
        "PAID_ADS",
        "WEBINAR",
        "TRADE_SHOW",
        "OTHER",
      ],
      lead_status: [
        "NEW",
        "ACTIVE",
        "CALLBACK",
        "NOT_INTERESTED",
        "READY_TO_TRANSFER",
        "CALLED",
        "DON'T_CALL",
      ],
      live_submission_status: [
        "new",
        "moved",
        "dismissed",
        "assigned",
        "converted",
      ],
      notification_type: [
        "NEW_LEAD",
        "WITHDRAWAL_REQUEST",
        "LEAD_ASSIGNED",
        "CLIENT_CONVERTED",
        "TASK_DUE",
        "TICKET_CREATED",
        "CONVERSION_APPROVED",
        "CONVERSION_REJECTED",
        "DEPOSIT_APPROVED",
        "DEPOSIT_REJECTED",
        "DEPOSIT_SPLIT_RECEIVED",
        "CLIENT_ASSIGNED",
      ],
      pipeline_stage: ["UPCOMING_SALE", "STUCK", "FLIPPED", "DEPOSIT"],
      pipeline_status: [
        "PROSPECT",
        "QUALIFIED",
        "NEGOTIATION",
        "CLOSED_WON",
        "CLOSED_LOST",
      ],
      risk_profile: ["LOW", "MEDIUM", "HIGH"],
      withdrawal_status: ["PENDING", "APPROVED", "REJECTED", "COMPLETED"],
    },
  },
} as const
