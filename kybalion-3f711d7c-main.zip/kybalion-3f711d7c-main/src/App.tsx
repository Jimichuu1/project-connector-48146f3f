import { Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useParams, useLocation } from "react-router-dom";
import { BreadcrumbProvider } from "@/contexts/BreadcrumbContext";
import { TenantProvider } from "@/contexts/TenantContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { UserDataProvider } from "@/contexts/UserDataContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { RoleProtectedRoute } from "@/components/auth/RoleProtectedRoute";
import { ManagerTeamProtectedRoute } from "@/components/auth/ManagerTeamProtectedRoute";
import { TokenRotationProvider } from "@/components/auth/TokenRotationProvider";
import { GeoAccessGuard } from "@/components/auth/GeoAccessGuard";
import { PageVisitTracker } from "@/components/auth/PageVisitTracker";
import { LEGACY_HASH_TO_READABLE } from "@/lib/routeMap";
import { AppLayout } from "@/components/AppLayout";
import { ErrorBoundary, RouteErrorBoundary } from "@/components/ErrorBoundary";
import { LoadingFallback } from "@/components/LoadingFallback";
import { lazyWithRetry } from "@/utils/lazyWithRetry";
import { queryClient } from "@/lib/queryClient";

const Index = lazyWithRetry(() => import("./pages/Index"));
const Dashboard = lazyWithRetry(() => import("./pages/Dashboard"));
const Leads = lazyWithRetry(() => import("./pages/Leads"));
const LeadDetail = lazyWithRetry(() => import("./pages/LeadDetail"));
const Clients = lazyWithRetry(() => import("./pages/Clients"));
const ClientDetail = lazyWithRetry(() => import("./pages/ClientDetail"));
const Pipeline = lazyWithRetry(() => import("./pages/Pipeline"));
const Reports = lazyWithRetry(() => import("./pages/Reports"));
const Salary = lazyWithRetry(() => import("./pages/Salary"));
const Targets = lazyWithRetry(() => import("./pages/Targets"));

const UserManagement = lazyWithRetry(() => import("./pages/UserManagement"));
const ConvertQueue = lazyWithRetry(() => import("./pages/ConvertQueue"));
const Attendance = lazyWithRetry(() => import("./pages/Attendance"));
const GeneralSettings = lazyWithRetry(() => import("./pages/GeneralSettings"));
const Profile = lazyWithRetry(() => import("./pages/Profile"));
const SecurityMonitoring = lazyWithRetry(() => import("./pages/SecurityMonitoring"));
const TeamManagement = lazyWithRetry(() => import("./pages/TeamManagement"));
const TenantManagement = lazyWithRetry(() => import("./pages/TenantManagement"));
const NotificationHistory = lazyWithRetry(() => import("./pages/NotificationHistory"));
const Scripts = lazyWithRetry(() => import("./pages/Scripts"));
const FavouriteClients = lazyWithRetry(() => import("./pages/FavouriteClients"));
const LiveTraffic = lazyWithRetry(() => import("./pages/LiveTraffic"));
const LiveSubmissionDetail = lazyWithRetry(() => import("./pages/LiveSubmissionDetail"));
const LiveSettings = lazyWithRetry(() => import("./pages/LiveSettings"));
const AppIntegration = lazyWithRetry(() => import("./pages/AppIntegration"));
const AccessDenied = lazyWithRetry(() => import("./pages/AccessDenied"));
const NotFound = lazyWithRetry(() => import("./pages/NotFound"));

const ProtectedPageRoute = ({ children }: { children: React.ReactNode }) => (
  <ProtectedRoute>
    <AppLayout>
      <RouteErrorBoundary>
        <Suspense fallback={<LoadingFallback />}>
          {children}
        </Suspense>
      </RouteErrorBoundary>
    </AppLayout>
  </ProtectedRoute>
);

// Legacy hashed-route detail redirect (preserves :id segment)
const LegacyDetailRedirect = () => {
  const { id } = useParams();
  const location = useLocation();
  const prefix = "/" + location.pathname.split("/").slice(1, 3).join("/"); // "/p/xxxxx"
  const readable = LEGACY_HASH_TO_READABLE[prefix];
  if (!readable) return <Navigate to="/" replace />;
  return <Navigate to={`${readable}/${id}`} replace />;
};

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <GeoAccessGuard>
        <AuthProvider>
          <TokenRotationProvider>
            <UserDataProvider>
              <TenantProvider>
                <BreadcrumbProvider>
                <TooltipProvider>
                  <Toaster />
                  <Sonner />
                  <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
                  <Suspense fallback={<LoadingFallback />}>
                    <PageVisitTracker />
                    <Routes>
                      <Route path="/" element={<RouteErrorBoundary><Index /></RouteErrorBoundary>} />

                      {/* Readable routes (real pages) */}
                      <Route path="/dashboard" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><Dashboard /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/live-traffic" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER", "SUPER_AGENT"]}><LiveTraffic /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/live-traffic/:id" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER", "SUPER_AGENT"]}><LiveSubmissionDetail /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/settings/live" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><LiveSettings /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/settings/app-integration" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><AppIntegration /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/leads" element={<ProtectedPageRoute><Leads /></ProtectedPageRoute>} />
                      <Route path="/leads/:id" element={<ProtectedPageRoute><LeadDetail /></ProtectedPageRoute>} />
                      <Route path="/clients" element={<ProtectedPageRoute><ManagerTeamProtectedRoute requiresSuperAgents><Clients /></ManagerTeamProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/clients/:id" element={<ProtectedPageRoute><ManagerTeamProtectedRoute requiresSuperAgents><ClientDetail /></ManagerTeamProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/pipeline" element={<ProtectedPageRoute><ManagerTeamProtectedRoute requiresSuperAgents><Pipeline /></ManagerTeamProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/reports" element={<ProtectedPageRoute><Reports /></ProtectedPageRoute>} />
                      <Route path="/salary" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><Salary /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/targets" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><Targets /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/user-management" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><UserManagement /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/convert-queue" element={<ProtectedPageRoute><ConvertQueue /></ProtectedPageRoute>} />
                      <Route path="/attendance" element={<ProtectedPageRoute><Attendance /></ProtectedPageRoute>} />
                      <Route path="/settings" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><GeneralSettings /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/settings/profile" element={<ProtectedPageRoute><Profile /></ProtectedPageRoute>} />
                      <Route path="/security-monitoring" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><SecurityMonitoring /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/team-management" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><TeamManagement /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/tenant-management" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><TenantManagement /></RoleProtectedRoute></ProtectedPageRoute>} />
                      <Route path="/notifications" element={<ProtectedPageRoute><NotificationHistory /></ProtectedPageRoute>} />
                      <Route path="/scripts" element={<ProtectedPageRoute><Scripts /></ProtectedPageRoute>} />
                      <Route path="/favourite-clients" element={<ProtectedPageRoute><RoleProtectedRoute allowedRoles={["SUPER_ADMIN", "TENANT_OWNER"]}><FavouriteClients /></RoleProtectedRoute></ProtectedPageRoute>} />

                      {/* Legacy hashed → readable redirects (preserve old bookmarks) */}
                      {Object.entries(LEGACY_HASH_TO_READABLE).map(([from, to]) => (
                        <Route key={from} path={from} element={<Navigate to={to} replace />} />
                      ))}
                      <Route path="/p/a3Wc5/:id" element={<LegacyDetailRedirect />} />
                      <Route path="/p/m8Yz3/:id" element={<LegacyDetailRedirect />} />
                      <Route path="/p/k9Lm4/:id" element={<LegacyDetailRedirect />} />

                      <Route path="/access-denied-preview" element={<RouteErrorBoundary><Suspense fallback={<LoadingFallback />}><AccessDenied /></Suspense></RouteErrorBoundary>} />
                      <Route path="*" element={<Suspense fallback={<LoadingFallback />}><NotFound /></Suspense>} />
                    </Routes>
                  </Suspense>
              </BrowserRouter>
            </TooltipProvider>
            </BreadcrumbProvider>
          </TenantProvider>
        </UserDataProvider>
      </TokenRotationProvider>
    </AuthProvider>
      </GeoAccessGuard>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
