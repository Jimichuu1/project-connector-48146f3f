/**
 * API response types for consistent typing across the application.
 */

/**
 * Generic API response wrapper
 */
export interface ApiResponse<T> {
  data: T | null;
  error: ApiError | null;
  success: boolean;
}

/**
 * API error structure
 */
export interface ApiError {
  message: string;
  code?: string;
  status?: number;
  details?: Record<string, unknown>;
}

/**
 * Pagination parameters
 */
export interface PaginationParams {
  page: number;
  pageSize: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

/**
 * Paginated response
 */
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasMore: boolean;
}

/**
 * Edge function response
 */
export interface EdgeFunctionResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

/**
 * User management edge function responses
 */
export interface DeleteUserResponse {
  success: boolean;
  needsConfirmation?: boolean;
  assignedClientsCount?: number;
  assignedLeadsCount?: number;
  error?: string;
}

export interface PasswordResetResponse {
  success: boolean;
  error?: string;
}

export interface BulkPasswordResetResponse {
  success: boolean;
  updated?: number;
  failed?: number;
  error?: string;
}

/**
 * Call initiation response
 */
export interface CallInitiateResponse {
  success: boolean;
  callId?: string;
  message?: string;
  error?: string;
}

/**
 * Email send response
 */
export interface EmailSendResponse {
  success: boolean;
  messageId?: string;
  error?: string;
}

/**
 * File upload response
 */
export interface FileUploadResponse {
  success: boolean;
  path?: string;
  url?: string;
  error?: string;
}
