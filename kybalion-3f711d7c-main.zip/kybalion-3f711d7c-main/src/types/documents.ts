export type DocumentType = 'PDF' | 'DOCX' | 'XLSX' | 'IMAGE' | 'OTHER';

export interface Document {
  id: string;
  name: string;
  size: number;
  type: DocumentType;
  file_path: string;
  uploaded_by: string;
  lead_id?: string;
  client_id?: string;
  kyc_record_id?: string;
  created_at: string;
}

export interface KYCRecord {
  id: string;
  lead_id?: string;
  client_id?: string;
  status: 'VERIFIED' | 'PENDING' | 'REJECTED';
  bank_name: string;
  notes?: string;
  verified_date?: string;
  verified_by?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface KYCRecordWithDocuments extends KYCRecord {
  documents?: Document[];
  verified_profile?: {
    id: string;
    full_name: string;
    email: string;
  };
}
