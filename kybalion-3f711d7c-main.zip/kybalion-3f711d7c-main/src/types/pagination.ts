/**
 * Pagination types and utilities for server-side pagination
 */

export interface PaginationParams {
  page: number;
  pageSize: number;
}

export interface PaginatedResult<T> {
  data: T[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export interface PaginationMeta {
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export function calculatePagination(
  totalCount: number,
  page: number,
  pageSize: number
): PaginationMeta {
  const totalPages = Math.ceil(totalCount / pageSize);
  return {
    totalCount,
    page,
    pageSize,
    totalPages,
    hasNextPage: page < totalPages,
    hasPreviousPage: page > 1,
  };
}

export function getOffsetAndLimit(page: number, pageSize: number): { offset: number; limit: number } {
  const offset = (page - 1) * pageSize;
  return { offset, limit: pageSize };
}

export const DEFAULT_PAGE_SIZE = 50;
export const PAGE_SIZE_OPTIONS = [20, 50, 100, 200, 500] as const;
export const LEADS_PAGE_SIZE_OPTIONS = [10, 20, 50] as const;
export const LEADS_PAGE_SIZE_OPTIONS_EXTENDED = [10, 20, 50, 500, 1000] as const;
export const LEADS_MAX_PAGE_SIZE = 50;
export const LEADS_MAX_PAGE_SIZE_EXTENDED = 1000;
export type PageSizeOption = typeof PAGE_SIZE_OPTIONS[number];
