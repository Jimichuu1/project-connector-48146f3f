import type { Json } from "@/integrations/supabase/types";

export interface WorkingPeriod {
  started_at: string;
  ended_at: string;
}

export interface Attendance {
  id: string;
  user_id: string;
  date: string;
  clock_in: string;
  clock_out: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  late_start_fee: number;
  break_time_fee: number;
  total_fees: number;
  released_fees: number;
  is_late: boolean;
  break_minutes: number;
  admin_id?: string | null;
  working_started_at?: string | null;
  working_periods?: Json | null;
  rule_snapshot?: Json | RuleSnapshot | null;
}

export interface RuleSnapshot {
  work_start_time: string;
  work_end_time: string;
  late_start_fee: number;
  excessive_break_fee: number;
  day_off_fee: number;
  max_break_minutes: number;
}

export interface AttendanceWithProfile extends Attendance {
  profiles: {
    full_name: string | null;
    email: string;
  };
}

export interface TenantSettings {
  work_start_time: string;
  work_end_time: string;
  late_start_fee: number;
  excessive_break_fee: number;
  day_off_fee: number;
  max_break_minutes: number;
  monthly_honorable_absences: number;
}

export interface TenantAttendanceGroup {
  tenantId: string;
  tenantName: string;
  settings: TenantSettings;
  attendance: AttendanceWithProfile[];
}
