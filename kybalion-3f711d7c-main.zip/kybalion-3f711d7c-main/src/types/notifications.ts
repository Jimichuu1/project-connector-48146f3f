export type NotificationType = 
  | 'NEW_LEAD'
  | 'WITHDRAWAL_REQUEST'
  | 'LEAD_ASSIGNED'
  | 'CLIENT_CONVERTED'
  | 'TASK_DUE'
  | 'TICKET_CREATED'
  | 'CONVERSION_APPROVED'
  | 'CONVERSION_REJECTED'
  | 'DEPOSIT_APPROVED'
  | 'DEPOSIT_REJECTED'
  | 'DEPOSIT_SPLIT_RECEIVED'
  | 'CLIENT_ASSIGNED';

export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  message: string;
  is_read: boolean;
  related_profile_id?: string;
  related_entity_type?: string;
  related_entity_id?: string;
  created_at: string;
}
