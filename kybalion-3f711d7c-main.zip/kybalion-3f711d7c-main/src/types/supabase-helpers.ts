/**
 * Helper types for Supabase query results and common patterns
 */

import { Database } from "@/integrations/supabase/types";

// Enum types from database
export type LeadSource = Database["public"]["Enums"]["lead_source"];
export type LeadStatus = Database["public"]["Enums"]["lead_status"];
export type ClientStatus = Database["public"]["Enums"]["client_status"];
export type PipelineStatus = Database["public"]["Enums"]["pipeline_status"];
export type KYCStatus = Database["public"]["Enums"]["kyc_status"];
export type PipelineStage = Database["public"]["Enums"]["pipeline_stage"];
export type NotificationType = Database["public"]["Enums"]["notification_type"];
export type DocumentType = Database["public"]["Enums"]["document_type"];
export type AppRole = Database["public"]["Enums"]["app_role"];
export type AppPermission = Database["public"]["Enums"]["app_permission"];
export type WithdrawalStatus = Database["public"]["Enums"]["withdrawal_status"];

// Table row types
export type LeadRow = Database["public"]["Tables"]["leads"]["Row"];
export type ClientRow = Database["public"]["Tables"]["clients"]["Row"];
export type ProfileRow = Database["public"]["Tables"]["profiles"]["Row"];
export type SaleBranchRow = Database["public"]["Tables"]["sale_branches"]["Row"];
export type DepositRow = Database["public"]["Tables"]["deposits"]["Row"];
export type KYCRecordRow = Database["public"]["Tables"]["kyc_records"]["Row"];
export type DocumentRow = Database["public"]["Tables"]["documents"]["Row"];
export type ReminderRow = Database["public"]["Tables"]["reminders"]["Row"];
export type NotificationRow = Database["public"]["Tables"]["notifications"]["Row"];
export type UserRoleRow = Database["public"]["Tables"]["user_roles"]["Row"];

// Common joined/enriched types
export interface ProfileBasic {
  id: string;
  full_name: string | null;
  email: string;
  avatar_url?: string | null;
}

// Profile with required avatar for table displays
export interface ProfileWithAvatar {
  id: string;
  full_name: string | null;
  email: string;
  avatar_url: string | null;
}

export interface UserWithRole extends ProfileBasic {
  username?: string | null;
  ccc_phone_number?: string | null;
  ccc_username?: string | null;
  role?: AppRole;
}

export interface LeadWithAssignment extends LeadRow {
  assigned_user?: ProfileBasic;
}

export interface ClientWithAssignment extends ClientRow {
  assigned_user?: ProfileBasic;
}

export interface SaleBranchWithClient extends SaleBranchRow {
  client?: {
    id: string;
    name: string;
    assigned_to?: string | null;
    assigned_user?: ProfileBasic | null;
  };
  deposit_status?: 'pending' | 'approved' | 'rejected';
  deposit_rejection_reason?: string | null;
}

export interface KYCRecordWithDocuments extends KYCRecordRow {
  documents?: DocumentRow[];
  verified_profile?: ProfileBasic;
}

export interface ReminderWithDetails extends ReminderRow {
  related_entity?: {
    name?: string;
    email?: string;
  };
}

// Document upload/management types
export interface DocumentUploadData {
  name: string;
  size: number;
  type: DocumentType;
  file_path: string;
  uploaded_by: string;
  lead_id?: string;
  client_id?: string;
  kyc_record_id?: string;
  admin_id?: string;
}

// KYC record creation types
export interface KYCRecordCreateData {
  status: KYCStatus;
  created_by: string;
  bank_name?: string;
  notes?: string;
  lead_id?: string;
  client_id?: string;
  admin_id?: string;
}

export interface KYCRecordUpdateData {
  status?: KYCStatus;
  bank_name?: string;
  notes?: string;
  verified_date?: string;
  verified_by?: string;
}

// Super agent types for convert queue
export interface SuperAgentUser {
  user_id: string;
  profiles: ProfileBasic;
  role?: AppRole;
}

// Mutation error type
export interface MutationError {
  message: string;
  code?: string;
  details?: string;
}

// Integration provider configuration - using Record for flexibility
export type ProviderConfigValue = string | boolean | number | null | undefined;
export type ProviderConfig = Record<string, ProviderConfigValue>;

// Helper to safely get string value from config
export const getConfigString = (config: ProviderConfig, key: string): string => {
  const value = config[key];
  if (value === null || value === undefined) return '';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  return String(value);
};

// Profile update data for user credentials
export interface ProfileUpdateData {
  ccc_phone_number?: string | null;
  ccc_username?: string | null;
  voiso_agent_extension?: string | null;
  voiso_agent_email?: string | null;
}

// Email credentials data
export interface EmailCredentialsData {
  email_address?: string | null;
  email_password?: string | null;
}
