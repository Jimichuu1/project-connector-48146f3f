// LeadStatus is dynamic from database - use string type
export type LeadStatus = string;

export type LeadSource = 
  | 'WEBSITE'
  | 'REFERRAL'
  | 'SOCIAL_MEDIA'
  | 'COLD_CALL'
  | 'EMAIL_CAMPAIGN'
  | 'PAID_ADS'
  | 'WEBINAR'
  | 'TRADE_SHOW'
  | 'OTHER';

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  country?: string;
  source: LeadSource;
  status: LeadStatus;
  job_title?: string;
  company?: string;
  assigned_to?: string;
  estimated_close_date?: string;
  best_contact_time?: string;
  is_transferred: boolean;
  pending_conversion: boolean;
  last_contacted_at?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  position?: number;
  admin_id?: string;
  balance?: number;
  equity?: number;
  closer_agent_id?: string;
}

export interface LeadActivity {
  id: string;
  lead_id: string;
  user_id: string;
  activity_type: string;
  description: string;
  created_at: string;
}

export interface LeadTask {
  id: string;
  lead_id: string;
  assigned_to: string;
  title: string;
  description?: string;
  due_date?: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface LeadComment {
  id: string;
  lead_id: string;
  user_id: string;
  comment: string;
  created_at: string;
}