/**
 * Type definitions for report data structures.
 * Eliminates "any" types in report components.
 */

export interface DateRange {
  from: Date;
  to: Date;
}

export interface RevenueByUser {
  user_id?: string;
  user_name: string;
  user_email: string;
  deals_won?: number;
  deals_lost?: number;
  total_revenue: number;
  win_rate?: number;
  avg_deal_size: number;
  deposits_count?: number;
}

export interface SalesMetrics {
  revenue_by_user: RevenueByUser[];
  total_revenue: number;
  total_deals_won: number;
  total_deals_lost?: number;
  overall_win_rate?: number;
  avg_deal_size: number;
  avg_sales_cycle_days?: number;
}

export interface DealsByStage {
  stage: string;
  deal_count?: number;
  count?: number;
  total_value?: number;
  value?: number;
  avg_value?: number;
  conversion_rate?: number;
}

export interface PipelineMetrics {
  deals_by_stage: DealsByStage[];
  total_pipeline_value?: number;
  weighted_pipeline_value?: number;
  total_opportunities?: number;
  total_value?: number;
}

export interface ActivityMetrics {
  activities_by_type: {
    type: string;
    count: number;
  }[];
  activities_by_user: {
    user_name: string;
    calls: number;
    emails: number;
    meetings: number;
    total: number;
    avg_response_time_hours: number;
  }[];
  total_activities: number;
}

export interface ConversionByStatus {
  status?: string;
  source?: string;
  leads?: number;
  count?: number;
  converted?: number;
  conversion_rate: number;
  avg_days_to_convert?: number;
}

export interface ConversionByAgent {
  agent_id: string;
  agent_name: string;
  agent_email: string;
  leads_assigned: number;
  converted: number;
  conversion_rate: number;
  total_deposits?: number;
}

export interface TransferBySuperAgent {
  super_agent_id: string;
  super_agent_name: string;
  super_agent_email: string;
  clients_received: number;
}

export interface ConversionMetrics {
  conversion_by_source?: ConversionByStatus[];
  conversion_by_status?: ConversionByStatus[];
  conversion_by_agent?: ConversionByAgent[];
  transfers_by_super_agent?: TransferBySuperAgent[];
  overall_conversion_rate: number;
  avg_time_to_conversion_days?: number;
  total_leads: number;
  total_converted: number;
  total_clients?: number;
}

export interface AgentDeposit {
  agent_id: string;
  agent_name: string;
  agent_email: string;
  deposits_count: number;
  total_amount: number;
  earnings: number;
}

export interface DepositsReportData {
  total_deposits: number;
  total_amount: number;
  deposits_by_agent: AgentDeposit[];
}

export type ReportType = 'sales' | 'pipeline' | 'activity' | 'conversion' | 'deposits' | 'team-deposits';
