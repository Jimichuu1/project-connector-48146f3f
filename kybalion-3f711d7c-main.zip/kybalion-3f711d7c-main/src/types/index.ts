/**
 * Main types barrel file - exports all application types
 */

// API Types
export type {
  ApiResponse,
  ApiError,
  PaginationParams,
  PaginatedResponse,
  EdgeFunctionResponse,
  DeleteUserResponse,
  PasswordResetResponse,
  BulkPasswordResetResponse,
  CallInitiateResponse,
  EmailSendResponse,
  FileUploadResponse,
} from "./api";

// Error Types
export type { AppError, SupabaseError, AuthError } from "./errors";
export { isErrorWithMessage, getErrorMessage } from "./errors";

// User Types
export type {
  UserProfile,
  UserWithRole,
  UserWithIpWhitelist,
  IpWhitelistEntry,
  SuperAgent,
  AssignedUser,
  UserSession,
  AppRole,
} from "./users";

// Report Types
export type {
  DateRange,
  ReportType,
  SalesMetrics,
  RevenueByUser,
  PipelineMetrics,
  DealsByStage,
  ConversionMetrics,
  ConversionByStatus,
  ActivityMetrics,
  AgentDeposit,
  DepositsReportData,
} from "./reports";

// Lead Types
export type {
  Lead,
  LeadStatus,
  LeadSource,
  LeadComment,
  LeadActivity,
} from "./leads";

// Client Types
export type {
  Client,
  ClientStatus,
  PipelineStatus,
  KYCStatus,
  ClientActivity,
  ClientComment,
  ClientTask,
  ClientWithdrawal,
} from "./clients";

// Notification Types
export type { Notification, NotificationType } from "./notifications";

// Document Types
export type { Document, DocumentType } from "./documents";

// Pipeline Types
export type { SaleBranch, SaleBranchWithClient, PipelineStage } from "./pipeline";
