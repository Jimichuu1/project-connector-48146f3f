/**
 * Type definitions for hook-related interfaces.
 * @module types/hooks
 */

import { Client, PipelineStatus } from "./clients";
import { Lead, LeadStatus } from "./leads";

/**
 * Lead filter options for useLeads hook
 */
export interface LeadFilters {
  search?: string;
  status?: LeadStatus;
  statuses?: LeadStatus[];
  source?: string;
  sources?: string[];
  assignedTo?: string;
  assignedToList?: string[];
  countries?: string[];
  groupId?: string;
  conversionProbMin?: number;
  conversionProbMax?: number;
  dateFrom?: Date;
  dateTo?: Date;
}

/**
 * Client filter options for useClients hook
 */
export interface ClientFilters {
  assignedTo?: string;
  search?: string;
  status?: string;
  statuses?: string[];
  countries?: string[];
}

/**
 * Mutation data for creating a lead
 */
export interface CreateLeadData {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  country?: string;
  source?: string;
  status?: LeadStatus;
  conversion_probability?: number;
  assigned_to?: string;
}

/**
 * Mutation data for updating a lead
 */
export interface UpdateLeadData {
  id: string;
  name?: string;
  email?: string;
  phone?: string;
  company?: string;
  country?: string;
  source?: string;
  status?: LeadStatus;
  conversion_probability?: number;
  assigned_to?: string;
  position?: number;
  balance?: number;
  equity?: number;
}

/**
 * Mutation data for creating a client
 */
export interface CreateClientData {
  name: string;
  email: string;
  home_phone?: string;
  country?: string;
  source?: string;
  status?: string;
  assigned_to?: string;
  balance?: number;
  equity?: number;
}

/**
 * Mutation data for updating a client
 */
export interface UpdateClientData {
  id: string;
  name?: string;
  email?: string;
  home_phone?: string;
  country?: string;
  status?: string;
  assigned_to?: string;
  balance?: number;
  equity?: number;
  pipeline_status?: PipelineStatus;
}

/**
 * Mutation data for lead conversion
 */
export interface ConvertLeadData {
  leadId: string;
  balance?: number;
  equity?: number;
  riskProfile?: 'LOW' | 'MEDIUM' | 'HIGH';
}

/**
 * Deposit filter options
 */
export interface DepositFilters {
  startDate?: Date;
  endDate?: Date;
  status?: string;
  agentId?: string;
  superAgentId?: string;
}

/**
 * KYC record creation data
 */
export interface CreateKYCRecordData {
  entityId: string;
  entityType: 'lead' | 'client';
  bankName?: string;
  notes?: string;
}

/**
 * KYC record update data
 */
export interface UpdateKYCRecordData {
  id: string;
  status?: 'VERIFIED' | 'PENDING' | 'REJECTED';
  bank_name?: string;
  notes?: string;
}

/**
 * Document upload data
 */
export interface UploadDocumentData {
  file: File;
  entityId: string;
  entityType: 'lead' | 'client';
  kycRecordId?: string;
}
