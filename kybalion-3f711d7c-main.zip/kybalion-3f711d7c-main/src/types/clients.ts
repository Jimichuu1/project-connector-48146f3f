import { LeadSource } from "./leads";

// ClientStatus is dynamic from database - use string type
export type ClientStatus = string;
export type PipelineStatus = 'PROSPECT' | 'QUALIFIED' | 'NEGOTIATION' | 'CLOSED_WON' | 'CLOSED_LOST';
export type WithdrawalStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'COMPLETED';
export type KYCStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';

export interface Client {
  id: string;
  name: string;
  email: string;
  country?: string;
  home_phone?: string;
  join_date: string;
  source?: LeadSource; // Now optional - removed from UI
  balance: number;
  equity: number;
  open_trades: number;
  deposits: number;
  status: ClientStatus;
  assigned_to?: string;
  pipeline_status: PipelineStatus;
  potential_value?: number;
  actual_value?: number;
  converted_from_lead_id?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  admin_id?: string;
  transferring_agent?: string;
  kyc_status?: KYCStatus;
  closer_agent_id?: string;
}

export interface ClientWithdrawal {
  id: string;
  client_id: string;
  amount: number;
  status: WithdrawalStatus;
  requested_at: string;
  approved_by?: string;
  approved_at?: string;
  rejection_reason?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface ClientActivity {
  id: string;
  client_id: string;
  user_id: string;
  activity_type: string;
  description: string;
  created_at: string;
}

export interface ClientTask {
  id: string;
  client_id: string;
  assigned_to: string;
  title: string;
  description?: string;
  due_date?: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export interface ClientComment {
  id: string;
  client_id: string;
  user_id: string;
  comment: string;
  created_at: string;
}