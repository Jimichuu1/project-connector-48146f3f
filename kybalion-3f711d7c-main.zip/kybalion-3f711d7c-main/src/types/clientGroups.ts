export interface ClientGroup {
  id: string;
  name: string;
  description: string | null;
  is_system: boolean;
  created_by: string | null;
  admin_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface ClientGroupMember {
  id: string;
  group_id: string;
  client_id: string;
  added_by: string | null;
  added_at: string;
}
