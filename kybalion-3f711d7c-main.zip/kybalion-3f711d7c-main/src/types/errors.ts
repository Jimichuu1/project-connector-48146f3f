/**
 * Type definitions for error handling.
 * Eliminates "any" types for error objects throughout the application.
 * @module types/errors
 */

/**
 * Standard error structure for API and database errors
 */
export interface AppError {
  message: string;
  code?: string;
  details?: string;
  hint?: string;
  statusCode?: number;
  originalError?: unknown;
}

/**
 * Supabase error structure
 */
export interface SupabaseError {
  message: string;
  details?: string;
  hint?: string;
  code?: string;
  status?: number;
}

/**
 * Auth error structure
 */
export interface AuthError {
  message: string;
  status?: number;
  code?: string;
}

/**
 * API response error type
 */
export interface ApiError {
  status: number;
  statusText: string;
  message: string;
  data?: unknown;
}

/**
 * API error response from edge functions
 */
export interface ApiErrorResponse {
  error: string;
  message?: string;
  code?: string;
  statusCode?: number;
  details?: Record<string, unknown>;
}

/**
 * Type guard to check if an unknown error has a message property
 * @param error - Unknown error to check
 * @returns True if error has a string message property
 */
export function isErrorWithMessage(error: unknown): error is { message: string } {
  return (
    typeof error === "object" &&
    error !== null &&
    "message" in error &&
    typeof (error as Record<string, unknown>).message === "string"
  );
}

/**
 * Type guard to check if an error is an Error instance
 */
export function isError(error: unknown): error is Error {
  return error instanceof Error;
}

/**
 * Type guard for Supabase errors
 */
export function isSupabaseError(error: unknown): error is SupabaseError {
  return (
    typeof error === 'object' &&
    error !== null &&
    'message' in error &&
    typeof (error as SupabaseError).message === 'string'
  );
}

/**
 * Type guard for API error responses
 */
export function isApiErrorResponse(error: unknown): error is ApiErrorResponse {
  return (
    typeof error === 'object' &&
    error !== null &&
    'error' in error &&
    typeof (error as ApiErrorResponse).error === 'string'
  );
}

/**
 * Parse any error into a consistent AppError format
 * Use this instead of catch(error: any)
 */
export function parseError(error: unknown): AppError {
  // Handle null/undefined
  if (error === null || error === undefined) {
    return {
      message: 'An unknown error occurred',
      code: 'UNKNOWN_ERROR',
    };
  }

  // Handle string errors
  if (typeof error === 'string') {
    return {
      message: error,
      code: 'STRING_ERROR',
      originalError: error,
    };
  }

  // Handle Supabase errors
  if (isSupabaseError(error)) {
    return {
      message: error.message,
      code: error.code || 'SUPABASE_ERROR',
      details: error.details,
      hint: error.hint,
      statusCode: error.status,
      originalError: error,
    };
  }

  // Handle API error responses
  if (isApiErrorResponse(error)) {
    return {
      message: error.message || error.error,
      code: error.code || 'API_ERROR',
      statusCode: error.statusCode,
      originalError: error,
    };
  }

  // Handle standard Error objects
  if (isError(error)) {
    return {
      message: error.message,
      code: error.name || 'ERROR',
      originalError: error,
    };
  }

  // Handle objects with message property
  if (isErrorWithMessage(error)) {
    return {
      message: error.message,
      code: 'OBJECT_ERROR',
      originalError: error,
    };
  }

  // Fallback for any other type
  return {
    message: 'An unexpected error occurred',
    code: 'UNEXPECTED_ERROR',
    originalError: error,
  };
}

/**
 * Safely extract error message from any error type.
 * Use this instead of `(error as any).message` pattern.
 * @param error - Unknown error to extract message from
 * @param fallback - Optional fallback message
 * @returns Error message string
 * @example
 * try { ... } catch (error) { toast.error(getErrorMessage(error)); }
 */
export function getErrorMessage(error: unknown, fallback = "An unexpected error occurred"): string {
  const parsed = parseError(error);
  return parsed.message || fallback;
}

/**
 * Creates a standardized error object
 * @param message - Error message
 * @param code - Optional error code
 * @param details - Optional error details
 */
export function createAppError(message: string, code?: string, details?: string): AppError {
  return { message, code, details };
}

/**
 * Log error with structured format for debugging
 * @param context - Where the error occurred
 * @param error - The error object
 * @param additionalData - Extra context data
 */
export function logError(context: string, error: unknown, additionalData?: Record<string, unknown>): void {
  const parsed = parseError(error);
  console.error(`[${context}]`, {
    message: parsed.message,
    code: parsed.code,
    details: parsed.details,
    ...additionalData,
    timestamp: new Date().toISOString(),
  });
}
