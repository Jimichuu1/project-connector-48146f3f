export type PipelineStage = 
  | 'UPCOMING_SALE'
  | 'STUCK'
  | 'FLIPPED'
  | 'DEPOSIT';

export interface SaleBranch {
  id: string;
  client_id: string;
  name: string;
  status: PipelineStage;
  value: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface SaleBranchWithClient extends SaleBranch {
  client?: {
    id: string;
    name: string;
    email?: string | null;
    assigned_to?: string;
    assigned_user?: {
      id: string;
      full_name: string | null;
      avatar_url: string | null;
    };
  };
  // Deposit attribution
  deposit_status?: 'pending' | 'approved' | 'rejected' | null;
  deposit_rejection_reason?: string | null;
  deposit_id?: string | null;
  deposit_agent_id?: string | null;
  deposit_super_agent_id?: string | null;
  agent?: {
    full_name: string | null;
    email: string | null;
  } | null;
  super_agent?: {
    full_name: string | null;
    email: string | null;
  } | null;
  // Flipped attribution
  flipped_record_id?: string | null;
  flipped_agent_id?: string | null;
  flipped_super_agent_id?: string | null;
  flipped_agent?: {
    full_name: string | null;
    email: string | null;
  } | null;
  flipped_super_agent?: {
    full_name: string | null;
    email: string | null;
  } | null;
  flipped_at?: string | null;
  flipped_by?: string | null;
  flipped_reason?: string | null;
  // True when the current viewer (a Super Agent) is seeing this card only
  // because of historical deposit attribution (the client is no longer
  // assigned to them). Card should be read-only.
  is_historical_for_viewer?: boolean;
}

export const PIPELINE_STAGES: { value: PipelineStage; label: string; color: string }[] = [
  { value: 'UPCOMING_SALE', label: 'Upcoming Sale', color: 'bg-emerald-600' },
  { value: 'STUCK', label: 'Stuck', color: 'bg-amber-600' },
  { value: 'FLIPPED', label: 'Flipped', color: 'bg-purple-600' },
  { value: 'DEPOSIT', label: 'Deposit', color: 'bg-green-600' },
];
