/**
 * Type definitions for user-related data structures.
 */

import { Enums } from "@/integrations/supabase/types";

export type AppRole = Enums<"app_role">;

export interface UserProfile {
  id: string;
  email: string;
  username: string | null;
  full_name: string | null;
  is_closer?: boolean | null;
  avatar_url?: string | null;
  created_at: string;
  updated_at?: string;
  admin_id?: string | null;
  created_by?: string | null;
}

export interface UserWithRole extends UserProfile {
  role?: AppRole;
}

export interface UserWithIpWhitelist extends UserWithRole {
  ip_whitelist?: IpWhitelistEntry[];
  tenant_name?: string | null;
  created_by_name?: string | null;
}

export interface IpWhitelistEntry {
  id: string;
  ip_address: string;
  is_active: boolean;
}

export interface SuperAgent {
  user_id: string;
  profiles: {
    id: string;
    full_name: string | null;
    email: string;
    avatar_url?: string | null;
  };
  role?: AppRole;
}

export interface AssignedUser {
  id: string;
  full_name: string | null;
  email: string;
  avatar_url: string | null;
}

export interface UserSession {
  id: string;
  user_id: string;
  session_token: string;
  ip_address: string | null;
  user_agent: string | null;
  is_active: boolean;
  created_at: string;
  last_activity: string;
  expires_at: string;
}
