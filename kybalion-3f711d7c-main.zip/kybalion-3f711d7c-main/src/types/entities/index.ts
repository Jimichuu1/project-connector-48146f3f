/**
 * Entity types barrel file - exports all domain entity types
 */

// Re-export from existing type files
export type { Lead, LeadStatus, LeadSource, LeadComment, LeadActivity } from "../leads";
export type { Client, ClientStatus, PipelineStatus, KYCStatus, ClientActivity, ClientComment, ClientTask, ClientWithdrawal } from "../clients";
export type { 
  DateRange, 
  ReportType, 
  SalesMetrics, 
  RevenueByUser, 
  PipelineMetrics, 
  DealsByStage, 
  ConversionMetrics, 
  ConversionByStatus, 
  ActivityMetrics, 
  AgentDeposit, 
  DepositsReportData 
} from "../reports";
export type { 
  UserProfile, 
  UserWithRole, 
  UserWithIpWhitelist, 
  IpWhitelistEntry, 
  SuperAgent, 
  AssignedUser, 
  UserSession, 
  AppRole 
} from "../users";
export type { AppError, SupabaseError, AuthError } from "../errors";
