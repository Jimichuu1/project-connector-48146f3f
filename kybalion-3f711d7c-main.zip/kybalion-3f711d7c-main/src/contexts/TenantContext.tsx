import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useUserData } from "@/contexts/UserDataContext";

interface Tenant {
  id: string;
  full_name: string;
}

interface TenantContextType {
  tenants: Tenant[];
  selectedTenantId: string | null;
  setSelectedTenantId: (id: string | null) => void;
  isSuperAdmin: boolean;
  isTenantOwner: boolean;
  loading: boolean;
  selectedTenantName: string | null;
  effectiveTenantId: string | null | undefined; // undefined = loading, null = SUPER_ADMIN sees all, string = specific tenant
  error: string | null;
  refetch: () => void;
}

const TenantContext = createContext<TenantContextType>({
  tenants: [],
  selectedTenantId: null,
  setSelectedTenantId: () => {},
  isSuperAdmin: false,
  isTenantOwner: false,
  loading: true,
  selectedTenantName: null,
  effectiveTenantId: null,
  error: null,
  refetch: () => {},
});

export function TenantProvider({ children }: { children: ReactNode }) {
  // Use centralized user data instead of separate queries
  const { 
    isSuperAdmin, 
    isTenantOwner, 
    adminId,
    profile,
    loading: userDataLoading 
  } = useUserData();
  
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [selectedTenantId, setSelectedTenantId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [fetchKey, setFetchKey] = useState(0);

  const refetch = useCallback(() => {
    setFetchKey(prev => prev + 1);
  }, []);

  // Determine userTenantId from centralized data
  // TENANT_OWNER: their own ID (from profile)
  // Others: their admin_id
  const userTenantId = isTenantOwner ? profile?.id ?? null : adminId;

  useEffect(() => {
    const fetchTenants = async () => {
      // Wait for user data to load
      if (userDataLoading) {
        return;
      }

      // If not super admin, no need to fetch tenants list
      if (!isSuperAdmin) {
        setTenants([]);
        setLoading(false);
        return;
      }

      setError(null);

      try {
        // Fetch all TENANT_OWNER users as tenants for SUPER_ADMIN
        const { data: adminRoles, error: adminError } = await supabase
          .from("user_roles")
          .select("user_id")
          .eq("role", "TENANT_OWNER");

        if (adminError) throw adminError;

        if (adminRoles && adminRoles.length > 0) {
          const adminIds = adminRoles.map(r => r.user_id);
          
          const { data: profiles, error: profilesError } = await supabase
            .from("profiles")
            .select("id, full_name")
            .in("id", adminIds);

          if (profilesError) throw profilesError;

          if (profiles) {
            setTenants(profiles.map(p => ({
              id: p.id,
              full_name: p.full_name || "Unknown Admin"
            })));
          }
        }
      } catch (err) {
        console.error("Error fetching tenants:", err);
        const errorMessage = err instanceof Error ? err.message : "Failed to load tenant data";
        setError(errorMessage);
        setTenants([]);
      } finally {
        setLoading(false);
      }
    };

    fetchTenants();
  }, [isSuperAdmin, userDataLoading, fetchKey]);

  // Only refetch on explicit sign in (not token refresh)
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN') {
        refetch();
      }
    });

    return () => subscription.unsubscribe();
  }, [refetch]);

  const selectedTenantName = selectedTenantId 
    ? tenants.find(t => t.id === selectedTenantId)?.full_name || null
    : null;

  // Calculate effective tenant ID for data filtering
  // SUPER_ADMIN: uses selected tenant or null (sees all)
  // TENANT_OWNER: always uses their own user.id as tenant
  // Others (MANAGER, SUPER_AGENT, AGENT): use admin_id from their profile
  // During loading, return undefined to signal "not ready yet"
  const isStillLoading = loading || userDataLoading;
  const effectiveTenantId = isStillLoading 
    ? undefined 
    : isSuperAdmin 
      ? selectedTenantId 
      : userTenantId;

  return (
    <TenantContext.Provider value={{
      tenants,
      selectedTenantId,
      setSelectedTenantId,
      isSuperAdmin,
      isTenantOwner,
      loading,
      selectedTenantName,
      effectiveTenantId,
      error,
      refetch,
    }}>
      {children}
    </TenantContext.Provider>
  );
}

export function useTenant() {
  return useContext(TenantContext);
}
