import { createContext, useContext, ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  last_name: string | null;
  username: string | null;
  avatar_url: string | null;
  admin_id: string | null;
  created_by: string | null;
}

interface UserSettings {
  show_phone_to_agents: boolean;
  show_phone_to_super_agents: boolean;
  work_start_time: string | null;
  work_end_time: string | null;
  max_break_minutes: number | null;
}

interface UserData {
  profile: UserProfile | null;
  role: string | null;
  adminId: string | null;
  settings: UserSettings;
  isSuperAdmin: boolean;
  isTenantOwner: boolean;
  isManager: boolean;
  isTeamLeader: boolean;
  isSuperAgent: boolean;
  isAgent: boolean;
  hasSuperAdminAccess: boolean;
  hasTenantOwnerAccess: boolean;
  hasManagerAccess: boolean;
  hasTeamLeaderAccess: boolean;
  hasSuperAgentAccess: boolean;
  canViewPhone: boolean;
  /** @deprecated Email integrations removed. Always true for admins/managers, true for others. Kept for back-compat. */
  canViewEmail: boolean;
}

interface UserDataContextType extends UserData {
  loading: boolean;
  error: Error | null;
  refetch: () => void;
}

const defaultSettings: UserSettings = {
  show_phone_to_agents: false,
  show_phone_to_super_agents: true,
  work_start_time: null,
  work_end_time: null,
  max_break_minutes: null,
};

const defaultUserData: UserData = {
  profile: null,
  role: null,
  adminId: null,
  settings: defaultSettings,
  isSuperAdmin: false,
  isTenantOwner: false,
  isManager: false,
  isTeamLeader: false,
  isSuperAgent: false,
  isAgent: false,
  hasSuperAdminAccess: false,
  hasTenantOwnerAccess: false,
  hasManagerAccess: false,
  hasTeamLeaderAccess: false,
  hasSuperAgentAccess: false,
  canViewPhone: false,
  canViewEmail: true,
};

const UserDataContext = createContext<UserDataContextType>({
  ...defaultUserData,
  loading: true,
  error: null,
  refetch: () => {},
});

export function UserDataProvider({ children }: { children: ReactNode }) {
  const { session } = useAuth();
  const userId = session?.user?.id;

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["user-data", userId],
    queryFn: async () => {
      if (!userId) return null;

      const { data, error } = await supabase.rpc("get_user_data", {
        p_user_id: userId,
      });

      if (error) throw error;
      return data;
    },
    enabled: !!userId,
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
  });

  const userData = computeUserData(data);

  const contextValue: UserDataContextType = {
    ...userData,
    loading: isLoading,
    error: error as Error | null,
    refetch,
  };

  return (
    <UserDataContext.Provider value={contextValue}>
      {children}
    </UserDataContext.Provider>
  );
}

function computeUserData(data: unknown): UserData {
  if (!data || typeof data !== "object") {
    return defaultUserData;
  }

  const rawData = data as Record<string, unknown>;

  const profile = rawData.profile as UserProfile | null;
  const role = (rawData.role as string) || null;
  const adminId = (rawData.admin_id as string) || null;
  const rawSettings = (rawData.settings as Record<string, unknown>) || {};

  const settings: UserSettings = {
    show_phone_to_agents: Boolean(rawSettings.show_phone_to_agents),
    show_phone_to_super_agents: rawSettings.show_phone_to_super_agents !== false,
    work_start_time: (rawSettings.work_start_time as string) || null,
    work_end_time: (rawSettings.work_end_time as string) || null,
    max_break_minutes: (rawSettings.max_break_minutes as number) || null,
  };

  const isSuperAdmin = Boolean(rawData.is_super_admin);
  const isTenantOwner = Boolean(rawData.is_tenant_owner);
  const isManager = Boolean(rawData.is_manager);
  const isTeamLeader = Boolean(rawData.is_team_leader);
  const isSuperAgent = Boolean(rawData.is_super_agent);
  const isAgent = Boolean(rawData.is_agent);

  const hasSuperAdminAccess = isSuperAdmin;
  const hasTenantOwnerAccess = isSuperAdmin || isTenantOwner;
  const hasManagerAccess = isSuperAdmin || isTenantOwner || isManager;
  const hasTeamLeaderAccess = isSuperAdmin || isTenantOwner || isManager || isTeamLeader;
  const hasSuperAgentAccess = isSuperAdmin || isTenantOwner || isManager || isTeamLeader || isSuperAgent;

  const canViewPhone = computeCanViewPhone(
    isSuperAdmin,
    isTenantOwner,
    isManager,
    isTeamLeader,
    isSuperAgent,
    isAgent,
    settings
  );

  // Email integrations removed — emails are visible to everyone now.
  const canViewEmail = true;

  return {
    profile,
    role,
    adminId,
    settings,
    isSuperAdmin,
    isTenantOwner,
    isManager,
    isTeamLeader,
    isSuperAgent,
    isAgent,
    hasSuperAdminAccess,
    hasTenantOwnerAccess,
    hasManagerAccess,
    hasTeamLeaderAccess,
    hasSuperAgentAccess,
    canViewPhone,
    canViewEmail,
  };
}

function computeCanViewPhone(
  isSuperAdmin: boolean,
  isTenantOwner: boolean,
  isManager: boolean,
  isTeamLeader: boolean,
  isSuperAgent: boolean,
  isAgent: boolean,
  settings: UserSettings
): boolean {
  if (isSuperAdmin || isTenantOwner || isManager || isTeamLeader) return true;
  if (isSuperAgent) return settings.show_phone_to_super_agents;
  if (isAgent) return settings.show_phone_to_agents;
  return false;
}

export function useUserData() {
  const context = useContext(UserDataContext);
  if (!context) {
    throw new Error("useUserData must be used within a UserDataProvider");
  }
  return context;
}
