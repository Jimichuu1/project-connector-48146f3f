import { createContext, useContext, useEffect, useState, ReactNode, useCallback, useRef } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getErrorMessage } from "@/types/errors";
import { setUser as setSentryUser, addBreadcrumb } from "@/lib/sentry";
import { queryClient } from "@/lib/queryClient";
// Rate limiting constants
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;
const SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes (for non-remembered sessions)
const REMEMBERED_SESSION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days (for remembered sessions)
const LAST_ACTIVITY_STORAGE_KEY = 'auth:lastActivity';
const ACTIVITY_SYNC_THROTTLE_MS = 15 * 1000;

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signIn: (username: string, password: string, rememberMe: boolean, captchaToken?: string) => Promise<{ error: Error | null; needsCaptcha?: boolean; isBlocked?: boolean; attemptsRemaining?: number; ipBlocked?: boolean }>;
  signOut: () => Promise<void>;
  logoutAllDevices: () => Promise<void>;
  requireReAuth: (callback: () => void, reason: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

// Hash token for secure storage
const hashToken = async (token: string): Promise<string> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(token);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [reAuthCallback, setReAuthCallback] = useState<{ fn: () => void; reason: string } | null>(null);
  const rememberMeRef = useRef<boolean>(localStorage.getItem('rememberMe') === 'true');
  const { toast } = useToast();

  // Get client IP address (with 3s timeout to avoid blocking auth)
  const getClientIp = async (): Promise<string> => {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 3000);
      try {
        const response = await fetch('https://api.ipify.org?format=json', { signal: controller.signal });
        const data = await response.json();
        return data.ip || 'unknown';
      } finally {
        clearTimeout(timer);
      }
    } catch {
      return 'unknown';
    }
  };

  // Use a ref for lastActivity to avoid re-creating the interval on every interaction
  const lastActivityRef = useRef(Date.now());
  const lastActivityWriteRef = useRef(0);

  const readSharedLastActivity = useCallback(() => {
    try {
      const storedValue = localStorage.getItem(LAST_ACTIVITY_STORAGE_KEY);
      const parsedValue = storedValue ? Number(storedValue) : NaN;

      if (Number.isFinite(parsedValue) && parsedValue > 0) {
        return parsedValue;
      }
    } catch {
      // ignore storage read failures
    }

    return Date.now();
  }, []);

  const syncLastActivity = useCallback((timestamp = Date.now(), force = false) => {
    lastActivityRef.current = timestamp;

    if (!force && timestamp - lastActivityWriteRef.current < ACTIVITY_SYNC_THROTTLE_MS) {
      return;
    }

    lastActivityWriteRef.current = timestamp;

    try {
      localStorage.setItem(LAST_ACTIVITY_STORAGE_KEY, String(timestamp));
    } catch {
      // ignore storage write failures
    }
  }, []);

  const clearLastActivity = useCallback(() => {
    lastActivityRef.current = Date.now();
    lastActivityWriteRef.current = 0;

    try {
      localStorage.removeItem(LAST_ACTIVITY_STORAGE_KEY);
    } catch {
      // ignore storage cleanup failures
    }
  }, []);

  // Update last activity timestamp
  const updateActivity = useCallback(() => {
    syncLastActivity(Date.now());
  }, [syncLastActivity]);

  // Inactivity logout removed — sessions persist until explicit sign-out

  useEffect(() => {
    let lastTokenRefreshTime = 0;
    const TOKEN_REFRESH_DEBOUNCE = 2000; // 2 seconds

    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        // Debounce TOKEN_REFRESHED events to prevent cascade
        if (event === 'TOKEN_REFRESHED') {
          const now = Date.now();
          if (now - lastTokenRefreshTime < TOKEN_REFRESH_DEBOUNCE) {
            return; // Skip rapid successive token refresh events
          }
          lastTokenRefreshTime = now;
        }

        setSession(session);
        setUser(session?.user ?? null);
        
        // Update Sentry user context
        if (session?.user) {
          setSentryUser({
            id: session.user.id,
            email: session.user.email,
            username: session.user.user_metadata?.username,
          });
          addBreadcrumb(`User ${event}`, 'auth', 'info', { userId: session.user.id });
        } else {
          setSentryUser(null);
          addBreadcrumb('User signed out', 'auth', 'info');
        }
        
        if (event === 'SIGNED_IN') {
          syncLastActivity(Date.now(), true);
          // Defer any additional data fetching
          setTimeout(() => {
            setLoading(false);
          }, 0);
        } else if (event === 'INITIAL_SESSION' || event === 'TOKEN_REFRESHED') {
          syncLastActivity(readSharedLastActivity(), true);
        } else if (event === 'SIGNED_OUT') {
          // Clear any corrupted tokens from localStorage
          try {
            const storageKey = `sb-lahchwagkhwypecmjojj-auth-token`;
            localStorage.removeItem(storageKey);
          } catch {
            // ignore
          }
          rememberMeRef.current = false;
          clearLastActivity();
          setLoading(false);
        }
      }
    );

    // THEN check for existing session
    // Let the SDK handle token refresh via autoRefreshToken — do NOT manually
    // call refreshSession() here as it races with the SDK's own refresh logic
    // and causes "Refresh Token Not Found" errors.
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session) {
        setSession(session);
        setUser(session.user ?? null);
        if (session.user) {
          setSentryUser({
            id: session.user.id,
            email: session.user.email,
            username: session.user.user_metadata?.username,
          });
        }
      } else {
        setSession(null);
        setUser(null);
      }
      
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [clearLastActivity, readSharedLastActivity, syncLastActivity]);

  const signIn = async (usernameOrEmail: string, password: string, rememberMe: boolean, captchaToken?: string) => {
    try {
      const ipAddress = await getClientIp();

      // Check if IP is blocked
      const { data: isBlocked } = await supabase.rpc('is_ip_blocked', { 
        p_ip_address: ipAddress 
      });

      if (isBlocked) {
        toast({
          title: "Access Blocked",
          description: `Too many failed attempts. Please try again in ${LOCKOUT_MINUTES} minutes.`,
          variant: "destructive",
        });
        return { error: new Error("IP blocked"), isBlocked: true };
      }

      // Count recent failed attempts
      const { data: failedCount } = await supabase.rpc('count_failed_attempts', {
        p_ip_address: ipAddress,
        p_minutes: LOCKOUT_MINUTES,
      });

      const attempts = failedCount || 0;
      const needsCaptcha = attempts >= 2;

      // Require CAPTCHA after 2 failed attempts
      if (needsCaptcha && !captchaToken) {
        return { 
          error: new Error("CAPTCHA required"), 
          needsCaptcha: true,
          attemptsRemaining: MAX_LOGIN_ATTEMPTS - attempts,
        };
      }

      // Determine if input is email or username
      const isEmail = usernameOrEmail.includes('@');
      let email: string;

      if (isEmail) {
        email = usernameOrEmail;
      } else {
        // Resolve username -> email via narrow RPC (does not expose any other profile data).
        const { data: resolvedEmail, error: profileError } = await supabase
          .rpc("lookup_email_by_username", { p_username: usernameOrEmail });

        if (profileError || !resolvedEmail) {
          const userAgent = navigator.userAgent;
          const { error: usernameAttemptError } = await supabase.from("auth_attempts").insert({
            ip_address: ipAddress,
            user_email: usernameOrEmail,
            attempt_type: 'login',
            success: false,
            failure_reason: "Username not found",
            user_agent: userAgent,
          });
          if (usernameAttemptError) {
            console.warn("Failed to log username lookup failure", usernameAttemptError);
          }
          
          toast({
            title: "Sign in failed",
            description: "Invalid username or password",
            variant: "destructive",
          });
          return { error: new Error("Invalid credentials"), attemptsRemaining: MAX_LOGIN_ATTEMPTS - attempts - 1 };
        }

        email = resolvedEmail as string;
      }

      // Attempt sign in with email
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      const userAgent = navigator.userAgent;

      // Record attempt (non-blocking)
      const { error: authAttemptError } = await supabase.from("auth_attempts").insert({
        ip_address: ipAddress,
        user_email: usernameOrEmail,
        attempt_type: 'login',
        success: !error,
        failure_reason: error?.message,
        user_agent: userAgent,
        blocked_until: (!error || attempts < MAX_LOGIN_ATTEMPTS - 1) 
          ? null 
          : new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000).toISOString(),
      });
      if (authAttemptError) {
        console.warn("Failed to log auth attempt", authAttemptError);
      }

      if (error) {
        const remaining = MAX_LOGIN_ATTEMPTS - attempts - 1;
        
        toast({
          title: "Sign in failed",
          description: remaining > 0 
            ? `${error.message}. ${remaining} attempt${remaining !== 1 ? 's' : ''} remaining.`
            : `Too many failed attempts. Account locked for ${LOCKOUT_MINUTES} minutes.`,
          variant: "destructive",
        });

        return { 
          error, 
          needsCaptcha: attempts + 1 >= 2,
          attemptsRemaining: remaining,
          isBlocked: remaining <= 0,
        };
      }

      // Check IP whitelist for the authenticated user
      if (data.user) {
        if (ipAddress === 'unknown') {
          console.warn('Skipping sign-in IP whitelist check because client IP could not be determined');
        } else {
          const { data: isWhitelisted, error: whitelistError } = await supabase.rpc('check_ip_whitelist', {
            p_user_id: data.user.id,
            p_ip_address: ipAddress,
          });

          if (whitelistError) {
            console.warn('IP whitelist check failed during sign-in, preserving session', whitelistError);
          } else if (isWhitelisted === false) {
            await supabase.auth.signOut();

          // Log the failed attempt due to IP restriction (non-blocking)
            const { error: blockedIpAuditError } = await supabase.from("audit_logs").insert({
              user_id: data.user.id,
              action_type: 'login_blocked_ip',
              ip_address: ipAddress,
              user_agent: userAgent,
              details: { reason: 'IP not in whitelist' },
            });
            if (blockedIpAuditError) {
              console.warn("Failed to log blocked IP login", blockedIpAuditError);
            }

            toast({
              title: "Access Denied",
              description: "Your IP address is not authorized to access this account.",
              variant: "destructive",
            });
            return { error: new Error("IP not whitelisted"), ipBlocked: true };
          }
        }
      }

      // Store remember me preference FIRST (before creating session)
      if (rememberMe) {
        localStorage.setItem('rememberMe', 'true');
        rememberMeRef.current = true;
      } else {
        localStorage.removeItem('rememberMe');
        rememberMeRef.current = false;
      }

      syncLastActivity(Date.now(), true);

      // Success - clean up old sessions and create new session record
      if (data.session) {
        // Clean up old sessions to prevent accumulation (non-blocking)
        try {
          await supabase.rpc('cleanup_user_sessions_on_login', { p_user_id: data.user.id });
        } catch (cleanupErr) {
          console.warn("Failed to cleanup old sessions", cleanupErr);
        }
        const sessionDuration = rememberMe ? REMEMBERED_SESSION_MS : SESSION_TIMEOUT_MS;
        const refreshTokenHash = data.session.refresh_token 
          ? await hashToken(data.session.refresh_token) 
          : null;

        // Create a new session for this device (allow multiple concurrent sessions)
        const { error: userSessionError } = await supabase.from("user_sessions").insert({
          user_id: data.user.id,
          session_token: data.session.access_token,
          refresh_token_hash: refreshTokenHash,
          ip_address: ipAddress,
          user_agent: userAgent,
          expires_at: new Date(Date.now() + sessionDuration).toISOString(),
          is_active: true,
        });
        if (userSessionError) {
          console.warn("Failed to persist user session", userSessionError);
        }

        // Log successful login
        const { error: loginAuditError } = await supabase.from("audit_logs").insert({
          user_id: data.user.id,
          action_type: 'login_success',
          ip_address: ipAddress,
          user_agent: userAgent,
          details: { remember_me: rememberMe },
        });
        if (loginAuditError) {
          console.warn("Failed to log login_success audit event", loginAuditError);
        }
      }

      // Prefetch user data immediately so it's ready when navigating
      if (data.user) {
        queryClient.prefetchQuery({
          queryKey: ["user-data", data.user.id],
          queryFn: async () => {
            const { data: userData, error: userError } = await supabase.rpc("get_user_data", {
              p_user_id: data.user!.id,
            });
            if (userError) throw userError;
            return userData;
          },
        });
      }

      toast({
        title: "Welcome back!",
        description: "You've successfully signed in.",
      });

      return { error: null };
    } catch (error: unknown) {
      return { error: new Error(getErrorMessage(error)) };
    }
  };


  const signOut = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // Deactivate only the current session, not all sessions
      if (user && session?.access_token) {
        await supabase
          .from("user_sessions")
          .update({ is_active: false })
          .eq("user_id", user.id)
          .eq("session_token", session.access_token);

        // Log logout
        const ipAddress = await getClientIp();
        await supabase.from("audit_logs").insert({
          user_id: user.id,
          action_type: 'logout',
          ip_address: ipAddress,
        });
      }

      await supabase.auth.signOut();
      localStorage.removeItem('rememberMe');
      rememberMeRef.current = false;
      clearLastActivity();
      
      toast({
        title: "Signed out",
        description: "You've been successfully signed out.",
      });
    } catch (error: unknown) {
      toast({
        title: "Sign out failed",
        description: getErrorMessage(error),
        variant: "destructive",
      });
    }
  };

  const logoutAllDevices = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Deactivate all sessions
      await supabase
        .from("user_sessions")
        .update({ is_active: false })
        .eq("user_id", user.id);

      // Log the action
      const ipAddress = await getClientIp();
      await supabase.from("audit_logs").insert({
        user_id: user.id,
        action_type: 'logout_all_devices',
        ip_address: ipAddress,
      });

      // Sign out
      await supabase.auth.signOut();
      localStorage.removeItem('rememberMe');
      rememberMeRef.current = false;
      clearLastActivity();
      
      toast({
        title: "Logged out from all devices",
        description: "You've been signed out from all your active sessions.",
      });
    } catch (error: unknown) {
      toast({
        title: "Logout all devices failed",
        description: getErrorMessage(error),
        variant: "destructive",
      });
    }
  };

  const requireReAuth = useCallback((callback: () => void, reason: string) => {
    setReAuthCallback({ fn: callback, reason });
  }, []);

  return (
    <AuthContext.Provider value={{ user, session, loading, signIn, signOut, logoutAllDevices, requireReAuth }}>
      {children}
    </AuthContext.Provider>
  );
};
