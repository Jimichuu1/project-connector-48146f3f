import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Monitor, 
  Smartphone, 
  Globe, 
  Clock, 
  Shield
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface UserSession {
  id: string;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
  last_activity: string;
  is_active: boolean;
  expires_at: string;
  session_token: string;
}

const parseUserAgent = (userAgent: string | null) => {
  if (!userAgent) return { device: "Unknown", browser: "Unknown", os: "Unknown" };
  
  const isMobile = /Mobile|Android|iPhone|iPad/i.test(userAgent);
  const isTablet = /iPad|Tablet/i.test(userAgent);
  
  let browser = "Unknown";
  if (userAgent.includes("Chrome")) browser = "Chrome";
  else if (userAgent.includes("Firefox")) browser = "Firefox";
  else if (userAgent.includes("Safari")) browser = "Safari";
  else if (userAgent.includes("Edge")) browser = "Edge";
  
  let os = "Unknown";
  if (userAgent.includes("Windows")) os = "Windows";
  else if (userAgent.includes("Mac")) os = "macOS";
  else if (userAgent.includes("Linux")) os = "Linux";
  else if (userAgent.includes("Android")) os = "Android";
  else if (userAgent.includes("iPhone") || userAgent.includes("iPad")) os = "iOS";
  
  return {
    device: isTablet ? "Tablet" : isMobile ? "Mobile" : "Desktop",
    browser,
    os,
  };
};

const DeviceIcon = ({ device }: { device: string }) => {
  if (device === "Mobile") return <Smartphone className="h-5 w-5" />;
  return <Monitor className="h-5 w-5" />;
};

export function SessionManagement() {
  const { user } = useAuth();

  const { data: currentSession, isLoading } = useQuery({
    queryKey: ['user-current-session', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('user_sessions')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (error) throw error;
      return data as UserSession | null;
    },
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Current Session</CardTitle>
          <CardDescription>Your active login session</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 p-4 border rounded-lg">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-48" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { device, browser, os } = parseUserAgent(currentSession?.user_agent ?? null);

  return (
    <Card>
      <CardHeader>
        <div>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Current Session
          </CardTitle>
          <CardDescription>
            Your active login session
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        {!currentSession ? (
          <p className="text-muted-foreground text-center py-4">
            No active session found
          </p>
        ) : (
          <div className="flex items-center gap-4 p-4 border rounded-lg border-primary bg-primary/5">
            <div className="p-2 rounded-full bg-primary/10 text-primary">
              <DeviceIcon device={device} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium truncate">
                  {browser} on {os}
                </span>
                <Badge variant="default" className="text-xs">
                  Current
                </Badge>
              </div>
              
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                <span className="flex items-center gap-1">
                  <Globe className="h-3 w-3" />
                  {currentSession.ip_address || "Unknown IP"}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Active {formatDistanceToNow(new Date(currentSession.last_activity || currentSession.created_at), { addSuffix: true })}
                </span>
              </div>
              
              <div className="text-xs text-muted-foreground mt-1">
                Signed in {formatDistanceToNow(new Date(currentSession.created_at), { addSuffix: true })}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
