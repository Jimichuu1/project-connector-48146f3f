import { Button } from "@/components/ui/button";
import { Calendar, Plus, CheckCircle2, Circle, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect, useRef } from "react";
import { useReminders } from "@/hooks/useReminders";
import { CreateReminderDialog } from "@/components/reminders/CreateReminderDialog";
import { format, formatDistanceToNow } from "date-fns";
import confetti from "canvas-confetti";

interface ReminderSidebarProps {
  collapsed: boolean;
}

interface ReminderItem {
  id: string;
  title: string;
  description?: string | null;
  due_date: string;
  priority: string;
  completed: boolean;
}

export const ReminderSidebar = ({ collapsed }: ReminderSidebarProps) => {
  const { reminders, pendingCount, toggleComplete, deleteReminder } = useReminders();
  const [dialogOpen, setDialogOpen] = useState(false);
  const prevPendingCountRef = useRef(pendingCount);

  useEffect(() => {
    if (
      reminders.length > 0 &&
      pendingCount === 0 &&
      prevPendingCountRef.current > 0
    ) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6, x: 0.9 },
        colors: ["#8b5cf6", "#a78bfa", "#c4b5fd"],
      });
    }
    prevPendingCountRef.current = pendingCount;
  }, [pendingCount, reminders.length]);

  const getDisplayTime = (reminder: ReminderItem) => {
    const dueDate = new Date(reminder.due_date);
    const now = new Date();
    const isPast = dueDate < now;
    const distance = formatDistanceToNow(dueDate, { addSuffix: true });
    
    return (
      <span className={`text-xs ${isPast ? "text-destructive" : "text-muted-foreground"}`}>
        {format(dueDate, "MMM d, h:mm a")} ({distance})
      </span>
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "call_back": return "bg-blue-500 text-white";
      case "send_email": return "bg-amber-500 text-white";
      case "deposit_arrived": return "bg-green-500 text-white";
      case "money_in": return "bg-emerald-600 text-white";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "call_back": return "Call back";
      case "send_email": return "Send email";
      case "deposit_arrived": return "Deposit Arrived";
      case "money_in": return "Money in";
      default: return status;
    }
  };

  const sortedReminders = [...reminders].sort((a, b) => {
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
  });

  return (
    <>
      <aside 
        className={`border-l border-border/30 transition-all duration-300 ease-in-out flex-shrink-0 h-full flex flex-col bg-sidebar ${
          collapsed ? "w-0 opacity-0 overflow-hidden" : "w-80 opacity-100"
        }`}
      >
        {/* Header */}
        <div className="flex flex-row items-center justify-between px-4 h-16 border-b border-border/30 flex-shrink-0">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            <h2 className="font-semibold">Reminders</h2>
          </div>
          <Button size="icon" variant="ghost" onClick={() => setDialogOpen(true)}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <div className="p-4 space-y-3">
            {sortedReminders.map((reminder, index) => (
              <div
                key={reminder.id}
                className={`flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent transition-all duration-300 animate-in fade-in slide-in-from-right ${
                  reminder.completed ? "opacity-60 scale-[0.98]" : "opacity-100 scale-100"
                }`}
                style={{
                  animationDelay: `${index * 50}ms`,
                  animationFillMode: "backwards"
                }}
              >
                <button
                  onClick={() => toggleComplete.mutate(reminder.id)}
                  className="mt-0.5 flex-shrink-0"
                >
                  {reminder.completed ? (
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                  ) : (
                    <Circle className="h-5 w-5 text-muted-foreground" />
                  )}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className={`text-sm font-medium ${reminder.completed ? "line-through text-muted-foreground" : ""}`}>
                      {reminder.title}
                    </p>
                    <Badge className={`text-[10px] px-1.5 py-0 ${getStatusColor(reminder.priority)}`}>
                      {getStatusLabel(reminder.priority)}
                    </Badge>
                  </div>
                  {reminder.description && (
                    <p className="text-xs text-muted-foreground mb-1 line-clamp-2">
                      {reminder.description}
                    </p>
                  )}
                  {getDisplayTime(reminder)}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 flex-shrink-0"
                  onClick={() => deleteReminder.mutate(reminder.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
            {reminders.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="text-sm">No reminders yet</p>
                <p className="text-xs mt-1">Click + to add your first reminder</p>
              </div>
            )}
          </div>
        </div>
      </aside>
      <CreateReminderDialog open={dialogOpen} onOpenChange={setDialogOpen} />
    </>
  );
};
