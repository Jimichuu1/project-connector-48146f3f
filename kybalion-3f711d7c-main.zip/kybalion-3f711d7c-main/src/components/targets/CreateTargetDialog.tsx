import { useEffect, useState, useMemo } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalendarIcon, X, ChevronsUpDown } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useUserData } from "@/contexts/UserDataContext";
import { useTenant } from "@/contexts/TenantContext";
import { useCreateTarget, type TargetPeriod, type TargetType } from "@/hooks/useTargets";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CreateTargetDialog({ open, onOpenChange }: Props) {
  const { profile } = useUserData();
  const { effectiveTenantId } = useTenant();
  const createMutation = useCreateTarget();

  const [period, setPeriod] = useState<TargetPeriod>("monthly");
  const [targetType, setTargetType] = useState<TargetType>("transfers");
  const [bulk, setBulk] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [value, setValue] = useState<string>("");
  const [notes, setNotes] = useState("");
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);

  const roles = targetType === "transfers"
    ? ["AGENT", "TEAM_LEADER"]
    : ["TEAM_LEADER"];

  const { data: users = [] } = useQuery({
    queryKey: ["targets-users-by-role", effectiveTenantId, roles.join(",")],
    enabled: !!effectiveTenantId && open,
    queryFn: async () => {
      const { data: roleRows } = await supabase
        .from("user_roles")
        .select("user_id")
        .in("role", roles as any);
      const ids = Array.from(new Set((roleRows || []).map(r => r.user_id)));
      if (!ids.length) return [];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .in("id", ids)
        .eq("admin_id", effectiveTenantId);
      return (profiles || []).sort((a: any, b: any) => (a.full_name || a.email).localeCompare(b.full_name || b.email));
    },
  });

  useEffect(() => {
    if (!open) {
      setBulk(false);
      setSelectedIds([]);
      setValue("");
      setNotes("");
      setStartDate(undefined);
    }
  }, [open]);

  // Reset selection when role/type changes (different user pool)
  useEffect(() => {
    setSelectedIds([]);
  }, [targetType]);

  const targetIds = useMemo(() => {
    if (bulk) return users.map((u: any) => u.id);
    return selectedIds;
  }, [bulk, users, selectedIds]);

  const handleSubmit = async () => {
    if (!effectiveTenantId || !profile?.id) return;
    if (!targetIds.length || !value) return;
    await createMutation.mutateAsync({
      adminId: effectiveTenantId,
      userIds: targetIds,
      target_type: targetType,
      target_value: Number(value),
      period,
      notes: notes || undefined,
      createdBy: profile.id,
      referenceDate: startDate,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Send Target</DialogTitle>
          <DialogDescription>Assign a weekly or monthly performance target.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Period</Label>
              <Select value={period} onValueChange={(v) => setPeriod(v as TargetPeriod)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={targetType} onValueChange={(v) => setTargetType(v as TargetType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="transfers">Transfers (Agents)</SelectItem>
                  <SelectItem value="team_transfers">Team Transfers (TL Team)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-between rounded-md border p-3">
            <div>
              <Label className="text-sm">
                Apply to all {targetType === "transfers" ? "agents" : targetType === "deposits" ? "super agents" : "team leaders"}
              </Label>
              <p className="text-xs text-muted-foreground">{users.length} user(s)</p>
            </div>
            <Switch checked={bulk} onCheckedChange={setBulk} />
          </div>

          {!bulk && (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label>{targetType === "team_transfers" ? "Team Leaders" : "Users"}</Label>
                {selectedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setSelectedIds([])}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    Clear
                  </button>
                )}
              </div>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-between font-normal">
                    <span className="truncate">
                      {selectedIds.length === 0
                        ? "Select users"
                        : `${selectedIds.length} selected`}
                    </span>
                    <ChevronsUpDown className="h-4 w-4 opacity-50 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                  <div className="flex items-center justify-between border-b px-2 py-1.5">
                    <button
                      type="button"
                      onClick={() => setSelectedIds(users.map((u: any) => u.id))}
                      className="text-xs text-primary hover:underline"
                    >
                      Select all
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedIds([])}
                      className="text-xs text-muted-foreground hover:text-foreground"
                    >
                      Clear
                    </button>
                  </div>
                  <ScrollArea className="max-h-64">
                    <div className="p-1">
                      {users.length === 0 ? (
                        <p className="p-2 text-xs text-muted-foreground">No users available.</p>
                      ) : users.map((u: any) => {
                        const checked = selectedIds.includes(u.id);
                        return (
                          <label
                            key={u.id}
                            className="flex items-center gap-2 rounded-sm px-2 py-1.5 hover:bg-accent cursor-pointer"
                          >
                            <Checkbox
                              checked={checked}
                              onCheckedChange={(v) => {
                                setSelectedIds(prev =>
                                  v ? [...prev, u.id] : prev.filter(id => id !== u.id),
                                );
                              }}
                            />
                            <span className="text-sm truncate">{u.full_name || u.email}</span>
                          </label>
                        );
                      })}
                    </div>
                  </ScrollArea>
                </PopoverContent>
              </Popover>
              {selectedIds.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-1">
                  {selectedIds.slice(0, 6).map(id => {
                    const u = users.find((x: any) => x.id === id);
                    if (!u) return null;
                    return (
                      <Badge key={id} variant="secondary" className="gap-1 pr-1">
                        <span className="truncate max-w-[120px]">{u.full_name || u.email}</span>
                        <button
                          type="button"
                          onClick={() => setSelectedIds(prev => prev.filter(x => x !== id))}
                          className="rounded-sm hover:bg-muted-foreground/20"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    );
                  })}
                  {selectedIds.length > 6 && (
                    <Badge variant="outline">+{selectedIds.length - 6}</Badge>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="space-y-1.5">
            <Label>
              Target {targetType === "transfers"
                ? "(transfers count)"
                : targetType === "deposits"
                  ? "(deposit amount $)"
                  : "(team transfers count)"}
            </Label>
            <Input
              type="number"
              min={1}
              step={targetType === "deposits" ? 100 : 1}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder={targetType === "deposits" ? "e.g. 5000" : "e.g. 20"}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Start Date (optional)</Label>
            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className={cn("flex-1 justify-start text-left font-normal", !startDate && "text-muted-foreground")}>
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "PPP") : <span>Defaults to today</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus className={cn("p-3 pointer-events-auto")} />
                </PopoverContent>
              </Popover>
              {startDate && (
                <Button variant="ghost" size="icon" onClick={() => setStartDate(undefined)} title="Clear">
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              The {period} period will be calculated relative to this date.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label>Notes (optional)</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!targetIds.length || !value || createMutation.isPending}>
            {createMutation.isPending ? "Saving..." : `Send to ${targetIds.length || "—"}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
