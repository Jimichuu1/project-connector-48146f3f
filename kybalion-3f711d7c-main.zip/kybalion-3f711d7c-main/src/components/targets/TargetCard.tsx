import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2, TrendingUp, TrendingDown, Calendar } from "lucide-react";
import { format } from "date-fns";
import type { TargetProgress, TargetHistoryRow } from "@/hooks/useTargets";

function formatValue(target_type: "deposits" | "transfers" | "team_transfers", v: number) {
  return target_type === "deposits"
    ? `$${Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : String(v);
}

function statusInfo(pct: number, achieved?: boolean, isHistory = false) {
  if (isHistory) {
    if (achieved) return { label: "Achieved", cls: "bg-emerald-500 text-white", barCls: "[&>div]:bg-emerald-500" };
    if (pct >= 50) return { label: "Behind", cls: "bg-amber-500 text-white", barCls: "[&>div]:bg-amber-500" };
    return { label: "Missed", cls: "bg-rose-500 text-white", barCls: "[&>div]:bg-rose-500" };
  }
  if (pct >= 100) return { label: "Achieved", cls: "bg-emerald-500 text-white", barCls: "[&>div]:bg-emerald-500" };
  if (pct >= 50) return { label: "On Track", cls: "bg-blue-500 text-white", barCls: "[&>div]:bg-blue-500" };
  return { label: "Behind", cls: "bg-amber-500 text-white", barCls: "[&>div]:bg-amber-500" };
}

interface TargetCardProps {
  target: TargetProgress;
  avatarUrl?: string | null;
  onEdit: (t: TargetProgress) => void;
  onDelete: (id: string) => void;
}

export function TargetCard({ target, avatarUrl, onEdit, onDelete }: TargetCardProps) {
  const current = Number(target.current_value);
  const goal = Number(target.target_value);
  const pct = Math.min(100, (current / goal) * 100);
  const remaining = Math.max(0, goal - current);
  const initials = target.user_name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const status = statusInfo(pct);
  const TrendIcon = pct >= 50 ? TrendingUp : TrendingDown;

  return (
    <Card className="group bg-secondary shadow-none transition-shadow duration-200">
      <CardContent className="p-4 space-y-3 bg-inherit rounded-xl pt-[16px]">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <Avatar className="h-9 w-9 shrink-0">
              <AvatarImage src={avatarUrl || undefined} />
              <AvatarFallback className="text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate flex items-center gap-1.5">
                <span className="truncate">{target.user_name}</span>
                {target.target_type === "team_transfers" && (
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 shrink-0">Team</Badge>
                )}
              </div>
              <div className="text-xs text-muted-foreground truncate">{target.user_email}</div>
            </div>
          </div>
          <Badge className={`${status.cls} hover:${status.cls.split(" ")[0]} shrink-0`}>{status.label}</Badge>
        </div>

        <div className="flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <div className="text-2xl font-bold tracking-tight">{formatValue(target.target_type, current)}</div>
            <div className="text-xs text-muted-foreground">of {formatValue(target.target_type, goal)} goal</div>
          </div>
          <div className="flex items-center gap-1 text-sm font-semibold">
            <TrendIcon className={`h-4 w-4 ${pct >= 50 ? "text-emerald-500" : "text-amber-500"}`} />
            {Math.round(pct)}%
          </div>
        </div>

        <Progress value={pct} className="h-2 border-inherit bg-background" />

        <div className="flex items-center justify-between text-xs text-muted-foreground pt-1">
          <span>{remaining > 0 ? `${formatValue(target.target_type, remaining)} to go` : "Target reached 🎉"}</span>
          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEdit(target)}>
              <Pencil className="h-3.5 w-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onDelete(target.id)}>
              <Trash2 className="h-3.5 w-3.5 text-destructive" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface HistoryCardProps {
  row: TargetHistoryRow;
  avatarUrl?: string | null;
}

export function HistoryCard({ row, avatarUrl }: HistoryCardProps) {
  const current = Number(row.current_value);
  const goal = Number(row.target_value);
  const pct = Math.min(100, (current / goal) * 100);
  const initials = row.user_name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  const status = statusInfo(pct, row.achieved, true);

  return (
    <Card className="bg-secondary shadow-none transition-shadow duration-200">
      <CardContent className="p-4 space-y-3 bg-inherit rounded-xl pt-[16px]">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <Avatar className="h-9 w-9 shrink-0">
              <AvatarImage src={avatarUrl || undefined} />
              <AvatarFallback className="text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate flex items-center gap-1.5">
                <span className="truncate">{row.user_name}</span>
                {row.target_type === "team_transfers" && (
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 shrink-0">Team</Badge>
                )}
              </div>
              <div className="text-xs text-muted-foreground truncate">{row.user_email}</div>
            </div>
          </div>
          <Badge className={`${status.cls} hover:${status.cls.split(" ")[0]} shrink-0`}>{status.label}</Badge>
        </div>

        <div className="flex items-baseline justify-between">
          <div className="flex items-baseline gap-1.5">
            <div className="text-2xl font-bold tracking-tight">{formatValue(row.target_type, current)}</div>
            <div className="text-xs text-muted-foreground">of {formatValue(row.target_type, goal)} goal</div>
          </div>
          <div className="text-sm font-semibold">{Math.round(pct)}%</div>
        </div>

        <Progress value={pct} className="h-2 border-inherit bg-background" />

        <div className="flex items-center gap-1.5 text-xs text-muted-foreground pt-1">
          <Calendar className="h-3 w-3" />
          {format(new Date(row.period_start), "MMM d")} – {format(new Date(row.period_end), "MMM d, yyyy")}
        </div>
      </CardContent>
    </Card>
  );
}