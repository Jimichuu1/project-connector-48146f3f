import { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Trophy, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TargetHistoryRow } from "@/hooks/useTargets";

interface Props {
  rows: TargetHistoryRow[];
  avatarMap: Map<string, string | null>;
  emptyText: string;
}

interface UserAgg {
  user_id: string;
  user_name: string;
  user_email: string;
  success: number;
  failed: number;
  total: number;
}

type Status = "all-success" | "all-failed" | "mixed";

const styles: Record<Status, {
  card: string;
  iconWrap: string;
  iconColor: string;
  avatarBorder: string;
  avatarFallback: string;
  Icon: typeof Trophy;
  badge: string;
  label: string;
}> = {
  "all-success": {
    card: "bg-gradient-to-br from-emerald-500/15 via-emerald-500/5 to-transparent",
    iconWrap: "bg-emerald-500/20",
    iconColor: "text-emerald-600 dark:text-emerald-400",
    avatarBorder: "border-emerald-500",
    avatarFallback: "bg-emerald-500 text-white",
    Icon: Trophy,
    badge: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
    label: "All achieved",
  },
  "all-failed": {
    card: "bg-gradient-to-br from-rose-500/15 via-rose-500/5 to-transparent",
    iconWrap: "bg-rose-500/20",
    iconColor: "text-rose-600 dark:text-rose-400",
    avatarBorder: "border-rose-500",
    avatarFallback: "bg-rose-500 text-white",
    Icon: XCircle,
    badge: "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30",
    label: "All missed",
  },
  mixed: {
    card: "bg-gradient-to-br from-orange-500/15 via-orange-500/5 to-transparent",
    iconWrap: "bg-orange-500/20",
    iconColor: "text-orange-600 dark:text-orange-400",
    avatarBorder: "border-orange-500",
    avatarFallback: "bg-orange-500 text-white",
    Icon: AlertTriangle,
    badge: "bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/30",
    label: "Mixed",
  },
};

export function UserSuccessSummaryCards({ rows, avatarMap, emptyText }: Props) {
  const aggregated = useMemo(() => {
    const map = new Map<string, UserAgg>();
    for (const r of rows) {
      const cur = map.get(r.user_id) ?? {
        user_id: r.user_id,
        user_name: r.user_name,
        user_email: r.user_email,
        success: 0,
        failed: 0,
        total: 0,
      };
      cur.total += 1;
      if (r.achieved) cur.success += 1;
      else cur.failed += 1;
      map.set(r.user_id, cur);
    }
    return Array.from(map.values()).sort((a, b) => {
      if (b.success !== a.success) return b.success - a.success;
      return a.user_name.localeCompare(b.user_name);
    });
  }, [rows]);

  if (aggregated.length === 0) {
    return (
      <div className="text-xs text-muted-foreground p-3 text-center border rounded-md">
        {emptyText}
      </div>
    );
  }

  const getInitials = (name: string) =>
    name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
      {aggregated.map((u) => {
        const status: Status =
          u.failed === 0 ? "all-success" : u.success === 0 ? "all-failed" : "mixed";
        const s = styles[status];
        const successRate = u.total > 0 ? Math.round((u.success / u.total) * 100) : 0;

        return (
          <Card
            key={u.user_id}
            className={cn(
              "transition-all duration-300 hover:shadow-md",
              s.card
            )}
          >
            <CardContent className="p-3.5">
              <div className="flex items-center gap-3">
                <Avatar className={cn("h-11 w-11 border-2 shadow-sm shrink-0", s.avatarBorder)}>
                  <AvatarImage src={avatarMap.get(u.user_id) || undefined} />
                  <AvatarFallback className={cn("text-xs font-bold", s.avatarFallback)}>
                    {getInitials(u.user_name)}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-semibold text-sm truncate" title={u.user_name}>
                      {u.user_name}
                    </h3>
                    <Badge variant="outline" className={cn("text-[10px] font-semibold shrink-0 px-1.5 py-0 h-5", s.badge)}>
                      {successRate}%
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 mt-1.5">
                    <span className="inline-flex items-center gap-1 text-sm font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      {u.success}
                    </span>
                    <span className="inline-flex items-center gap-1 text-sm font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                      <XCircle className="h-3.5 w-3.5" />
                      {u.failed}
                    </span>
                    <span className="ml-auto text-[10px] uppercase tracking-wide text-muted-foreground tabular-nums">
                      {u.total}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
