import { useMemo, useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { Search } from "lucide-react";
import type { TargetHistoryRow } from "@/hooks/useTargets";

type Mode = "daily" | "weekly" | "monthly";

function formatValue(target_type: "deposits" | "transfers" | "team_transfers", v: number) {
  return target_type === "deposits"
    ? `$${Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : String(v);
}

function statusInfo(pct: number, achieved: boolean) {
  if (achieved) return { label: "Achieved", cls: "bg-emerald-500 text-white", barCls: "[&>div]:bg-emerald-500" };
  if (pct >= 50) return { label: "Behind", cls: "bg-amber-500 text-white", barCls: "[&>div]:bg-amber-500" };
  return { label: "Missed", cls: "bg-rose-500 text-white", barCls: "[&>div]:bg-rose-500" };
}

function periodLabel(mode: Mode, start: string, end: string) {
  if (mode === "daily") return format(new Date(start), "EEE, MMM d, yyyy");
  if (mode === "weekly") return `${format(new Date(start), "MMM d")} – ${format(new Date(end), "MMM d, yyyy")}`;
  return format(new Date(start), "MMMM yyyy");
}

interface Props {
  rows: TargetHistoryRow[];
  emptyText: string;
  avatarMap: Map<string, string | null>;
  mode: Mode;
}

export function HistoryTable({ rows, emptyText, avatarMap, mode }: Props) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "achieved" | "behind" | "missed">("all");
  const [typeFilter, setTypeFilter] = useState<"all" | "transfers" | "deposits" | "team_transfers">("all");
  const [periodFilter, setPeriodFilter] = useState<string>("all");

  const periodOptions = useMemo(() => {
    const set = new Map<string, { start: string; end: string }>();
    for (const r of rows) if (!set.has(r.period_start)) set.set(r.period_start, { start: r.period_start, end: r.period_end });
    return Array.from(set.values()).sort((a, b) => new Date(b.start).getTime() - new Date(a.start).getTime());
  }, [rows]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(r => {
      const cv = Number(r.current_value);
      const tv = Number(r.target_value);
      const pct = tv > 0 ? (cv / tv) * 100 : 0;
      const status = r.achieved ? "achieved" : pct >= 50 ? "behind" : "missed";
      if (statusFilter !== "all" && status !== statusFilter) return false;
      if (typeFilter !== "all" && r.target_type !== typeFilter) return false;
      if (periodFilter !== "all" && r.period_start !== periodFilter) return false;
      if (q && !(r.user_name.toLowerCase().includes(q) || r.user_email.toLowerCase().includes(q))) return false;
      return true;
    }).sort((a, b) => {
      const ta = new Date(b.period_start).getTime() - new Date(a.period_start).getTime();
      if (ta !== 0) return ta;
      const pa = Number(a.target_value) > 0 ? Number(a.current_value) / Number(a.target_value) : 0;
      const pb = Number(b.target_value) > 0 ? Number(b.current_value) / Number(b.target_value) : 0;
      return pb - pa;
    });
  }, [rows, search, statusFilter, typeFilter, periodFilter]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search user..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-9" />
        </div>
        {mode !== "monthly" && (
          <Select value={periodFilter} onValueChange={setPeriodFilter}>
            <SelectTrigger className="w-[220px] h-9"><SelectValue placeholder="Period" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All {mode === "daily" ? "days" : "weeks"}</SelectItem>
              {periodOptions.map(p => (
                <SelectItem key={p.start} value={p.start}>{periodLabel(mode, p.start, p.end)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as typeof typeFilter)}>
          <SelectTrigger className="w-[160px] h-9"><SelectValue placeholder="Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            <SelectItem value="transfers">Transfers</SelectItem>
            <SelectItem value="team_transfers">Team Transfers</SelectItem>
            <SelectItem value="deposits">Deposits</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
          <SelectTrigger className="w-[140px] h-9"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All status</SelectItem>
            <SelectItem value="achieved">Achieved</SelectItem>
            <SelectItem value="behind">Behind</SelectItem>
            <SelectItem value="missed">Missed</SelectItem>
          </SelectContent>
        </Select>
        <div className="text-xs text-muted-foreground ml-auto">
          {filtered.length} of {rows.length}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-sm text-muted-foreground p-6 text-center border rounded-md">
          {rows.length === 0 ? emptyText : "No targets match the filters."}
        </div>
      ) : (() => {
        const renderTable = (data: TargetHistoryRow[]) => (
          <div className="border rounded-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  {mode === "monthly" && <TableHead>Period</TableHead>}
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Current</TableHead>
                  <TableHead className="text-right">Goal</TableHead>
                  <TableHead className="w-[200px]">Progress</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map(r => {
                  const cv = Number(r.current_value);
                  const tv = Number(r.target_value);
                  const pct = tv > 0 ? Math.min(100, (cv / tv) * 100) : 0;
                  const status = statusInfo(pct, r.achieved);
                  const initials = r.user_name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
                  return (
                    <TableRow key={r.id}>
                      <TableCell>
                        <div className="flex items-center gap-2 min-w-0">
                          <Avatar className="h-7 w-7 shrink-0">
                            <AvatarImage src={avatarMap.get(r.user_id) || undefined} />
                            <AvatarFallback className="text-[10px]">{initials}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <div className="text-sm font-medium truncate">{r.user_name}</div>
                            <div className="text-xs text-muted-foreground truncate">{r.user_email}</div>
                          </div>
                        </div>
                      </TableCell>
                      {mode === "monthly" && (
                        <TableCell className="text-sm whitespace-nowrap">
                          {periodLabel(mode, r.period_start, r.period_end)}
                        </TableCell>
                      )}
                      <TableCell>
                        {r.target_type === "team_transfers" ? (
                          <Badge variant="outline" className="text-[10px]">Team Transfers</Badge>
                        ) : r.target_type === "transfers" ? (
                          <span className="text-sm">Transfers</span>
                        ) : (
                          <span className="text-sm">Deposits</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right text-sm font-semibold tabular-nums">
                        {formatValue(r.target_type, cv)}
                      </TableCell>
                      <TableCell className="text-right text-sm text-muted-foreground tabular-nums">
                        {formatValue(r.target_type, tv)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={pct} className={`h-2 flex-1 ${status.barCls}`} />
                          <span className="text-xs font-medium tabular-nums w-9 text-right">{Math.round(pct)}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${status.cls} hover:${status.cls.split(" ")[0]}`}>{status.label}</Badge>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        );

        if (mode === "monthly") return renderTable(filtered);

        const groups = new Map<string, { start: string; end: string; rows: TargetHistoryRow[] }>();
        for (const r of filtered) {
          if (!groups.has(r.period_start)) groups.set(r.period_start, { start: r.period_start, end: r.period_end, rows: [] });
          groups.get(r.period_start)!.rows.push(r);
        }
        const sorted = Array.from(groups.values()).sort(
          (a, b) => new Date(b.start).getTime() - new Date(a.start).getTime()
        );

        return (
          <div className="space-y-6">
            {sorted.map(g => {
              const achievedCount = g.rows.filter(r => r.achieved).length;
              return (
                <div key={g.start} className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-semibold">{periodLabel(mode, g.start, g.end)}</h3>
                    <span className="text-xs text-muted-foreground">
                      · {g.rows.length} target{g.rows.length === 1 ? "" : "s"} · {achievedCount} achieved
                    </span>
                  </div>
                  {renderTable(g.rows)}
                </div>
              );
            })}
          </div>
        );
      })()}
    </div>
  );
}
