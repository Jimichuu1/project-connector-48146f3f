import { useMemo } from "react";
import { useUserData } from "@/contexts/UserDataContext";
import { useMyTargets, getPeriodRange, type PerformanceTarget } from "@/hooks/useTargets";
import { useQueries } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Target, TrendingUp, ChevronDown } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";
import { format } from "date-fns";

const PERIOD_ORDER: Record<string, number> = { daily: 0, weekly: 1, monthly: 2 };

async function fetchProgress(target: PerformanceTarget, userId: string, adminId: string): Promise<number> {
  // Use the SECURITY DEFINER RPC so role-based RLS doesn't shrink counts
  // (e.g. Team Leaders only seeing their own clients via direct query)
  const { data, error } = await (supabase as any).rpc("get_target_progress", {
    p_admin_id: adminId,
    p_period_start: target.period_start,
    p_period_end: target.period_end,
  });
  if (error) return 0;
  const row = (data || []).find((r: any) => r.id === target.id);
  return Number(row?.current_value ?? 0);
}

function formatVal(type: string, v: number) {
  return type === "deposits"
    ? `$${Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : String(v);
}

function periodLabel(p: string) {
  return p === "monthly" ? "Monthly" : p === "weekly" ? "Weekly" : "Daily";
}

function periodLabelShort(p: string) {
  return p === "monthly" ? "M. Target" : p === "weekly" ? "W. Target" : "D. Target";
}

function statusColors(pct: number) {
  const achieved = pct >= 100;
  const onTrack = pct >= 50;
  return {
    achieved,
    onTrack,
    gradient: achieved
      ? "from-emerald-500/20 via-emerald-500/10 to-transparent border-emerald-500/40"
      : onTrack
      ? "from-blue-500/15 via-blue-500/5 to-transparent border-blue-500/30"
      : "from-amber-500/15 via-amber-500/5 to-transparent border-amber-500/30",
    iconBg: achieved ? "bg-emerald-500" : onTrack ? "bg-blue-500" : "bg-amber-500",
    accent: achieved ? "text-emerald-500" : onTrack ? "text-blue-500" : "text-amber-500",
  };
}

export function TargetProgressBanner() {
  const { profile, isAgent, isSuperAgent, isTeamLeader, adminId } = useUserData();
  const userId = profile?.id;

  const enabled = (isAgent || isSuperAgent || isTeamLeader) && !!userId;
  const { data: myTargets = [] } = useMyTargets(enabled ? userId : null);

  // Sort targets by priority: daily > weekly > monthly
  const sortedTargets = useMemo(
    () =>
      [...myTargets].sort(
        (a, b) => (PERIOD_ORDER[a.period] ?? 99) - (PERIOD_ORDER[b.period] ?? 99),
      ),
    [myTargets],
  );

  // Fetch progress for all targets in parallel
  const progressQueries = useQueries({
    queries: sortedTargets.map(t => ({
      queryKey: ["my-target-progress", t.id, userId, adminId],
      enabled: !!userId && !!adminId,
      staleTime: 60 * 1000,
      queryFn: () => fetchProgress(t, userId!, adminId!),
    })),
  });

  if (!enabled || sortedTargets.length === 0) return null;

  const targetsWithProgress = sortedTargets.map((t, i) => {
    const progress = Number(progressQueries[i]?.data ?? 0);
    const pct = Math.min(100, (progress / Number(t.target_value)) * 100);
    return { target: t, progress, pct };
  });

  const primary = targetsWithProgress[0];
  const colors = statusColors(primary.pct);
  const hasMultiple = targetsWithProgress.length > 1;

  const trigger = (
    <div
      className={`group relative flex items-center gap-2.5 py-1 pl-1 pr-3 bg-gradient-to-r ${colors.gradient} rounded-lg border backdrop-blur-sm animate-fade-in transition-all hover:shadow-md ${hasMultiple ? "cursor-pointer" : ""}`}
    >
      <div className={`relative flex items-center justify-center w-7 h-7 rounded-md ${colors.iconBg} shadow-md`}>
        <Target className="w-4 h-4 text-white" />
      </div>
      <div className="flex flex-col leading-tight">
        <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
          {periodLabelShort(primary.target.period)}
        </span>
        <span className="text-xs font-semibold text-foreground">
          {formatVal(primary.target.target_type, primary.progress)}{" "}
          <span className="text-muted-foreground">
            / {formatVal(primary.target.target_type, primary.target.target_value)}
          </span>
        </span>
      </div>
      <div className="flex items-center gap-1">
        <TrendingUp className={`w-3.5 h-3.5 ${colors.accent}`} />
        <span className="text-xs font-bold">
          {formatVal(primary.target.target_type, primary.progress)} / {formatVal(primary.target.target_type, primary.target.target_value)}
        </span>
      </div>
      {hasMultiple && (
        <>
          <span className="ml-1 text-[10px] font-semibold text-muted-foreground bg-muted/60 rounded-full px-1.5 py-0.5">
            +{targetsWithProgress.length - 1}
          </span>
          <ChevronDown className="w-3 h-3 text-muted-foreground" />
        </>
      )}
    </div>
  );

  if (!hasMultiple) {
    return (
      <HoverCard openDelay={150} closeDelay={100}>
        <HoverCardTrigger asChild>{trigger}</HoverCardTrigger>
        <HoverCardContent side="bottom" align="end" className="w-72 text-xs">
          <div className="space-y-1">
            <p className="font-semibold">
              {periodLabel(primary.target.period)} {primary.target.target_type} target
            </p>
            <p>
              Progress: {formatVal(primary.target.target_type, primary.progress)} of{" "}
              {formatVal(primary.target.target_type, primary.target.target_value)}
            </p>
            <p className="text-muted-foreground">
              {format(new Date(primary.target.period_start), "MMM d")} –{" "}
              {format(new Date(primary.target.period_end), "MMM d")}
            </p>
            {primary.target.notes && (
              <p className="text-muted-foreground italic">{primary.target.notes}</p>
            )}
          </div>
        </HoverCardContent>
      </HoverCard>
    );
  }

  const renderRow = ({ target: t, progress, pct }: typeof targetsWithProgress[number]) => {
    const c = statusColors(pct);
    return (
      <div
        key={t.id}
        className="flex items-center gap-2.5 p-2 rounded-md hover:bg-muted/50 transition-colors"
      >
        <div className={`flex items-center justify-center w-7 h-7 rounded-md ${c.iconBg} shrink-0`}>
          <Target className="w-3.5 h-3.5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
              {periodLabel(t.period)}
            </span>
            <span className={`text-xs font-bold ${c.accent}`}>{Math.round(pct)}%</span>
          </div>
          <div className="text-xs font-semibold truncate">
            {formatVal(t.target_type, progress)}{" "}
            <span className="text-muted-foreground font-normal">
              / {formatVal(t.target_type, t.target_value)}
            </span>
          </div>
          <div className="mt-1 w-full h-1 rounded-full bg-muted overflow-hidden">
            <div className={`h-full ${c.iconBg} transition-all`} style={{ width: `${pct}%` }} />
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">
            {format(new Date(t.period_start), "MMM d")} – {format(new Date(t.period_end), "MMM d")}
          </p>
        </div>
      </div>
    );
  };

  const mine = targetsWithProgress.filter(({ target }) => target.target_type !== "team_transfers");
  const team = targetsWithProgress.filter(({ target }) => target.target_type === "team_transfers");
  const showSplit = isTeamLeader && mine.length > 0 && team.length > 0;

  return (
    <HoverCard openDelay={120} closeDelay={120}>
      <HoverCardTrigger asChild>{trigger}</HoverCardTrigger>
      <HoverCardContent side="bottom" align="end" className="w-80 p-2">
        <div className="px-2 py-1.5 mb-1 border-b">
          <p className="text-xs font-semibold">All targets</p>
          <p className="text-[11px] text-muted-foreground">
            {showSplit ? "Personal & team performance" : "Daily · Weekly · Monthly"}
          </p>
        </div>
        {showSplit ? (
          <div className="space-y-2">
            <div>
              <p className="px-2 pt-1 pb-0.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                My targets
              </p>
              <div className="space-y-1">{mine.map(renderRow)}</div>
            </div>
            <div className="border-t pt-1">
              <p className="px-2 pt-1 pb-0.5 text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                Team targets
              </p>
              <div className="space-y-1">{team.map(renderRow)}</div>
            </div>
          </div>
        ) : (
          <div className="space-y-1">{targetsWithProgress.map(renderRow)}</div>
        )}
      </HoverCardContent>
    </HoverCard>
  );
}
