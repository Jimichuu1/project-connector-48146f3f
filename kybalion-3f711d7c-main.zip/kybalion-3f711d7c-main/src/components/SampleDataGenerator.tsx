import { useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Database, Loader2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function SampleDataGenerator() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  const generateSampleData = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      // Insert sample leads
      const { data: leads, error: leadsError } = await supabase
        .from("leads")
        .insert([
          {
            name: "John Smith",
            email: "john.smith@email.com",
            phone: "+1-555-0101",
            country: "United States",
            source: "WEBSITE",
            status: "NEW",
            conversion_probability: 0.75,
            created_by: user.id,
            assigned_to: user.id,
          },
          {
            name: "Maria Garcia",
            email: "maria.garcia@email.com",
            phone: "+34-600-123456",
            country: "Spain",
            source: "REFERRAL",
            status: "ACTIVE",
            conversion_probability: 0.85,
            created_by: user.id,
            assigned_to: user.id,
          },
          {
            name: "Ahmed Hassan",
            email: "ahmed.hassan@email.com",
            phone: "+971-50-1234567",
            country: "UAE",
            source: "SOCIAL_MEDIA",
            status: "CALLBACK",
            conversion_probability: 0.45,
            created_by: user.id,
            assigned_to: user.id,
          },
          {
            name: "Sophie Chen",
            email: "sophie.chen@email.com",
            phone: "+86-138-12345678",
            country: "China",
            source: "PAID_ADS",
            status: "ACTIVE",
            conversion_probability: 0.65,
            created_by: user.id,
            assigned_to: user.id,
          },
          {
            name: "Michael Johnson",
            email: "michael.j@email.com",
            phone: "+44-7700-900123",
            country: "United Kingdom",
            source: "WEBINAR",
            status: "READY_TO_TRANSFER",
            conversion_probability: 0.90,
            created_by: user.id,
            assigned_to: user.id,
          },
        ])
        .select();

      if (leadsError) throw leadsError;

      // Insert sample clients (some converted from leads for the Convert Queue view)
      const { data: clients, error: clientsError } = await supabase
        .from("clients")
        .insert([
          {
            name: "Emma Thompson",
            email: "emma.t@email.com",
            country: "Australia",
            source: "TRADE_SHOW",
            balance: 125000,
            equity: 130000,
            open_trades: 5,
            deposits: 125000,
            created_by: user.id,
            assigned_to: user.id,
            converted_from_lead_id: leads && leads.length > 0 ? leads[0].id : null,
          },
          {
            name: "Lucas Silva",
            email: "lucas.silva@email.com",
            country: "Brazil",
            source: "REFERRAL",
            balance: 85000,
            equity: 88000,
            open_trades: 3,
            deposits: 85000,
            created_by: user.id,
            assigned_to: user.id,
            converted_from_lead_id: leads && leads.length > 1 ? leads[1].id : null,
          },
          {
            name: "Yuki Tanaka",
            email: "yuki.tanaka@email.com",
            country: "Japan",
            source: "WEBSITE",
            balance: 200000,
            equity: 210000,
            open_trades: 8,
            deposits: 200000,
            created_by: user.id,
            assigned_to: user.id,
          },
          {
            name: "Anna Kowalski",
            email: "anna.k@email.com",
            country: "Poland",
            source: "PAID_ADS",
            balance: 45000,
            equity: 43000,
            open_trades: 2,
            deposits: 45000,
            created_by: user.id,
            assigned_to: user.id,
          },
        ])
        .select();

      if (clientsError) throw clientsError;

      // Insert sale branches for clients
      if (clients && clients.length > 0) {
        const { error: branchesError } = await supabase
          .from("sale_branches")
          .insert([
            {
              client_id: clients[0].id,
              name: "Q1 Trading Expansion",
              status: "UPCOMING_SALE",
              value: 50000,
              created_by: user.id,
            },
            {
              client_id: clients[0].id,
              name: "Additional Investment",
              status: "UPCOMING_SALE",
              value: 75000,
              created_by: user.id,
            },
            {
              client_id: clients[1].id,
              name: "Portfolio Diversification",
              status: "DEPOSIT",
              value: 35000,
              created_by: user.id,
            },
            {
              client_id: clients[2].id,
              name: "Premium Account Upgrade",
              status: "UPCOMING_SALE",
              value: 100000,
              created_by: user.id,
            },
            {
              client_id: clients[3].id,
              name: "Recovery Plan",
              status: "STUCK",
              value: 20000,
              created_by: user.id,
            },
          ]);

        if (branchesError) throw branchesError;
      }

      // Insert sample notifications
      const { error: notificationsError } = await supabase
        .from("notifications")
        .insert([
          {
            user_id: user.id,
            type: "NEW_LEAD",
            message: "New lead assigned: Michael Johnson from webinar",
            related_entity_type: "lead",
          },
          {
            user_id: user.id,
            type: "CLIENT_CONVERTED",
            message: "Lead Emma Thompson converted to client successfully",
            related_entity_type: "client",
          },
          {
            user_id: user.id,
            type: "WITHDRAWAL_REQUEST",
            message: "New withdrawal request from Anna Kowalski - $5,000",
            related_entity_type: "client",
          },
          {
            user_id: user.id,
            type: "TASK_DUE",
            message: "Follow-up call with Sophie Chen is due today",
            related_entity_type: "lead",
          },
        ]);

      if (notificationsError) throw notificationsError;

      toast.success("Sample data created successfully!", {
        description: "5 leads, 4 clients, 5 opportunities, and 4 notifications added.",
      });
    } catch (error) {
      console.error("Error generating sample data:", error);
      toast.error("Failed to generate sample data", {
        description: "Please try again or check the console for details.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Database className="h-4 w-4" />
          Generate Sample Data
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Generate Sample Data?</AlertDialogTitle>
          <AlertDialogDescription>
            This will create example leads, clients, opportunities, and notifications to help you
            explore the CRM features. This action will add:
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>5 sample leads with various statuses</li>
              <li>4 sample clients with trading accounts</li>
              <li>5 pipeline opportunities</li>
              <li>4 notifications</li>
            </ul>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={generateSampleData} disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Generate Data
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
