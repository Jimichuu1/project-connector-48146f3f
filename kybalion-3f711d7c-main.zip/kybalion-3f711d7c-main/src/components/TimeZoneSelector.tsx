import { useState, useEffect } from "react";
import { Clock, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { toZonedTime } from "date-fns-tz";
import { useUserPreferences } from "@/hooks/useUserPreferences";

const TIME_ZONES = [
  { label: "Afghanistan", value: "Asia/Kabul", flag: "🇦🇫" },
  { label: "Albania", value: "Europe/Tirane", flag: "🇦🇱" },
  { label: "Algeria", value: "Africa/Algiers", flag: "🇩🇿" },
  { label: "Andorra", value: "Europe/Andorra", flag: "🇦🇩" },
  { label: "Angola", value: "Africa/Luanda", flag: "🇦🇴" },
  { label: "Argentina", value: "America/Argentina/Buenos_Aires", flag: "🇦🇷" },
  { label: "Armenia", value: "Asia/Yerevan", flag: "🇦🇲" },
  { label: "Australia - Sydney", value: "Australia/Sydney", flag: "🇦🇺" },
  { label: "Australia - Melbourne", value: "Australia/Melbourne", flag: "🇦🇺" },
  { label: "Australia - Perth", value: "Australia/Perth", flag: "🇦🇺" },
  { label: "Austria", value: "Europe/Vienna", flag: "🇦🇹" },
  { label: "Azerbaijan", value: "Asia/Baku", flag: "🇦🇿" },
  { label: "Bahamas", value: "America/Nassau", flag: "🇧🇸" },
  { label: "Bahrain", value: "Asia/Bahrain", flag: "🇧🇭" },
  { label: "Bangladesh", value: "Asia/Dhaka", flag: "🇧🇩" },
  { label: "Barbados", value: "America/Barbados", flag: "🇧🇧" },
  { label: "Belarus", value: "Europe/Minsk", flag: "🇧🇾" },
  { label: "Belgium", value: "Europe/Brussels", flag: "🇧🇪" },
  { label: "Belize", value: "America/Belize", flag: "🇧🇿" },
  { label: "Benin", value: "Africa/Porto-Novo", flag: "🇧🇯" },
  { label: "Bhutan", value: "Asia/Thimphu", flag: "🇧🇹" },
  { label: "Bolivia", value: "America/La_Paz", flag: "🇧🇴" },
  { label: "Bosnia", value: "Europe/Sarajevo", flag: "🇧🇦" },
  { label: "Botswana", value: "Africa/Gaborone", flag: "🇧🇼" },
  { label: "Brazil - São Paulo", value: "America/Sao_Paulo", flag: "🇧🇷" },
  { label: "Brazil - Rio", value: "America/Sao_Paulo", flag: "🇧🇷" },
  { label: "Brunei", value: "Asia/Brunei", flag: "🇧🇳" },
  { label: "Bulgaria", value: "Europe/Sofia", flag: "🇧🇬" },
  { label: "Burkina Faso", value: "Africa/Ouagadougou", flag: "🇧🇫" },
  { label: "Burundi", value: "Africa/Bujumbura", flag: "🇧🇮" },
  { label: "Cambodia", value: "Asia/Phnom_Penh", flag: "🇰🇭" },
  { label: "Cameroon", value: "Africa/Douala", flag: "🇨🇲" },
  { label: "Canada - Toronto", value: "America/Toronto", flag: "🇨🇦" },
  { label: "Canada - Vancouver", value: "America/Vancouver", flag: "🇨🇦" },
  { label: "Canada - Montreal", value: "America/Montreal", flag: "🇨🇦" },
  { label: "Cape Verde", value: "Atlantic/Cape_Verde", flag: "🇨🇻" },
  { label: "Central African Rep.", value: "Africa/Bangui", flag: "🇨🇫" },
  { label: "Chad", value: "Africa/Ndjamena", flag: "🇹🇩" },
  { label: "Chile", value: "America/Santiago", flag: "🇨🇱" },
  { label: "China - Beijing", value: "Asia/Shanghai", flag: "🇨🇳" },
  { label: "China - Shanghai", value: "Asia/Shanghai", flag: "🇨🇳" },
  { label: "Colombia", value: "America/Bogota", flag: "🇨🇴" },
  { label: "Comoros", value: "Indian/Comoro", flag: "🇰🇲" },
  { label: "Congo", value: "Africa/Brazzaville", flag: "🇨🇬" },
  { label: "Costa Rica", value: "America/Costa_Rica", flag: "🇨🇷" },
  { label: "Croatia", value: "Europe/Zagreb", flag: "🇭🇷" },
  { label: "Cuba", value: "America/Havana", flag: "🇨🇺" },
  { label: "Cyprus", value: "Asia/Nicosia", flag: "🇨🇾" },
  { label: "Czech Republic", value: "Europe/Prague", flag: "🇨🇿" },
  { label: "Denmark", value: "Europe/Copenhagen", flag: "🇩🇰" },
  { label: "Djibouti", value: "Africa/Djibouti", flag: "🇩🇯" },
  { label: "Dominica", value: "America/Dominica", flag: "🇩🇲" },
  { label: "Dominican Republic", value: "America/Santo_Domingo", flag: "🇩🇴" },
  { label: "Ecuador", value: "America/Guayaquil", flag: "🇪🇨" },
  { label: "Egypt", value: "Africa/Cairo", flag: "🇪🇬" },
  { label: "El Salvador", value: "America/El_Salvador", flag: "🇸🇻" },
  { label: "Equatorial Guinea", value: "Africa/Malabo", flag: "🇬🇶" },
  { label: "Eritrea", value: "Africa/Asmara", flag: "🇪🇷" },
  { label: "Estonia", value: "Europe/Tallinn", flag: "🇪🇪" },
  { label: "Ethiopia", value: "Africa/Addis_Ababa", flag: "🇪🇹" },
  { label: "Fiji", value: "Pacific/Fiji", flag: "🇫🇯" },
  { label: "Finland", value: "Europe/Helsinki", flag: "🇫🇮" },
  { label: "France - Paris", value: "Europe/Paris", flag: "🇫🇷" },
  { label: "Gabon", value: "Africa/Libreville", flag: "🇬🇦" },
  { label: "Gambia", value: "Africa/Banjul", flag: "🇬🇲" },
  { label: "Georgia", value: "Asia/Tbilisi", flag: "🇬🇪" },
  { label: "Germany - Berlin", value: "Europe/Berlin", flag: "🇩🇪" },
  { label: "Germany - Munich", value: "Europe/Berlin", flag: "🇩🇪" },
  { label: "Ghana", value: "Africa/Accra", flag: "🇬🇭" },
  { label: "Greece", value: "Europe/Athens", flag: "🇬🇷" },
  { label: "Grenada", value: "America/Grenada", flag: "🇬🇩" },
  { label: "Guatemala", value: "America/Guatemala", flag: "🇬🇹" },
  { label: "Guinea", value: "Africa/Conakry", flag: "🇬🇳" },
  { label: "Guinea-Bissau", value: "Africa/Bissau", flag: "🇬🇼" },
  { label: "Guyana", value: "America/Guyana", flag: "🇬🇾" },
  { label: "Haiti", value: "America/Port-au-Prince", flag: "🇭🇹" },
  { label: "Honduras", value: "America/Tegucigalpa", flag: "🇭🇳" },
  { label: "Hong Kong", value: "Asia/Hong_Kong", flag: "🇭🇰" },
  { label: "Hungary", value: "Europe/Budapest", flag: "🇭🇺" },
  { label: "Iceland", value: "Atlantic/Reykjavik", flag: "🇮🇸" },
  { label: "India - Mumbai", value: "Asia/Kolkata", flag: "🇮🇳" },
  { label: "India - Delhi", value: "Asia/Kolkata", flag: "🇮🇳" },
  { label: "Indonesia - Jakarta", value: "Asia/Jakarta", flag: "🇮🇩" },
  { label: "Indonesia - Bali", value: "Asia/Makassar", flag: "🇮🇩" },
  { label: "Iran", value: "Asia/Tehran", flag: "🇮🇷" },
  { label: "Iraq", value: "Asia/Baghdad", flag: "🇮🇶" },
  { label: "Ireland", value: "Europe/Dublin", flag: "🇮🇪" },
  { label: "Israel", value: "Asia/Jerusalem", flag: "🇮🇱" },
  { label: "Italy - Rome", value: "Europe/Rome", flag: "🇮🇹" },
  { label: "Italy - Milan", value: "Europe/Rome", flag: "🇮🇹" },
  { label: "Jamaica", value: "America/Jamaica", flag: "🇯🇲" },
  { label: "Japan - Tokyo", value: "Asia/Tokyo", flag: "🇯🇵" },
  { label: "Japan - Osaka", value: "Asia/Tokyo", flag: "🇯🇵" },
  { label: "Jordan", value: "Asia/Amman", flag: "🇯🇴" },
  { label: "Kazakhstan", value: "Asia/Almaty", flag: "🇰🇿" },
  { label: "Kenya", value: "Africa/Nairobi", flag: "🇰🇪" },
  { label: "Kiribati", value: "Pacific/Tarawa", flag: "🇰🇮" },
  { label: "Kuwait", value: "Asia/Kuwait", flag: "🇰🇼" },
  { label: "Kyrgyzstan", value: "Asia/Bishkek", flag: "🇰🇬" },
  { label: "Laos", value: "Asia/Vientiane", flag: "🇱🇦" },
  { label: "Latvia", value: "Europe/Riga", flag: "🇱🇻" },
  { label: "Lebanon", value: "Asia/Beirut", flag: "🇱🇧" },
  { label: "Lesotho", value: "Africa/Maseru", flag: "🇱🇸" },
  { label: "Liberia", value: "Africa/Monrovia", flag: "🇱🇷" },
  { label: "Libya", value: "Africa/Tripoli", flag: "🇱🇾" },
  { label: "Liechtenstein", value: "Europe/Vaduz", flag: "🇱🇮" },
  { label: "Lithuania", value: "Europe/Vilnius", flag: "🇱🇹" },
  { label: "Luxembourg", value: "Europe/Luxembourg", flag: "🇱🇺" },
  { label: "Macau", value: "Asia/Macau", flag: "🇲🇴" },
  { label: "Madagascar", value: "Indian/Antananarivo", flag: "🇲🇬" },
  { label: "Malawi", value: "Africa/Blantyre", flag: "🇲🇼" },
  { label: "Malaysia", value: "Asia/Kuala_Lumpur", flag: "🇲🇾" },
  { label: "Maldives", value: "Indian/Maldives", flag: "🇲🇻" },
  { label: "Mali", value: "Africa/Bamako", flag: "🇲🇱" },
  { label: "Malta", value: "Europe/Malta", flag: "🇲🇹" },
  { label: "Marshall Islands", value: "Pacific/Majuro", flag: "🇲🇭" },
  { label: "Mauritania", value: "Africa/Nouakchott", flag: "🇲🇷" },
  { label: "Mauritius", value: "Indian/Mauritius", flag: "🇲🇺" },
  { label: "Mexico - Mexico City", value: "America/Mexico_City", flag: "🇲🇽" },
  { label: "Mexico - Cancun", value: "America/Cancun", flag: "🇲🇽" },
  { label: "Micronesia", value: "Pacific/Pohnpei", flag: "🇫🇲" },
  { label: "Moldova", value: "Europe/Chisinau", flag: "🇲🇩" },
  { label: "Monaco", value: "Europe/Monaco", flag: "🇲🇨" },
  { label: "Mongolia", value: "Asia/Ulaanbaatar", flag: "🇲🇳" },
  { label: "Montenegro", value: "Europe/Podgorica", flag: "🇲🇪" },
  { label: "Morocco", value: "Africa/Casablanca", flag: "🇲🇦" },
  { label: "Mozambique", value: "Africa/Maputo", flag: "🇲🇿" },
  { label: "Myanmar", value: "Asia/Yangon", flag: "🇲🇲" },
  { label: "Namibia", value: "Africa/Windhoek", flag: "🇳🇦" },
  { label: "Nauru", value: "Pacific/Nauru", flag: "🇳🇷" },
  { label: "Nepal", value: "Asia/Kathmandu", flag: "🇳🇵" },
  { label: "Netherlands", value: "Europe/Amsterdam", flag: "🇳🇱" },
  { label: "New Zealand", value: "Pacific/Auckland", flag: "🇳🇿" },
  { label: "Nicaragua", value: "America/Managua", flag: "🇳🇮" },
  { label: "Niger", value: "Africa/Niamey", flag: "🇳🇪" },
  { label: "Nigeria", value: "Africa/Lagos", flag: "🇳🇬" },
  { label: "North Korea", value: "Asia/Pyongyang", flag: "🇰🇵" },
  { label: "North Macedonia", value: "Europe/Skopje", flag: "🇲🇰" },
  { label: "Norway", value: "Europe/Oslo", flag: "🇳🇴" },
  { label: "Oman", value: "Asia/Muscat", flag: "🇴🇲" },
  { label: "Pakistan", value: "Asia/Karachi", flag: "🇵🇰" },
  { label: "Palau", value: "Pacific/Palau", flag: "🇵🇼" },
  { label: "Panama", value: "America/Panama", flag: "🇵🇦" },
  { label: "Papua New Guinea", value: "Pacific/Port_Moresby", flag: "🇵🇬" },
  { label: "Paraguay", value: "America/Asuncion", flag: "🇵🇾" },
  { label: "Peru", value: "America/Lima", flag: "🇵🇪" },
  { label: "Philippines", value: "Asia/Manila", flag: "🇵🇭" },
  { label: "Poland", value: "Europe/Warsaw", flag: "🇵🇱" },
  { label: "Portugal", value: "Europe/Lisbon", flag: "🇵🇹" },
  { label: "Qatar", value: "Asia/Qatar", flag: "🇶🇦" },
  { label: "Romania", value: "Europe/Bucharest", flag: "🇷🇴" },
  { label: "Russia - Moscow", value: "Europe/Moscow", flag: "🇷🇺" },
  { label: "Russia - St Petersburg", value: "Europe/Moscow", flag: "🇷🇺" },
  { label: "Rwanda", value: "Africa/Kigali", flag: "🇷🇼" },
  { label: "Saint Lucia", value: "America/St_Lucia", flag: "🇱🇨" },
  { label: "Samoa", value: "Pacific/Apia", flag: "🇼🇸" },
  { label: "San Marino", value: "Europe/San_Marino", flag: "🇸🇲" },
  { label: "Saudi Arabia", value: "Asia/Riyadh", flag: "🇸🇦" },
  { label: "Senegal", value: "Africa/Dakar", flag: "🇸🇳" },
  { label: "Serbia", value: "Europe/Belgrade", flag: "🇷🇸" },
  { label: "Seychelles", value: "Indian/Mahe", flag: "🇸🇨" },
  { label: "Sierra Leone", value: "Africa/Freetown", flag: "🇸🇱" },
  { label: "Singapore", value: "Asia/Singapore", flag: "🇸🇬" },
  { label: "Slovakia", value: "Europe/Bratislava", flag: "🇸🇰" },
  { label: "Slovenia", value: "Europe/Ljubljana", flag: "🇸🇮" },
  { label: "Solomon Islands", value: "Pacific/Guadalcanal", flag: "🇸🇧" },
  { label: "Somalia", value: "Africa/Mogadishu", flag: "🇸🇴" },
  { label: "South Africa", value: "Africa/Johannesburg", flag: "🇿🇦" },
  { label: "South Korea", value: "Asia/Seoul", flag: "🇰🇷" },
  { label: "South Sudan", value: "Africa/Juba", flag: "🇸🇸" },
  { label: "Spain - Madrid", value: "Europe/Madrid", flag: "🇪🇸" },
  { label: "Spain - Barcelona", value: "Europe/Madrid", flag: "🇪🇸" },
  { label: "Sri Lanka", value: "Asia/Colombo", flag: "🇱🇰" },
  { label: "Sudan", value: "Africa/Khartoum", flag: "🇸🇩" },
  { label: "Suriname", value: "America/Paramaribo", flag: "🇸🇷" },
  { label: "Sweden", value: "Europe/Stockholm", flag: "🇸🇪" },
  { label: "Switzerland - Zurich", value: "Europe/Zurich", flag: "🇨🇭" },
  { label: "Switzerland - Geneva", value: "Europe/Zurich", flag: "🇨🇭" },
  { label: "Syria", value: "Asia/Damascus", flag: "🇸🇾" },
  { label: "Taiwan", value: "Asia/Taipei", flag: "🇹🇼" },
  { label: "Tajikistan", value: "Asia/Dushanbe", flag: "🇹🇯" },
  { label: "Tanzania", value: "Africa/Dar_es_Salaam", flag: "🇹🇿" },
  { label: "Thailand", value: "Asia/Bangkok", flag: "🇹🇭" },
  { label: "Timor-Leste", value: "Asia/Dili", flag: "🇹🇱" },
  { label: "Togo", value: "Africa/Lome", flag: "🇹🇬" },
  { label: "Tonga", value: "Pacific/Tongatapu", flag: "🇹🇴" },
  { label: "Trinidad and Tobago", value: "America/Port_of_Spain", flag: "🇹🇹" },
  { label: "Tunisia", value: "Africa/Tunis", flag: "🇹🇳" },
  { label: "Turkey", value: "Europe/Istanbul", flag: "🇹🇷" },
  { label: "Turkmenistan", value: "Asia/Ashgabat", flag: "🇹🇲" },
  { label: "Tuvalu", value: "Pacific/Funafuti", flag: "🇹🇻" },
  { label: "Uganda", value: "Africa/Kampala", flag: "🇺🇬" },
  { label: "Ukraine", value: "Europe/Kiev", flag: "🇺🇦" },
  { label: "United Arab Emirates", value: "Asia/Dubai", flag: "🇦🇪" },
  { label: "United Kingdom", value: "Europe/London", flag: "🇬🇧" },
  { label: "USA - New York", value: "America/New_York", flag: "🇺🇸" },
  { label: "USA - Los Angeles", value: "America/Los_Angeles", flag: "🇺🇸" },
  { label: "USA - Chicago", value: "America/Chicago", flag: "🇺🇸" },
  { label: "USA - Houston", value: "America/Chicago", flag: "🇺🇸" },
  { label: "USA - Phoenix", value: "America/Phoenix", flag: "🇺🇸" },
  { label: "USA - Miami", value: "America/New_York", flag: "🇺🇸" },
  { label: "Uruguay", value: "America/Montevideo", flag: "🇺🇾" },
  { label: "Uzbekistan", value: "Asia/Tashkent", flag: "🇺🇿" },
  { label: "Vanuatu", value: "Pacific/Efate", flag: "🇻🇺" },
  { label: "Vatican City", value: "Europe/Vatican", flag: "🇻🇦" },
  { label: "Venezuela", value: "America/Caracas", flag: "🇻🇪" },
  { label: "Vietnam", value: "Asia/Ho_Chi_Minh", flag: "🇻🇳" },
  { label: "Yemen", value: "Asia/Aden", flag: "🇾🇪" },
  { label: "Zambia", value: "Africa/Lusaka", flag: "🇿🇲" },
  { label: "Zimbabwe", value: "Africa/Harare", flag: "🇿🇼" },
];

export function TimeZoneSelector() {
  const { preferences, setTimezone } = useUserPreferences();
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleSelectZone = (zone: string) => {
    setTimezone(zone);
    setSearchQuery("");
  };

  const zonedTime = toZonedTime(currentTime, preferences.timezone);
  const selectedTimeZone = TIME_ZONES.find((tz) => tz.value === preferences.timezone);

  const filteredZones = TIME_ZONES.filter((zone) =>
    zone.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 h-9 px-3">
          <Clock className="h-4 w-4" />
          <span className="font-mono text-sm">
            {format(zonedTime, "HH:mm:ss")}
          </span>
          <span className="text-xs text-muted-foreground hidden lg:inline">
            {selectedTimeZone?.flag}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 bg-popover z-50 p-0">
        <div className="sticky top-0 bg-popover z-10 p-2 border-b">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search countries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 h-9"
            />
          </div>
        </div>
        <div className="max-h-[400px] overflow-y-auto p-1">
          {filteredZones.length === 0 ? (
            <div className="text-center text-sm text-muted-foreground py-8">
              No countries found
            </div>
          ) : (
            filteredZones.map((zone) => {
              const zoneTime = toZonedTime(currentTime, zone.value);
              return (
                <DropdownMenuItem
                  key={`${zone.value}-${zone.label}`}
                  onClick={() => handleSelectZone(zone.value)}
                  className="flex items-center justify-between cursor-pointer px-3 py-2"
                >
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <span className="flex-shrink-0">{zone.flag}</span>
                    <span className="text-sm truncate">{zone.label}</span>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground ml-2 flex-shrink-0">
                    {format(zoneTime, "HH:mm")}
                  </span>
                </DropdownMenuItem>
              );
            })
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
