import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { Calendar } from "lucide-react";
import { logger } from "@/utils/logger";
import type { Tables } from "@/integrations/supabase/types";

type Reminder = Tables<"reminders">;

export const ReminderNotifications = () => {
  const { user } = useAuth();
  const notifiedReminders = useRef<Set<string>>(new Set());
  const checkInterval = useRef<NodeJS.Timeout>();

  const checkDueReminders = async () => {
    if (!user) return;

    try {
      const now = new Date();
      
      // Get reminders due in the next 30 minutes that haven't been completed
      const thirtyMinutesFromNow = new Date(now.getTime() + 30 * 60000);
      
      const { data: reminders, error } = await supabase
        .from("reminders")
        .select("*")
        .eq("user_id", user.id)
        .eq("completed", false)
        .lte("due_date", thirtyMinutesFromNow.toISOString())
        .gte("due_date", now.toISOString());

      if (error) {
        logger.error("Error fetching due reminders", error);
        return;
      }

      reminders?.forEach((reminder) => {
        // Check if we've already notified about this reminder
        if (notifiedReminders.current.has(reminder.id)) {
          return;
        }

        const dueDate = new Date(reminder.due_date);
        const minutesUntilDue = Math.floor((dueDate.getTime() - now.getTime()) / 60000);

        // Show notification
        toast(reminder.title, {
          description: minutesUntilDue <= 0 
            ? "This reminder is due now!" 
            : `Due in ${minutesUntilDue} minute${minutesUntilDue !== 1 ? 's' : ''}`,
          icon: <Calendar className="h-4 w-4" />,
          duration: 10000,
          action: {
            label: "Mark Complete",
            onClick: async () => {
              await supabase
                .from("reminders")
                .update({ 
                  completed: true,
                  completed_at: new Date().toISOString()
                })
                .eq("id", reminder.id);
            },
          },
        });

        // Mark as notified
        notifiedReminders.current.add(reminder.id);
      });
    } catch (error) {
      logger.error("Error checking due reminders", error instanceof Error ? error : undefined);
    }
  };

  useEffect(() => {
    if (!user) return;

    // Initial check
    checkDueReminders();

    // Set up interval to check every 30 seconds
    checkInterval.current = setInterval(checkDueReminders, 30000);

    // Subscribe to real-time changes
    const channel = supabase
      .channel("reminder_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "reminders",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          // If a reminder is created or updated, check immediately
          if (payload.eventType === "INSERT" || payload.eventType === "UPDATE") {
            checkDueReminders();
          }
          
          // If a reminder is deleted or completed, remove from notified set
          if (payload.eventType === "DELETE" || 
              (payload.eventType === "UPDATE" && payload.new && (payload.new as Reminder).completed)) {
            const reminderId = payload.old?.id || (payload.new as Reminder)?.id;
            if (reminderId) {
              notifiedReminders.current.delete(reminderId);
            }
          }
        }
      )
      .subscribe();

    return () => {
      if (checkInterval.current) {
        clearInterval(checkInterval.current);
      }
      supabase.removeChannel(channel);
    };
  }, [user]);

  // This component doesn't render anything
  return null;
};
