import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useReminders } from "@/hooks/useReminders";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { useClients } from "@/hooks/useClients";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { Lead } from "@/types/leads";
import { format } from "date-fns";
import { fromZonedTime } from "date-fns-tz";
import { isValidUUID } from "@/lib/uuidUtils";

const TIME_ZONES = [
  { label: "Afghanistan", value: "Asia/Kabul", flag: "🇦🇫" },
  { label: "Albania", value: "Europe/Tirane", flag: "🇦🇱" },
  { label: "Algeria", value: "Africa/Algiers", flag: "🇩🇿" },
  { label: "Andorra", value: "Europe/Andorra", flag: "🇦🇩" },
  { label: "Angola", value: "Africa/Luanda", flag: "🇦🇴" },
  { label: "Argentina", value: "America/Argentina/Buenos_Aires", flag: "🇦🇷" },
  { label: "Armenia", value: "Asia/Yerevan", flag: "🇦🇲" },
  { label: "Australia - Sydney", value: "Australia/Sydney", flag: "🇦🇺" },
  { label: "Australia - Melbourne", value: "Australia/Melbourne", flag: "🇦🇺" },
  { label: "Australia - Perth", value: "Australia/Perth", flag: "🇦🇺" },
  { label: "Austria", value: "Europe/Vienna", flag: "🇦🇹" },
  { label: "Azerbaijan", value: "Asia/Baku", flag: "🇦🇿" },
  { label: "Bahamas", value: "America/Nassau", flag: "🇧🇸" },
  { label: "Bahrain", value: "Asia/Bahrain", flag: "🇧🇭" },
  { label: "Bangladesh", value: "Asia/Dhaka", flag: "🇧🇩" },
  { label: "Barbados", value: "America/Barbados", flag: "🇧🇧" },
  { label: "Belarus", value: "Europe/Minsk", flag: "🇧🇾" },
  { label: "Belgium", value: "Europe/Brussels", flag: "🇧🇪" },
  { label: "Belize", value: "America/Belize", flag: "🇧🇿" },
  { label: "Benin", value: "Africa/Porto-Novo", flag: "🇧🇯" },
  { label: "Bhutan", value: "Asia/Thimphu", flag: "🇧🇹" },
  { label: "Bolivia", value: "America/La_Paz", flag: "🇧🇴" },
  { label: "Bosnia", value: "Europe/Sarajevo", flag: "🇧🇦" },
  { label: "Botswana", value: "Africa/Gaborone", flag: "🇧🇼" },
  { label: "Brazil - São Paulo", value: "America/Sao_Paulo", flag: "🇧🇷" },
  { label: "Brazil - Rio", value: "America/Sao_Paulo", flag: "🇧🇷" },
  { label: "Brunei", value: "Asia/Brunei", flag: "🇧🇳" },
  { label: "Bulgaria", value: "Europe/Sofia", flag: "🇧🇬" },
  { label: "Burkina Faso", value: "Africa/Ouagadougou", flag: "🇧🇫" },
  { label: "Burundi", value: "Africa/Bujumbura", flag: "🇧🇮" },
  { label: "Cambodia", value: "Asia/Phnom_Penh", flag: "🇰🇭" },
  { label: "Cameroon", value: "Africa/Douala", flag: "🇨🇲" },
  { label: "Canada - Toronto", value: "America/Toronto", flag: "🇨🇦" },
  { label: "Canada - Vancouver", value: "America/Vancouver", flag: "🇨🇦" },
  { label: "Canada - Montreal", value: "America/Montreal", flag: "🇨🇦" },
  { label: "Cape Verde", value: "Atlantic/Cape_Verde", flag: "🇨🇻" },
  { label: "Central African Rep.", value: "Africa/Bangui", flag: "🇨🇫" },
  { label: "Chad", value: "Africa/Ndjamena", flag: "🇹🇩" },
  { label: "Chile", value: "America/Santiago", flag: "🇨🇱" },
  { label: "China - Beijing", value: "Asia/Shanghai", flag: "🇨🇳" },
  { label: "China - Shanghai", value: "Asia/Shanghai", flag: "🇨🇳" },
  { label: "Colombia", value: "America/Bogota", flag: "🇨🇴" },
  { label: "Comoros", value: "Indian/Comoro", flag: "🇰🇲" },
  { label: "Congo", value: "Africa/Brazzaville", flag: "🇨🇬" },
  { label: "Costa Rica", value: "America/Costa_Rica", flag: "🇨🇷" },
  { label: "Croatia", value: "Europe/Zagreb", flag: "🇭🇷" },
  { label: "Cuba", value: "America/Havana", flag: "🇨🇺" },
  { label: "Cyprus", value: "Asia/Nicosia", flag: "🇨🇾" },
  { label: "Czech Republic", value: "Europe/Prague", flag: "🇨🇿" },
  { label: "Denmark", value: "Europe/Copenhagen", flag: "🇩🇰" },
  { label: "Djibouti", value: "Africa/Djibouti", flag: "🇩🇯" },
  { label: "Dominica", value: "America/Dominica", flag: "🇩🇲" },
  { label: "Dominican Republic", value: "America/Santo_Domingo", flag: "🇩🇴" },
  { label: "Ecuador", value: "America/Guayaquil", flag: "🇪🇨" },
  { label: "Egypt", value: "Africa/Cairo", flag: "🇪🇬" },
  { label: "El Salvador", value: "America/El_Salvador", flag: "🇸🇻" },
  { label: "Equatorial Guinea", value: "Africa/Malabo", flag: "🇬🇶" },
  { label: "Eritrea", value: "Africa/Asmara", flag: "🇪🇷" },
  { label: "Estonia", value: "Europe/Tallinn", flag: "🇪🇪" },
  { label: "Ethiopia", value: "Africa/Addis_Ababa", flag: "🇪🇹" },
  { label: "Fiji", value: "Pacific/Fiji", flag: "🇫🇯" },
  { label: "Finland", value: "Europe/Helsinki", flag: "🇫🇮" },
  { label: "France - Paris", value: "Europe/Paris", flag: "🇫🇷" },
  { label: "Gabon", value: "Africa/Libreville", flag: "🇬🇦" },
  { label: "Gambia", value: "Africa/Banjul", flag: "🇬🇲" },
  { label: "Georgia", value: "Asia/Tbilisi", flag: "🇬🇪" },
  { label: "Germany - Berlin", value: "Europe/Berlin", flag: "🇩🇪" },
  { label: "Germany - Munich", value: "Europe/Berlin", flag: "🇩🇪" },
  { label: "Ghana", value: "Africa/Accra", flag: "🇬🇭" },
  { label: "Greece", value: "Europe/Athens", flag: "🇬🇷" },
  { label: "Grenada", value: "America/Grenada", flag: "🇬🇩" },
  { label: "Guatemala", value: "America/Guatemala", flag: "🇬🇹" },
  { label: "Guinea", value: "Africa/Conakry", flag: "🇬🇳" },
  { label: "Guinea-Bissau", value: "Africa/Bissau", flag: "🇬🇼" },
  { label: "Guyana", value: "America/Guyana", flag: "🇬🇾" },
  { label: "Haiti", value: "America/Port-au-Prince", flag: "🇭🇹" },
  { label: "Honduras", value: "America/Tegucigalpa", flag: "🇭🇳" },
  { label: "Hong Kong", value: "Asia/Hong_Kong", flag: "🇭🇰" },
  { label: "Hungary", value: "Europe/Budapest", flag: "🇭🇺" },
  { label: "Iceland", value: "Atlantic/Reykjavik", flag: "🇮🇸" },
  { label: "India - Mumbai", value: "Asia/Kolkata", flag: "🇮🇳" },
  { label: "India - Delhi", value: "Asia/Kolkata", flag: "🇮🇳" },
  { label: "Indonesia - Jakarta", value: "Asia/Jakarta", flag: "🇮🇩" },
  { label: "Indonesia - Bali", value: "Asia/Makassar", flag: "🇮🇩" },
  { label: "Iran", value: "Asia/Tehran", flag: "🇮🇷" },
  { label: "Iraq", value: "Asia/Baghdad", flag: "🇮🇶" },
  { label: "Ireland", value: "Europe/Dublin", flag: "🇮🇪" },
  { label: "Israel", value: "Asia/Jerusalem", flag: "🇮🇱" },
  { label: "Italy - Rome", value: "Europe/Rome", flag: "🇮🇹" },
  { label: "Italy - Milan", value: "Europe/Rome", flag: "🇮🇹" },
  { label: "Jamaica", value: "America/Jamaica", flag: "🇯🇲" },
  { label: "Japan - Tokyo", value: "Asia/Tokyo", flag: "🇯🇵" },
  { label: "Japan - Osaka", value: "Asia/Tokyo", flag: "🇯🇵" },
  { label: "Jordan", value: "Asia/Amman", flag: "🇯🇴" },
  { label: "Kazakhstan", value: "Asia/Almaty", flag: "🇰🇿" },
  { label: "Kenya", value: "Africa/Nairobi", flag: "🇰🇪" },
  { label: "Kiribati", value: "Pacific/Tarawa", flag: "🇰🇮" },
  { label: "Kuwait", value: "Asia/Kuwait", flag: "🇰🇼" },
  { label: "Kyrgyzstan", value: "Asia/Bishkek", flag: "🇰🇬" },
  { label: "Laos", value: "Asia/Vientiane", flag: "🇱🇦" },
  { label: "Latvia", value: "Europe/Riga", flag: "🇱🇻" },
  { label: "Lebanon", value: "Asia/Beirut", flag: "🇱🇧" },
  { label: "Lesotho", value: "Africa/Maseru", flag: "🇱🇸" },
  { label: "Liberia", value: "Africa/Monrovia", flag: "🇱🇷" },
  { label: "Libya", value: "Africa/Tripoli", flag: "🇱🇾" },
  { label: "Liechtenstein", value: "Europe/Vaduz", flag: "🇱🇮" },
  { label: "Lithuania", value: "Europe/Vilnius", flag: "🇱🇹" },
  { label: "Luxembourg", value: "Europe/Luxembourg", flag: "🇱🇺" },
  { label: "Macau", value: "Asia/Macau", flag: "🇲🇴" },
  { label: "Madagascar", value: "Indian/Antananarivo", flag: "🇲🇬" },
  { label: "Malawi", value: "Africa/Blantyre", flag: "🇲🇼" },
  { label: "Malaysia", value: "Asia/Kuala_Lumpur", flag: "🇲🇾" },
  { label: "Maldives", value: "Indian/Maldives", flag: "🇲🇻" },
  { label: "Mali", value: "Africa/Bamako", flag: "🇲🇱" },
  { label: "Malta", value: "Europe/Malta", flag: "🇲🇹" },
  { label: "Marshall Islands", value: "Pacific/Majuro", flag: "🇲🇭" },
  { label: "Mauritania", value: "Africa/Nouakchott", flag: "🇲🇷" },
  { label: "Mauritius", value: "Indian/Mauritius", flag: "🇲🇺" },
  { label: "Mexico - Mexico City", value: "America/Mexico_City", flag: "🇲🇽" },
  { label: "Mexico - Cancun", value: "America/Cancun", flag: "🇲🇽" },
  { label: "Micronesia", value: "Pacific/Pohnpei", flag: "🇫🇲" },
  { label: "Moldova", value: "Europe/Chisinau", flag: "🇲🇩" },
  { label: "Monaco", value: "Europe/Monaco", flag: "🇲🇨" },
  { label: "Mongolia", value: "Asia/Ulaanbaatar", flag: "🇲🇳" },
  { label: "Montenegro", value: "Europe/Podgorica", flag: "🇲🇪" },
  { label: "Morocco", value: "Africa/Casablanca", flag: "🇲🇦" },
  { label: "Mozambique", value: "Africa/Maputo", flag: "🇲🇿" },
  { label: "Myanmar", value: "Asia/Yangon", flag: "🇲🇲" },
  { label: "Namibia", value: "Africa/Windhoek", flag: "🇳🇦" },
  { label: "Nauru", value: "Pacific/Nauru", flag: "🇳🇷" },
  { label: "Nepal", value: "Asia/Kathmandu", flag: "🇳🇵" },
  { label: "Netherlands", value: "Europe/Amsterdam", flag: "🇳🇱" },
  { label: "New Zealand", value: "Pacific/Auckland", flag: "🇳🇿" },
  { label: "Nicaragua", value: "America/Managua", flag: "🇳🇮" },
  { label: "Niger", value: "Africa/Niamey", flag: "🇳🇪" },
  { label: "Nigeria", value: "Africa/Lagos", flag: "🇳🇬" },
  { label: "North Korea", value: "Asia/Pyongyang", flag: "🇰🇵" },
  { label: "North Macedonia", value: "Europe/Skopje", flag: "🇲🇰" },
  { label: "Norway", value: "Europe/Oslo", flag: "🇳🇴" },
  { label: "Oman", value: "Asia/Muscat", flag: "🇴🇲" },
  { label: "Pakistan", value: "Asia/Karachi", flag: "🇵🇰" },
  { label: "Palau", value: "Pacific/Palau", flag: "🇵🇼" },
  { label: "Panama", value: "America/Panama", flag: "🇵🇦" },
  { label: "Papua New Guinea", value: "Pacific/Port_Moresby", flag: "🇵🇬" },
  { label: "Paraguay", value: "America/Asuncion", flag: "🇵🇾" },
  { label: "Peru", value: "America/Lima", flag: "🇵🇪" },
  { label: "Philippines", value: "Asia/Manila", flag: "🇵🇭" },
  { label: "Poland", value: "Europe/Warsaw", flag: "🇵🇱" },
  { label: "Portugal", value: "Europe/Lisbon", flag: "🇵🇹" },
  { label: "Qatar", value: "Asia/Qatar", flag: "🇶🇦" },
  { label: "Romania", value: "Europe/Bucharest", flag: "🇷🇴" },
  { label: "Russia - Moscow", value: "Europe/Moscow", flag: "🇷🇺" },
  { label: "Russia - St Petersburg", value: "Europe/Moscow", flag: "🇷🇺" },
  { label: "Rwanda", value: "Africa/Kigali", flag: "🇷🇼" },
  { label: "Saint Lucia", value: "America/St_Lucia", flag: "🇱🇨" },
  { label: "Samoa", value: "Pacific/Apia", flag: "🇼🇸" },
  { label: "San Marino", value: "Europe/San_Marino", flag: "🇸🇲" },
  { label: "Saudi Arabia", value: "Asia/Riyadh", flag: "🇸🇦" },
  { label: "Senegal", value: "Africa/Dakar", flag: "🇸🇳" },
  { label: "Serbia", value: "Europe/Belgrade", flag: "🇷🇸" },
  { label: "Seychelles", value: "Indian/Mahe", flag: "🇸🇨" },
  { label: "Sierra Leone", value: "Africa/Freetown", flag: "🇸🇱" },
  { label: "Singapore", value: "Asia/Singapore", flag: "🇸🇬" },
  { label: "Slovakia", value: "Europe/Bratislava", flag: "🇸🇰" },
  { label: "Slovenia", value: "Europe/Ljubljana", flag: "🇸🇮" },
  { label: "Solomon Islands", value: "Pacific/Guadalcanal", flag: "🇸🇧" },
  { label: "Somalia", value: "Africa/Mogadishu", flag: "🇸🇴" },
  { label: "South Africa", value: "Africa/Johannesburg", flag: "🇿🇦" },
  { label: "South Korea", value: "Asia/Seoul", flag: "🇰🇷" },
  { label: "South Sudan", value: "Africa/Juba", flag: "🇸🇸" },
  { label: "Spain - Madrid", value: "Europe/Madrid", flag: "🇪🇸" },
  { label: "Spain - Barcelona", value: "Europe/Madrid", flag: "🇪🇸" },
  { label: "Sri Lanka", value: "Asia/Colombo", flag: "🇱🇰" },
  { label: "Sudan", value: "Africa/Khartoum", flag: "🇸🇩" },
  { label: "Suriname", value: "America/Paramaribo", flag: "🇸🇷" },
  { label: "Sweden", value: "Europe/Stockholm", flag: "🇸🇪" },
  { label: "Switzerland - Zurich", value: "Europe/Zurich", flag: "🇨🇭" },
  { label: "Switzerland - Geneva", value: "Europe/Zurich", flag: "🇨🇭" },
  { label: "Syria", value: "Asia/Damascus", flag: "🇸🇾" },
  { label: "Taiwan", value: "Asia/Taipei", flag: "🇹🇼" },
  { label: "Tajikistan", value: "Asia/Dushanbe", flag: "🇹🇯" },
  { label: "Tanzania", value: "Africa/Dar_es_Salaam", flag: "🇹🇿" },
  { label: "Thailand", value: "Asia/Bangkok", flag: "🇹🇭" },
  { label: "Timor-Leste", value: "Asia/Dili", flag: "🇹🇱" },
  { label: "Togo", value: "Africa/Lome", flag: "🇹🇬" },
  { label: "Tonga", value: "Pacific/Tongatapu", flag: "🇹🇴" },
  { label: "Trinidad and Tobago", value: "America/Port_of_Spain", flag: "🇹🇹" },
  { label: "Tunisia", value: "Africa/Tunis", flag: "🇹🇳" },
  { label: "Turkey", value: "Europe/Istanbul", flag: "🇹🇷" },
  { label: "Turkmenistan", value: "Asia/Ashgabat", flag: "🇹🇲" },
  { label: "Tuvalu", value: "Pacific/Funafuti", flag: "🇹🇻" },
  { label: "Uganda", value: "Africa/Kampala", flag: "🇺🇬" },
  { label: "Ukraine", value: "Europe/Kiev", flag: "🇺🇦" },
  { label: "United Arab Emirates", value: "Asia/Dubai", flag: "🇦🇪" },
  { label: "United Kingdom", value: "Europe/London", flag: "🇬🇧" },
  { label: "USA - New York", value: "America/New_York", flag: "🇺🇸" },
  { label: "USA - Los Angeles", value: "America/Los_Angeles", flag: "🇺🇸" },
  { label: "USA - Chicago", value: "America/Chicago", flag: "🇺🇸" },
  { label: "USA - Houston", value: "America/Chicago", flag: "🇺🇸" },
  { label: "USA - Phoenix", value: "America/Phoenix", flag: "🇺🇸" },
  { label: "USA - Miami", value: "America/New_York", flag: "🇺🇸" },
  { label: "Uruguay", value: "America/Montevideo", flag: "🇺🇾" },
  { label: "Uzbekistan", value: "Asia/Tashkent", flag: "🇺🇿" },
  { label: "Vanuatu", value: "Pacific/Efate", flag: "🇻🇺" },
  { label: "Vatican City", value: "Europe/Vatican", flag: "🇻🇦" },
  { label: "Venezuela", value: "America/Caracas", flag: "🇻🇪" },
  { label: "Vietnam", value: "Asia/Ho_Chi_Minh", flag: "🇻🇳" },
  { label: "Yemen", value: "Asia/Aden", flag: "🇾🇪" },
  { label: "Zambia", value: "Africa/Lusaka", flag: "🇿🇲" },
  { label: "Zimbabwe", value: "Africa/Harare", flag: "🇿🇼" },
];

interface CreateReminderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateReminderDialog = ({ open, onOpenChange }: CreateReminderDialogProps) => {
  const { createReminder } = useReminders();
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const [note, setNote] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [dueTime, setDueTime] = useState("");
  const [timezone, setTimezone] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [status, setStatus] = useState<"call_back" | "send_email" | "deposit_arrived" | "money_in">("call_back");
  const [userRole, setUserRole] = useState<string | null>(null);
  const [selectedEntityId, setSelectedEntityId] = useState<string>("");

  // Fetch user role
  useEffect(() => {
    const fetchUserRole = async () => {
      if (!user) return;
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();
      
      if (roles) {
        setUserRole(roles.role);
      }
    };
    fetchUserRole();
  }, [user]);

  // Fetch leads for AGENT role - simple query without realtime subscription
  const { data: allLeads } = useQuery({
    queryKey: ['leads-for-reminder', effectiveTenantId],
    queryFn: async () => {
      let query = supabase
        .from('leads')
        .select('id, name, email, assigned_to')
        .order('name', { ascending: true })
        .limit(500);

      if (isValidUUID(effectiveTenantId)) {
        query = query.or(`admin_id.eq.${effectiveTenantId},created_by.eq.${effectiveTenantId}`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Lead[];
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    enabled: open && userRole === 'AGENT',
  });
  
  // Fetch clients for SUPER_AGENT/ADMIN/MANAGER roles
  const { clients: allClients } = useClients();

  // Filter leads/clients based on role
  const leads = allLeads?.filter(lead => lead.assigned_to === user?.id);
  const clients = userRole === 'SUPER_AGENT' 
    ? allClients?.filter(client => client.assigned_to === user?.id)
    : allClients; // ADMIN and MANAGER see all clients

  // Check if entity selection is optional (for TENANT_OWNER and MANAGER)
  const isEntityOptional = userRole === 'TENANT_OWNER' || userRole === 'MANAGER';
  
  const [customTitle, setCustomTitle] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Treat "none" as no entity selected
    const hasEntitySelected = selectedEntityId && selectedEntityId !== "none";

    // Validate: entity is required for AGENT and SUPER_AGENT, optional for TENANT_OWNER/MANAGER
    if (!isEntityOptional && !hasEntitySelected) {
      return;
    }

    // For TENANT_OWNER/MANAGER without entity, require a custom title
    if (isEntityOptional && !hasEntitySelected && !customTitle.trim()) {
      return;
    }

    // Get the title based on role and selection
    let reminderTitle = "";
    if (hasEntitySelected) {
      if (userRole === 'AGENT') {
        const lead = leads?.find(l => l.id === selectedEntityId);
        reminderTitle = lead ? `${lead.name} - ${lead.email}` : "Lead Reminder";
      } else {
        const client = clients?.find(c => c.id === selectedEntityId);
        reminderTitle = client ? `${client.name} - ${client.email}` : "Client Reminder";
      }
    } else {
      // No entity selected - use custom title
      reminderTitle = customTitle.trim();
    }

    // Build due_date only if both date and time are provided
    let dueDateValue: string | null = null;
    if (dueDate && dueTime) {
      const dateTimeString = `${dueDate}T${dueTime}:00`;
      let finalDateTime: Date;

      if (timezone) {
        // Convert from target timezone to UTC
        finalDateTime = fromZonedTime(dateTimeString, timezone);
      } else {
        // Use system time
        finalDateTime = new Date(dateTimeString);
      }
      dueDateValue = finalDateTime.toISOString();
    }

    // Determine entity type and id based on role
    let entityType: string | null = null;
    let entityId: string | null = null;
    
    if (userRole === 'AGENT' && hasEntitySelected) {
      entityType = 'lead';
      entityId = selectedEntityId;
    } else if (hasEntitySelected) {
      entityType = 'client';
      entityId = selectedEntityId;
    }

    await createReminder.mutateAsync({
      title: reminderTitle,
      description: note || null,
      due_date: dueDateValue,
      timezone: timezone || null,
      completed: false,
      priority: status,
      related_entity_type: entityType,
      related_entity_id: entityId,
    });

    // Reset form
    setNote("");
    setDueDate("");
    setDueTime("");
    setTimezone("");
    setSearchQuery("");
    setStatus("call_back");
    setSelectedEntityId("");
    setCustomTitle("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Create Reminder</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {userRole === 'AGENT' && (
            <div>
              <Label htmlFor="lead">Lead *</Label>
              <Select value={selectedEntityId} onValueChange={setSelectedEntityId} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select a lead" />
                </SelectTrigger>
                <SelectContent>
                  {leads?.map((lead) => (
                    <SelectItem key={lead.id} value={lead.id}>
                      {lead.name} - {lead.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {(userRole === 'SUPER_AGENT' || userRole === 'TENANT_OWNER' || userRole === 'MANAGER') && (
            <div>
              <Label htmlFor="client">
                Client {isEntityOptional ? "(Optional)" : "*"}
              </Label>
              <Select 
                value={selectedEntityId} 
                onValueChange={setSelectedEntityId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a client" />
                </SelectTrigger>
                <SelectContent>
                  {isEntityOptional && (
                    <SelectItem value="none">No client (general reminder)</SelectItem>
                  )}
                  {clients?.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.name} - {client.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Show title input when no entity is selected for TENANT_OWNER/MANAGER */}
          {isEntityOptional && (!selectedEntityId || selectedEntityId === "none") && (
            <div>
              <Label htmlFor="customTitle">Reminder Title *</Label>
              <Input
                id="customTitle"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                placeholder="Enter reminder title..."
                required
              />
            </div>
          )}

          <div>
            <Label htmlFor="note">Note</Label>
            <Textarea
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Additional notes..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dueDate">Date (Optional)</Label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                min={format(new Date(), "yyyy-MM-dd")}
              />
            </div>
            <div>
              <Label htmlFor="dueTime">Time (Optional)</Label>
              <Input
                id="dueTime"
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="timezone">Target Country (Optional)</Label>
            <div className="relative">
              <Select value={timezone} onValueChange={setTimezone}>
                <SelectTrigger>
                  <SelectValue placeholder="Use system time" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  <div className="sticky top-0 bg-popover z-10 p-2 border-b">
                    <Input
                      placeholder="Search countries..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="h-9"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                  {TIME_ZONES.filter((tz) =>
                    tz.label.toLowerCase().includes(searchQuery.toLowerCase())
                  ).map((tz, index) => (
                    <SelectItem key={`${tz.value}-${index}`} value={tz.value}>
                      {tz.flag} {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Set reminder time for a specific country's timezone
            </p>
          </div>

          <div>
            <Label htmlFor="status">Status</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as "call_back" | "send_email" | "deposit_arrived" | "money_in")}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="call_back">Call back</SelectItem>
                <SelectItem value="send_email">Send email</SelectItem>
                <SelectItem value="deposit_arrived">Deposit Arrived</SelectItem>
                <SelectItem value="money_in">Money in</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createReminder.isPending}>
              {createReminder.isPending ? "Creating..." : "Create Reminder"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
