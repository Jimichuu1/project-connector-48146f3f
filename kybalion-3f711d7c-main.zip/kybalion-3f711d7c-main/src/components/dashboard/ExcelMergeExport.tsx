import { useState, useCallback, useMemo } from "react";
import { useDropzone } from "react-dropzone";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Upload, Download, FileSpreadsheet, X, File, AlertTriangle, Copy, CheckCircle2, ChevronDown, ChevronUp, Globe, Trash2, Loader2, Users, Filter, Search } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { escapeCSVValue, downloadCSV } from "@/lib/exportCsv";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { getCountryFromPhone, getPhonePrefixFromCountry } from "@/lib/phoneCountryCode";
import { getCountryFlag, normalizeCountryName, isKnownCountry } from "@/lib/countryFlags";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useActiveLeadStatuses } from "@/hooks/useLeadStatuses";

interface MergedRow {
  phone: string;
  name: string;
  country: string;
  email: string;
  sourceFile: string;
}

interface UploadedFile {
  name: string;
  rowCount: number;
}

interface ParseError {
  file: string;
  row: number;
  reason: string;
}

// Specific client name aliases are prioritized over generic "name"
const CLIENT_NAME_ALIASES = ["client name", "client_name", "customer name", "customer_name", "contact name", "contact_name", "lead name", "lead_name", "fullname", "full name", "full_name"];
const GENERIC_NAME_ALIASES = ["name"];
const FIRST_NAME_ALIASES = ["first name", "first_name", "firstname", "given name", "given_name", "fname"];
const LAST_NAME_ALIASES = ["last name", "last_name", "lastname", "surname", "surename", "family name", "family_name", "lname"];
const PHONE_ALIASES = ["phone", "phone number", "phone_number", "phonenumber", "mobile", "mobile number", "mobile_number", "tel", "telephone", "contact number", "contact_number", "cell", "cellphone", "cell_phone"];
const EMAIL_ALIASES = ["email", "e-mail", "email address", "email_address", "emailaddress", "mail", "e_mail"];
const COUNTRY_ALIASES = ["country", "nation", "location", "region", "country name", "country_name"];
const AGENT_ALIASES = ["agent", "agent name", "agent_name", "assigned agent", "assigned_agent", "sales agent", "sales_agent", "rep", "representative", "advisor", "account manager", "account_manager", "assigned to", "assigned_to", "assignee", "broker", "salesperson", "sales rep", "sales_rep"];
const PREFIX_ALIASES = ["prefix", "country code", "country_code", "dial code", "dial_code", "phone code", "phone_code", "intl code", "intl_code", "calling code", "calling_code", "cc", "dialing code", "dialing_code"];

function matchHeader(header: string, aliases: string[]): boolean {
  const normalized = header.trim().toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
  if (aliases.includes(normalized)) return true;
  return aliases.some(alias => normalized.includes(alias));
}

function matchHeaderExact(header: string, aliases: string[]): boolean {
  const normalized = header.trim().toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
  return aliases.includes(normalized);
}

function isAgentColumn(header: string): boolean {
  return matchHeader(header, AGENT_ALIASES);
}

function detectColumns(headers: string[]) {
  let nameIdx = -1, firstNameIdx = -1, lastNameIdx = -1, phoneIdx = -1, emailIdx = -1, countryIdx = -1, prefixIdx = -1;
  const claimed = new Set<number>();
  headers.forEach((h, i) => {
    if (isAgentColumn(h)) { claimed.add(i); }
  });

  headers.forEach((h, i) => {
    if (phoneIdx === -1 && !claimed.has(i) && matchHeader(h, PHONE_ALIASES)) { phoneIdx = i; claimed.add(i); }
  });
  headers.forEach((h, i) => {
    if (!claimed.has(i) && emailIdx === -1 && matchHeader(h, EMAIL_ALIASES)) { emailIdx = i; claimed.add(i); }
  });

  // Always look for a dedicated full name / client name column first
  headers.forEach((h, i) => {
    if (!claimed.has(i) && nameIdx === -1 && matchHeader(h, CLIENT_NAME_ALIASES)) { nameIdx = i; claimed.add(i); }
  });

  // Look for first name and last name columns
  headers.forEach((h, i) => {
    if (!claimed.has(i) && firstNameIdx === -1 && matchHeader(h, FIRST_NAME_ALIASES)) { firstNameIdx = i; claimed.add(i); }
  });
  headers.forEach((h, i) => {
    if (!claimed.has(i) && lastNameIdx === -1 && matchHeader(h, LAST_NAME_ALIASES)) { lastNameIdx = i; claimed.add(i); }
  });

  // If no dedicated full name AND no first/last name columns found, try generic "name"
  if (nameIdx === -1 && firstNameIdx === -1 && lastNameIdx === -1) {
    headers.forEach((h, i) => {
      if (!claimed.has(i) && nameIdx === -1 && matchHeaderExact(h, GENERIC_NAME_ALIASES)) { nameIdx = i; claimed.add(i); }
    });
  }
  // If we have only one of first/last but no full name, check for generic "name" as the missing piece
  if (nameIdx === -1 && (firstNameIdx === -1) !== (lastNameIdx === -1)) {
    headers.forEach((h, i) => {
      if (!claimed.has(i) && nameIdx === -1 && matchHeaderExact(h, GENERIC_NAME_ALIASES)) { nameIdx = i; claimed.add(i); }
    });
  }

  headers.forEach((h, i) => {
    if (!claimed.has(i) && prefixIdx === -1 && matchHeaderExact(h, PREFIX_ALIASES)) { prefixIdx = i; claimed.add(i); }
  });
  headers.forEach((h, i) => {
    if (!claimed.has(i) && countryIdx === -1 && matchHeader(h, COUNTRY_ALIASES)) { countryIdx = i; claimed.add(i); }
  });

  return { nameIdx, firstNameIdx, lastNameIdx, phoneIdx, emailIdx, countryIdx, prefixIdx };
}

function looksLikeEmail(val: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
}

function looksLikePhone(val: string): boolean {
  const digits = val.replace(/[\s\-\+\(\)\.]/g, "");
  return /^\d{7,15}$/.test(digits);
}

function hasHeaders(firstRow: string[]): boolean {
  const detected = detectColumns(firstRow);
  if (detected.phoneIdx !== -1) return true;
  return !firstRow.some(cell => looksLikePhone(String(cell)));
}

function looksLikeCountry(val: string): boolean {
  const trimmed = val.trim();
  if (!trimmed || trimmed.length < 2 || trimmed.length > 40) return false;
  if (/\d/.test(trimmed)) return false;
  if (looksLikeEmail(trimmed) || looksLikePhone(trimmed)) return false;
  return /^[a-zA-Z\s\-']+$/.test(trimmed);
}

function nameMatchesEmail(name: string, email: string): boolean {
  if (!name || !email) return false;
  const nameParts = name.toLowerCase().split(/\s+/);
  const emailLocal = email.toLowerCase().split("@")[0] || "";
  return nameParts.some(part => part.length >= 3 && emailLocal.includes(part));
}

function guessColumnsFromData(rows: string[][]): { nameIdx: number; firstNameIdx: number; lastNameIdx: number; phoneIdx: number; emailIdx: number; countryIdx: number; prefixIdx: number } {
  let emailIdx = -1, phoneIdx = -1, countryIdx = -1;
  const sampleRows = rows.slice(0, Math.min(10, rows.length));
  const colCount = sampleRows[0]?.length || 0;

  for (let col = 0; col < colCount; col++) {
    const values = sampleRows.map(r => String(r[col] || "").trim()).filter(Boolean);
    if (emailIdx === -1 && values.some(v => looksLikeEmail(v))) emailIdx = col;
    else if (phoneIdx === -1 && values.some(v => looksLikePhone(v))) phoneIdx = col;
  }

  // Detect country column: most values match known country names/codes
  for (let col = 0; col < colCount; col++) {
    if (col === emailIdx || col === phoneIdx) continue;
    const values = sampleRows.map(r => String(r[col] || "").trim()).filter(Boolean);
    if (values.length === 0) continue;
    const countryMatches = values.filter(v => isKnownCountry(v)).length;
    if (countryMatches / values.length >= 0.5) {
      countryIdx = col;
      console.log(`[ExcelMerge] Guessed country column: ${col} (${countryMatches}/${values.length} known countries)`);
      break;
    }
  }

  const nameCandidates: number[] = [];
  for (let col = 0; col < colCount; col++) {
    if (col === emailIdx || col === phoneIdx || col === countryIdx) continue;
    const values = sampleRows.map(r => String(r[col] || "").trim()).filter(Boolean);
    const isNameLike = values.length > 0 && values.every(v => /^[a-zA-Z\s\-'\.]+$/.test(v) && v.length >= 2);
    if (isNameLike) nameCandidates.push(col);
  }

  let nameIdx = -1;
  if (nameCandidates.length === 1) {
    nameIdx = nameCandidates[0];
  } else if (nameCandidates.length > 1 && emailIdx !== -1) {
    const scores: { col: number; score: number }[] = [];
    for (const col of nameCandidates) {
      let score = 0;
      for (const row of sampleRows) {
        const name = String(row[col] || "").trim();
        const email = String(row[emailIdx] || "").trim();
        if (nameMatchesEmail(name, email)) score++;
      }
      scores.push({ col, score });
    }
    scores.sort((a, b) => b.score - a.score);
    if (scores[0].score >= 1) {
      nameIdx = scores[0].col;
      console.log(`[ExcelMerge] Multiple name candidates [${nameCandidates}], picked col ${nameIdx} (${scores[0].score} email match(es)), skipping agent col(s): [${scores.filter(s => s.col !== nameIdx).map(s => s.col)}]`);
    } else {
      nameIdx = nameCandidates[nameCandidates.length - 1];
      console.log(`[ExcelMerge] No email correlation found, defaulting to col ${nameIdx}`);
    }
  } else if (nameCandidates.length > 1) {
    nameIdx = nameCandidates[0];
  } else {
    for (let col = 0; col < colCount; col++) {
      if (col !== emailIdx && col !== phoneIdx && col !== countryIdx) { nameIdx = col; break; }
    }
  }

  return { nameIdx, firstNameIdx: -1, lastNameIdx: -1, phoneIdx, emailIdx, countryIdx, prefixIdx: -1 };
}

function parseFile(workbook: XLSX.WorkBook, fileName: string): { rows: MergedRow[]; errors: ParseError[] } {
  const rows: MergedRow[] = [];
  const errors: ParseError[] = [];
  if (workbook.SheetNames.length === 0) {
    errors.push({ file: fileName, row: 0, reason: "No worksheet found" });
    return { rows, errors };
  }

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) continue;
    const sheetLabel = workbook.SheetNames.length > 1 ? `${fileName} [${sheetName}]` : fileName;
    const data: string[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
    if (data.length < 1) {
      errors.push({ file: sheetLabel, row: 0, reason: "Sheet is empty or has no data rows" });
      continue;
    }

    const firstRow = data[0].map(String);
    const fileHasHeaders = hasHeaders(firstRow);
    console.log(`[ExcelMerge] ${sheetLabel}, First row:`, firstRow, `hasHeaders: ${fileHasHeaders}`);

    let detected: ReturnType<typeof detectColumns>;
    let dataStartIdx: number;

    if (fileHasHeaders) {
      detected = detectColumns(firstRow);
      dataStartIdx = 1;
      if (data.length < 2) {
        errors.push({ file: sheetLabel, row: 0, reason: "Sheet has headers but no data rows" });
        continue;
      }
    } else {
      detected = guessColumnsFromData(data);
      dataStartIdx = 0;
      console.log(`[ExcelMerge] ${sheetLabel}, No headers detected — guessed columns:`, detected);
    }

    console.log(`[ExcelMerge] ${sheetLabel}, Detected columns:`, detected);

    if (detected.phoneIdx === -1) {
      errors.push({ file: sheetLabel, row: 0, reason: `Could not detect Phone column. First row: [${firstRow.join(", ")}]` });
      continue;
    }

    for (let i = dataStartIdx; i < data.length; i++) {
      const row = data[i];
      if (!row || row.every(cell => !cell)) continue;
      let name = "";
      const d = detected;
      const hasFullName = d.nameIdx !== -1;
      const hasFirstName = d.firstNameIdx !== -1;
      const hasLastName = d.lastNameIdx !== -1;

      if (hasFullName && !hasFirstName && !hasLastName) {
        // Only a full/client name column
        name = String(row[d.nameIdx] || "").trim();
      } else if (hasFirstName && hasLastName) {
        // Dedicated first + last name columns — combine them
        const first = String(row[d.firstNameIdx] || "").trim();
        const last = String(row[d.lastNameIdx] || "").trim();
        name = [first, last].filter(Boolean).join(" ");
      } else if (hasFullName && hasLastName && !hasFirstName) {
        // "Name" column + "Last Name" column — treat Name as first name
        const first = String(row[d.nameIdx] || "").trim();
        const last = String(row[d.lastNameIdx] || "").trim();
        name = [first, last].filter(Boolean).join(" ");
      } else if (hasFullName && hasFirstName && !hasLastName) {
        // "Name" column + "First Name" column — use first name, Name might be last
        const first = String(row[d.firstNameIdx] || "").trim();
        const extra = String(row[d.nameIdx] || "").trim();
        name = [first, extra].filter(Boolean).join(" ");
      } else if (hasFirstName) {
        name = String(row[d.firstNameIdx] || "").trim();
      } else if (hasLastName) {
        name = String(row[d.lastNameIdx] || "").trim();
      } else if (hasFullName) {
        name = String(row[d.nameIdx] || "").trim();
      }
      let phone = detected.phoneIdx !== -1 ? String(row[detected.phoneIdx] || "").trim() : "";
      let email = detected.emailIdx !== -1 ? String(row[detected.emailIdx] || "").trim() : "";
      let country = detected.countryIdx !== -1 ? String(row[detected.countryIdx] || "").trim() : "";
      let prefixVal = detected.prefixIdx !== -1 ? String(row[detected.prefixIdx] || "").trim() : "";

      if (email && !looksLikeEmail(email)) email = "";
      if (phone && !looksLikePhone(phone)) phone = "";
      if (phone) phone = phone.replace(/[\s\-\+\(\)\.]/g, "");
      if (country && (looksLikeEmail(country) || looksLikePhone(country))) country = "";
      if (country) country = normalizeCountryName(country);

      if (!phone) {
        errors.push({ file: sheetLabel, row: i + 1, reason: `Missing phone number${name ? ` (${name})` : ""}` });
        continue;
      }

      // Check if phone already has a recognized international prefix
      const detectedCountry = getCountryFromPhone(phone);
      
      if (detectedCountry && country) {
        // Country column exists — check if it contradicts the auto-detected country
        const normalizedDetected = detectedCountry.toLowerCase().trim();
        const normalizedExplicit = country.toLowerCase().trim();
        if (normalizedDetected !== normalizedExplicit) {
          const correctPrefix = getPhonePrefixFromCountry(country);
          if (correctPrefix) {
            // The entire phone string is a local number — prepend the correct prefix
            let localNumber = phone;
            if (localNumber.startsWith("0")) {
              localNumber = localNumber.substring(1);
            }
            phone = correctPrefix + localNumber;
            console.log(`[ExcelMerge] Country override: detected "${detectedCountry}" but column says "${country}" → prepended ${correctPrefix} → ${phone} (row ${i + 1})`);
          }
        }
      } else if (!detectedCountry) {
        // Phone has no recognized prefix — try to resolve from prefix or country column
        let resolvedPrefix: string | null = null;

        // Try prefix column first
        if (prefixVal) {
          resolvedPrefix = prefixVal.replace(/[^\d]/g, "");
          if (!resolvedPrefix) resolvedPrefix = null;
        }

        // Fallback to country column
        if (!resolvedPrefix && country) {
          resolvedPrefix = getPhonePrefixFromCountry(country);
        }

        if (resolvedPrefix) {
          // Strip leading 0 from local number before prepending prefix
          let localNumber = phone;
          if (localNumber.startsWith("0")) {
            localNumber = localNumber.substring(1);
          }
          phone = resolvedPrefix + localNumber;
          console.log(`[ExcelMerge] Fixed phone: prepended ${resolvedPrefix} → ${phone} (row ${i + 1})`);
        } else {
          errors.push({ file: sheetLabel, row: i + 1, reason: `Phone number missing international prefix${name ? ` (${name}: ${phone})` : ` (${phone})`}` });
        }
      }

      rows.push({
        phone, name,
        country, email, sourceFile: sheetLabel,
      });
    }
  }
  return { rows, errors };
}

function deduplicateRows(rows: MergedRow[]) {
  const seen = new Map<string, MergedRow>();
  const duplicates: MergedRow[] = [];
  for (const row of rows) {
    const key = row.phone.replace(/[\s\-\+\(\)\.]/g, "");
    if (seen.has(key)) duplicates.push(row);
    else seen.set(key, row);
  }
  return { unique: Array.from(seen.values()), duplicates };
}

export const ExcelMergeExport = () => {
  const { effectiveTenantId } = useTenant();
  const { data: leadStatuses } = useActiveLeadStatuses();

  const [open, setOpen] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [allRows, setAllRows] = useState<MergedRow[]>([]);
  const [errors, setErrors] = useState<ParseError[]>([]);
  const [showDuplicates, setShowDuplicates] = useState(false);
  const [showErrors, setShowErrors] = useState(false);
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [countryFilterOpen, setCountryFilterOpen] = useState(true);
  const [removePhoneText, setRemovePhoneText] = useState("");
  const [showRemovePhones, setShowRemovePhones] = useState(false);
  // Remove by Lead Status
  const [showRemoveByStatus, setShowRemoveByStatus] = useState(false);
  const [selectedRemoveStatuses, setSelectedRemoveStatuses] = useState<string[]>([]);
  const [isRemovingByStatus, setIsRemovingByStatus] = useState(false);
  const [statusMatchCount, setStatusMatchCount] = useState<{ dbCount: number; rowCount: number } | null>(null);
  const [isScanningStatus, setIsScanningStatus] = useState(false);
  // Remove Converted Clients
  const [showRemoveConverted, setShowRemoveConverted] = useState(false);
  const [isRemovingConverted, setIsRemovingConverted] = useState(false);
  const [convertedMatchCount, setConvertedMatchCount] = useState<{ dbCount: number; rowCount: number } | null>(null);
  const [isScanningConverted, setIsScanningConverted] = useState(false);

  const { unique, duplicates } = useMemo(() => deduplicateRows(allRows), [allRows]);

  // Enrich rows with country from phone detection
  const enrichedUnique = useMemo(() => {
    return unique.map(row => {
      let country = row.country;
      if (!country || country.trim() === '') {
        const detected = getCountryFromPhone(row.phone);
        if (detected) country = detected;
      }
      if (country) country = normalizeCountryName(country);
      return country !== row.country ? { ...row, country } : row;
    });
  }, [unique]);

  // Compute country stats
  const countryStats = useMemo(() => {
    const counts = new Map<string, number>();
    enrichedUnique.forEach(row => {
      const c = row.country || "Unknown";
      counts.set(c, (counts.get(c) || 0) + 1);
    });
    return Array.from(counts.entries())
      .map(([country, count]) => ({ country, count }))
      .sort((a, b) => b.count - a.count);
  }, [enrichedUnique]);

  // Initialize selectedCountries when countryStats change
  useMemo(() => {
    if (countryStats.length > 0 && selectedCountries.length === 0 && enrichedUnique.length > 0) {
      setSelectedCountries(countryStats.map(s => s.country));
    }
  }, [countryStats, enrichedUnique.length]);

  // Filtered rows based on selected countries
  const filteredUnique = useMemo(() => {
    if (selectedCountries.length === 0 && enrichedUnique.length > 0) return enrichedUnique;
    return enrichedUnique.filter(row => {
      const c = row.country || "Unknown";
      return selectedCountries.includes(c);
    });
  }, [enrichedUnique, selectedCountries]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles: UploadedFile[] = [...files];
    const newRows: MergedRow[] = [...allRows];
    const newErrors: ParseError[] = [...errors];
    let processed = 0;
    acceptedFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const result = parseFile(workbook, file.name);
          newFiles.push({ name: file.name, rowCount: result.rows.length });
          newRows.push(...result.rows);
          newErrors.push(...result.errors);
        } catch (err) {
          console.error(`Excel merge parse error for ${file.name}:`, err);
          newErrors.push({ file: file.name, row: 0, reason: `Failed to parse file: ${err instanceof Error ? err.message : "Unknown error"}` });
        }
        processed++;
        if (processed === acceptedFiles.length) {
          setFiles([...newFiles]);
          setAllRows([...newRows]);
          setErrors([...newErrors]);
          setSelectedCountries([]); // Reset so it re-initializes
          const deduped = deduplicateRows(newRows);
          toast.success(`Processed ${acceptedFiles.length} file(s) — ${deduped.unique.length} unique, ${deduped.duplicates.length} duplicates`);
        }
      };
      reader.readAsArrayBuffer(file);
    });
  }, [files, allRows, errors]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    onDropRejected: (rejections) => {
      rejections.forEach((r) => {
        toast.error(`Rejected: ${r.file.name} — ${r.errors.map(e => e.message).join(", ")}`);
      });
    },
    multiple: true,
    validator: (file) => {
      const ext = file.name.toLowerCase().split(".").pop();
      if (!["xlsx", "xls", "csv"].includes(ext || "")) {
        return { code: "file-invalid-type", message: "Only .xlsx, .xls, and .csv files are accepted" };
      }
      return null;
    },
  });

  const handleDownload = () => {
    if (filteredUnique.length === 0) { toast.error("No data to export"); return; }
    const headers = ["Phone", "Name", "Country", "Email"];
    const csvRows = filteredUnique.map((r) =>
      [escapeCSVValue(r.phone), escapeCSVValue(r.name), escapeCSVValue(r.country), escapeCSVValue(r.email)].join(",")
    );
    downloadCSV([headers.join(","), ...csvRows].join("\n"), `merged-leads-${new Date().toISOString().split("T")[0]}.csv`);
    toast.success(`Exported ${filteredUnique.length} rows`);
  };

  const handleDownloadLeadImportExcel = () => {
    if (filteredUnique.length === 0) { toast.error("No data to export"); return; }
    const wsData = [
      ["Name", "Email", "Phone", "Country"],
      ...filteredUnique.map((r) => [r.name, r.email, r.phone, r.country]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Leads");
    XLSX.writeFile(wb, `leads-import-${new Date().toISOString().split("T")[0]}.xlsx`);
    toast.success(`Exported ${filteredUnique.length} leads for import`);
  };

  const handleClear = () => {
    setFiles([]); setAllRows([]); setErrors([]);
    setShowDuplicates(false); setShowErrors(false);
    setSelectedCountries([]);
    setRemovePhoneText(""); setShowRemovePhones(false);
    setShowRemoveByStatus(false); setSelectedRemoveStatuses([]); setIsRemovingByStatus(false);
    setStatusMatchCount(null); setIsScanningStatus(false);
    setShowRemoveConverted(false); setIsRemovingConverted(false);
    setConvertedMatchCount(null); setIsScanningConverted(false);
  };

  const handleOpenChange = (v: boolean) => {
    setOpen(v);
    if (!v) handleClear();
  };

  const toggleCountry = (country: string) => {
    setSelectedCountries(prev =>
      prev.includes(country)
        ? prev.filter(c => c !== country)
        : [...prev, country]
    );
  };

  const selectAllCountries = () => setSelectedCountries(countryStats.map(s => s.country));
  const deselectAllCountries = () => setSelectedCountries([]);

  const handleRemoveByPhones = () => {
    if (!removePhoneText.trim()) { toast.error("Paste phone numbers first"); return; }
    const phonesToRemove = new Set(
      removePhoneText
        .split(/[\s,;]+/)
        .map(p => p.replace(/[\s\-\+\(\)\.]/g, ""))
        .filter(p => p.length >= 7)
    );
    if (phonesToRemove.size === 0) { toast.error("No valid phone numbers found"); return; }
    const before = allRows.length;
    const remaining = allRows.filter(row => {
      const normalized = row.phone.replace(/[\s\-\+\(\)\.]/g, "");
      return !phonesToRemove.has(normalized);
    });
    const removed = before - remaining.length;
    setAllRows(remaining);
    setSelectedCountries([]);
    setRemovePhoneText("");
    toast.success(`Removed ${removed} row(s) matching ${phonesToRemove.size} phone number(s)`);
  };

  const fetchLeadPhonesByStatus = async (statuses: string[]) => {
    const phones = new Set<string>();
    let from = 0;
    const batchSize = 1000;
    while (true) {
      let query = supabase.from("leads").select("phone").in("status", statuses).not("phone", "is", null).range(from, from + batchSize - 1);
      if (effectiveTenantId) query = query.eq("admin_id", effectiveTenantId);
      const { data, error } = await query;
      if (error) throw error;
      if (!data || data.length === 0) break;
      for (const row of data) { if (row.phone) phones.add(row.phone.replace(/\D/g, "")); }
      if (data.length < batchSize) break;
      from += batchSize;
    }
    return phones;
  };

  const fetchConvertedClientPhones = async () => {
    const phones = new Set<string>();
    let from = 0;
    const batchSize = 1000;
    while (true) {
      let query = supabase.from("clients").select("home_phone").not("converted_from_lead_id", "is", null).not("home_phone", "is", null).range(from, from + batchSize - 1);
      if (effectiveTenantId) query = query.eq("admin_id", effectiveTenantId);
      const { data, error } = await query;
      if (error) throw error;
      if (!data || data.length === 0) break;
      for (const row of data) { if (row.home_phone) phones.add(row.home_phone.replace(/\D/g, "")); }
      if (data.length < batchSize) break;
      from += batchSize;
    }
    return phones;
  };

  const countMatchingRows = (phonesToRemove: Set<string>) => {
    return allRows.filter(row => phonesToRemove.has(row.phone.replace(/\D/g, ""))).length;
  };

  const handleScanByLeadStatus = async () => {
    if (selectedRemoveStatuses.length === 0) { toast.error("Select at least one status"); return; }
    setIsScanningStatus(true);
    setStatusMatchCount(null);
    try {
      const phones = await fetchLeadPhonesByStatus(selectedRemoveStatuses);
      if (phones.size === 0) { toast.info("No leads found with selected statuses"); setIsScanningStatus(false); return; }
      const rowCount = countMatchingRows(phones);
      setStatusMatchCount({ dbCount: phones.size, rowCount });
    } catch (err) {
      console.error("Error scanning by lead status:", err);
      toast.error("Failed to fetch leads from database");
    } finally {
      setIsScanningStatus(false);
    }
  };

  const handleRemoveByLeadStatus = async () => {
    setIsRemovingByStatus(true);
    try {
      const phones = await fetchLeadPhonesByStatus(selectedRemoveStatuses);
      const before = allRows.length;
      const remaining = allRows.filter(row => !phones.has(row.phone.replace(/\D/g, "")));
      const removed = before - remaining.length;
      setAllRows(remaining);
      setSelectedCountries([]);
      setStatusMatchCount(null);
      toast.success(`Removed ${removed} row(s) matching ${phones.size} lead phone(s)`);
    } catch (err) {
      console.error("Error removing by lead status:", err);
      toast.error("Failed to fetch leads from database");
    } finally {
      setIsRemovingByStatus(false);
    }
  };

  const handleScanConvertedClients = async () => {
    setIsScanningConverted(true);
    setConvertedMatchCount(null);
    try {
      const phones = await fetchConvertedClientPhones();
      if (phones.size === 0) { toast.info("No converted clients found"); setIsScanningConverted(false); return; }
      const rowCount = countMatchingRows(phones);
      setConvertedMatchCount({ dbCount: phones.size, rowCount });
    } catch (err) {
      console.error("Error scanning converted clients:", err);
      toast.error("Failed to fetch clients from database");
    } finally {
      setIsScanningConverted(false);
    }
  };

  const handleRemoveByConvertedClients = async () => {
    setIsRemovingConverted(true);
    try {
      const phones = await fetchConvertedClientPhones();
      const before = allRows.length;
      const remaining = allRows.filter(row => !phones.has(row.phone.replace(/\D/g, "")));
      const removed = before - remaining.length;
      setAllRows(remaining);
      setSelectedCountries([]);
      setConvertedMatchCount(null);
      toast.success(`Removed ${removed} row(s) matching ${phones.size} converted client(s)`);
    } catch (err) {
      console.error("Error removing converted clients:", err);
      toast.error("Failed to fetch clients from database");
    } finally {
      setIsRemovingConverted(false);
    }
  };

  const toggleRemoveStatus = (statusName: string) => {
    setStatusMatchCount(null); // reset scan when selection changes
    setSelectedRemoveStatuses(prev =>
      prev.includes(statusName) ? prev.filter(s => s !== statusName) : [...prev, statusName]
    );
  };

  const previewRows = filteredUnique.slice(0, 5);

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <FileSpreadsheet className="h-4 w-4" />
          Merge Excel Documents
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Merge Excel Documents
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Drop zone */}
          <div
            {...getRootProps()}
            className={`flex flex-col items-center justify-center p-6 cursor-pointer transition-colors rounded-lg border-2 border-dashed ${
              isDragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25"
            } hover:border-primary hover:bg-primary/5`}
          >
            <input {...getInputProps()} />
            <Upload className={`h-10 w-10 mb-3 ${isDragActive ? "text-primary" : "text-muted-foreground"}`} />
            <p className="text-sm text-center">
              {isDragActive ? (
                <span className="text-primary font-medium">Drop files here...</span>
              ) : (
                <>
                  <span className="font-medium">Click to upload</span> or drag and drop
                  <br />
                  <span className="text-xs text-muted-foreground">Excel (.xlsx, .xls) or CSV files</span>
                </>
              )}
            </p>
          </div>

          {/* Results */}
          {files.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{files.length} file(s) uploaded</p>
                <Button variant="ghost" size="sm" onClick={handleClear}>
                  <X className="h-4 w-4 mr-1" /> Clear All
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                {files.map((f, i) => (
                  <div key={i} className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-muted text-xs">
                    <File className="h-3 w-3" />
                    {f.name} ({f.rowCount})
                  </div>
                ))}
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-2">
                <Badge variant="default" className="gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  {enrichedUnique.length} unique
                </Badge>
                {duplicates.length > 0 && (
                  <Badge variant="secondary" className="gap-1 cursor-pointer hover:bg-secondary/80"
                    onClick={() => setShowDuplicates(!showDuplicates)}>
                    <Copy className="h-3 w-3" />
                    {duplicates.length} duplicates
                  </Badge>
                )}
                {errors.length > 0 && (
                  <Badge variant="destructive" className="gap-1 cursor-pointer"
                    onClick={() => setShowErrors(!showErrors)}>
                    <AlertTriangle className="h-3 w-3" />
                    {errors.length} error(s)
                  </Badge>
                )}
              </div>

              {/* Errors */}
              {showErrors && errors.length > 0 && (
                <div className="rounded-md border border-destructive/50 bg-destructive/5 p-3 space-y-1">
                  <p className="text-sm font-medium text-destructive">Errors</p>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {errors.map((err, i) => (
                      <p key={i} className="text-xs text-muted-foreground">
                        <span className="font-medium">{err.file}</span>
                        {err.row > 0 && <span> (row {err.row})</span>}: {err.reason}
                      </p>
                    ))}
                  </div>
                </div>
              )}

              {/* Duplicates */}
              {showDuplicates && duplicates.length > 0 && (
                <div className="rounded-md border border-muted p-3 space-y-2">
                  <p className="text-sm font-medium">Duplicates ({duplicates.length})</p>
                  <div className="rounded-md border max-h-60 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Phone</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Country</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Source File</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {duplicates.map((row, i) => (
                          <TableRow key={i}>
                            <TableCell className="font-mono text-xs">{row.phone}</TableCell>
                            <TableCell>{row.name}</TableCell>
                            <TableCell>{row.country}</TableCell>
                            <TableCell>{row.email}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{row.sourceFile}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* Country Filter */}
              {countryStats.length > 0 && (
                <Collapsible open={countryFilterOpen} onOpenChange={setCountryFilterOpen}>
                  <div className="rounded-md border border-border">
                    <CollapsibleTrigger asChild>
                      <button className="flex items-center justify-between w-full p-3 text-sm font-medium hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4" />
                          <span>Country Filter</span>
                          <Badge variant="outline" className="text-xs">
                            {selectedCountries.length}/{countryStats.length}
                          </Badge>
                          {selectedCountries.length < countryStats.length && (
                            <Badge variant="secondary" className="text-xs">
                              {filteredUnique.length} rows
                            </Badge>
                          )}
                        </div>
                        {countryFilterOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <Separator />
                      <div className="p-3 space-y-2">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="text-xs h-7" onClick={selectAllCountries}>
                            Select All
                          </Button>
                          <Button variant="outline" size="sm" className="text-xs h-7" onClick={deselectAllCountries}>
                            Deselect All
                          </Button>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 max-h-48 overflow-y-auto">
                          {countryStats.map(({ country, count }) => (
                            <label
                              key={country}
                              className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 p-1.5 rounded text-sm"
                            >
                              <Checkbox
                                checked={selectedCountries.includes(country)}
                                onCheckedChange={() => toggleCountry(country)}
                              />
                              <span>{getCountryFlag(country)}</span>
                              <span className="truncate flex-1">{country}</span>
                              <span className="text-xs text-muted-foreground">{count}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              )}

              {/* Remove by Phone Numbers */}
              {enrichedUnique.length > 0 && (
                <Collapsible open={showRemovePhones} onOpenChange={setShowRemovePhones}>
                  <div className="rounded-md border border-border">
                    <CollapsibleTrigger asChild>
                      <button className="flex items-center justify-between w-full p-3 text-sm font-medium hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-2">
                          <Trash2 className="h-4 w-4" />
                          <span>Remove by Phone Numbers</span>
                        </div>
                        {showRemovePhones ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <Separator />
                      <div className="p-3 space-y-2">
                        <p className="text-xs text-muted-foreground">
                          Paste phone numbers separated by spaces, newlines, or commas to remove matching rows.
                        </p>
                        <Textarea
                          value={removePhoneText}
                          onChange={(e) => setRemovePhoneText(e.target.value)}
                          placeholder={"12265673711 12268200018 12363134991\nor one per line"}
                          rows={4}
                          className="font-mono text-xs"
                        />
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={handleRemoveByPhones}
                          disabled={!removePhoneText.trim()}
                          className="gap-1"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Remove Matching Rows
                        </Button>
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              )}

              {/* Remove by Lead Status */}
              {enrichedUnique.length > 0 && (
                <Collapsible open={showRemoveByStatus} onOpenChange={setShowRemoveByStatus}>
                  <div className="rounded-md border border-border">
                    <CollapsibleTrigger asChild>
                      <button className="flex items-center justify-between w-full p-3 text-sm font-medium hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-2">
                          <Filter className="h-4 w-4" />
                          <span>Remove by Lead Status</span>
                          {selectedRemoveStatuses.length > 0 && (
                            <Badge variant="secondary" className="text-xs">
                              {selectedRemoveStatuses.length} selected
                            </Badge>
                          )}
                        </div>
                        {showRemoveByStatus ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <Separator />
                      <div className="p-3 space-y-2">
                        <p className="text-xs text-muted-foreground">
                          Select lead statuses to remove matching rows from the merged data.
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 max-h-48 overflow-y-auto">
                          {leadStatuses?.map((status) => (
                            <label
                              key={status.id}
                              className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 p-1.5 rounded text-sm"
                            >
                              <Checkbox
                                checked={selectedRemoveStatuses.includes(status.name)}
                                onCheckedChange={() => toggleRemoveStatus(status.name)}
                              />
                              <span
                                className="h-2.5 w-2.5 rounded-full shrink-0"
                                style={{ backgroundColor: status.color || "#6366f1" }}
                              />
                              <span className="truncate">{status.name}</span>
                            </label>
                          ))}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={handleScanByLeadStatus}
                            disabled={selectedRemoveStatuses.length === 0 || isScanningStatus}
                            className="gap-1"
                          >
                            {isScanningStatus ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
                            Scan Matches
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={handleRemoveByLeadStatus}
                            disabled={selectedRemoveStatuses.length === 0 || isRemovingByStatus}
                            className="gap-1"
                          >
                            {isRemovingByStatus ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                            Remove Matching Rows
                          </Button>
                        </div>
                        {statusMatchCount && (
                          <div className="rounded-md bg-muted p-2 text-xs space-y-0.5">
                            <p><span className="font-medium">{statusMatchCount.dbCount}</span> lead phone(s) found in database</p>
                            <p><span className="font-medium">{statusMatchCount.rowCount}</span> row(s) in merged data match</p>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              )}

              {/* Remove Converted Clients */}
              {enrichedUnique.length > 0 && (
                <Collapsible open={showRemoveConverted} onOpenChange={setShowRemoveConverted}>
                  <div className="rounded-md border border-border">
                    <CollapsibleTrigger asChild>
                      <button className="flex items-center justify-between w-full p-3 text-sm font-medium hover:bg-muted/50 transition-colors">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          <span>Remove Converted Clients</span>
                        </div>
                        {showRemoveConverted ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <Separator />
                      <div className="p-3 space-y-2">
                        <p className="text-xs text-muted-foreground">
                          Remove rows that match phone numbers of clients converted from leads.
                        </p>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={handleScanConvertedClients}
                            disabled={isScanningConverted}
                            className="gap-1"
                          >
                            {isScanningConverted ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
                            Scan Matches
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={handleRemoveByConvertedClients}
                            disabled={isRemovingConverted}
                            className="gap-1"
                          >
                            {isRemovingConverted ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                            Remove Converted Clients
                          </Button>
                        </div>
                        {convertedMatchCount && (
                          <div className="rounded-md bg-muted p-2 text-xs space-y-0.5">
                            <p><span className="font-medium">{convertedMatchCount.dbCount}</span> converted client phone(s) found in database</p>
                            <p><span className="font-medium">{convertedMatchCount.rowCount}</span> row(s) in merged data match</p>
                          </div>
                        )}
                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              )}

              {previewRows.length > 0 && (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Phone</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Country</TableHead>
                        <TableHead>Email</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {previewRows.map((row, i) => (
                        <TableRow key={i}>
                          <TableCell className="font-mono text-xs">{row.phone}</TableCell>
                          <TableCell>{row.name}</TableCell>
                          <TableCell>
                            {row.country && <span className="mr-1">{getCountryFlag(row.country)}</span>}
                            {row.country}
                          </TableCell>
                          <TableCell>{row.email}</TableCell>
                        </TableRow>
                      ))}
                      {filteredUnique.length > 5 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-xs text-muted-foreground">
                            ...and {filteredUnique.length - 5} more rows
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}

              <div className="flex gap-2">
                <Button onClick={handleDownload} className="flex-1 gap-2">
                  <Download className="h-4 w-4" />
                  Download CSV ({filteredUnique.length}{filteredUnique.length !== enrichedUnique.length ? `/${enrichedUnique.length}` : ""})
                </Button>
                <Button onClick={handleDownloadLeadImportExcel} variant="outline" className="flex-1 gap-2">
                  <FileSpreadsheet className="h-4 w-4" />
                  Download Excel for Import ({filteredUnique.length}{filteredUnique.length !== enrichedUnique.length ? `/${enrichedUnique.length}` : ""})
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
