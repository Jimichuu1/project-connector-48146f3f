import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Target } from "lucide-react";
import { CreateTargetDialog } from "@/components/targets/CreateTargetDialog";

export function SendTargetCard() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Card
        onClick={() => setOpen(true)}
        className="cursor-pointer hover:border-primary/40 transition-colors group"
      >
        <CardContent className="flex items-start gap-3 p-4">
          <div className="p-2.5 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
            <Target className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-sm">Send Target</h3>
            <p className="text-xs text-muted-foreground mt-0.5">
              Set weekly/monthly performance targets for agents and super agents.
            </p>
          </div>
        </CardContent>
      </Card>
      <CreateTargetDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
