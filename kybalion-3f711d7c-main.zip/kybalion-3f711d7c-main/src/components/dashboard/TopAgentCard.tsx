import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { startOfMonth, endOfMonth, format } from "date-fns";

interface AgentTotal {
  id: string;
  name: string | null;
  avatar: string | null;
  totalDeposits: number;
  depositCount: number;
}

interface DepositWithProfile {
  agent_id: string | null;
  amount: number;
  status: string;
  profiles: {
    id: string;
    full_name: string | null;
    avatar_url: string | null;
  } | null;
}

interface TopAgentCardProps {
  month?: string; // "yyyy-MM"
  tenantId?: string | null;
}

export function TopAgentCard({ month, tenantId }: TopAgentCardProps = {}) {
  const effectiveMonth = month ?? format(new Date(), "yyyy-MM");

  const { data: topAgent, isLoading } = useQuery({
    queryKey: ['top-agent', effectiveMonth, tenantId ?? null],
    queryFn: async () => {
      const [year, m] = effectiveMonth.split("-").map(Number);
      const monthStart = startOfMonth(new Date(year, m - 1)).toISOString();
      const monthEnd = endOfMonth(new Date(year, m - 1)).toISOString();

      let query = supabase
        .from('deposits')
        .select(`
          agent_id,
          amount,
          status,
          profiles:agent_id (
            id,
            full_name,
            avatar_url
          )
        `)
        .eq('status', 'approved')
        .gte('created_at', monthStart)
        .lte('created_at', monthEnd)
        .not('agent_id', 'is', null);

      if (tenantId) query = query.eq('admin_id', tenantId);

      const { data: deposits, error } = await query;
      if (error) throw error;

      const agentTotals = (deposits as unknown as DepositWithProfile[])?.reduce((acc: Record<string, AgentTotal>, deposit) => {
        const agentId = deposit.agent_id;
        if (!agentId || !deposit.profiles) return acc;

        if (!acc[agentId]) {
          acc[agentId] = {
            id: agentId,
            name: deposit.profiles.full_name,
            avatar: deposit.profiles.avatar_url,
            totalDeposits: 0,
            depositCount: 0,
          };
        }

        acc[agentId].totalDeposits += Number(deposit.amount);
        acc[agentId].depositCount += 1;

        return acc;
      }, {});

      const agents = Object.values(agentTotals || {});
      if (agents.length === 0) return null;

      return agents.reduce((top: AgentTotal | null, current: AgentTotal) =>
        current.totalDeposits > (top?.totalDeposits || 0) ? current : top
      , null);
    },
    refetchInterval: 30000,
  });

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
        <CardHeader>
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!topAgent) {
    return (
      <Card className="bg-gradient-to-br from-muted/50 to-muted/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-muted-foreground" />
            Top Agent This Month
          </CardTitle>
          <CardDescription>No deposits recorded for this month</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Card className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-primary/30 hover:shadow-lg hover:border-primary/50 transition-all duration-300">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="p-2 bg-primary/20 rounded-lg">
            <Trophy className="h-5 w-5 text-primary" />
          </div>
          Top Agent This Month
        </CardTitle>
        <CardDescription>Leading performer in deposits</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Avatar className="h-16 w-16 border-2 border-primary shadow-lg">
              <AvatarImage src={topAgent.avatar || undefined} />
              <AvatarFallback className="bg-primary text-primary-foreground text-lg font-bold">
                {getInitials(topAgent.name || 'Agent')}
              </AvatarFallback>
            </Avatar>
            <div className="absolute -top-1 -right-1 bg-primary rounded-full p-1.5 shadow-md">
              <Trophy className="h-3 w-3 text-primary-foreground" />
            </div>
          </div>

          <div className="flex-1">
            <h3 className="font-bold text-lg">{topAgent.name}</h3>
            <div className="flex items-center gap-3 mt-2">
              <div className="flex items-center gap-1.5">
                <TrendingUp className="h-4 w-4 text-primary" />
                <span className="text-2xl font-bold text-primary">
                  ${topAgent.totalDeposits.toLocaleString()}
                </span>
              </div>
              <Badge variant="outline" className="text-xs font-semibold bg-primary/10 text-primary border-primary/30">
                {topAgent.depositCount} deposit{topAgent.depositCount !== 1 ? 's' : ''}
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
