import { useState, useMemo, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, subDays, subMonths, startOfMonth, endOfMonth } from "date-fns";
import {
  Users, TrendingUp, DollarSign, UserCheck, BarChart3, Clock, Shield,
  ArrowUpRight, FileSpreadsheet, Eye, AlertCircle, Bell,
  Trophy, Briefcase, ListChecks, Phone, Mail, CalendarClock,
  Settings, KeyRound, ShieldAlert, Star, Plus, Target,
  Zap, GitCompareArrows,
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { clientHref } from "@/lib/idCipher";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";


import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { useNotifications } from "@/hooks/useNotifications";

import { exportDashboardToExcel } from "@/lib/dashboardExport";

import { ExcelMergeExport } from "@/components/dashboard/ExcelMergeExport";
import { CompareLeadsDialog } from "@/components/leads/CompareLeadsDialog";


import { CreateLeadDialog } from "@/components/leads/CreateLeadDialog";
import { TopAgentCard } from "@/components/dashboard/TopAgentCard";
import { SendTargetCard } from "@/components/dashboard/SendTargetCard";

const getMonthOptions = () => {
  const options = [];
  for (let i = 0; i < 12; i++) {
    const date = subMonths(new Date(), i);
    options.push({ value: format(date, "yyyy-MM"), label: format(date, "MMMM yyyy") });
  }
  return options;
};



export const TenantOwnerHub = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const { isTenantOwner } = useUserData();
  const tenantId = user?.id;

  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), "yyyy-MM"));
  const monthOptions = useMemo(() => getMonthOptions(), []);

  // Dialogs
  
  const [excelOpen, setExcelOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  
  const [createLeadOpen, setCreateLeadOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Notifications hook for badges
  const { notifications } = useNotifications();
  const unreadCount = notifications?.filter(n => !n.is_read).length || 0;

  // Stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["hub-stats", tenantId, selectedMonth],
    enabled: !!tenantId,
    queryFn: async () => {
      const [year, month] = selectedMonth.split("-").map(Number);
      const monthStart = startOfMonth(new Date(year, month - 1));
      const monthEnd = endOfMonth(new Date(year, month - 1));
      const monthStartISO = monthStart.toISOString();
      const monthEndISO = monthEnd.toISOString();
      const todayISO = format(new Date(), "yyyy-MM-dd");
      const weekAgoISO = format(subDays(new Date(), 7), "yyyy-MM-dd");

      const [
        leadsRes, clientsRes, depositsRes, pendingDepositsRes, pendingConvRes,
        usersRes, todayLeadsRes, todayClientsRes, weekLeadsRes, weekClientsRes,
        prevDepositsRes, transfersRes,
      ] = await Promise.all([
        supabase.from("leads").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).gte("created_at", monthStartISO).lte("created_at", monthEndISO),
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).gte("created_at", monthStartISO).lte("created_at", monthEndISO),
        supabase.from("deposits").select("amount,created_at,super_agent_id").eq("admin_id", tenantId).eq("status", "approved").gte("created_at", monthStartISO).lte("created_at", monthEndISO),
        supabase.from("deposits").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).eq("status", "pending"),
        supabase.from("leads").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).eq("pending_conversion", true),
        supabase.from("profiles").select("id", { count: "exact", head: true }).eq("admin_id", tenantId),
        supabase.from("leads").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).gte("created_at", todayISO),
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).gte("created_at", todayISO),
        supabase.from("leads").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).gte("created_at", weekAgoISO),
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("admin_id", tenantId).gte("created_at", weekAgoISO),
        supabase.from("deposits").select("amount").eq("admin_id", tenantId).eq("status", "approved")
          .gte("created_at", startOfMonth(subMonths(new Date(year, month - 1), 1)).toISOString())
          .lte("created_at", endOfMonth(subMonths(new Date(year, month - 1), 1)).toISOString()),
        supabase.from("clients").select("created_at").eq("admin_id", tenantId).not("transferring_agent", "is", null).gte("created_at", monthStartISO).lte("created_at", monthEndISO),
      ]);

      const transfersByDay: Record<string, number> = {};
      (transfersRes.data || []).forEach((c: any) => {
        const day = format(new Date(c.created_at), "yyyy-MM-dd");
        transfersByDay[day] = (transfersByDay[day] || 0) + 1;
      });
      let topTransfersInDay = 0;
      let topTransfersDay: string | null = null;
      Object.entries(transfersByDay).forEach(([day, n]) => {
        if (n > topTransfersInDay) { topTransfersInDay = n; topTransfersDay = day; }
      });

      const totalDeposits = depositsRes.data?.reduce((s, d) => s + Number(d.amount), 0) || 0;
      const prevDeposits = prevDepositsRes.data?.reduce((s, d) => s + Number(d.amount), 0) || 0;
      const dailySaTotals: Record<string, number> = {};
      (depositsRes.data || []).forEach((d: any) => {
        if (!d.super_agent_id) return;
        const day = format(new Date(d.created_at), "yyyy-MM-dd");
        dailySaTotals[day] = (dailySaTotals[day] || 0) + Number(d.amount);
      });
      const topDeposit = Object.values(dailySaTotals).reduce((m, v) => Math.max(m, v), 0);
      const depositChange = prevDeposits > 0 ? ((totalDeposits - prevDeposits) / prevDeposits) * 100 : null;
      const conversionRate = leadsRes.count && clientsRes.count
        ? ((clientsRes.count / (leadsRes.count + clientsRes.count)) * 100).toFixed(1)
        : "0";

      return {
        totalLeads: leadsRes.count || 0,
        totalClients: clientsRes.count || 0,
        totalUsers: usersRes.count || 0,
        totalDeposits,
        topDeposit,
        depositChange,
        pendingDeposits: pendingDepositsRes.count || 0,
        pendingConversions: pendingConvRes.count || 0,
        todayLeads: todayLeadsRes.count || 0,
        todayClients: todayClientsRes.count || 0,
        weekLeads: weekLeadsRes.count || 0,
        weekClients: weekClientsRes.count || 0,
        conversionRate,
        depositsRaw: depositsRes.data || [],
        topTransfersInDay,
        topTransfersDay,
      };
    },
  });

  // Top 5 agents (transfers) – queried directly because RPC limits to 1
  const { data: topAgents } = useQuery({
    queryKey: ["hub-top-agents-5", tenantId, selectedMonth],
    enabled: !!tenantId,
    queryFn: async () => {
      const [year, month] = selectedMonth.split("-").map(Number);
      const monthStart = startOfMonth(new Date(year, month - 1)).toISOString();
      const monthEnd = endOfMonth(new Date(year, month - 1)).toISOString();
      const { data } = await supabase
        .from("clients")
        .select("transferring_agent")
        .eq("admin_id", tenantId)
        .not("transferring_agent", "is", null)
        .gte("created_at", monthStart)
        .lte("created_at", monthEnd);
      const counts: Record<string, number> = {};
      (data || []).forEach((c: any) => {
        counts[c.transferring_agent] = (counts[c.transferring_agent] || 0) + 1;
      });
      const ids = Object.keys(counts);
      if (!ids.length) return [];
      const { data: profiles } = await supabase.from("profiles").select("id, full_name, email, avatar_url").in("id", ids);
      const profMap: Record<string, { name: string; avatar: string | null }> = {};
      (profiles || []).forEach((p: any) => { profMap[p.id] = { name: p.full_name || p.email || "Unknown", avatar: p.avatar_url || null }; });
      return Object.entries(counts)
        .map(([id, n]) => ({ agent_id: id, agent_name: profMap[id]?.name || "Unknown", agent_avatar: profMap[id]?.avatar || null, transfer_count: n }))
        .sort((a, b) => b.transfer_count - a.transfer_count)
        .slice(0, 5);
    },
  });

  // Top 5 super agents (earnings) – queried directly because RPC limits to 1
  const { data: topSuperAgents } = useQuery({
    queryKey: ["hub-top-sa-5", tenantId, selectedMonth],
    enabled: !!tenantId,
    queryFn: async () => {
      const [year, month] = selectedMonth.split("-").map(Number);
      const monthStart = startOfMonth(new Date(year, month - 1)).toISOString();
      const monthEnd = endOfMonth(new Date(year, month - 1)).toISOString();
      const { data } = await supabase
        .from("deposits")
        .select("super_agent_id, super_agent_amount, split_super_agent_id, split_super_agent_amount")
        .eq("admin_id", tenantId)
        .eq("status", "approved")
        .gte("created_at", monthStart)
        .lte("created_at", monthEnd);
      const totals: Record<string, number> = {};
      (data || []).forEach((d: any) => {
        if (d.super_agent_id) totals[d.super_agent_id] = (totals[d.super_agent_id] || 0) + Number(d.super_agent_amount || 0);
        if (d.split_super_agent_id) totals[d.split_super_agent_id] = (totals[d.split_super_agent_id] || 0) + Number(d.split_super_agent_amount || 0);
      });
      const ids = Object.keys(totals);
      if (!ids.length) return [];
      const { data: profiles } = await supabase.from("profiles").select("id, full_name, email, avatar_url").in("id", ids);
      const profMap: Record<string, { name: string; avatar: string | null }> = {};
      (profiles || []).forEach((p: any) => { profMap[p.id] = { name: p.full_name || p.email || "Unknown", avatar: p.avatar_url || null }; });
      return Object.entries(totals)
        .map(([id, t]) => ({ super_agent_id: id, super_agent_name: profMap[id]?.name || "Unknown", super_agent_avatar: profMap[id]?.avatar || null, total_earnings: t }))
        .sort((a, b) => b.total_earnings - a.total_earnings)
        .slice(0, 5);
    },
  });




  // Clients Received by Super Agent (same logic as Reports page)
  const { data: transfersBySuperAgent } = useQuery({
    queryKey: ["hub-transfers-by-sa", tenantId, selectedMonth],
    enabled: !!tenantId,
    queryFn: async () => {
      const [year, month] = selectedMonth.split("-").map(Number);
      const start = startOfMonth(new Date(year, month - 1));
      const end = endOfMonth(new Date(year, month - 1));
      const { data, error } = await (supabase as any).rpc("get_conversion_metrics", {
        p_start_date: start.toISOString(),
        p_end_date: end.toISOString(),
        p_admin_id: tenantId,
        p_team_member_ids: null,
      });
      if (error) return [];
      const list = (data?.transfers_by_super_agent || []) as Array<{
        super_agent_id: string;
        super_agent_name: string;
        super_agent_email: string;
        clients_received: number;
      }>;
      return list.sort((a, b) => b.clients_received - a.clients_received);
    },
  });


  // Active sessions
  const { data: activeSessions } = useQuery({
    queryKey: ["hub-sessions", tenantId],
    enabled: !!tenantId,
    queryFn: async () => {
      const { data: tenantUsers } = await supabase.from("profiles").select("id").eq("admin_id", tenantId);
      const userIds = tenantUsers?.map(u => u.id) || [];
      if (userIds.length === 0) return 0;
      const { count } = await supabase.from("user_sessions").select("id", { count: "exact", head: true })
        .gt("expires_at", new Date().toISOString()).in("user_id", userIds);
      return count || 0;
    },
  });

  // Favourite clients with deposits
  const { data: favouriteClients, isLoading: favLoading } = useQuery({
    queryKey: ["hub-favourites", tenantId, user?.id],
    enabled: !!tenantId && !!user?.id,
    queryFn: async () => {
      const { data: favs } = await supabase
        .from("favourite_clients")
        .select("client_id, created_at")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      const clientIds = (favs || []).map((f: any) => f.client_id);
      if (clientIds.length === 0) return [];

      const [clientsRes, depositsRes] = await Promise.all([
        supabase.from("clients")
          .select("id, name, email, country, deposits, status, assigned_to")
          .in("id", clientIds)
          .eq("admin_id", tenantId),
        supabase.from("deposits")
          .select("client_id, amount, status, created_at")
          .in("client_id", clientIds)
          .eq("admin_id", tenantId)
          .eq("status", "approved"),
      ]);

      const depositsByClient: Record<string, { total: number; count: number; last: string | null }> = {};
      (depositsRes.data || []).forEach((d: any) => {
        if (!depositsByClient[d.client_id]) depositsByClient[d.client_id] = { total: 0, count: 0, last: null };
        depositsByClient[d.client_id].total += Number(d.amount) || 0;
        depositsByClient[d.client_id].count += 1;
        if (!depositsByClient[d.client_id].last || d.created_at > depositsByClient[d.client_id].last!) {
          depositsByClient[d.client_id].last = d.created_at;
        }
      });

      return (clientsRes.data || [])
        .map((c: any) => ({
          ...c,
          totalDeposits: depositsByClient[c.id]?.total || 0,
          depositCount: depositsByClient[c.id]?.count || 0,
          lastDepositAt: depositsByClient[c.id]?.last || null,
        }))
        .sort((a, b) => b.totalDeposits - a.totalDeposits);
    },
  });


  const handleExport = async () => {
    setIsExporting(true);
    try {
      await exportDashboardToExcel({ tenantId: tenantId!, month: selectedMonth });
    } finally {
      setIsExporting(false);
    }
  };

  const needsAttention = [
    { label: "Pending deposits", value: stats?.pendingDeposits || 0, icon: DollarSign, to: "/convert-queue" },
    { label: "Pending conversions", value: stats?.pendingConversions || 0, icon: UserCheck, to: "/convert-queue" },
    { label: "Unread notifications", value: unreadCount, icon: Bell, to: "/notifications" },
  ];

  const shortcuts = [
    { label: "Leads", icon: TrendingUp, to: "/leads", badge: stats?.totalLeads },
    { label: "Clients", icon: UserCheck, to: "/clients", badge: stats?.totalClients },
    { label: "Convert Queue", icon: ListChecks, to: "/convert-queue", badge: stats?.pendingConversions },
    { label: "Pipeline", icon: Target, to: "/pipeline" },
    { label: "Reports", icon: BarChart3, to: "/reports" },
    { label: "Salary", icon: DollarSign, to: "/salary" },
    { label: "Attendance", icon: Clock, to: "/attendance" },
    { label: "Team", icon: Users, to: "/team-management" },
    { label: "Users", icon: KeyRound, to: "/user-management" },
    { label: "Security", icon: ShieldAlert, to: "/security-monitoring" },
    { label: "Notifications", icon: Bell, to: "/notifications", badge: unreadCount },
    { label: "Settings", icon: Settings, to: "/settings" },
    { label: "Favourites", icon: Star, to: "/favourite-clients" },
  ];

  return (
    <div className="pb-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Briefcase className="h-6 w-6 text-primary" />
            Hub
          </h1>
          <p className="text-muted-foreground text-sm mt-1">Your central command — KPIs, tools, reports & shortcuts</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {monthOptions.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" className="gap-2"><Plus className="h-4 w-4" />Quick Create</Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setCreateLeadOpen(true)}>
                <TrendingUp className="h-4 w-4 mr-2" />New Lead
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("/user-management")}>
                <KeyRound className="h-4 w-4 mr-2" />New User
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Badge variant="secondary" className="text-xs">
            <Shield className="h-3 w-3 mr-1" />Tenant Owner
          </Badge>
        </div>
      </div>

      <div className="w-full space-y-10">
        {/* OVERVIEW */}
        <section className="space-y-6">
          <SectionHeader title="Overview" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <KpiCard title="Team" value={stats?.totalUsers} icon={Users} loading={statsLoading} hint={`${activeSessions || 0} active`} />
            <KpiCard
              title="Top Transfers in a Day"
              value={stats?.topTransfersInDay || 0}
              icon={UserCheck}
              loading={statsLoading}
              hint={stats?.topTransfersDay ? format(new Date(stats.topTransfersDay), "MMM d") : "No transfers"}
            />
            <KpiCard title="Clients" value={stats?.totalClients} icon={UserCheck} loading={statsLoading} hint={`+${stats?.todayClients || 0} today`} />
            <KpiCard
              title="Deposits"
              value={stats?.totalDeposits ? `$${stats.totalDeposits.toLocaleString()}` : "$0"}
              icon={DollarSign}
              loading={statsLoading}
              hint={stats?.depositChange != null ? `${stats.depositChange >= 0 ? "+" : ""}${stats.depositChange.toFixed(1)}% vs last` : "—"}
            />
            
            <KpiCard
              title="Top Deposit"
              value={`$${(stats?.topDeposit || 0).toLocaleString()}`}
              icon={Trophy}
              loading={statsLoading}
              hint="Highest this month"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <TopAgentCard month={selectedMonth} tenantId={tenantId} />
            <Card className="bg-gradient-to-br from-blue-500/10 via-blue-500/5 to-transparent border-blue-500/30 hover:shadow-lg hover:border-blue-500/50 transition-all duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="p-2 bg-blue-500/20 rounded-lg">
                    <UserCheck className="h-5 w-5 text-blue-500" />
                  </div>
                  Top Transferring Agent
                </CardTitle>
                <CardDescription>Most client transfers this month</CardDescription>
              </CardHeader>
              <CardContent>
                {topAgents && topAgents.length > 0 ? (
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Avatar className="h-16 w-16 border-2 border-blue-500 shadow-lg">
                        <AvatarImage src={topAgents[0].agent_avatar || undefined} />
                        <AvatarFallback className="bg-blue-500 text-white text-lg font-bold">
                          {topAgents[0].agent_name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -top-1 -right-1 bg-blue-500 rounded-full p-1.5 shadow-md">
                        <UserCheck className="h-3 w-3 text-white" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-lg truncate">{topAgents[0].agent_name}</h3>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-2xl font-bold text-blue-600">{topAgents[0].transfer_count}</span>
                        <Badge variant="outline" className="text-xs font-semibold bg-blue-500/10 text-blue-600 border-blue-500/30">
                          transfer{topAgents[0].transfer_count !== 1 ? "s" : ""}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">No transfers yet</div>
                )}
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-emerald-500/10 via-emerald-500/5 to-transparent border-emerald-500/30 hover:shadow-lg hover:border-emerald-500/50 transition-all duration-300">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className="p-2 bg-emerald-500/20 rounded-lg">
                    <Trophy className="h-5 w-5 text-emerald-500" />
                  </div>
                  Top Deposit Super Agent
                </CardTitle>
                <CardDescription>Highest super agent earnings this month</CardDescription>
              </CardHeader>
              <CardContent>
                {topSuperAgents && topSuperAgents.length > 0 ? (
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Avatar className="h-16 w-16 border-2 border-emerald-500 shadow-lg">
                        <AvatarImage src={topSuperAgents[0].super_agent_avatar || undefined} />
                        <AvatarFallback className="bg-emerald-500 text-white text-lg font-bold">
                          {topSuperAgents[0].super_agent_name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -top-1 -right-1 bg-emerald-500 rounded-full p-1.5 shadow-md">
                        <Trophy className="h-3 w-3 text-white" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-lg truncate">{topSuperAgents[0].super_agent_name}</h3>
                      <div className="flex items-center gap-3 mt-2">
                        <TrendingUp className="h-4 w-4 text-emerald-600" />
                        <span className="text-2xl font-bold text-emerald-600">
                          ${topSuperAgents[0].total_earnings.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">No deposits yet</div>
                )}
              </CardContent>
            </Card>
          </div>

          {(stats?.pendingConversions || 0) > 0 && (
            <Card className="border-warning/40 bg-warning/5 cursor-pointer hover:bg-warning/10" onClick={() => navigate("/convert-queue")}>
              <CardContent className="flex items-center justify-between p-4">
                <div className="flex items-center gap-3">
                  <AlertCircle className="h-5 w-5 text-warning" />
                  <div>
                    <p className="font-medium">{stats?.pendingConversions} lead conversion{stats?.pendingConversions === 1 ? "" : "s"} awaiting approval</p>
                    <p className="text-sm text-muted-foreground">Click to review in Convert Queue</p>
                  </div>
                </div>
                <ArrowUpRight className="h-5 w-5 text-muted-foreground" />
              </CardContent>
            </Card>
          )}
        </section>

        {/* TOOLS */}
        <section className="space-y-6">
          <SectionHeader title="Tools" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <SendTargetCard />
            <ToolCard
              title="Excel Merge & Dedupe"
              description="Merge multiple Excel/CSV files, dedupe phones, export."
              icon={FileSpreadsheet}
              onClick={() => setExcelOpen(true)}
            />
            <ToolCard
              title="Compare Leads/Clients"
              description="Paste a list — find existing leads or clients."
              icon={GitCompareArrows}
              onClick={() => setCompareOpen(true)}
            />
            <ToolCard
              title="Export Dashboard to Excel"
              description="Download a multi-sheet snapshot of your KPIs."
              icon={FileSpreadsheet}
              onClick={handleExport}
              loading={isExporting}
            />
            <ToolCard
              title="IP Block Preview"
              description="Preview the access-denied screen geo-blocked users see."
              icon={Eye}
              onClick={() => navigate("/access-denied-preview")}
            />
          </div>
        </section>


        {/* CLIENTS RECEIVED BY SUPER AGENT */}
        <section className="space-y-4">
          <SectionHeader title="Clients Received by Super Agent" />
          {transfersBySuperAgent && transfersBySuperAgent.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
              {transfersBySuperAgent.map((sa) => (
                <div key={sa.super_agent_id} className="rounded-lg border bg-card p-3 space-y-1">
                  <div className="font-medium text-sm truncate">{sa.super_agent_name}</div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-xs text-muted-foreground">Clients</span>
                    <span className="text-primary text-lg font-extrabold">{sa.clients_received}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="py-8 text-center text-sm text-muted-foreground">
                No transfers to super agents this month.
              </CardContent>
            </Card>
          )}
        </section>

        {/* QUICK REPORTS */}
        <section className="space-y-4">
          <SectionHeader title="Quick Reports" />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-base">Top 5 Agents (Transfers)</CardTitle>
                  <CardDescription>This month</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => navigate("/reports")}>View →</Button>
              </CardHeader>
              <CardContent>
                {topAgents && topAgents.length ? (
                  <ol className="space-y-2">
                    {topAgents.map((a: any, i: number) => (
                      <li key={a.agent_id} className="flex items-center justify-between text-sm">
                        <span className="flex items-center gap-2">
                          <span className="w-5 text-xs text-muted-foreground">{i + 1}.</span>
                          {a.agent_name || "Unknown"}
                        </span>
                        <Badge variant="secondary">{a.transfer_count} transfers</Badge>
                      </li>
                    ))}
                  </ol>
                ) : <EmptyMini text="No transfer data" />}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-base">Top 5 Super Agents (Earnings)</CardTitle>
                  <CardDescription>This month</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => navigate("/reports")}>View →</Button>
              </CardHeader>
              <CardContent>
                {topSuperAgents && topSuperAgents.length ? (
                  <ol className="space-y-2">
                    {topSuperAgents.map((a: any, i: number) => (
                      <li key={a.super_agent_id} className="flex items-center justify-between text-sm">
                        <span className="flex items-center gap-2">
                          <span className="w-5 text-xs text-muted-foreground">{i + 1}.</span>
                          {a.super_agent_name || "Unknown"}
                        </span>
                        <Badge variant="secondary">${Number(a.total_earnings).toLocaleString()}</Badge>
                      </li>
                    ))}
                  </ol>
                ) : <EmptyMini text="No earnings data" />}
              </CardContent>
            </Card>
          </div>
        </section>


        <section className="space-y-4">
          <SectionHeader title="Favourite Clients" />
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5 text-primary" fill="currentColor" />
                Favourites & Their Deposits
              </CardTitle>
              <CardDescription>
                Your starred clients ranked by total approved deposits
              </CardDescription>
            </CardHeader>
            <CardContent>
              {favLoading ? (
                <div className="space-y-2">
                  {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : favouriteClients && favouriteClients.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b text-left text-xs text-muted-foreground">
                        <th className="py-2 px-2 font-medium">#</th>
                        <th className="py-2 px-2 font-medium">Client</th>
                        <th className="py-2 px-2 font-medium">Country</th>
                        <th className="py-2 px-2 font-medium text-right">Deposits</th>
                        <th className="py-2 px-2 font-medium text-right">Count</th>
                        <th className="py-2 px-2 font-medium">Last Deposit</th>
                        <th className="py-2 px-2 font-medium text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {favouriteClients.map((c: any, idx: number) => (
                        <tr key={c.id} className="border-b border-border/50 last:border-0 hover:bg-accent/30 transition-colors">
                          <td className="py-3 px-2 text-muted-foreground">{idx + 1}</td>
                          <td className="py-3 px-2">
                            <div className="font-medium truncate max-w-[200px]">{c.name}</div>
                            {c.email && <div className="text-xs text-muted-foreground truncate max-w-[200px]">{c.email}</div>}
                          </td>
                          <td className="py-3 px-2 text-muted-foreground">{c.country || "—"}</td>
                          <td className="py-3 px-2 text-right font-semibold tabular-nums">
                            ${c.totalDeposits.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                          </td>
                          <td className="py-3 px-2 text-right tabular-nums">
                            <Badge variant={c.depositCount > 0 ? "secondary" : "outline"} className="text-xs">
                              {c.depositCount}
                            </Badge>
                          </td>
                          <td className="py-3 px-2 text-xs text-muted-foreground whitespace-nowrap">
                            {c.lastDepositAt ? format(new Date(c.lastDepositAt), "MMM d, yyyy") : "—"}
                          </td>
                          <td className="py-3 px-2 text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(clientHref(c.id))}
                            >
                              View
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="border-t-2">
                        <td colSpan={3} className="py-3 px-2 font-semibold">Total ({favouriteClients.length})</td>
                        <td className="py-3 px-2 text-right font-bold tabular-nums text-primary">
                          ${favouriteClients.reduce((s: number, c: any) => s + c.totalDeposits, 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="py-3 px-2 text-right tabular-nums font-semibold">
                          {favouriteClients.reduce((s: number, c: any) => s + c.depositCount, 0)}
                        </td>
                        <td colSpan={2} />
                      </tr>
                    </tfoot>
                  </table>
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <Star className="h-10 w-10 mx-auto mb-3 opacity-40" />
                  <p className="text-sm">No favourite clients yet.</p>
                  <Button variant="link" size="sm" onClick={() => navigate("/clients")} className="mt-2">
                    Browse clients to star favourites →
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </div>

      {/* Dialogs / overlays */}
      {excelOpen && (
        <div className="hidden">{/* ExcelMergeExport renders its own trigger */}</div>
      )}
      <ExcelMergeExportControlled open={excelOpen} onOpenChange={setExcelOpen} />
      <CompareLeadsDialog open={compareOpen} onOpenChange={setCompareOpen} />
      
      {createLeadOpen && <CreateLeadDialog open={createLeadOpen} onOpenChange={setCreateLeadOpen} />}
    </div>
  );
};

// Wrapper that hides the built-in trigger and only opens via the controlled state
const ExcelMergeExportControlled = ({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) => {
  if (!open) return null;
  // Render in a hidden container; ExcelMergeExport manages its own Dialog open state internally,
  // so we mount a fresh instance and auto-open it via a click on its trigger.
  return (
    <div className="contents">
      <AutoOpenExcel onClose={() => onOpenChange(false)} />
    </div>
  );
};

const AutoOpenExcel = ({ onClose }: { onClose: () => void }) => {
  // Render ExcelMergeExport and programmatically click its trigger on mount.
  const ref = (node: HTMLDivElement | null) => {
    if (node) {
      const btn = node.querySelector("button");
      if (btn && !btn.dataset.autoOpened) {
        btn.dataset.autoOpened = "1";
        (btn as HTMLButtonElement).click();
      }
    }
  };
  // Watch for dialog close via Escape/overlay — listen for visibility of dialog content.
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  return (
    <div ref={ref} className="fixed -left-[9999px] top-0">
      <ExcelMergeExport />
    </div>
  );
};

const KpiCard = ({ title, value, icon: Icon, loading, hint }: any) => (
  <Card className="bg-gradient-to-br from-card to-card/80">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-xs font-medium text-muted-foreground">{title}</CardTitle>
      <div className="p-1.5 rounded-md bg-primary/10"><Icon className="h-3.5 w-3.5 text-primary" /></div>
    </CardHeader>
    <CardContent>
      {loading ? <Skeleton className="h-7 w-16" /> : (
        <>
          <div className="text-2xl font-bold">{value ?? 0}</div>
          {hint && <p className="text-[11px] text-muted-foreground mt-1">{hint}</p>}
        </>
      )}
    </CardContent>
  </Card>
);

const ToolCard = ({ title, description, icon: Icon, onClick, loading }: any) => (
  <button
    onClick={onClick}
    disabled={loading}
    className="text-left rounded-lg border bg-card p-4 hover:border-primary/40 hover:shadow-md transition-all disabled:opacity-60"
  >
    <div className="flex items-start gap-3">
      <div className="p-2 rounded-md bg-primary/10 text-primary"><Icon className="h-5 w-5" /></div>
      <div>
        <h3 className="font-semibold text-sm">{title}{loading && "…"}</h3>
        <p className="text-xs text-muted-foreground mt-1">{description}</p>
      </div>
    </div>
  </button>
);

const EmptyMini = ({ text }: { text: string }) => (
  <p className="text-sm text-muted-foreground text-center py-6">{text}</p>
);

const SectionHeader = ({ title }: { title: string }) => (
  <div className="flex items-center gap-3">
    <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
    <div className="flex-1 h-px bg-border" />
  </div>
);

export default TenantOwnerHub;
