import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

interface DeleteUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  assignedClientsCount: number;
  assignedLeadsCount: number;
  onConfirm: () => Promise<void>;
}

export function DeleteUserDialog({
  open,
  onOpenChange,
  userId,
  assignedClientsCount,
  assignedLeadsCount,
  onConfirm,
}: DeleteUserDialogProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleConfirm = async () => {
    setIsLoading(true);
    try {
      await onConfirm();
      onOpenChange(false);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to delete user");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Confirm Delete User</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-sm text-muted-foreground mb-4">
            This user has assigned items that will be unassigned:
          </p>
          <ul className="list-disc list-inside space-y-1 text-sm">
            {assignedClientsCount > 0 && (
              <li>
                <strong>{assignedClientsCount}</strong> client{assignedClientsCount !== 1 ? 's' : ''} will be unassigned
              </li>
            )}
            {assignedLeadsCount > 0 && (
              <li>
                <strong>{assignedLeadsCount}</strong> lead{assignedLeadsCount !== 1 ? 's' : ''} will be unassigned
              </li>
            )}
          </ul>
          <p className="text-sm text-destructive mt-4">
            Are you sure you want to delete this user? This action cannot be undone.
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={handleConfirm} disabled={isLoading}>
            {isLoading ? "Deleting..." : "Delete User"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
