import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { z } from "zod";
import { UserWithIpWhitelist, AppRole } from "@/types/users";
import { updateProfile, updateUserRole } from "@/services/userService";
import { fullNameSchema } from "@/utils/validation";
import { supabase } from "@/integrations/supabase/client";

interface EditUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: UserWithIpWhitelist | null;
  onSuccess: () => void;
  onResetPassword: (user: UserWithIpWhitelist) => void;
  currentUserRole?: AppRole | null;
}

export function EditUserDialog({
  open,
  onOpenChange,
  user,
  onSuccess,
  onResetPassword,
  currentUserRole,
}: EditUserDialogProps) {
  const [editedFullName, setEditedFullName] = useState("");
  const [editedUsername, setEditedUsername] = useState("");
  const [selectedRole, setSelectedRole] = useState<AppRole>("AGENT");
  const [isCloser, setIsCloser] = useState(false);
  const [nameError, setNameError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Sync local state from user prop whenever dialog opens
  useEffect(() => {
    if (open && user) {
      setEditedFullName(user.full_name || "");
      setEditedUsername(user.username || "");
      setSelectedRole(user.role || "AGENT");
      setNameError(null);
      // Load is_closer flag from profile
      supabase
        .from("profiles")
        .select("is_closer")
        .eq("id", user.id)
        .maybeSingle()
        .then(({ data }) => {
          setIsCloser(Boolean((data as { is_closer?: boolean } | null)?.is_closer));
        });
    }
  }, [open, user]);

  // Get available roles based on current user's role
  // Hierarchy: SUPER_ADMIN > ADMIN > MANAGER > SUPER_AGENT > AGENT
  const getAvailableRoles = (): { value: AppRole; label: string }[] => {
    if (currentUserRole === "SUPER_ADMIN") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
        { value: "TEAM_LEADER", label: "Team Leader" },
        { value: "MANAGER", label: "Manager" },
        { value: "TENANT_OWNER", label: "Tenant Owner" },
      ];
    }
    
    if (currentUserRole === "TENANT_OWNER") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
        { value: "TEAM_LEADER", label: "Team Leader" },
        { value: "MANAGER", label: "Manager" },
      ];
    }
    
    if (currentUserRole === "MANAGER") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
        { value: "TEAM_LEADER", label: "Team Leader" },
      ];
    }

    if (currentUserRole === "TEAM_LEADER") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
      ];
    }
    
    return [];
  };

  const availableRoles = getAvailableRoles();
  
  // Check if user can edit this user's role based on hierarchy
  const canEditRole = () => {
    if (!user) return false;
    
    if (user.role === "SUPER_ADMIN") return false;
    if (user.role === "TENANT_OWNER" && currentUserRole !== "SUPER_ADMIN") return false;
    if (user.role === "MANAGER" && !["SUPER_ADMIN", "TENANT_OWNER"].includes(currentUserRole || "")) return false;
    if (user.role === "TEAM_LEADER" && !["SUPER_ADMIN", "TENANT_OWNER", "MANAGER"].includes(currentUserRole || "")) return false;
    if (currentUserRole === "MANAGER" && !["SUPER_AGENT", "AGENT", "TEAM_LEADER"].includes(user.role || "")) return false;
    if (currentUserRole === "TEAM_LEADER" && !["SUPER_AGENT", "AGENT"].includes(user.role || "")) return false;
    
    return true;
  };

  // Sync state when user changes
  const handleOpenChange = (isOpen: boolean) => {
    if (isOpen && user) {
      setEditedFullName(user.full_name || "");
      setEditedUsername(user.username || "");
      setSelectedRole(user.role || "AGENT");
      setNameError(null);
    }
    onOpenChange(isOpen);
  };

  const handleSave = async () => {
    if (!user) return;

    // Validate name
    try {
      fullNameSchema.parse(editedFullName);
    } catch (error) {
      if (error instanceof z.ZodError) {
        setNameError(error.errors[0].message);
        return;
      }
    }

    setIsLoading(true);
    try {
      // Update profile (include is_closer when AGENT; force false otherwise)
      await updateProfile(user.id, {
        full_name: editedFullName.trim(),
        username: editedUsername.trim(),
        is_closer: selectedRole === "AGENT" ? isCloser : false,
      });

      // Update role
      await updateUserRole(user.id, selectedRole);

      toast.success("User updated successfully");
      setNameError(null);
      onOpenChange(false);
      onSuccess();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to update user");
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit User</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="edit-fullname">Full Name</Label>
            <Input
              id="edit-fullname"
              value={editedFullName}
              onChange={(e) => {
                setEditedFullName(e.target.value);
                setNameError(null);
              }}
              placeholder="Enter full name"
            />
            {nameError && (
              <p className="text-sm text-destructive">{nameError}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-username">Username</Label>
            <Input
              id="edit-username"
              value={editedUsername}
              onChange={(e) => setEditedUsername(e.target.value)}
              placeholder="Enter username"
            />
          </div>
          <div className="space-y-2">
            <Label>Role</Label>
            <Select 
              value={selectedRole} 
              onValueChange={(v) => setSelectedRole(v as AppRole)}
              disabled={!canEditRole()}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {canEditRole() ? (
                  availableRoles.map((r) => (
                    <SelectItem key={r.value} value={r.value}>
                      {r.label}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value={user?.role || "AGENT"}>
                    {user?.role === "SUPER_ADMIN" ? "SuperAdmin" : user?.role === "TENANT_OWNER" ? "Tenant Owner" : user?.role}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
            {!canEditRole() && (
              <p className="text-xs text-muted-foreground">
                {user?.role === "SUPER_ADMIN" 
                  ? "SuperAdmin role cannot be changed" 
                  : "Only SuperAdmin can change Admin roles"}
              </p>
            )}
          </div>

          {selectedRole === "AGENT" && (
            <div className="flex items-center justify-between rounded-md border p-3">
              <div className="space-y-0.5 pr-3">
                <Label htmlFor="edit_is_closer" className="cursor-pointer text-sm font-medium">
                  Closer Agent
                </Label>
                <p className="text-xs text-muted-foreground">
                  Applies the dedicated Closer Agent salary tiers.
                </p>
              </div>
              <Switch
                id="edit_is_closer"
                checked={isCloser}
                onCheckedChange={setIsCloser}
              />
            </div>
          )}
        </div>
        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={() => onResetPassword(user)}
            className="w-full sm:w-auto"
          >
            Reset Password
          </Button>
          <div className="flex gap-2 w-full sm:w-auto">
            <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isLoading}>
              {isLoading ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
