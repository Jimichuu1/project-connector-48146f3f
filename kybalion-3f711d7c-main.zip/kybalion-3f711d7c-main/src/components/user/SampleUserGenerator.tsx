import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Users, Loader2 } from "lucide-react";

export const SampleUserGenerator = () => {
  const [isGenerating, setIsGenerating] = useState(false);

  const generateSampleUsers = async () => {
    setIsGenerating(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast.error("You must be logged in to generate sample data");
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-sample-users`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            "Content-Type": "application/json",
          },
        }
      );

      const result = await response.json();

      if (result.success) {
        toast.success(result.message);
        // Display user credentials
        toast.info(
          "Sample users created. Default password for agents: Agent123!@# and super agents: SuperAgent123!@#",
          { duration: 10000 }
        );
        
        // Refresh the page to show new users
        window.location.reload();
      } else {
        toast.error(result.error || "Failed to generate sample users");
      }
    } catch (error) {
      console.error("Error generating sample users:", error);
      const message = error instanceof Error ? error.message : "Failed to generate sample users";
      toast.error(message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Sample User Data
        </CardTitle>
        <CardDescription>
          Generate sample agent and super agent users for testing
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button
          size="sm"
          onClick={generateSampleUsers}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            <>
              <Users className="mr-2 h-4 w-4" />
              Generate Sample Users
            </>
          )}
        </Button>
        <p className="text-xs text-muted-foreground mt-3">
          Creates 3 agents and 2 super agents with pre-set credentials
        </p>
      </CardContent>
    </Card>
  );
};
