import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Edit, Plus, X } from "lucide-react";
import { UserWithIpWhitelist, AppRole } from "@/types/users";
import { format } from "date-fns";

interface UserTableProps {
  users: UserWithIpWhitelist[];
  isLoading: boolean;
  editingIpUserId: string | null;
  newIpAddress: string;
  currentUserRole?: AppRole | null;
  isSuperAdmin?: boolean;
  onEdit: (user: UserWithIpWhitelist) => void;
  onDelete: (userId: string) => void;
  onStartAddIp: (userId: string) => void;
  onCancelAddIp: () => void;
  onIpAddressChange: (value: string) => void;
  onAddIp: (userId: string) => void;
  onRemoveIp: (ipId: string) => void;
  canDeleteUser: (targetUserRole?: AppRole) => boolean;
}

export function UserTable({
  users,
  isLoading,
  editingIpUserId,
  newIpAddress,
  currentUserRole,
  isSuperAdmin = false,
  onEdit,
  onDelete,
  onStartAddIp,
  onCancelAddIp,
  onIpAddressChange,
  onAddIp,
  onRemoveIp,
  canDeleteUser,
}: UserTableProps) {
  const getRoleBadgeColor = (role?: AppRole) => {
    switch (role) {
      case "SUPER_ADMIN":
        return "bg-chart-5 text-white";
      case "TENANT_OWNER":
        return "bg-destructive text-black";
      case "MANAGER":
        return "bg-primary text-black";
      case "TEAM_LEADER":
        return "bg-cyan-500 text-black";
      case "SUPER_AGENT":
        return "bg-chart-4 text-black";
      case "AGENT":
        return "bg-success text-black";
      default:
        return "bg-muted text-black";
    }
  };

  const getRoleDisplayName = (role?: AppRole) => {
    switch (role) {
      case "SUPER_ADMIN":
        return "SuperAdmin";
      case "TENANT_OWNER":
        return "Tenant";
      case "MANAGER":
        return "Manager";
      case "TEAM_LEADER":
        return "Team Leader";
      case "SUPER_AGENT":
        return "Super Agent";
      case "AGENT":
        return "Agent";
      default:
        return "NO ROLE";
    }
  };

  const columnCount = isSuperAdmin ? 8 : 6;

  if (isLoading) {
    return (
      <Table>
        <TableHeader className="rounded-t-lg overflow-hidden">
          <TableRow className="[&>th:first-child]:rounded-tl-lg [&>th:last-child]:rounded-tr-lg">
            <TableHead>User</TableHead>
            <TableHead>Username</TableHead>
            <TableHead>Role</TableHead>
            {isSuperAdmin && <TableHead>Tenant</TableHead>}
            {isSuperAdmin && <TableHead>Created By</TableHead>}
            <TableHead>IP Whitelist</TableHead>
            <TableHead>Joined</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow>
            <TableCell colSpan={columnCount} className="text-center py-8">
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    );
  }

  if (users.length === 0) {
    return (
      <Table>
        <TableHeader className="rounded-t-lg overflow-hidden">
          <TableRow className="[&>th:first-child]:rounded-tl-lg [&>th:last-child]:rounded-tr-lg">
            <TableHead>User</TableHead>
            <TableHead>Username</TableHead>
            <TableHead>Role</TableHead>
            {isSuperAdmin && <TableHead>Tenant</TableHead>}
            {isSuperAdmin && <TableHead>Created By</TableHead>}
            <TableHead>IP Whitelist</TableHead>
            <TableHead>Joined</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow>
            <TableCell colSpan={columnCount} className="text-center py-8 text-muted-foreground">
              No users found
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    );
  }

  return (
    <Table>
      <TableHeader className="rounded-t-lg overflow-hidden">
        <TableRow className="[&>th:first-child]:rounded-tl-lg [&>th:last-child]:rounded-tr-lg">
          <TableHead>User</TableHead>
          <TableHead>Username</TableHead>
          <TableHead>Role</TableHead>
          {isSuperAdmin && <TableHead>Tenant</TableHead>}
          {isSuperAdmin && <TableHead>Created By</TableHead>}
          <TableHead>IP Whitelist</TableHead>
          <TableHead>Joined</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {users.map((u) => (
          <TableRow key={u.id}>
            <TableCell className="font-medium text-foreground">
              {u.full_name || "No name"}
            </TableCell>
            <TableCell className="text-foreground">{u.username || "No username"}</TableCell>
            <TableCell>
              <div className="flex flex-wrap items-center gap-1.5">
                <Badge className={getRoleBadgeColor(u.role)}>
                  {getRoleDisplayName(u.role)}
                </Badge>
                {u.role === "AGENT" && (u as any).is_closer && (
                  <Badge variant="outline" className="border-primary/40 text-primary bg-primary/10">
                    Closer
                  </Badge>
                )}
              </div>
            </TableCell>
            {isSuperAdmin && (
              <TableCell className="text-muted-foreground">
                {u.tenant_name || <span className="text-muted-foreground/50">—</span>}
              </TableCell>
            )}
            {isSuperAdmin && (
              <TableCell className="text-muted-foreground">
                {u.created_by_name || <span className="text-muted-foreground/50">—</span>}
              </TableCell>
            )}
            <TableCell>
              <div className="space-y-2">
                {u.ip_whitelist && u.ip_whitelist.length > 0 ? (
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono">{u.ip_whitelist[0].ip_address}</span>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6"
                      onClick={() => onRemoveIp(u.ip_whitelist![0].id)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : editingIpUserId === u.id ? (
                  <div className="flex items-center gap-2">
                    <Input
                      value={newIpAddress}
                      onChange={(e) => onIpAddressChange(e.target.value)}
                      placeholder="Enter IP address"
                      className="h-8 w-32"
                    />
                    <Button size="sm" onClick={() => onAddIp(u.id)}>
                      Add
                    </Button>
                    <Button size="sm" variant="ghost" onClick={onCancelAddIp}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onStartAddIp(u.id)}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add IP
                  </Button>
                )}
              </div>
            </TableCell>
            <TableCell className="text-muted-foreground">
              {format(new Date(u.created_at), "MMM d, yyyy")}
            </TableCell>
            <TableCell>
              <div className="flex items-center gap-2">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => onEdit(u)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                {canDeleteUser(u.role) && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => onDelete(u.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                )}
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
