import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Shield } from "lucide-react";
import { Enums } from "@/integrations/supabase/types";

export interface UserFilterValues {
  roles: Enums<"app_role">[];
}

interface UserManagementFiltersProps {
  filterValues: UserFilterValues;
  onFilterValuesChange: (values: UserFilterValues) => void;
}

// ADMIN role excluded - tenants are managed in Tenant Management page
const ROLE_OPTIONS: {
  value: Enums<"app_role">;
  label: string;
}[] = [
  { value: "SUPER_ADMIN", label: "SuperAdmin" },
  { value: "MANAGER", label: "Manager" },
  { value: "SUPER_AGENT", label: "Super Agent" },
  { value: "AGENT", label: "Agent" },
];

export function UserManagementFilters({
  filterValues,
  onFilterValuesChange,
}: UserManagementFiltersProps) {
  const toggleRole = (role: Enums<"app_role">) => {
    const newRoles = filterValues.roles.includes(role)
      ? filterValues.roles.filter((r) => r !== role)
      : [...filterValues.roles, role];
    
    onFilterValuesChange({
      ...filterValues,
      roles: newRoles,
    });
  };

  return (
    <div className="flex items-center gap-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className={`gap-2 rounded-full ${
              filterValues.roles.length > 0
                ? "bg-primary/10 border-primary/50 pr-2"
                : "bg-background"
            }`}
          >
            <Shield className="h-4 w-4" />
            <span
              className={
                filterValues.roles.length > 0
                  ? "text-primary-foreground font-medium"
                  : "text-muted-foreground"
              }
            >
              Role
            </span>
            {filterValues.roles.length > 0 && (
              <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                {filterValues.roles.length}
              </Badge>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-48 border-0">
          {ROLE_OPTIONS.map((option) => (
            <DropdownMenuCheckboxItem
              key={option.value}
              checked={filterValues.roles.includes(option.value)}
              onCheckedChange={() => toggleRole(option.value)}
            >
              {option.label}
            </DropdownMenuCheckboxItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
