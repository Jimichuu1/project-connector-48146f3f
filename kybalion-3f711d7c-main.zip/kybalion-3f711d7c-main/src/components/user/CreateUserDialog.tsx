import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Enums } from "@/integrations/supabase/types";
import { z } from "zod";

// Comprehensive validation schemas
const usernameSchema = z.string()
  .trim()
  .min(3, "Username must be at least 3 characters")
  .max(50, "Username must be less than 50 characters")
  .regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, hyphens, and underscores");

const passwordSchema = z.string()
  .min(6, "Password must be at least 6 characters");

const fullNameSchema = z.string()
  .trim()
  .min(1, "Name is required")
  .max(100, "Name must be less than 100 characters")
  .regex(/^[a-zA-Z\s\-'.]+$/, "Name contains invalid characters");

const ipv4Schema = z.string().regex(
  /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
  "Invalid IPv4 address format"
);

const ipv6Schema = z.string().regex(
  /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/,
  "Invalid IPv6 address format"
);

const ipSchema = z.union([ipv4Schema, ipv6Schema]);

interface CreateUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUserCreated: () => void;
  currentUserRole?: Enums<"app_role"> | null;
}

export function CreateUserDialog({ open, onOpenChange, onUserCreated, currentUserRole }: CreateUserDialogProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<Enums<"app_role">>("AGENT");
  const [whitelistedIps, setWhitelistedIps] = useState("");
  const [isCloser, setIsCloser] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  // Get available roles based on current user's role
  // Hierarchy: SUPER_ADMIN > ADMIN > MANAGER > SUPER_AGENT > AGENT
  // Note: ADMIN role is not available here - tenants are created via Tenant Management
  const getAvailableRoles = (): { value: Enums<"app_role">; label: string }[] => {
    // SuperAdmin and TenantOwner can create Manager, Team Leader, Super Agent, Agent
    if (currentUserRole === "SUPER_ADMIN" || currentUserRole === "TENANT_OWNER") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
        { value: "TEAM_LEADER", label: "Team Leader" },
        { value: "MANAGER", label: "Manager" },
      ];
    }
    
    // Manager can create Team Leader, Super Agent, Agent
    if (currentUserRole === "MANAGER") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
        { value: "TEAM_LEADER", label: "Team Leader" },
      ];
    }

    // Team Leader can create Super Agent, Agent
    if (currentUserRole === "TEAM_LEADER") {
      return [
        { value: "AGENT", label: "Agent" },
        { value: "SUPER_AGENT", label: "Super Agent" },
      ];
    }
    
    return [];
  };

  const availableRoles = getAvailableRoles();

  const handleCreate = async () => {
    // Validate all inputs before proceeding
    try {
      usernameSchema.parse(username);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    try {
      passwordSchema.parse(password);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    try {
      fullNameSchema.parse(fullName);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    setIsCreating(true);
    try {
      // Call edge function to create user
      const { data, error } = await supabase.functions.invoke('create-user', {
        body: {
          username,
          password,
          fullName,
          role,
          whitelistedIps,
          isCloser: role === "AGENT" ? isCloser : false,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success("User created successfully");
      
      onUserCreated();
      onOpenChange(false);
      resetForm();
    } catch (error) {
      console.error("Error creating user:", error);
      const message = error instanceof Error ? error.message : "Failed to create user";
      toast.error(message);
    } finally {
      setIsCreating(false);
    }
  };

  const resetForm = () => {
    setUsername("");
    setPassword("");
    setFullName("");
    setRole("AGENT");
    setWhitelistedIps("");
    setIsCloser(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New User</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="full_name">Full Name *</Label>
            <Input
              id="full_name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="John Doe"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username *</Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="john_doe"
            />
            <p className="text-xs text-muted-foreground">
              3-50 characters. Letters, numbers, hyphens, and underscores only.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password *</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role *</Label>
            <Select value={role} onValueChange={(value) => setRole(value as Enums<"app_role">)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableRoles.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Permissions are automatically assigned based on role
            </p>
          </div>

          {role === "AGENT" && (
            <div className="flex items-center justify-between rounded-md border p-3">
              <div className="space-y-0.5 pr-3">
                <Label htmlFor="is_closer" className="cursor-pointer text-sm font-medium">
                  Closer Agent
                </Label>
                <p className="text-xs text-muted-foreground">
                  Applies the dedicated Closer Agent salary tiers.
                </p>
              </div>
              <Switch
                id="is_closer"
                checked={isCloser}
                onCheckedChange={setIsCloser}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="ips">Whitelisted IPs (Optional)</Label>
            <Input
              id="ips"
              value={whitelistedIps}
              onChange={(e) => setWhitelistedIps(e.target.value)}
              placeholder="192.168.1.1, 10.0.0.1, 2001:0db8::1"
            />
            <p className="text-xs text-muted-foreground">
              Comma-separated valid IPv4 or IPv6 addresses. Leave empty for no restrictions.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={handleCreate} disabled={isCreating}>
            {isCreating ? "Creating..." : "Create User"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
