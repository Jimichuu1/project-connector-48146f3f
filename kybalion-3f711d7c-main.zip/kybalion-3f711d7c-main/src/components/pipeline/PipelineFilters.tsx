import { memo } from "react";
import { FilterBar } from "@/components/filters/FilterBar";
import { MultiSelectFilter } from "@/components/filters/MultiSelectFilter";
import { RangeFilter } from "@/components/filters/RangeFilter";
import { SearchFilter } from "@/components/filters/SearchFilter";
import { Button } from "@/components/ui/button";
import { User, UserCheck, DollarSign, X, Banknote } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface PipelineFiltersProps {
  // Client filter
  clientOptions: { value: string; label: string }[];
  selectedClients: string[];
  onToggleClient: (clientId: string) => void;

  // Super agent filter
  isAdmin: boolean;
  superAgentOptions: { value: string; label: string }[];
  selectedSuperAgents: string[];
  onToggleSuperAgent: (superAgentId: string) => void;

  // Amount filter
  amountRange: [number, number];
  isAmountFilterActive: boolean;
  onAmountRangeChange: (values: number[]) => void;
  onClearAmountFilter: () => void;

  // Deposit filter
  depositRange: [number, number];
  isDepositFilterActive: boolean;
  onDepositRangeChange: (values: number[]) => void;
  onClearDepositFilter: () => void;

  // Search
  searchQuery: string;
  onSearchChange: (value: string) => void;

  // Clear all
  hasActiveFilters: boolean;
  activeFilterCount: number;
  onClearAllFilters: () => void;
}

export const PipelineFilters = memo(function PipelineFilters({
  clientOptions,
  selectedClients,
  onToggleClient,
  isAdmin,
  superAgentOptions,
  selectedSuperAgents,
  onToggleSuperAgent,
  amountRange,
  isAmountFilterActive,
  onAmountRangeChange,
  onClearAmountFilter,
  depositRange,
  isDepositFilterActive,
  onDepositRangeChange,
  onClearDepositFilter,
  searchQuery,
  onSearchChange,
  hasActiveFilters,
  activeFilterCount,
  onClearAllFilters,
}: PipelineFiltersProps) {
  return (
    <FilterBar>
      <div className="flex items-center gap-2 flex-wrap">
        <MultiSelectFilter
          icon={User}
          label="Clients"
          options={clientOptions}
          selectedValues={selectedClients}
          onToggle={onToggleClient}
        />

        {isAdmin && (
          <MultiSelectFilter
            icon={UserCheck}
            label="Super Agent"
            options={superAgentOptions}
            selectedValues={selectedSuperAgents}
            onToggle={onToggleSuperAgent}
          />
        )}

        <RangeFilter
          icon={DollarSign}
          label="Amount"
          min={0}
          max={100000}
          step={1000}
          value={amountRange}
          isActive={isAmountFilterActive}
          onChange={onAmountRangeChange}
          onClear={onClearAmountFilter}
          formatValue={(v) => `$${v.toLocaleString()}`}
        />

        <RangeFilter
          icon={Banknote}
          label="Deposit"
          min={0}
          max={100000}
          step={1000}
          value={depositRange}
          isActive={isDepositFilterActive}
          onChange={onDepositRangeChange}
          onClear={onClearDepositFilter}
          formatValue={(v) => `$${v.toLocaleString()}`}
        />

        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearAllFilters}
            className="gap-2 h-9 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
            Clear all
            <Badge variant="outline" className="ml-1 text-xs h-5 px-1.5 bg-primary/10 text-primary border-primary/30">
              {activeFilterCount}
            </Badge>
          </Button>
        )}
      </div>

      <SearchFilter
        value={searchQuery}
        onChange={onSearchChange}
        placeholder="Search clients..."
      />
    </FilterBar>
  );
});
