import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { X, Users } from "lucide-react";
import { useAuditLog } from "@/hooks/useAuditLog";
import { formatCurrency } from "@/lib/utils";
import { Checkbox } from "@/components/ui/checkbox";

interface DepositDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (depositAmount: number) => void;
  leadId?: string | null;
  branchId: string;
  clientId: string;
}

export const DepositDialog = ({ open, onOpenChange, onConfirm, leadId, branchId, clientId }: DepositDialogProps) => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const { logAction } = useAuditLog();
  const [branchValue, setBranchValue] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  
  // Transferring agent (the original agent who transferred the lead)
  const [transferringAgentId, setTransferringAgentId] = useState<string | null>(null);
  const [transferringAgentName, setTransferringAgentName] = useState<string | null>(null);
  const [includeTransferringAgent, setIncludeTransferringAgent] = useState(true);
  
  // Closer agent (optional - the agent who closed the deal, gets 50% deposit credit)
  const [closerAgentId, setCloserAgentId] = useState<string | null>(null);
  const [closerAgentName, setCloserAgentName] = useState<string | null>(null);
  
  // Working super agent (current user doing the deposit)
  const [workingSuperAgentId, setWorkingSuperAgentId] = useState<string | null>(null);
  
  // Split with another super agent (optional 50-50)
  const [splitWithSuperAgent, setSplitWithSuperAgent] = useState(false);
  const [splitSuperAgentId, setSplitSuperAgentId] = useState<string | null>(null);
  const [availableSuperAgents, setAvailableSuperAgents] = useState<Array<{ id: string; name: string }>>([]);
  
  const [exchanges, setExchanges] = useState<string[]>([]);
  const [exchangeInput, setExchangeInput] = useState("");

  useEffect(() => {
    const fetchLeadInfo = async () => {
      if (!open || !branchId) return;

      setLoading(true);
      try {
        // Fetch branch value
        const { data: branch, error: branchError } = await supabase
          .from("sale_branches")
          .select("value")
          .eq("id", branchId)
          .single();

        if (branchError) throw branchError;
        setBranchValue(branch.value || 0);

        // Fetch client to get transferring_agent, closer_agent_id and assigned super agent
        const { data: client } = await supabase
          .from("clients")
          .select("assigned_to, transferring_agent, closer_agent_id, admin_id")
          .eq("id", clientId)
          .single();

        // Determine the tenant to filter agents by
        const tenantId = client?.admin_id || effectiveTenantId;

        // Fetch super agents for the tenant
        const { data: agentRoles, error: rolesError } = await supabase
          .from("user_roles")
          .select("user_id, role")
          .eq("role", "SUPER_AGENT");

        if (rolesError) throw rolesError;

        if (agentRoles && agentRoles.length > 0) {
          const userIds = agentRoles.map(r => r.user_id);
          
          const { data: profiles, error: profilesError } = await supabase
            .from("profiles")
            .select("id, full_name, email, admin_id")
            .in("id", userIds);

          if (profilesError) throw profilesError;

          // Filter super agents by tenant
          const tenantSuperAgents = (profiles || [])
            .filter((profile) => {
              if (tenantId && profile.admin_id !== tenantId) {
                return false;
              }
              return true;
            })
            .map(p => ({ id: p.id, name: p.full_name || p.email || "Unknown" }));
          
          setAvailableSuperAgents(tenantSuperAgents);
        }

        // Set transferring agent
        if (client?.transferring_agent) {
          const { data: transferAgent } = await supabase
            .from("profiles")
            .select("id, full_name, email")
            .eq("id", client.transferring_agent)
            .single();
          
          if (transferAgent) {
            setTransferringAgentId(transferAgent.id);
            setTransferringAgentName(transferAgent.full_name || transferAgent.email || "Unknown");
            setIncludeTransferringAgent(true);
          } else {
            setIncludeTransferringAgent(false);
          }
        } else {
          setIncludeTransferringAgent(false);
        }

        // Set closer agent (separate from transferring agent)
        if (client?.closer_agent_id) {
          const { data: closer } = await supabase
            .from("profiles")
            .select("id, full_name, email")
            .eq("id", client.closer_agent_id)
            .single();
          
          if (closer) {
            setCloserAgentId(closer.id);
            setCloserAgentName(`${closer.full_name || closer.email || "Unknown"} (Closer)`);
          }
        }

        // Set current user as working super agent
        if (user) {
          setWorkingSuperAgentId(user.id);
        }
      } catch (error) {
        console.error("Error fetching lead info:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLeadInfo();
  }, [open, leadId, branchId, user, clientId, effectiveTenantId]);

  // Reset split super agent when toggling off
  useEffect(() => {
    if (!splitWithSuperAgent) {
      setSplitSuperAgentId(null);
    }
  }, [splitWithSuperAgent]);

  const handleConfirm = async () => {
    if (!branchValue || branchValue <= 0) {
      return;
    }

    // Save deposit with split info
    if (user) {
      // Calculate amounts based on whether splitting with another super agent
      let agentPercentage = 0;
      let superAgentPercentage = 100;
      let agentAmount = 0;
      let superAgentAmount = branchValue;

      if (splitWithSuperAgent && splitSuperAgentId) {
        // 50-50 split between two super agents
        superAgentPercentage = 50;
        superAgentAmount = branchValue / 2;
      }

      try {
        // Determine admin_id for tenant-scoped notifications
        let adminId = effectiveTenantId;
        if (!adminId) {
          const { data: clientData } = await supabase
            .from("clients")
            .select("admin_id")
            .eq("id", clientId)
            .single();
          adminId = clientData?.admin_id || null;
        }

        // Calculate split amounts
        const splitAmount = splitWithSuperAgent && splitSuperAgentId ? branchValue / 2 : 0;

        // Build single insert object with split info
        const insertData: Record<string, unknown> = {
          sale_branch_id: branchId,
          client_id: clientId,
          lead_id: null as string | null,
          amount: branchValue,
          agent_id: includeTransferringAgent ? transferringAgentId : null,
          closer_agent_id: closerAgentId || null,
          super_agent_id: workingSuperAgentId,
          agent_percentage: agentPercentage,
          super_agent_percentage: superAgentPercentage,
          agent_amount: agentAmount,
          super_agent_amount: superAgentAmount,
          created_by: user.id,
          exchanges: exchanges.length > 0 ? exchanges : null,
          admin_id: adminId,
          // Store split super agent info in single record
          split_super_agent_id: splitWithSuperAgent && splitSuperAgentId ? splitSuperAgentId : null,
          split_super_agent_amount: splitAmount,
        };

        const { data: depositData, error } = await supabase
          .from("deposits")
          .insert(insertData as any)
          .select()
          .single();

        if (error) throw error;

        // Send DEPOSIT_SPLIT_RECEIVED notification to split super agent
        if (splitWithSuperAgent && splitSuperAgentId && depositData) {
          const splitAgentName = filteredSuperAgents.find(a => a.id === splitSuperAgentId)?.name || "Another super agent";
          await supabase.from("notifications").insert({
            user_id: splitSuperAgentId,
            type: "DEPOSIT_SPLIT_RECEIVED" as const,
            message: `You've been added to a 50-50 split deposit of $${branchValue} ($${branchValue / 2} your share)`,
            related_entity_type: "deposit",
            related_entity_id: depositData.id,
            admin_id: adminId,
          });
        }

        // Log deposit creation
        await logAction({
          actionType: 'deposit_created',
          entityType: 'deposit',
          entityId: depositData?.id,
          details: {
            amount: branchValue,
            client_id: clientId,
            agent_id: includeTransferringAgent ? transferringAgentId : null,
            super_agent_id: workingSuperAgentId,
            split_super_agent_id: splitWithSuperAgent ? splitSuperAgentId : null,
            exchanges: exchanges,
          },
        });
      } catch (error) {
        console.error("Error saving deposit:", error);
      }
    }

    onConfirm(branchValue);
    onOpenChange(false);
    setExchanges([]);
    setSplitWithSuperAgent(false);
    setSplitSuperAgentId(null);
  };

  const handleAddExchange = () => {
    if (exchangeInput.trim() && !exchanges.includes(exchangeInput.trim())) {
      setExchanges([...exchanges, exchangeInput.trim()]);
      setExchangeInput("");
    }
  };

  const handleRemoveExchange = (exchange: string) => {
    setExchanges(exchanges.filter((e) => e !== exchange));
  };

  const handleExchangeKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddExchange();
    }
  };

  // Filter out current user from split super agents list
  const filteredSuperAgents = availableSuperAgents.filter(sa => sa.id !== workingSuperAgentId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm Deposit</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {loading ? (
            <>
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </>
          ) : (
            <>
              {/* Transferring Agent Section (Optional - only original agent) */}
              {transferringAgentId && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Checkbox 
                      id="include-agent" 
                      checked={includeTransferringAgent}
                      onCheckedChange={(checked) => setIncludeTransferringAgent(!!checked)}
                    />
                    <Label htmlFor="include-agent" className="cursor-pointer">
                      Include Transferring Agent
                    </Label>
                  </div>
                  {includeTransferringAgent && (
                    <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm">
                      {transferringAgentName || "Unknown Agent"}
                    </div>
                  )}
                </div>
              )}

              {/* Working Super Agent (Current User - Read Only) */}
              <div className="space-y-2">
                <Label>Working Super Agent</Label>
                <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm">
                  {availableSuperAgents.find(a => a.id === workingSuperAgentId)?.name || user?.email || "You"}
                </div>
              </div>

              {/* Split with Another Super Agent Section */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="split-super-agent" 
                    checked={splitWithSuperAgent}
                    onCheckedChange={(checked) => setSplitWithSuperAgent(!!checked)}
                    disabled={filteredSuperAgents.length === 0}
                  />
                  <Label htmlFor="split-super-agent" className="cursor-pointer flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Split 50-50 with another Super Agent
                  </Label>
                </div>
                {splitWithSuperAgent && (
                  <Select 
                    value={splitSuperAgentId || undefined} 
                    onValueChange={setSplitSuperAgentId}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select super agent to split with" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredSuperAgents.map((agent) => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              {/* Exchanges Section */}
              <div className="space-y-2">
                <Label>Exchanges Used</Label>
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={exchangeInput}
                      onChange={(e) => setExchangeInput(e.target.value)}
                      onKeyDown={handleExchangeKeyDown}
                      placeholder="Type exchange name and press Enter"
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    />
                    <Button type="button" size="sm" onClick={handleAddExchange}>
                      Add
                    </Button>
                  </div>
                  {exchanges.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {exchanges.map((exchange) => (
                        <Badge key={exchange} variant="outline" className="gap-1 bg-muted text-foreground border-border">
                          {exchange}
                          <X className="h-3 w-3 cursor-pointer hover:text-destructive" onClick={() => handleRemoveExchange(exchange)} />
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Summary Section */}
              {branchValue > 0 && (
                <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-3">
                  <div className="flex justify-between items-center text-sm border-b border-border pb-2">
                    <span className="font-medium">Total Deposit</span>
                    <span className="font-bold text-base">
                      {formatCurrency(branchValue)}
                    </span>
                  </div>
                  
                  {includeTransferringAgent && transferringAgentId && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        {transferringAgentName || "Transferring Agent"}
                      </span>
                      <span className="font-semibold">
                        {closerAgentId ? formatCurrency(branchValue / 2) : formatCurrency(branchValue)}
                        {closerAgentId && <span className="text-xs text-muted-foreground ml-1">(50%)</span>}
                      </span>
                    </div>
                  )}
                  
                  {closerAgentId && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        {closerAgentName || "Closer Agent"}
                      </span>
                      <span className="font-semibold">
                        {formatCurrency(branchValue / 2)}
                        <span className="text-xs text-muted-foreground ml-1">(50%)</span>
                      </span>
                    </div>
                  )}
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">
                      {availableSuperAgents.find(a => a.id === workingSuperAgentId)?.name || "You"}
                    </span>
                    <span className="font-semibold">
                      {formatCurrency(splitWithSuperAgent && splitSuperAgentId ? branchValue / 2 : branchValue)}
                      {splitWithSuperAgent && splitSuperAgentId && <span className="text-xs text-muted-foreground ml-1">(50%)</span>}
                    </span>
                  </div>
                  
                  {splitWithSuperAgent && splitSuperAgentId && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        {filteredSuperAgents.find(a => a.id === splitSuperAgentId)?.name || "Split Super Agent"}
                      </span>
                      <span className="font-semibold">
                        {formatCurrency(branchValue / 2)}
                        <span className="text-xs text-muted-foreground ml-1">(50%)</span>
                      </span>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            size="sm" 
            onClick={handleConfirm} 
            disabled={!branchValue || loading || (splitWithSuperAgent && !splitSuperAgentId)}
          >
            Confirm Deposit
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
