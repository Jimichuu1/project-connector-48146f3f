import { memo, useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { User, Plus, Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useUserData } from "@/contexts/UserDataContext";
import { supabase } from "@/integrations/supabase/client";

interface Client {
  id: string;
  name: string;
  email: string;
}

interface ClientsColumnProps {
  clients: Client[] | undefined;
  onAddOpportunity: (client: { id: string; name: string }) => void;
  isLoading?: boolean;
  error?: Error | null;
}

export const ClientsColumn = memo(function ClientsColumn({
  clients,
  onAddOpportunity,
  isLoading = false,
  error = null,
}: ClientsColumnProps) {
  const { user } = useAuth();
  const { canViewEmail } = useUserData();
  const [searchQuery, setSearchQuery] = useState("");

  // Touch user to keep auth-bound rendering pattern (no role-based gating needed for email anymore)
  useEffect(() => { void user; }, [user]);
  void supabase;

  const filteredClients = useMemo(() => {
    if (!clients) return [];
    if (!searchQuery.trim()) return clients;
    const query = searchQuery.toLowerCase().trim();
    return clients.filter(
      (client) =>
        client.name.toLowerCase().includes(query) ||
        client.email?.toLowerCase().includes(query)
    );
  }, [clients, searchQuery]);

  const shouldShowEmail = canViewEmail;

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2 pt-2 bg-primary text-primary-foreground rounded-t-md flex-shrink-0 h-[88px]">
        <CardTitle className="text-xs">All Clients</CardTitle>
        <p className="opacity-90 text-lg">{filteredClients.length || 0} clients</p>
      </CardHeader>
      <div className="px-3 pt-3 flex-shrink-0">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search clients..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 h-8 text-sm"
          />
        </div>
      </div>
      <CardContent className="p-3 space-y-3 flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-16 w-full rounded-lg" />
            ))}
          </div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>Failed to load clients. Please try again.</AlertDescription>
          </Alert>
        ) : filteredClients.length > 0 ? (
          filteredClients.map((client) => (
            <Card
              key={client.id}
              className="hover:shadow-md transition-all duration-200 hover:border-primary/50"
            >
              <CardContent className="p-3 flex items-center justify-between gap-2 bg-muted/30 rounded-lg">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{client.name}</p>
                    {shouldShowEmail && (
                      <p className="text-xs text-muted-foreground truncate">{client.email}</p>
                    )}
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0 flex-shrink-0 hover:bg-primary/10"
                  onClick={() => onAddOpportunity({ id: client.id, name: client.name })}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
            {searchQuery ? "No clients match your search" : "No clients found"}
          </div>
        )}
      </CardContent>
    </Card>
  );
});
