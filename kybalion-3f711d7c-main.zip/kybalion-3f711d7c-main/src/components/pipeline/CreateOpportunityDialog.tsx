import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useSaleBranches } from "@/hooks/useSaleBranches";

interface CreateOpportunityDialogProps {
  clientId: string;
  clientName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateOpportunityDialog = ({ clientId, clientName, open, onOpenChange }: CreateOpportunityDialogProps) => {
  const [name, setName] = useState("");
  const [value, setValue] = useState("0");
  const { createBranch } = useSaleBranches();

  const handleCreate = () => {
    createBranch.mutate(
      {
        client_id: clientId,
        name,
        value: parseFloat(value) || 0,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          setName("");
          setValue("0");
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Sales Opportunity</DialogTitle>
          <DialogDescription>
            Add a new sales opportunity for {clientName}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="value">Opportunity Value ($) *</Label>
            <Input
              id="value"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={value}
              onChange={(e) => setValue(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Note</Label>
            <Input
              id="name"
              placeholder="e.g., Premium Account Upgrade"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <ButtonGroup>
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreate}
              disabled={!value || parseFloat(value) <= 0 || createBranch.isPending}
            >
              {createBranch.isPending ? "Creating..." : "Create Opportunity"}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
