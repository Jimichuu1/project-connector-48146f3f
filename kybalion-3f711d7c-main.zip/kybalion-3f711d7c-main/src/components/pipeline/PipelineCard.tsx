import { useState, memo } from "react";
import { useDraggable } from "@dnd-kit/core";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Pencil, X, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { SaleBranchWithClient } from "@/types/pipeline";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { formatDistanceToNow } from "date-fns";
import { formatCurrency } from "@/lib/utils";

type ViewDensity = "compact" | "comfortable" | "spacious";

interface PipelineCardProps {
  branch: SaleBranchWithClient;
  onEdit: (id: string, value: number) => void;
  onDelete: (id: string) => void;
  onCardClick?: (branch: SaleBranchWithClient) => void;
  density?: ViewDensity;
  isAdmin?: boolean;
  isManager?: boolean;
  isSuperAgent?: boolean;
}

const densityStyles = {
  compact: {
    padding: "p-2",
    spacing: "space-y-1",
    nameSize: "text-xs",
    descSize: "text-[10px]",
    valueSize: "text-xs",
    buttonSize: "h-4 w-4",
    iconSize: "h-2.5 w-2.5",
    inputHeight: "h-5",
    inputWidth: "w-16",
  },
  comfortable: {
    padding: "p-2.5",
    spacing: "space-y-2",
    nameSize: "text-sm",
    descSize: "text-xs",
    valueSize: "text-sm",
    buttonSize: "h-5 w-5",
    iconSize: "h-3 w-3",
    inputHeight: "h-6",
    inputWidth: "w-20",
  },
  spacious: {
    padding: "p-4",
    spacing: "space-y-3",
    nameSize: "text-sm",
    descSize: "text-sm",
    valueSize: "text-lg",
    buttonSize: "h-6 w-6",
    iconSize: "h-4 w-4",
    inputHeight: "h-8",
    inputWidth: "w-24",
  },
};

export const PipelineCard = memo(function PipelineCard({
  branch,
  onEdit,
  onDelete,
  onCardClick,
  density = "comfortable",
  isAdmin = false,
  isManager = false,
  isSuperAgent = false,
}: PipelineCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(branch.value.toString());

  const isDraggingDisabled =
    branch.status === "FLIPPED" || branch.status === "DEPOSIT";
  
  // Only ADMIN and MANAGER can edit/delete cards in Flipped or Deposit columns
  const isFlippedOrDeposit = branch.status === "FLIPPED" || branch.status === "DEPOSIT";
  const isEditDeleteDisabled = isFlippedOrDeposit && !isAdmin && !isManager;

  // Deposit status styling
  const isDepositColumn = branch.status === "DEPOSIT";
  const isApproved = branch.deposit_status === "approved";
  const isRejected = branch.deposit_status === "rejected";
  const isPending = branch.deposit_status === "pending" || (isDepositColumn && !branch.deposit_status && !isRejected);

  const { attributes, listeners, setNodeRef, transform, isDragging } =
    useDraggable({
      id: branch.id,
      data: {
        type: "branch",
        branch,
      },
      disabled: isDraggingDisabled,
    });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      }
    : undefined;

  const handleSave = () => {
    onEdit(branch.id, parseFloat(editValue) || 0);
    setIsEditing(false);
  };

  const styles = densityStyles[density];

  const createdAt = new Date(branch.created_at);
  const timeAgo = formatDistanceToNow(createdAt, { addSuffix: true });

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(isDragging && "opacity-50")}
    >
      <Card
        className={cn(
          "group hover:shadow-md transition-all duration-200 border-border",
          isDraggingDisabled
            ? "cursor-not-allowed"
            : "cursor-move hover:border-primary/50"
        )}
        {...(!isDraggingDisabled ? listeners : {})}
        {...(!isDraggingDisabled ? attributes : {})}
      >
        <CardContent className={cn(styles.padding, styles.spacing)}>
          <div className="flex items-start justify-between gap-2">
            <div
              className="flex-1 min-w-0"
              onClick={(e) => {
                e.stopPropagation();
                if (!isEditing && onCardClick) {
                  onCardClick(branch);
                }
              }}
            >
              <div className="flex items-center gap-1.5">
                {/* Deposit status dot indicator */}
                {isDepositColumn && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <span 
                          className={cn(
                            "h-2 w-2 rounded-full flex-shrink-0",
                            isApproved && "bg-emerald-500",
                            isPending && "bg-amber-500",
                            isRejected && "bg-red-500 cursor-help"
                          )}
                        />
                      </TooltipTrigger>
                      {isRejected && branch.deposit_rejection_reason && (
                        <TooltipContent side="bottom" className="max-w-xs bg-red-950 border-red-500">
                          <div className="space-y-1">
                            <p className="text-xs font-medium text-red-400">Rejection Reason</p>
                            <p className="text-xs text-red-200">{branch.deposit_rejection_reason}</p>
                          </div>
                        </TooltipContent>
                      )}
                    </Tooltip>
                  </TooltipProvider>
                )}
                <p
                  className={cn(
                    "font-medium text-foreground hover:text-primary cursor-pointer transition-colors truncate",
                    styles.nameSize
                  )}
                >
                  {branch.client?.name || "Unknown Client"}
                </p>
              </div>
            {isAdmin && (branch.client?.assigned_user || branch.super_agent) && (
                <div className="flex items-center gap-1.5 mt-1">
                  <Avatar className="h-4 w-4">
                    <AvatarImage
                      src={branch.client?.assigned_user?.avatar_url || undefined}
                    />
                    <AvatarFallback className="text-[8px]">
                      {(isDepositColumn && branch.super_agent
                        ? branch.super_agent.full_name?.charAt(0)
                        : branch.client?.assigned_user?.full_name?.charAt(0)) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <p className={cn("text-muted-foreground truncate", styles.descSize)}>
                    {/* For DEPOSIT cards, show the deposit's stored agent; otherwise show current assignment */}
                    {isDepositColumn && branch.super_agent
                      ? branch.super_agent.full_name || branch.super_agent.email || "Unknown"
                      : branch.client?.assigned_user?.full_name || "Unassigned"}
                  </p>
                </div>
              )}
            </div>
            {!isEditDeleteDisabled && (
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  "opacity-0 group-hover:opacity-100 transition-opacity p-0 flex-shrink-0",
                  styles.buttonSize
                )}
                onClick={(e) => {
                  e.stopPropagation();
                  if (confirm("Delete this opportunity?")) {
                    onDelete(branch.id);
                  }
                }}
              >
                <X className={cn("text-destructive", styles.iconSize)} />
              </Button>
            )}
          </div>

          <div className="flex items-center justify-between">
            {isEditing ? (
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  step="0.01"
                  value={editValue}
                  onChange={(e) => setEditValue(e.target.value)}
                  className={cn(styles.inputHeight, styles.inputWidth, "text-xs")}
                  onBlur={handleSave}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSave();
                    if (e.key === "Escape") setIsEditing(false);
                  }}
                  autoFocus
                />
              </div>
            ) : (
              <>
                <span className={cn(
                  "font-bold",
                  styles.valueSize,
                  isDepositColumn && isApproved && "text-emerald-500",
                  isDepositColumn && isPending && "text-amber-500",
                  isDepositColumn && isRejected && "text-red-500",
                  !isDepositColumn && "text-success"
                )}>
                  {formatCurrency(branch.value)}
                </span>
                {!isEditDeleteDisabled && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className={cn(
                      "opacity-0 group-hover:opacity-100 transition-opacity p-0",
                      styles.buttonSize
                    )}
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsEditing(true);
                    }}
                  >
                    <Pencil className={styles.iconSize} />
                  </Button>
                )}
              </>
            )}
          </div>

          {/* Activity Timeline Preview */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span className="text-[10px]">{timeAgo}</span>
                </div>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="max-w-xs">
                <div className="space-y-1">
                  <p className="text-xs font-medium">Activity Timeline</p>
                  <p className="text-[11px] text-muted-foreground">
                    Created: {createdAt.toLocaleDateString()} at{" "}
                    {createdAt.toLocaleTimeString()}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    Last updated: {new Date(branch.updated_at).toLocaleString()}
                  </p>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </CardContent>
      </Card>
    </div>
  );
});
