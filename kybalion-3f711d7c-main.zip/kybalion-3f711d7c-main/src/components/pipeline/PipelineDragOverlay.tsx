import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SaleBranchWithClient } from "@/types/pipeline";

interface PipelineDragOverlayProps {
  activeBranch: SaleBranchWithClient | undefined;
  isAdmin: boolean;
}

export function PipelineDragOverlay({ activeBranch, isAdmin }: PipelineDragOverlayProps) {
  if (!activeBranch) return null;

  return (
    <Card className="w-[220px] opacity-90 rotate-3 shadow-xl">
      <CardContent className="p-2.5">
        <p className="font-medium text-sm">{activeBranch.client?.name}</p>
        {isAdmin && activeBranch.client?.assigned_user && (
          <div className="flex items-center gap-1.5 mt-1">
            <Avatar className="h-4 w-4">
              <AvatarImage
                src={activeBranch.client.assigned_user.avatar_url || undefined}
              />
              <AvatarFallback className="text-[8px]">
                {activeBranch.client.assigned_user.full_name?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <p className="text-xs text-muted-foreground">
              {activeBranch.client.assigned_user.full_name || "Unassigned"}
            </p>
          </div>
        )}
        <p className="text-sm font-bold text-success mt-2">
          ${Number(activeBranch.value).toLocaleString()}
        </p>
      </CardContent>
    </Card>
  );
}
