import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { DepositWithProfiles } from "@/hooks/useDeposits";
import { formatCurrency } from "@/lib/utils";
import { useUserRole } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

interface DepositInfoDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  branchId: string;
  onDepositDeleted?: () => void;
}

export const DepositInfoDialog = ({ open, onOpenChange, branchId, onDepositDeleted }: DepositInfoDialogProps) => {
  const [deposit, setDeposit] = useState<DepositWithProfiles | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const { isTenantOwner, isSuperAdmin, loading: roleLoading } = useUserRole();
  
  const canDelete = !roleLoading && (isTenantOwner || isSuperAdmin);

  useEffect(() => {
    const fetchDepositInfo = async () => {
      if (!open || !branchId) return;
      
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('deposits')
          .select(`
            *,
            agent:profiles!deposits_agent_id_fkey(id, full_name, email),
            super_agent:profiles!deposits_super_agent_id_fkey(id, full_name, email)
          `)
          .eq('sale_branch_id', branchId)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        // Fetch closer agent profile separately if exists
        let closerAgent = null;
        if (data?.closer_agent_id) {
          const { data: closerProfile } = await supabase
            .from('profiles')
            .select('id, full_name, email')
            .eq('id', data.closer_agent_id)
            .single();
          closerAgent = closerProfile;
        }

        if (error) {
          console.error('Error fetching deposit info:', error);
        }
        const depositWithCloser = data ? { ...data, closer_agent: closerAgent } : null;
        setDeposit(depositWithCloser as DepositWithProfiles | null);
      } catch (error) {
        console.error('Unexpected error fetching deposit info:', error);
        setDeposit(null);
      } finally {
        setLoading(false);
      }
    };

    fetchDepositInfo();
  }, [open, branchId]);

  const handleDeleteDeposit = async () => {
    if (!deposit) return;
    
    setDeleting(true);
    try {
      const { error } = await supabase
        .from('deposits')
        .delete()
        .eq('id', deposit.id);
      
      if (error) throw error;
      
      toast.success('Deposit deleted successfully');
      onOpenChange(false);
      onDepositDeleted?.();
    } catch (error) {
      console.error('Error deleting deposit:', error);
      toast.error('Failed to delete deposit');
    } finally {
      setDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Deposit Information</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {loading ? (
            <>
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </>
          ) : deposit ? (
            <>
              <div className="space-y-2">
                <Label>Total Deposit Amount</Label>
                <div className="rounded-md border border-border bg-muted px-3 py-2 text-lg font-bold">
                  {formatCurrency(deposit.amount)}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Transferring Agent</Label>
                <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm">
                  {deposit.agent?.full_name || deposit.agent?.email || 'Unknown'}
                </div>
              </div>

              {(deposit as any).closer_agent && (
                <div className="space-y-2">
                  <Label>Closer Agent</Label>
                  <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm">
                    {(deposit as any).closer_agent?.full_name || (deposit as any).closer_agent?.email || 'Unknown'}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>Working Super Agent</Label>
                <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm">
                  {deposit.super_agent?.full_name || deposit.super_agent?.email || 'Unknown'}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Exchanges Used</Label>
                {deposit.exchanges && deposit.exchanges.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {deposit.exchanges.map((exchange) => (
                      <Badge key={exchange} variant="secondary">
                        {exchange}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm text-muted-foreground">
                    No exchanges specified
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Split Percentage</Label>
                <div className="flex gap-2">
                  <Badge variant="secondary">
                    Agent: {deposit.agent_percentage}%
                  </Badge>
                  <Badge variant="secondary">
                    Super Agent: {deposit.super_agent_percentage}%
                  </Badge>
                </div>
              </div>

              <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Agent Amount:</span>
                  <span className="font-semibold">
                    {formatCurrency(deposit.agent_amount)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Super Agent Amount:</span>
                  <span className="font-semibold">
                    {formatCurrency(deposit.super_agent_amount)}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Badge 
                  variant={deposit.status === 'approved' ? 'default' : 'secondary'}
                  className="capitalize"
                >
                  {deposit.status}
                </Badge>
              </div>

              <div className="space-y-2">
                <Label>Created At</Label>
                <div className="rounded-md border border-border bg-muted px-3 py-2 text-sm">
                  {new Date(deposit.created_at).toLocaleString()}
                </div>
              </div>
              
              {deposit.status === 'approved' && (
                <DialogFooter className="pt-4">
                  {roleLoading ? (
                    <Skeleton className="h-8 w-32" />
                  ) : canDelete ? (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => setShowDeleteConfirm(true)}
                      disabled={deleting}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete Deposit
                    </Button>
                  ) : null}
                </DialogFooter>
              )}
            </>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              No deposit information found
            </div>
          )}
        </div>
      </DialogContent>
      
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Deposit?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this deposit of {deposit ? formatCurrency(deposit.amount) : '$0'}. 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteDeposit}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
};
