import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { Check, X, DollarSign, User } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

interface DepositApprovalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  depositId: string;
  amount: number;
  clientName: string;
  agentName?: string;
  superAgentName?: string;
}

export function DepositApprovalDialog({
  open,
  onOpenChange,
  depositId,
  amount,
  clientName,
  agentName,
  superAgentName,
}: DepositApprovalDialogProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isApproving, setIsApproving] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");

  const handleApprove = async () => {
    setIsApproving(true);
    try {
      // First fetch deposit details to get agent IDs for notifications
      const { data: deposit } = await supabase
        .from("deposits")
        .select("super_agent_id, split_super_agent_id, agent_id, amount, admin_id")
        .eq("id", depositId)
        .single();

      const { error } = await supabase
        .from("deposits")
        .update({
          status: "approved",
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
        })
        .eq("id", depositId);

      if (error) throw error;

      // Send DEPOSIT_APPROVED notifications to involved agents
      const notifications = [];
      
      if (deposit?.super_agent_id) {
        notifications.push({
          user_id: deposit.super_agent_id,
          type: "DEPOSIT_APPROVED" as const,
          message: `Your deposit of $${amount} for ${clientName} has been approved`,
          related_entity_type: "deposit",
          related_entity_id: depositId,
          admin_id: deposit.admin_id,
        });
      }
      
      if (deposit?.split_super_agent_id) {
        notifications.push({
          user_id: deposit.split_super_agent_id,
          type: "DEPOSIT_APPROVED" as const,
          message: `A split deposit of $${amount / 2} for ${clientName} has been approved`,
          related_entity_type: "deposit",
          related_entity_id: depositId,
          admin_id: deposit.admin_id,
        });
      }
      
      // NOTE: Transferring/closer agent notifications are gated by the
      // `counts_for_agent` toggle and sent by the DB trigger
      // `notify_agent_on_deposit_counted_trg` only when a Tenant Owner /
      // Super Admin flips it ON.

      if (notifications.length > 0) {
        await supabase.from("notifications").insert(notifications);
      }

      toast.success("Deposit approved successfully!");
      queryClient.invalidateQueries({ queryKey: ["sale-branches"] });
      queryClient.invalidateQueries({ queryKey: ["pending-deposits"] });
      onOpenChange(false);
    } catch (error) {
      console.error("Error approving deposit:", error);
      toast.error("Failed to approve deposit");
    } finally {
      setIsApproving(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) {
      toast.error("Please provide a rejection reason");
      return;
    }

    setIsRejecting(true);
    try {
      // First fetch deposit details to get agent IDs for notifications
      const { data: deposit } = await supabase
        .from("deposits")
        .select("super_agent_id, split_super_agent_id, agent_id, amount, admin_id")
        .eq("id", depositId)
        .single();

      const { error } = await supabase
        .from("deposits")
        .update({
          status: "rejected",
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
          rejection_reason: rejectionReason,
        })
        .eq("id", depositId);

      if (error) throw error;

      // Send DEPOSIT_REJECTED notifications to involved agents
      const notifications = [];
      
      if (deposit?.super_agent_id) {
        notifications.push({
          user_id: deposit.super_agent_id,
          type: "DEPOSIT_REJECTED" as const,
          message: `Your deposit of $${amount} for ${clientName} has been rejected: ${rejectionReason}`,
          related_entity_type: "deposit",
          related_entity_id: depositId,
          admin_id: deposit.admin_id,
        });
      }
      
      if (deposit?.split_super_agent_id) {
        notifications.push({
          user_id: deposit.split_super_agent_id,
          type: "DEPOSIT_REJECTED" as const,
          message: `A split deposit of $${amount / 2} for ${clientName} has been rejected`,
          related_entity_type: "deposit",
          related_entity_id: depositId,
          admin_id: deposit.admin_id,
        });
      }

      if (notifications.length > 0) {
        await supabase.from("notifications").insert(notifications);
      }

      toast.success("Deposit rejected");
      queryClient.invalidateQueries({ queryKey: ["sale-branches"] });
      queryClient.invalidateQueries({ queryKey: ["pending-deposits"] });
      onOpenChange(false);
    } catch (error) {
      console.error("Error rejecting deposit:", error);
      toast.error("Failed to reject deposit");
    } finally {
      setIsRejecting(false);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setShowRejectForm(false);
      setRejectionReason("");
    }
    onOpenChange(newOpen);
  };

  return (
    <AlertDialog open={open} onOpenChange={handleOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            {showRejectForm ? "Reject Deposit" : "Approve Deposit"}
          </AlertDialogTitle>
          <AlertDialogDescription asChild>
            <div className="space-y-4 pt-2">
              <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Amount</span>
                  <span className="text-lg font-bold text-primary">
                    {formatCurrency(amount)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Client</span>
                  <span className="text-sm font-medium">{clientName}</span>
                </div>
                {agentName && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <User className="h-3 w-3" /> Agent
                    </span>
                    <span className="text-sm">{agentName}</span>
                  </div>
                )}
                {superAgentName && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <User className="h-3 w-3" /> Super Agent
                    </span>
                    <span className="text-sm">{superAgentName}</span>
                  </div>
                )}
              </div>

              {showRejectForm ? (
                <div className="space-y-2">
                  <Label htmlFor="rejection-reason">Rejection Reason</Label>
                  <Textarea
                    id="rejection-reason"
                    placeholder="Please provide a reason for rejection..."
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    className="min-h-[80px]"
                  />
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Do you want to approve or reject this deposit request?
                </p>
              )}
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col sm:flex-row gap-2">
          {showRejectForm ? (
            <>
              <Button
                variant="outline"
                onClick={() => setShowRejectForm(false)}
                className="w-full sm:w-auto"
              >
                Back
              </Button>
              <Button
                variant="destructive"
                onClick={handleReject}
                disabled={isRejecting || !rejectionReason.trim()}
                className="w-full sm:w-auto"
              >
                <X className="h-4 w-4 mr-1" />
                {isRejecting ? "Rejecting..." : "Confirm Rejection"}
              </Button>
            </>
          ) : (
            <>
              <AlertDialogCancel className="w-full sm:w-auto">
                Cancel
              </AlertDialogCancel>
              <Button
                variant="destructive"
                onClick={() => setShowRejectForm(true)}
                className="w-full sm:w-auto"
              >
                <X className="h-4 w-4 mr-1" />
                Reject
              </Button>
              <Button
                onClick={handleApprove}
                disabled={isApproving}
                className="w-full sm:w-auto"
              >
                <Check className="h-4 w-4 mr-1" />
                {isApproving ? "Approving..." : "Approve"}
              </Button>
            </>
          )}
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
