import { memo, useMemo, useState } from "react";
import { useDroppable } from "@dnd-kit/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { PipelineStage, SaleBranchWithClient } from "@/types/pipeline";
import { PipelineCard } from "./PipelineCard";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency } from "@/lib/utils";
import { Search, X } from "lucide-react";

type ViewDensity = "compact" | "comfortable" | "spacious";

interface PipelineColumnProps {
  stage: {
    value: PipelineStage;
    label: string;
    color: string;
  };
  branches: SaleBranchWithClient[];
  onEdit: (id: string, value: number) => void;
  onDelete: (id: string) => void;
  onCardClick?: (branch: SaleBranchWithClient) => void;
  density?: ViewDensity;
  isAdmin?: boolean;
  isManager?: boolean;
  isSuperAgent?: boolean;
  isLoading?: boolean;
}

export const PipelineColumn = memo(function PipelineColumn({
  stage,
  branches,
  onEdit,
  onDelete,
  onCardClick,
  density = "comfortable",
  isAdmin = false,
  isManager = false,
  isSuperAgent = false,
  isLoading = false,
}: PipelineColumnProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const isDepositColumn = stage.value === 'DEPOSIT';

  // Filter branches by search query (only for deposit column)
  const filteredBranches = useMemo(() => {
    if (!isDepositColumn || !searchQuery.trim()) {
      return branches;
    }
    const query = searchQuery.toLowerCase();
    return branches.filter(
      (b) =>
        b.client?.name?.toLowerCase().includes(query) ||
        b.client?.email?.toLowerCase().includes(query) ||
        b.name?.toLowerCase().includes(query)
    );
  }, [branches, searchQuery, isDepositColumn]);

  const totalValue = useMemo(() => {
    // For DEPOSIT stage, only count approved deposits
    if (stage.value === 'DEPOSIT') {
      return filteredBranches
        .filter((b) => b.deposit_status === 'approved')
        .reduce((sum, b) => sum + Number(b.value), 0);
    }
    // For all other stages, count all branches
    return filteredBranches.reduce((sum, b) => sum + Number(b.value), 0);
  }, [filteredBranches, stage.value]);

  const { setNodeRef, isOver } = useDroppable({
    id: stage.value,
    data: {
      type: "column",
      stage: stage.value,
    },
  });

  const minHeight =
    density === "compact"
      ? "min-h-[250px]"
      : density === "comfortable"
      ? "min-h-[300px]"
      : "min-h-[400px]";

  const spacing =
    density === "compact"
      ? "space-y-1"
      : density === "comfortable"
      ? "space-y-2"
      : "space-y-3";

  const padding =
    density === "compact" ? "p-2" : density === "comfortable" ? "p-2" : "p-3";

  return (
    <div ref={setNodeRef} className="h-full">
      <Card
        className={cn(
          "h-full flex flex-col border-border shadow-sm transition-all",
          isOver && "ring-2 ring-primary shadow-lg"
        )}
      >
        <CardHeader className="pb-2 pt-2 border-b bg-muted rounded-t-md flex-shrink-0 h-[88px]">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xs font-semibold">{stage.label}</CardTitle>
            <Badge variant="secondary" className="text-sm h-6 px-2">
              {filteredBranches.length}
              {searchQuery && filteredBranches.length !== branches.length && (
                <span className="text-muted-foreground">/{branches.length}</span>
              )}
            </Badge>
          </div>
          <p className="font-medium opacity-90 text-lg">
            {formatCurrency(totalValue)}
          </p>
        </CardHeader>
        {isDepositColumn && (
          <div className="px-3 pt-3 flex-shrink-0">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search deposits..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 h-8 text-sm"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        )}
        <CardContent className={cn(padding, spacing, "flex-1 bg-muted/30 overflow-y-auto", minHeight)}>
          {isLoading ? (
            // Loading skeletons
            <div className={spacing}>
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-24 w-full rounded-lg" />
              ))}
            </div>
          ) : filteredBranches.length > 0 ? (
            filteredBranches.map((branch) => (
              <div key={branch.id} className="animate-fade-in">
                <PipelineCard
                  branch={branch}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  onCardClick={onCardClick}
                  density={density}
                  isAdmin={isAdmin}
                  isManager={isManager}
                  isSuperAgent={isSuperAgent}
                />
              </div>
            ))
          ) : (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
              {searchQuery ? "No matching deposits" : "Drop opportunities here"}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
});
