import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";
import { Eye, EyeOff } from "lucide-react";

const fullNameSchema = z.string()
  .trim()
  .min(1, "Tenant name is required")
  .max(100, "Name must be less than 100 characters");

const usernameSchema = z.string()
  .trim()
  .min(3, "Username must be at least 3 characters")
  .max(50, "Username must be less than 50 characters")
  .regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, hyphens, and underscores");

const passwordSchema = z.string()
  .min(6, "Password must be at least 6 characters")
  .optional()
  .or(z.literal(""));

interface Tenant {
  id: string;
  full_name: string | null;
  email: string;
  username?: string | null;
}

interface EditTenantDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tenant: Tenant | null;
  onTenantUpdated: () => void;
}

export function EditTenantDialog({ open, onOpenChange, tenant, onTenantUpdated }: EditTenantDialogProps) {
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    if (tenant) {
      setFullName(tenant.full_name || "");
      setUsername(tenant.username || "");
      setNewPassword("");
    }
  }, [tenant]);

  const handleUpdate = async () => {
    if (!tenant) return;

    // Validate inputs
    try {
      fullNameSchema.parse(fullName);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    try {
      usernameSchema.parse(username);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    if (newPassword) {
      try {
        passwordSchema.parse(newPassword);
      } catch (error) {
        if (error instanceof z.ZodError) {
          toast.error(error.errors[0].message);
        }
        return;
      }
    }

    setIsUpdating(true);
    try {
      // Generate new email from username
      const newEmail = `${username}@crm.internal`;

      // Update profile (name and username)
      const { error: profileError } = await supabase
        .from("profiles")
        .update({ 
          full_name: fullName,
          username: username,
          email: newEmail
        })
        .eq("id", tenant.id);

      if (profileError) throw profileError;

      // Update password if provided
      if (newPassword) {
        const { error: passwordError } = await supabase.functions.invoke("manage-user-password", {
          body: {
            action: "update-password",
            userId: tenant.id,
            newPassword: newPassword,
          },
        });

        if (passwordError) {
          throw new Error(passwordError.message || "Failed to update password");
        }
      }

      toast.success("Tenant updated successfully");
      onTenantUpdated();
      onOpenChange(false);
    } catch (error: unknown) {
      console.error("Error updating tenant:", error);
      const message = error instanceof Error ? error.message : "Failed to update tenant";
      toast.error(message);
    } finally {
      setIsUpdating(false);
    }
  };

  // Extract username from email (before @crm.internal)
  const displayUsername = tenant?.username || tenant?.email?.split("@")[0] || "";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Tenant</DialogTitle>
          <DialogDescription>
            Update tenant credentials and information.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit_tenant_name">Tenant Name *</Label>
            <Input
              id="edit_tenant_name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Acme Trading Co."
            />
          </div>

          <Separator />

          <div className="space-y-2">
            <Label htmlFor="edit_username">Login Username *</Label>
            <Input
              id="edit_username"
              value={username || displayUsername}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="tenant_admin"
            />
            <p className="text-xs text-muted-foreground">
              This is used for logging in to the tenant account.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit_password">New Password (optional)</Label>
            <div className="relative">
              <Input
                id="edit_password"
                type={showPassword ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Leave empty to keep current password"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <Eye className="h-4 w-4 text-muted-foreground" />
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Minimum 6 characters. Leave empty to keep current password.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={handleUpdate} disabled={isUpdating}>
            {isUpdating ? "Updating..." : "Update Tenant"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
