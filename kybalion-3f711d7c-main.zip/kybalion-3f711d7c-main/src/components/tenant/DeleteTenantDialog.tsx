import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { AlertTriangle } from "lucide-react";

interface Tenant {
  id: string;
  full_name: string | null;
  email: string;
  stats?: {
    usersCount: number;
    leadsCount: number;
    clientsCount: number;
    depositsCount: number;
  };
}

interface DeleteTenantDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tenant: Tenant | null;
  onTenantDeleted: () => void;
}

export function DeleteTenantDialog({
  open,
  onOpenChange,
  tenant,
  onTenantDeleted,
}: DeleteTenantDialogProps) {
  const [deleteUsers, setDeleteUsers] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    if (!tenant) return;

    setIsDeleting(true);
    try {
      const { data, error } = await supabase.functions.invoke("delete-tenant", {
        body: {
          tenantId: tenant.id,
          deleteUsers,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success(
        deleteUsers
          ? "Tenant and all users deleted successfully"
          : "Tenant deleted successfully"
      );
      onTenantDeleted();
      onOpenChange(false);
      setDeleteUsers(false);
    } catch (error: unknown) {
      console.error("Error deleting tenant:", error);
      const message =
        error instanceof Error ? error.message : "Failed to delete tenant";
      toast.error(message);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleClose = () => {
    if (!isDeleting) {
      setDeleteUsers(false);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Delete Tenant
          </DialogTitle>
          <DialogDescription>
            This action cannot be undone. All tenant data will be permanently
            deleted.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4">
            <p className="text-sm font-medium mb-2">
              You are about to delete tenant:
            </p>
            <p className="text-lg font-bold">
              {tenant?.full_name || tenant?.email}
            </p>
          </div>

          {tenant?.stats && (
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>This will permanently delete:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>
                  <strong>{tenant.stats.leadsCount}</strong> leads
                </li>
                <li>
                  <strong>{tenant.stats.clientsCount}</strong> clients
                </li>
                <li>
                  <strong>{tenant.stats.depositsCount}</strong> deposits
                </li>
                <li>All related settings, activities, and documents</li>
              </ul>
            </div>
          )}

          {tenant?.stats?.usersCount && tenant.stats.usersCount > 0 && (
            <div className="flex items-start space-x-3 rounded-lg border p-4">
              <Checkbox
                id="deleteUsers"
                checked={deleteUsers}
                onCheckedChange={(checked) => setDeleteUsers(checked === true)}
              />
              <div className="space-y-1">
                <Label
                  htmlFor="deleteUsers"
                  className="text-sm font-medium cursor-pointer"
                >
                  Also delete all users under this tenant
                </Label>
                <p className="text-xs text-muted-foreground">
                  This will delete <strong>{tenant.stats.usersCount}</strong>{" "}
                  user{tenant.stats.usersCount !== 1 ? "s" : ""} created by this
                  tenant.
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={isDeleting}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleDelete}
            disabled={isDeleting}
          >
            {isDeleting ? "Deleting..." : "Delete Tenant"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
