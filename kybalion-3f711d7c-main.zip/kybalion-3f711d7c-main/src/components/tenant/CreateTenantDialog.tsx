import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { z } from "zod";

const usernameSchema = z.string()
  .trim()
  .min(3, "Username must be at least 3 characters")
  .max(50, "Username must be less than 50 characters")
  .regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, hyphens, and underscores");

const passwordSchema = z.string()
  .min(6, "Password must be at least 6 characters");

const fullNameSchema = z.string()
  .trim()
  .min(1, "Tenant name is required")
  .max(100, "Name must be less than 100 characters");

interface CreateTenantDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onTenantCreated: () => void;
}

export function CreateTenantDialog({ open, onOpenChange, onTenantCreated }: CreateTenantDialogProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [whitelistedIps, setWhitelistedIps] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  const handleCreate = async () => {
    try {
      usernameSchema.parse(username);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    try {
      passwordSchema.parse(password);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    try {
      fullNameSchema.parse(fullName);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      }
      return;
    }

    setIsCreating(true);
    try {
      // Call edge function to create user with TENANT_OWNER role
      const { data, error } = await supabase.functions.invoke('create-user', {
        body: {
          username,
          password,
          fullName,
          role: "TENANT_OWNER", // Tenants are TENANT_OWNER role users
          whitelistedIps,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success("Tenant created successfully");
      
      onTenantCreated();
      onOpenChange(false);
      resetForm();
    } catch (error: unknown) {
      console.error("Error creating tenant:", error);
      const message = error instanceof Error ? error.message : "Failed to create tenant";
      toast.error(message);
    } finally {
      setIsCreating(false);
    }
  };

  const resetForm = () => {
    setUsername("");
    setPassword("");
    setFullName("");
    setWhitelistedIps("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Tenant</DialogTitle>
          <DialogDescription>
            Create a new tenant workspace. Each tenant has their own isolated data, users, and settings.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="tenant_name">Tenant Name *</Label>
            <Input
              id="tenant_name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Acme Trading Co."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Login Username *</Label>
            <Input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="acme_admin"
            />
            <p className="text-xs text-muted-foreground">
              This will be the tenant admin's login username.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password *</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ips">Whitelisted IPs (Optional)</Label>
            <Input
              id="ips"
              value={whitelistedIps}
              onChange={(e) => setWhitelistedIps(e.target.value)}
              placeholder="192.168.1.1, 10.0.0.1"
            />
            <p className="text-xs text-muted-foreground">
              Comma-separated IP addresses. Leave empty for no restrictions.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={handleCreate} disabled={isCreating}>
            {isCreating ? "Creating..." : "Create Tenant"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
