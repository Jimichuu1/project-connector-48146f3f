import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Plus, Trash2, Globe, Shield } from "lucide-react";

interface TenantIPWhitelistDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tenant: {
    id: string;
    full_name: string | null;
  } | null;
}

interface IPEntry {
  id: string;
  ip_address: string;
  description: string | null;
  is_active: boolean;
  created_at: string;
  user_id: string;
}

export function TenantIPWhitelistDialog({
  open,
  onOpenChange,
  tenant,
}: TenantIPWhitelistDialogProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [newIP, setNewIP] = useState("");
  const [newDescription, setNewDescription] = useState("");

  const { data: ipEntries, isLoading } = useQuery({
    queryKey: ["tenant-ip-whitelist", tenant?.id],
    queryFn: async () => {
      if (!tenant?.id) return [];
      
      const { data, error } = await supabase
        .from("ip_whitelist")
        .select("*")
        .eq("admin_id", tenant.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as IPEntry[];
    },
    enabled: open && !!tenant?.id,
  });

  const addIPMutation = useMutation({
    mutationFn: async () => {
      if (!tenant?.id || !user?.id) throw new Error("Missing tenant or user");
      
      // Validate IP format
      const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
      if (!ipRegex.test(newIP)) {
        throw new Error("Invalid IP address format");
      }

      const { error } = await supabase.from("ip_whitelist").insert({
        ip_address: newIP,
        description: newDescription || null,
        user_id: tenant.id, // The tenant owner
        created_by: user.id,
        admin_id: tenant.id,
        is_active: true,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("IP address added to whitelist");
      setNewIP("");
      setNewDescription("");
      queryClient.invalidateQueries({ queryKey: ["tenant-ip-whitelist", tenant?.id] });
    },
    onError: (error: Error) => {
      toast.error(error.message || "Failed to add IP address");
    },
  });

  const toggleIPMutation = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase
        .from("ip_whitelist")
        .update({ is_active })
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("IP status updated");
      queryClient.invalidateQueries({ queryKey: ["tenant-ip-whitelist", tenant?.id] });
    },
    onError: () => {
      toast.error("Failed to update IP status");
    },
  });

  const deleteIPMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("ip_whitelist")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("IP address removed from whitelist");
      queryClient.invalidateQueries({ queryKey: ["tenant-ip-whitelist", tenant?.id] });
    },
    onError: () => {
      toast.error("Failed to remove IP address");
    },
  });

  const handleAddIP = () => {
    if (!newIP.trim()) {
      toast.error("Please enter an IP address");
      return;
    }
    addIPMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            IP Whitelist
          </DialogTitle>
          <DialogDescription>
            Manage allowed IP addresses for {tenant?.full_name || "this tenant"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Add new IP form */}
          <div className="space-y-3 p-4 border rounded-lg bg-muted/30">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Plus className="h-4 w-4" />
              Add New IP Address
            </div>
            <div className="grid gap-3">
              <div className="grid gap-2">
                <Label htmlFor="ip">IP Address</Label>
                <Input
                  id="ip"
                  placeholder="192.168.1.1"
                  value={newIP}
                  onChange={(e) => setNewIP(e.target.value)}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Input
                  id="description"
                  placeholder="Office main network"
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                />
              </div>
              <Button 
                onClick={handleAddIP} 
                disabled={addIPMutation.isPending}
                size="sm"
              >
                {addIPMutation.isPending ? "Adding..." : "Add IP"}
              </Button>
            </div>
          </div>

          {/* IP list */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Whitelisted IPs</span>
              <Badge variant="outline">{ipEntries?.length || 0}</Badge>
            </div>

            {isLoading ? (
              <div className="space-y-2">
                {[1, 2].map((i) => (
                  <Skeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            ) : ipEntries && ipEntries.length > 0 ? (
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {ipEntries.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between p-3 border rounded-lg bg-background"
                  >
                    <div className="flex items-center gap-3">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <code className="text-sm font-mono">{entry.ip_address}</code>
                        {entry.description && (
                          <p className="text-xs text-muted-foreground">{entry.description}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={entry.is_active}
                        onCheckedChange={(checked) =>
                          toggleIPMutation.mutate({ id: entry.id, is_active: checked })
                        }
                      />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => deleteIPMutation.mutate(entry.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground text-sm">
                <Globe className="h-8 w-8 mx-auto mb-2 opacity-50" />
                No IP addresses whitelisted
                <p className="text-xs mt-1">Users can login from any IP</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
