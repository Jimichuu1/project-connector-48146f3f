import { useDraggable } from "@dnd-kit/core";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";

interface TeamMember {
  id: string;
  full_name: string | null;
  username: string | null;
  email: string;
  avatar_url: string | null;
  role: string;
  created_by: string | null;
  admin_id: string | null;
}

interface DraggableTeamMemberProps {
  member: TeamMember;
  isDragging?: boolean;
}

const getRoleBadgeColor = (role: string) => {
  switch (role) {
    case "SUPER_ADMIN":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    case "TENANT_OWNER":
      return "bg-red-500/20 text-red-400 border-red-500/30";
    case "MANAGER":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    case "SUPER_AGENT":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "AGENT":
      return "bg-green-500/20 text-green-400 border-green-500/30";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getRoleLabel = (role: string) => {
  switch (role) {
    case "SUPER_ADMIN":
      return "Super Admin";
    case "TENANT_OWNER":
      return "Admin";
    case "MANAGER":
      return "Manager";
    case "SUPER_AGENT":
      return "Super Agent";
    case "AGENT":
      return "Agent";
    default:
      return role;
  }
};

const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

export function DraggableTeamMember({ member, isDragging }: DraggableTeamMemberProps) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: member.id,
    data: { member, type: "team-member" },
  });

  const style = transform
    ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
      }
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg border border-border bg-card",
        "hover:border-primary/50 hover:shadow-md transition-all duration-200",
        "cursor-grab active:cursor-grabbing group",
        isDragging && "opacity-50 shadow-xl ring-2 ring-primary"
      )}
      {...listeners}
      {...attributes}
    >
      <GripVertical className="h-4 w-4 text-muted-foreground" />
      <Avatar className="h-9 w-9 ring-2 ring-background shadow-sm">
        <AvatarImage src={member.avatar_url || ""} alt={member.full_name || ""} />
        <AvatarFallback className="text-xs font-medium bg-primary/10 text-primary">
          {getInitials(member.full_name || member.username || "U")}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">
          {member.full_name || member.username || "Unknown"}
        </p>
        <p className="text-xs text-muted-foreground truncate">@{member.username}</p>
      </div>
      <Badge variant="outline" className={cn("text-xs", getRoleBadgeColor(member.role))}>
        {getRoleLabel(member.role)}
      </Badge>
    </div>
  );
}

export function DragOverlayContent({ member }: { member: TeamMember }) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg border-2 border-primary bg-card shadow-2xl cursor-grabbing">
      <GripVertical className="h-4 w-4 text-primary" />
      <Avatar className="h-9 w-9 ring-2 ring-primary shadow-sm">
        <AvatarImage src={member.avatar_url || ""} alt={member.full_name || ""} />
        <AvatarFallback className="text-xs font-medium bg-primary/10 text-primary">
          {getInitials(member.full_name || member.username || "U")}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">
          {member.full_name || member.username || "Unknown"}
        </p>
        <p className="text-xs text-muted-foreground truncate">@{member.username}</p>
      </div>
      <Badge variant="outline" className={cn("text-xs", getRoleBadgeColor(member.role))}>
        {getRoleLabel(member.role)}
      </Badge>
    </div>
  );
}
