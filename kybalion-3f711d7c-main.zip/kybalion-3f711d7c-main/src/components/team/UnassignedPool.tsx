import { useDroppable } from "@dnd-kit/core";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserMinus, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { DraggableTeamMember } from "./DraggableTeamMember";

interface TeamMember {
  id: string;
  full_name: string | null;
  username: string | null;
  email: string;
  avatar_url: string | null;
  role: string;
  created_by: string | null;
  admin_id: string | null;
}

interface UnassignedPoolProps {
  members: TeamMember[];
}

export function UnassignedPool({ members }: UnassignedPoolProps) {
  const { isOver, setNodeRef } = useDroppable({
    id: "unassigned-pool",
    data: { type: "unassigned" },
  });

  if (members.length === 0 && !isOver) return null;

  return (
    <Card
      ref={setNodeRef}
      className={cn(
        "border-2 border-dashed transition-all duration-200",
        isOver
          ? "border-amber-500 bg-amber-500/10 shadow-lg shadow-amber-500/20"
          : "border-amber-500/50 bg-amber-500/5"
      )}
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2 text-amber-500">
          <AlertCircle className="h-5 w-5" />
          Unassigned Team Members
          <span className="ml-auto text-sm font-normal text-muted-foreground">
            {members.length} {members.length === 1 ? "member" : "members"}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {members.length === 0 && isOver ? (
            <div className="col-span-full flex items-center justify-center h-20 text-amber-500">
              <UserMinus className="h-6 w-6 mr-2" />
              <span>Drop here to unassign</span>
            </div>
          ) : (
            members.map((member) => (
              <DraggableTeamMember key={member.id} member={member} />
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
