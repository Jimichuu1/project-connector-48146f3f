import { useDroppable } from "@dnd-kit/core";
import { useDraggable } from "@dnd-kit/core";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Users, UserPlus, GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";
import { DraggableTeamMember } from "./DraggableTeamMember";

interface TeamMember {
  id: string;
  full_name: string | null;
  username: string | null;
  email: string;
  avatar_url: string | null;
  role: string;
  created_by: string | null;
  admin_id: string | null;
}

interface DroppableTeamLeaderGroupProps {
  teamLeader: TeamMember;
  teamMembers: TeamMember[];
}

const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

export function DroppableTeamLeaderGroup({ teamLeader, teamMembers }: DroppableTeamLeaderGroupProps) {
  const { isOver, setNodeRef: setDropRef } = useDroppable({
    id: `team-leader-${teamLeader.id}`,
    data: { teamLeader, type: "team-leader-group" },
  });

  const { attributes, listeners, setNodeRef: setDragRef, isDragging } = useDraggable({
    id: teamLeader.id,
    data: { member: teamLeader, type: "team-member" },
  });

  return (
    <div
      ref={(node) => {
        setDropRef(node);
      }}
      className={cn(
        "rounded-lg border p-3 transition-all duration-200",
        "bg-gradient-to-b from-cyan-500/5 to-transparent",
        isOver && "ring-2 ring-cyan-500 border-cyan-500 shadow-lg shadow-cyan-500/20",
        isDragging && "opacity-40"
      )}
    >
      {/* Team Leader Header - Draggable */}
      <div
        ref={setDragRef}
        {...listeners}
        {...attributes}
        className="flex items-center gap-2 mb-2 cursor-grab active:cursor-grabbing"
      >
        <GripVertical className="h-4 w-4 text-muted-foreground/50 flex-shrink-0" />
        <Avatar className="h-8 w-8 ring-2 ring-cyan-500/30">
          <AvatarImage src={teamLeader.avatar_url || ""} alt={teamLeader.full_name || ""} />
          <AvatarFallback className="bg-cyan-500/20 text-cyan-400 text-xs font-semibold">
            {getInitials(teamLeader.full_name || teamLeader.username || "TL")}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{teamLeader.full_name || teamLeader.username}</p>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-[10px] px-1.5 py-0">
              Team Leader
            </Badge>
            <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
              <Users className="h-2.5 w-2.5" />
              {teamMembers.length}
            </span>
          </div>
        </div>
      </div>

      {/* Sub-team members */}
      <div
        className={cn(
          "min-h-[60px] rounded-md border border-dashed p-1.5 space-y-1.5 transition-all",
          isOver
            ? "border-cyan-500 bg-cyan-500/5"
            : "border-border/40 bg-muted/10"
        )}
      >
        {teamMembers.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[50px] text-muted-foreground">
            <UserPlus className="h-5 w-5 mb-1 opacity-40" />
            <p className="text-[10px] text-center">Drop agents here</p>
          </div>
        ) : (
          teamMembers.map((member) => (
            <DraggableTeamMember key={member.id} member={member} />
          ))
        )}
      </div>
    </div>
  );
}
