import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface TeamMember {
  id: string;
  full_name: string | null;
  username: string | null;
  email: string;
  avatar_url: string | null;
  role: string;
  created_by: string | null;
}

interface AssignUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: TeamMember;
  availableParents: TeamMember[];
  parentLabel: string;
}

const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

const getRoleBadgeColor = (role: string) => {
  switch (role) {
    case "SUPER_ADMIN":
      return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    case "TENANT_OWNER":
      return "bg-red-500/20 text-red-400 border-red-500/30";
    case "MANAGER":
      return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    case "SUPER_AGENT":
      return "bg-amber-500/20 text-amber-400 border-amber-500/30";
    case "AGENT":
      return "bg-green-500/20 text-green-400 border-green-500/30";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getRoleLabel = (role: string) => {
  switch (role) {
    case "SUPER_ADMIN":
      return "Super Admin";
    case "TENANT_OWNER":
      return "Tenant Owner";
    case "MANAGER":
      return "Manager";
    case "SUPER_AGENT":
      return "Super Agent";
    case "AGENT":
      return "Agent";
    default:
      return role;
  }
};

export function AssignUserDialog({ 
  open, 
  onOpenChange, 
  user, 
  availableParents,
  parentLabel 
}: AssignUserDialogProps) {
  const [selectedParentId, setSelectedParentId] = useState<string>(user.created_by || "");
  const queryClient = useQueryClient();

  const assignMutation = useMutation({
    mutationFn: async (parentId: string | null) => {
      const { error } = await supabase
        .from("profiles")
        .update({ created_by: parentId })
        .eq("id", user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("User assigned successfully");
      queryClient.invalidateQueries({ queryKey: ["team-hierarchy"] });
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error("Failed to assign user: " + error.message);
    },
  });

  const handleAssign = () => {
    const parentId = selectedParentId === "unassigned" || !selectedParentId ? null : selectedParentId;
    assignMutation.mutate(parentId);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Assign User</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {/* User being assigned */}
          <div className="flex items-center gap-3 p-3 rounded-lg bg-accent/50">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user.avatar_url || ""} alt={user.full_name || ""} />
              <AvatarFallback>
                {getInitials(user.full_name || user.username || "U")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="font-medium">{user.full_name || user.username || "Unknown"}</p>
              <p className="text-sm text-muted-foreground">{user.username}</p>
            </div>
            <Badge variant="outline" className={getRoleBadgeColor(user.role)}>
              {getRoleLabel(user.role)}
            </Badge>
          </div>

          {/* Parent selection */}
          <div className="space-y-2">
            <Label>Assign to {parentLabel}</Label>
            <Select value={selectedParentId} onValueChange={setSelectedParentId}>
              <SelectTrigger>
                <SelectValue placeholder={`Select ${parentLabel.toLowerCase()}`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="unassigned">
                  <span className="text-muted-foreground">Unassigned</span>
                </SelectItem>
                {availableParents.map((parent) => (
                  <SelectItem key={parent.id} value={parent.id}>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-5 w-5">
                        <AvatarImage src={parent.avatar_url || ""} />
                        <AvatarFallback className="text-[10px]">
                          {getInitials(parent.full_name || parent.username || "U")}
                        </AvatarFallback>
                      </Avatar>
                      <span>{parent.full_name || parent.username}</span>
                      <Badge variant="outline" className={`text-[10px] px-1 py-0 ${getRoleBadgeColor(parent.role)}`}>
                        {getRoleLabel(parent.role)}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleAssign} disabled={assignMutation.isPending}>
            {assignMutation.isPending ? "Assigning..." : "Assign"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
