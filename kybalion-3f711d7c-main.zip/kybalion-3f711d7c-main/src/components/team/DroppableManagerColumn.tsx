import { useDroppable } from "@dnd-kit/core";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Users, UserPlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { DraggableTeamMember } from "./DraggableTeamMember";
import { DroppableTeamLeaderGroup } from "./DroppableTeamLeaderGroup";

interface TeamMember {
  id: string;
  full_name: string | null;
  username: string | null;
  email: string;
  avatar_url: string | null;
  role: string;
  created_by: string | null;
  admin_id: string | null;
}

interface DroppableManagerColumnProps {
  manager: TeamMember;
  teamMembers: TeamMember[];
  teamLeaders?: TeamMember[];
  allMembers?: TeamMember[];
  isOver?: boolean;
}

const getInitials = (name: string) => {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};

export function DroppableManagerColumn({ manager, teamMembers, teamLeaders = [], allMembers = [] }: DroppableManagerColumnProps) {
  const { isOver, setNodeRef } = useDroppable({
    id: `manager-${manager.id}`,
    data: { manager, type: "manager-column" },
  });

  const teamLeaderIds = new Set(teamLeaders.map(tl => tl.id));
  const directMembers = teamMembers.filter(m => !teamLeaderIds.has(m.id));

  const getTeamLeaderMembers = (tlId: string) => {
    return allMembers.filter(m => m.created_by === tlId && m.role !== "TEAM_LEADER");
  };

  const totalCount = teamMembers.length + teamLeaders.reduce((acc, tl) => acc + getTeamLeaderMembers(tl.id).length, 0);

  return (
    <Card
      ref={setNodeRef}
      className={cn(
        "min-w-[320px] max-w-[340px] flex-shrink-0 transition-all duration-200",
        "bg-gradient-to-b from-card to-card/95",
        isOver && "ring-2 ring-primary border-primary shadow-lg shadow-primary/20"
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-12 w-12 ring-2 ring-primary/30 shadow-lg">
            <AvatarImage src={manager.avatar_url || ""} alt={manager.full_name || ""} />
            <AvatarFallback className="bg-primary/20 text-primary font-semibold">
              {getInitials(manager.full_name || manager.username || "M")}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{manager.full_name || manager.username}</p>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant="outline" className="bg-primary/20 text-primary border-primary/30 text-xs">
                Manager
              </Badge>
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Users className="h-3 w-3" />
                {totalCount}
              </span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        {teamLeaders.length > 0 && (
          <div className="space-y-2">
            {teamLeaders.map((tl) => (
              <DroppableTeamLeaderGroup
                key={tl.id}
                teamLeader={tl}
                teamMembers={getTeamLeaderMembers(tl.id)}
              />
            ))}
          </div>
        )}

        <div
          className={cn(
            "min-h-[80px] rounded-lg border-2 border-dashed p-2 space-y-2 transition-all",
            isOver
              ? "border-primary bg-primary/5"
              : "border-border/50 bg-muted/20"
          )}
        >
          {directMembers.length === 0 && teamLeaders.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[80px] text-muted-foreground">
              <UserPlus className="h-8 w-8 mb-2 opacity-40" />
              <p className="text-xs text-center">Drop agents here<br />to assign</p>
            </div>
          ) : directMembers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[40px] text-muted-foreground">
              <p className="text-[10px] text-center opacity-50">Drop more agents here</p>
            </div>
          ) : (
            directMembers.map((member) => (
              <DraggableTeamMember key={member.id} member={member} />
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
