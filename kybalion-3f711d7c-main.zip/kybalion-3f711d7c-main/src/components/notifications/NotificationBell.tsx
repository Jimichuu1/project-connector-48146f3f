import { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Bell, X, Check, DollarSign, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNotifications } from "@/hooks/useNotifications";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { NotificationType } from "@/types/notifications";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { clientHref, leadHref } from "@/lib/idCipher";
import { useUserData } from "@/contexts/UserDataContext";
import { toast } from "sonner";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { updateFaviconWithBadge, resetFavicon } from "@/utils/faviconBadge";
const getNotificationIcon = (type: NotificationType) => {
  switch (type) {
    case 'NEW_LEAD':
      return '🆕';
    case 'WITHDRAWAL_REQUEST':
      return '💰';
    case 'LEAD_ASSIGNED':
      return '📋';
    case 'CLIENT_CONVERTED':
      return '🎉';
    case 'TASK_DUE':
      return '⏰';
    case 'TICKET_CREATED':
      return '🎫';
    case 'CONVERSION_APPROVED':
      return '✅';
    case 'CONVERSION_REJECTED':
      return '❌';
    case 'DEPOSIT_APPROVED':
      return '✅💰';
    case 'DEPOSIT_REJECTED':
      return '❌💰';
    case 'DEPOSIT_SPLIT_RECEIVED':
      return '🤝💰';
    case 'CLIENT_ASSIGNED':
      return '👤';
    default:
      return '🔔';
  }
};

// Helper to render notification message with clickable entity name
const renderNotificationMessage = (
  message: string,
  entityType: string | null | undefined,
  entityId: string | null | undefined,
  onClick?: () => void
) => {
  if (!entityType || !entityId) {
    return <span>{message}</span>;
  }

  // Match name in quotes: "Name Here"
  const match = message.match(/"([^"]+)"/);
  if (!match) {
    return <span>{message}</span>;
  }

  const name = match[1];
  const route = entityType === 'client' ? clientHref(entityId) : leadHref(entityId);
  const parts = message.split(`"${name}"`);

  return (
    <span>
      {parts[0]}
      <Link
        to={route}
        className="text-primary hover:underline font-medium"
        onClick={onClick}
      >
        "{name}"
      </Link>
      {parts[1]}
    </span>
  );
};
export const NotificationBell = () => {
  const {
    user
  } = useAuth();
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const {
    notifications: rawNotifications,
    unreadCount: rawUnreadCount,
    markAsRead,
    markAllAsRead,
    dismissNotification
  } = useNotifications();
  const { isTeamLeader } = useUserData();

  // Filter out deposit-related notifications for Team Leaders
  const depositNotificationTypes: NotificationType[] = ['DEPOSIT_APPROVED', 'DEPOSIT_REJECTED', 'DEPOSIT_SPLIT_RECEIVED'];
  const notifications = isTeamLeader
    ? rawNotifications?.filter(n => !depositNotificationTypes.includes(n.type))
    : rawNotifications;
  const unreadCount = isTeamLeader
    ? notifications?.filter(n => !n.is_read).length || 0
    : rawUnreadCount;
  const [pendingApproval, setPendingApproval] = useState<any | null>(null);
  const [pendingRejection, setPendingRejection] = useState<string | null>(null);
  const [notificationSoundUrl, setNotificationSoundUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Fetch pending deposits for admins
  const {
    data: pendingDeposits,
    refetch
  } = useQuery({
    queryKey: ["pending-deposits"],
    queryFn: async () => {
      if (!user) return [];

      // Check if user is super admin or tenant owner (managers cannot approve deposits)
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .in("role", ["SUPER_ADMIN", "TENANT_OWNER", "ADMIN"]);
      
      if (!roles || roles.length === 0) return [];

      // Fetch pending deposits (RLS will filter by tenant)
      const { data, error } = await supabase
        .from("deposits")
        .select(`
          *,
          agent:profiles!deposits_agent_id_fkey(full_name, email),
          super_agent:profiles!deposits_super_agent_id_fkey(full_name, email),
          client:clients!deposits_client_id_fkey(name)
        `)
        .eq("status", "pending")
        .order("created_at", { ascending: false })
        .limit(10);
      
      if (error) {
        console.error("Error fetching pending deposits:", error);
        return [];
      }
      
      // Fetch split super agent profiles separately
      const depositsData = data || [];
      const splitAgentIds = [...new Set(depositsData
        .filter(d => d.split_super_agent_id)
        .map(d => d.split_super_agent_id))] as string[];
      
      let splitAgentProfiles: Record<string, { full_name: string | null; email: string }> = {};
      
      if (splitAgentIds.length > 0) {
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .in('id', splitAgentIds);
        
        if (profiles) {
          splitAgentProfiles = profiles.reduce((acc, p) => {
            acc[p.id] = { full_name: p.full_name, email: p.email };
            return acc;
          }, {} as Record<string, { full_name: string | null; email: string }>);
        }
      }
      
      // Attach split_super_agent to deposits
      return depositsData.map(d => ({
        ...d,
        split_super_agent: d.split_super_agent_id ? splitAgentProfiles[d.split_super_agent_id] : undefined,
      }));
    },
    enabled: !!user
  });

  // Fetch notification sound URL (tenant-scoped)
  useEffect(() => {
    const loadNotificationSound = async () => {
      try {
        let settingsQuery = supabase.from('admin_settings').select('celebration_sound_url');
        if (effectiveTenantId) {
          settingsQuery = settingsQuery.eq('admin_id', effectiveTenantId);
        }
        const { data: settings } = await settingsQuery.maybeSingle();
        if (settings?.celebration_sound_url) {
          setNotificationSoundUrl(settings.celebration_sound_url);
        }
      } catch {
        // Silent fail for notification sound load
      }
    };
    loadNotificationSound();
  }, [effectiveTenantId]);

  // Update browser tab title and favicon with notification count
  useEffect(() => {
    const totalCount = unreadCount + (pendingDeposits?.length || 0);
    const baseTitle = "Kybalion CRM";
    
    if (totalCount > 0) {
      document.title = `${baseTitle} (${totalCount})`;
    } else {
      document.title = baseTitle;
    }
    
    // Update favicon with badge
    updateFaviconWithBadge(totalCount);
    
    return () => {
      document.title = baseTitle;
      resetFavicon();
    };
  }, [unreadCount, pendingDeposits?.length]);

  // Play notification sound
  const playNotificationSound = () => {
    if (audioRef.current && notificationSoundUrl) {
      audioRef.current.currentTime = 0; // Reset to start
      audioRef.current.play().catch(() => {/* Audio playback failed silently */});
    }
  };

  // Set up real-time subscription for deposits
  useEffect(() => {
    if (!user) return;
    const channel = supabase.channel('deposits-changes').on('postgres_changes', {
      event: 'INSERT',
      schema: 'public',
      table: 'deposits',
      filter: 'status=eq.pending'
    }, () => {
      // Invalidate and refetch pending deposits
      queryClient.invalidateQueries({
        queryKey: ['pending-deposits']
      });
      // TLs don't approve deposits, skip notification sound and toast
      if (!isTeamLeader) {
        toast.info('New deposit request received');
        playNotificationSound();
      }
    }).on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'deposits'
    }, async payload => {
      // Invalidate and refetch when deposit status changes
      queryClient.invalidateQueries({
        queryKey: ['pending-deposits']
      });
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient, notificationSoundUrl, isTeamLeader]);
  const confirmApprove = async () => {
    if (!pendingApproval) return;
    try {
      const {
        error
      } = await supabase.from("deposits").update({
        status: "approved",
        approved_by: user?.id,
        approved_at: new Date().toISOString()
      }).eq("id", pendingApproval.id);
      if (error) throw error;
      
      // Mark related notifications as read (keep history)
      await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("related_entity_id", pendingApproval.id)
        .eq("related_entity_type", "deposit");
      
      // Send DEPOSIT_APPROVED notifications to involved agents
      const approvalNotifications = [];
      if (pendingApproval.super_agent_id) {
        approvalNotifications.push({
          user_id: pendingApproval.super_agent_id,
          type: "DEPOSIT_APPROVED" as const,
          message: `Your deposit of $${pendingApproval.amount} for ${pendingApproval.client?.name || 'client'} has been approved`,
          related_entity_type: "deposit",
          related_entity_id: pendingApproval.id,
          admin_id: pendingApproval.admin_id,
        });
      }
      if (pendingApproval.split_super_agent_id) {
        approvalNotifications.push({
          user_id: pendingApproval.split_super_agent_id,
          type: "DEPOSIT_APPROVED" as const,
          message: `A split deposit of $${Number(pendingApproval.amount) / 2} for ${pendingApproval.client?.name || 'client'} has been approved`,
          related_entity_type: "deposit",
          related_entity_id: pendingApproval.id,
          admin_id: pendingApproval.admin_id,
        });
      }
      // NOTE: Transferring/closer agent notifications are gated by the
      // `counts_for_agent` toggle. The DB trigger
      // `notify_agent_on_deposit_counted_trg` will notify the agent when a
      // Tenant Owner / Super Admin flips the toggle ON. Do NOT notify the
      // agent here on plain deposit approval.
      if (approvalNotifications.length > 0) {
        await supabase.from("notifications").insert(approvalNotifications);
      }
      
      toast.success("Deposit approved successfully");
      setPendingApproval(null);

      // Invalidate and refetch to remove from list immediately
      await queryClient.invalidateQueries({ queryKey: ['pending-deposits'] });
      await queryClient.invalidateQueries({ queryKey: ['notifications'] });
      await refetch();
    } catch {
      toast.error("Failed to approve deposit");
    }
  };
  const confirmReject = async () => {
    if (!pendingRejection) return;
    try {
      const {
        error
      } = await supabase.from("deposits").update({
        status: "rejected",
        approved_by: user?.id,
        approved_at: new Date().toISOString()
      }).eq("id", pendingRejection);
      if (error) throw error;
      
      // Mark related notifications as read (keep history)
      await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("related_entity_id", pendingRejection)
        .eq("related_entity_type", "deposit");
      
      toast.success("Deposit rejected");
      setPendingRejection(null);
      
      // Invalidate and refetch to remove from list immediately
      await queryClient.invalidateQueries({ queryKey: ['pending-deposits'] });
      await queryClient.invalidateQueries({ queryKey: ['notifications'] });
      await refetch();
    } catch {
      toast.error("Failed to reject deposit");
    }
  };
  return <>
      {/* Hidden audio element for notification sound */}
      {notificationSoundUrl && <audio ref={audioRef} src={notificationSoundUrl} preload="auto" />}
      
      <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="h-5 w-5" />
          {unreadCount + (pendingDeposits?.length || 0) > 0 && <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs bg-destructive text-destructive-foreground mx-[2px] my-[2px]">
              {unreadCount + (pendingDeposits?.length || 0) > 9 ? '9+' : unreadCount + (pendingDeposits?.length || 0)}
            </Badge>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0" align="end">
        <div className="flex items-center justify-between border-b p-4">
          <h3 className="font-semibold">Notifications</h3>
          {unreadCount > 0 && <Button variant="ghost" size="sm" onClick={() => markAllAsRead.mutate()} className="text-xs">
              <Check className="h-3 w-3 mr-1" />
              Mark all read
            </Button>}
        </div>
        <ScrollArea className="h-[400px]">
          {(!notifications || notifications.length === 0) && (!pendingDeposits || pendingDeposits.length === 0) ? <div className="p-8 text-center text-muted-foreground">
              <Bell className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No notifications</p>
            </div> : <div className="divide-y">
              {/* Pending Deposits Section */}
              {pendingDeposits && pendingDeposits.length > 0 && <div className="bg-primary/5 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="h-4 w-4 text-primary" />
                    <span className="text-sm font-semibold">Pending Approvals ({pendingDeposits.length})</span>
                  </div>
                  {pendingDeposits.map((deposit) => <div key={deposit.id} className="p-3 mb-2 bg-card rounded-md border border-border">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="text-sm font-semibold">${Number(deposit.amount).toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground font-medium">
                            Client: {deposit.client?.name || 'Unknown'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {deposit.super_agent?.full_name || deposit.super_agent?.email}
                            {deposit.split_super_agent && ` & ${deposit.split_super_agent.full_name || deposit.split_super_agent.email}`}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(deposit.created_at), {
                        addSuffix: true
                      })}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button size="sm" variant="default" onClick={() => setPendingApproval(deposit)} className="h-7 flex-1">
                          <Check className="h-3 w-3 mr-1" />
                          Approve
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => setPendingRejection(deposit.id)} className="h-7 flex-1">
                          <X className="h-3 w-3 mr-1" />
                          Reject
                        </Button>
                      </div>
                    </div>)}
                </div>}

              {/* Regular Notifications */}
              {notifications && notifications.map(notification => {
                return (
                  <div key={notification.id} className={cn("p-4 hover:bg-muted/50 transition-colors relative group", !notification.is_read && "bg-primary/5")}>
                    <div className="flex gap-3">
                      <div className="text-2xl flex-shrink-0">
                        {notification.related_entity_type === 'page_access_denied' ? (
                          <AlertTriangle className="h-6 w-6 text-destructive" />
                        ) : (
                          getNotificationIcon(notification.type)
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm">
                          {renderNotificationMessage(
                            notification.message,
                            notification.related_entity_type,
                            notification.related_entity_id,
                            () => setOpen(false)
                          )}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <p className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-1">
                        {!notification.is_read && <div className="w-2 h-2 rounded-full bg-primary mt-2" />}
                      </div>
                    </div>
                    {!notification.is_read && <Button variant="ghost" size="sm" className="absolute bottom-2 right-2 text-xs opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => markAsRead.mutate(notification.id)}>
                        Mark as read
                      </Button>}
                  </div>
                );
              })}
            </div>}
        </ScrollArea>
        <div className="border-t p-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full text-sm text-muted-foreground hover:text-foreground"
            onClick={() => {
              setOpen(false);
              navigate('/notifications');
            }}
          >
            See all Notifications
          </Button>
        </div>
      </PopoverContent>
    </Popover>


    {/* Approve Confirmation Dialog */}
    <AlertDialog open={!!pendingApproval} onOpenChange={() => setPendingApproval(null)}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Approve Deposit</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to approve this deposit of ${Number(pendingApproval?.amount || 0).toLocaleString()}?
            <div className="mt-4 space-y-2 text-sm">
              {pendingApproval?.agent?.full_name && (
                <div><strong>Transferring Agent:</strong> {pendingApproval.agent.full_name || pendingApproval.agent.email}</div>
              )}
              <div><strong>Super Agent:</strong> {pendingApproval?.super_agent?.full_name || pendingApproval?.super_agent?.email} ({pendingApproval?.split_super_agent ? '50%' : '100%'})</div>
              {pendingApproval?.split_super_agent && (
                <div><strong>Split Super Agent:</strong> {pendingApproval.split_super_agent.full_name || pendingApproval.split_super_agent.email} (50%)</div>
              )}
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={confirmApprove}>Approve Deposit</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>

    {/* Reject Confirmation Dialog */}
    <AlertDialog open={!!pendingRejection} onOpenChange={() => setPendingRejection(null)}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Reject Deposit</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to reject this deposit? This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={confirmReject} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
            Reject Deposit
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>;
};