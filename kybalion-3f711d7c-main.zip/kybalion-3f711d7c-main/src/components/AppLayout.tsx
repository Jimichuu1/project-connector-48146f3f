import { ReactNode, useState, useEffect, useCallback, memo } from "react";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { ContentHeader } from "@/components/ContentHeader";
import { LockScreen } from "@/components/attendance/LockScreen";
import { ClockInLockScreen } from "@/components/attendance/ClockInLockScreen";

import { ReminderSidebar } from "@/components/ReminderSidebar";
import { ReminderNotifications } from "@/components/reminders/ReminderNotifications";
import { supabase } from "@/integrations/supabase/client";
import { useUserData } from "@/contexts/UserDataContext";

interface AppLayoutProps {
  children: ReactNode;
}

const AppLayoutContent = memo(function AppLayoutContent({ children }: AppLayoutProps) {
  const [reminderOpen, setReminderOpen] = useState(false);
  
  const handleReminderToggle = useCallback(() => {
    setReminderOpen(prev => !prev);
  }, []);
  
  return (
    <div className="flex h-screen w-full bg-[hsl(var(--sidebar-background))] overflow-hidden">
      {/* Full Height Sidebar */}
      <AppSidebar />
      
      {/* Main Content Area */}
      <div className="flex flex-col flex-1 min-w-0 h-full overflow-hidden">
        {/* Content Header */}
        <ContentHeader 
          reminderOpen={reminderOpen} 
          onReminderToggle={handleReminderToggle} 
        />
        
        {/* Page Content */}
        <main className="flex-1 min-h-0 bg-background overflow-auto">
          <div className="container max-w-[1600px] mx-auto p-6">
            {children}
          </div>
        </main>
      </div>
      
      {/* Reminder Sidebar */}
      <ReminderSidebar collapsed={!reminderOpen} />
    </div>
  );
});

export const AppLayout = memo(function AppLayout({ children }: AppLayoutProps) {
  const { profile, hasManagerAccess, loading } = useUserData();
  const [showLockScreen, setShowLockScreen] = useState(false);
  const [showClockInScreen, setShowClockInScreen] = useState(false);

  const checkAttendance = useCallback(async (userId: string, isAdminOrManager: boolean) => {
    if (isAdminOrManager) {
      setShowClockInScreen(false);
      setShowLockScreen(false);
      return;
    }

    const today = new Date().toISOString().split("T")[0];
    const { data: records } = await supabase
      .from("attendance")
      .select("id, working_started_at")
      .eq("user_id", userId)
      .eq("date", today)
      .is("clock_out", null)
      .order("clock_in", { ascending: false })
      .limit(1);

    const activeRecord = records?.[0];
    
    if (!activeRecord) {
      setShowClockInScreen(true);
      setShowLockScreen(false);
    } else if (!activeRecord.working_started_at) {
      setShowClockInScreen(false);
      setShowLockScreen(true);
    } else {
      setShowClockInScreen(false);
      setShowLockScreen(false);
    }
  }, []);

  useEffect(() => {
    if (loading || !profile?.id) return;

    checkAttendance(profile.id, hasManagerAccess);

    const channel = supabase
      .channel("attendance_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "attendance",
          filter: `user_id=eq.${profile.id}`,
        },
        () => checkAttendance(profile.id, hasManagerAccess)
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile?.id, hasManagerAccess, loading, checkAttendance]);

  const handleBackToWork = useCallback(async () => {
    if (!profile?.id) return;

    const today = new Date().toISOString().split("T")[0];
    const { data: records } = await supabase
      .from("attendance")
      .select("id")
      .eq("user_id", profile.id)
      .eq("date", today)
      .is("clock_out", null)
      .order("clock_in", { ascending: false })
      .limit(1);

    const todayRecord = records?.[0];
    if (!todayRecord) return;

    const now = new Date().toISOString();
    const { error } = await supabase
      .from("attendance")
      .update({ working_started_at: now })
      .eq("id", todayRecord.id);

    if (!error) {
      setShowLockScreen(false);
    }
  }, [profile?.id]);

  return (
    <SidebarProvider className="!min-h-0 h-screen overflow-hidden">
      {showClockInScreen ? (
        <ClockInLockScreen />
      ) : (
        <>
          <AppLayoutContent>{children}</AppLayoutContent>
          {showLockScreen && <LockScreen onBackToWork={handleBackToWork} />}
          <ReminderNotifications />
        </>
      )}
    </SidebarProvider>
  );
});
