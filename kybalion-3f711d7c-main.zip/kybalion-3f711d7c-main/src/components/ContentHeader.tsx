import { useSidebar } from "@/components/ui/sidebar";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { GlobalSearch } from "@/components/GlobalSearch";
import { WorldClock } from "@/components/WorldClock";
import { ThemeToggle } from "@/components/ThemeToggle";
import { WorkingToggle } from "@/components/attendance/WorkingToggle";
import { ClockButtons } from "@/components/attendance/ClockButtons";
import { HighDepositAgentBanner } from "@/components/attendance/HighDepositAgentBanner";
import { TargetProgressBanner } from "@/components/targets/TargetProgressBanner";

import { ScriptsPopover } from "@/components/scripts/ScriptsPopover";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, PanelLeft, Home } from "lucide-react";
import { useReminders } from "@/hooks/useReminders";
import { useLocation, Link } from "react-router-dom";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { useBreadcrumb } from "@/contexts/BreadcrumbContext";
import { useUserData } from "@/contexts/UserDataContext";
const routeLabels: Record<string, string> = {
  dashboard: "Dashboard",
  leads: "Leads",
  clients: "Clients",
  pipeline: "Pipeline",
  email: "Email",
  "convert-queue": "Convert Queue",
  "user-management": "User Management",
  "tenant-management": "Tenant Management",
  "team-management": "Team Management",
  attendance: "Attendance",
  admin: "Admin",
  "security-monitoring": "Security Monitoring",
  settings: "Settings",
  reports: "Reports",
  profile: "Profile",
  salary: "Salary",
  scripts: "Scripts"
};
interface ContentHeaderProps {
  reminderOpen: boolean;
  onReminderToggle: () => void;
}
export function ContentHeader({
  reminderOpen,
  onReminderToggle
}: ContentHeaderProps) {
  const {
    toggleSidebar
  } = useSidebar();
  const {
    pendingCount
  } = useReminders();
  const {
    customLabel
  } = useBreadcrumb();
  const { isTenantOwner, isSuperAdmin } = useUserData();
  const isAgentView = !isTenantOwner && !isSuperAdmin;
  const location = useLocation();
  const pathSegments = location.pathname.split("/").filter(Boolean);

  // Check if the last segment looks like a UUID
  const isUUID = (str: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
  return <header className="sticky top-0 z-40 flex flex-col bg-[hsl(var(--header-background))]">
      {/* Main header row */}
      <div className="flex h-16 items-center px-4 pl-0 pb-0 pt-0 my-0">
        {/* Left side - Toggle & Search */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={toggleSidebar} className="h-8 w-8 hover:bg-accent">
            <PanelLeft className="h-4 w-4" />
          </Button>
          
          <GlobalSearch />
          <HighDepositAgentBanner />
          <TargetProgressBanner />
        </div>
        
        {/* Right side - Actions */}
        <div className="flex items-center ml-auto gap-[2px]">
          <div className="flex items-center gap-3 pr-2">
            <ClockButtons />
            <WorkingToggle />
          </div>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <ThemeToggle />
          <NotificationBell />
          <ScriptsPopover />
          <Button size="icon" variant="ghost" className="relative h-8 w-8" onClick={onReminderToggle}>
            <Calendar className="h-4 w-4" />
            {pendingCount > 0 && <Badge variant="destructive" className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs bg-destructive text-destructive-foreground">
                {pendingCount}
              </Badge>}
          </Button>
        </div>
      </div>
      
      {/* Breadcrumb row */}
      {pathSegments.length > 0 && <div className="h-9 flex items-center bg-background rounded-tl-[16px] border-b border-border/30">
        <div className="container max-w-[1600px] mx-auto px-6">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/dashboard" className="flex items-center gap-1 text-muted-foreground hover:text-foreground">
                    <Home className="h-3.5 w-3.5" />
                  </Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              
              {pathSegments.map((segment, index) => {
              const path = `/${pathSegments.slice(0, index + 1).join("/")}`;
              const isLast = index === pathSegments.length - 1;
              // Use custom label for UUID segments (detail pages), otherwise use route labels
              const label = isLast && isUUID(segment) && customLabel ? customLabel : routeLabels[segment] || segment.charAt(0).toUpperCase() + segment.slice(1);
              return <div key={path} className="flex items-center gap-1.5">
                    <BreadcrumbSeparator />
                    <BreadcrumbItem>
                      {isLast ? <BreadcrumbPage className="text-sm">{label}</BreadcrumbPage> : <BreadcrumbLink asChild>
                          <Link to={path} className="text-sm text-muted-foreground hover:text-foreground">
                            {label}
                          </Link>
                        </BreadcrumbLink>}
                    </BreadcrumbItem>
                  </div>;
            })}
            </BreadcrumbList>
          </Breadcrumb>
        </div>
        </div>}
    </header>;
}