import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { CustomSalaryEntry } from "@/hooks/useCustomSalaryEntries";

interface CustomSalaryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entry?: CustomSalaryEntry | null;
  onSave: (data: { name: string; base_salary: number; commission: number; advance: number; notes?: string }) => void;
  onDelete?: () => void;
  isPending?: boolean;
}

export function CustomSalaryDialog({
  open,
  onOpenChange,
  entry,
  onSave,
  onDelete,
  isPending,
}: CustomSalaryDialogProps) {
  const [name, setName] = useState("");
  const [baseSalary, setBaseSalary] = useState("");
  const [commission, setCommission] = useState("");
  const [advance, setAdvance] = useState("");
  const [notes, setNotes] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const isEdit = !!entry;

  useEffect(() => {
    if (open) {
      setName(entry?.name ?? "");
      setBaseSalary(entry?.base_salary?.toString() ?? "");
      setCommission(entry?.commission?.toString() ?? "");
      setAdvance(entry?.advance?.toString() ?? "");
      setNotes(entry?.notes ?? "");
      setConfirmDelete(false);
    }
  }, [open, entry]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      base_salary: Number(baseSalary) || 0,
      commission: Number(commission) || 0,
      advance: Number(advance) || 0,
      notes: notes.trim() || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Custom Salary" : "Add Custom Salary"}</DialogTitle>
          <DialogDescription>
            {isEdit ? "Update the custom salary entry details." : "Add a manual salary entry with name, base salary, and commission."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cs-name">Name</Label>
            <Input
              id="cs-name"
              placeholder="e.g. Office Rent, Bonus, etc."
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cs-base">Base Salary ($)</Label>
              <Input
                id="cs-base"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={baseSalary}
                onChange={(e) => setBaseSalary(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cs-commission">Commission ($)</Label>
              <Input
                id="cs-commission"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={commission}
                onChange={(e) => setCommission(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cs-advance">Advance ($)</Label>
              <Input
                id="cs-advance"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={advance}
                onChange={(e) => setAdvance(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="cs-notes">Notes (optional)</Label>
            <Textarea
              id="cs-notes"
              placeholder="Add any additional notes or context..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter className="flex-row gap-2 sm:justify-between">
            {isEdit && onDelete && (
              <div>
                {confirmDelete ? (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-destructive">Confirm?</span>
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={onDelete}
                      disabled={isPending}
                    >
                      Delete
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setConfirmDelete(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                ) : (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => setConfirmDelete(true)}
                  >
                    Delete
                  </Button>
                )}
              </div>
            )}
            <div className="flex gap-2 ml-auto">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isPending || !name.trim()}>
                {isEdit ? "Save Changes" : "Add Entry"}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
