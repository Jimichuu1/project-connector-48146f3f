import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { format, startOfMonth, endOfMonth } from "date-fns";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/utils";

interface Props {
  selectedMonth: string; // "yyyy-MM"
}

interface DepositRow {
  id: string;
  amount: number;
  status: string;
  created_at: string;
  counts_for_agent: boolean;
  client_id: string;
  agent_id: string | null;
  closer_agent_id: string | null;
  super_agent_id: string | null;
  client_name: string;
  agent_name: string;
  closer_name: string | null;
  super_agent_name: string | null;
}

export function AgentDepositApprovalsTab({ selectedMonth }: Props) {
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [pendingIds, setPendingIds] = useState<Set<string>>(new Set());

  const { startDate, endDate } = useMemo(() => {
    const [y, m] = selectedMonth.split("-").map(Number);
    const d = new Date(y, m - 1, 1);
    return {
      startDate: startOfMonth(d).toISOString(),
      endDate: endOfMonth(d).toISOString(),
    };
  }, [selectedMonth]);

  const { data: deposits = [], isLoading } = useQuery({
    queryKey: ["agent-deposit-approvals", effectiveTenantId, selectedMonth],
    enabled: !!effectiveTenantId,
    queryFn: async (): Promise<DepositRow[]> => {
      const { data, error } = await supabase
        .from("deposits")
        .select(
          "id, amount, status, created_at, counts_for_agent, client_id, agent_id, closer_agent_id, super_agent_id"
        )
        .eq("admin_id", effectiveTenantId!)
        .gte("created_at", startDate)
        .lte("created_at", endDate)
        .or("agent_id.not.is.null,closer_agent_id.not.is.null")
        .neq("status", "rejected")
        .order("created_at", { ascending: false });

      if (error) throw error;
      const rows = data || [];
      if (rows.length === 0) return [];

      const clientIds = [...new Set(rows.map((r) => r.client_id).filter(Boolean))];
      const profileIds = [
        ...new Set(
          rows
            .flatMap((r) => [r.agent_id, r.closer_agent_id, r.super_agent_id])
            .filter(Boolean) as string[]
        ),
      ];

      const [clientsRes, profilesRes] = await Promise.all([
        clientIds.length
          ? supabase.from("clients").select("id, name").in("id", clientIds)
          : Promise.resolve({ data: [] as { id: string; name: string }[] }),
        profileIds.length
          ? supabase
              .from("profiles")
              .select("id, full_name, username, email")
              .in("id", profileIds)
          : Promise.resolve({
              data: [] as {
                id: string;
                full_name: string | null;
                username: string | null;
                email: string | null;
              }[],
            }),
      ]);

      const clientMap = new Map(
        (clientsRes.data || []).map((c) => [c.id, c.name])
      );
      const profileMap = new Map(
        (profilesRes.data || []).map((p) => [
          p.id,
          p.full_name || p.username || p.email || "Unknown",
        ])
      );

      return rows.map((r) => ({
        ...r,
        amount: Number(r.amount) || 0,
        client_name: clientMap.get(r.client_id) || "Unknown",
        agent_name: r.agent_id ? profileMap.get(r.agent_id) || "—" : "—",
        closer_name: r.closer_agent_id
          ? profileMap.get(r.closer_agent_id) || "—"
          : null,
        super_agent_name: r.super_agent_id
          ? profileMap.get(r.super_agent_id) || "—"
          : null,
      }));
    },
  });

  const handleToggle = async (deposit: DepositRow, next: boolean) => {
    setPendingIds((prev) => new Set(prev).add(deposit.id));
    const { error } = await supabase
      .from("deposits")
      .update({ counts_for_agent: next })
      .eq("id", deposit.id);

    setPendingIds((prev) => {
      const n = new Set(prev);
      n.delete(deposit.id);
      return n;
    });

    if (error) {
      toast.error(`Failed to update: ${error.message}`);
      return;
    }
    toast.success(
      next
        ? `Deposit now counts for ${deposit.agent_name} — agent notified`
        : `Deposit no longer counts for ${deposit.agent_name}`
    );
    queryClient.invalidateQueries({ queryKey: ["agent-deposit-approvals"] });
    queryClient.invalidateQueries({ queryKey: ["salary-data"] });
    queryClient.invalidateQueries({ queryKey: ["agent-report-deposits"] });
    queryClient.invalidateQueries({ queryKey: ["reports-conversion"] });
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return deposits;
    return deposits.filter(
      (d) =>
        d.client_name.toLowerCase().includes(q) ||
        d.agent_name.toLowerCase().includes(q) ||
        (d.closer_name || "").toLowerCase().includes(q) ||
        (d.super_agent_name || "").toLowerCase().includes(q)
    );
  }, [deposits, search]);

  const counted = filtered.filter((d) => d.counts_for_agent).length;
  const totalCounted = filtered
    .filter((d) => d.counts_for_agent)
    .reduce((s, d) => s + d.amount, 0);

  return (
    <div className="space-y-4">
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Toggle which transferred-client deposits count toward the
          transferring/closer agent (and their manager/team leader commission).
          New deposits start as <strong>not counted</strong>: the agent
          receives <strong>no notifications, sounds, toasts, salary credit,
          or report entries</strong> until you flip this ON. Flipping ON sends
          the agent a deposit-approved notification and unlocks salary &amp;
          report counting. Super Agent earnings are not affected by this toggle.
        </AlertDescription>
      </Alert>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Deposits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filtered.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Counted for Agent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{counted}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Counted Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(totalCounted)}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-2">
        <Input
          placeholder="Search client, agent, super agent…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Transferring Agent</TableHead>
                <TableHead>Closer Agent</TableHead>
                <TableHead>Super Agent</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Deposit Status</TableHead>
                <TableHead className="text-center">Counts for Agent</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell colSpan={8}>
                      <Skeleton className="h-8 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    className="h-24 text-center text-muted-foreground"
                  >
                    No transferred-client deposits for this month.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((d) => (
                  <TableRow key={d.id}>
                    <TableCell className="text-sm">
                      {format(new Date(d.created_at), "MMM dd, yyyy")}
                    </TableCell>
                    <TableCell className="font-medium">{d.client_name}</TableCell>
                    <TableCell>{d.agent_name}</TableCell>
                    <TableCell>{d.closer_name || "—"}</TableCell>
                    <TableCell>{d.super_agent_name || "—"}</TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatCurrency(d.amount)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          d.status === "approved"
                            ? "default"
                            : d.status === "rejected"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {d.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Switch
                        checked={d.counts_for_agent}
                        disabled={pendingIds.has(d.id)}
                        onCheckedChange={(v) => handleToggle(d, v)}
                      />
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
