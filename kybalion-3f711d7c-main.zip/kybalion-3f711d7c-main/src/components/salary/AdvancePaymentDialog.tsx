import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface AdvancePaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userName: string;
  currentAmount?: number;
  currentNote?: string;
  isPending: boolean;
  onSave: (amount: number, note: string) => void;
  onDelete?: () => void;
}

export function AdvancePaymentDialog({
  open,
  onOpenChange,
  userName,
  currentAmount,
  currentNote,
  isPending,
  onSave,
  onDelete,
}: AdvancePaymentDialogProps) {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  useEffect(() => {
    if (open) {
      setAmount(currentAmount ? String(currentAmount) : "");
      setNote(currentNote || "");
    }
  }, [open, currentAmount, currentNote]);

  const handleSave = () => {
    const parsed = parseFloat(amount);
    if (isNaN(parsed) || parsed < 0) return;
    onSave(parsed, note);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Advance Payment — {userName}</DialogTitle>
          <DialogDescription>
            Enter the advance amount to deduct from this user's net salary.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="advance-amount">Amount ($)</Label>
            <Input
              id="advance-amount"
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="advance-note">Note (optional)</Label>
            <Textarea
              id="advance-note"
              placeholder="Reason for advance..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
            />
          </div>
        </div>
        <DialogFooter className="flex justify-between sm:justify-between">
          {onDelete && (
            <Button variant="destructive" onClick={onDelete} disabled={isPending} size="sm">
              Remove
            </Button>
          )}
          <div className="flex gap-2 ml-auto">
            <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isPending}>
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isPending || !amount || parseFloat(amount) < 0}>
              {isPending ? "Saving..." : "Save"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
