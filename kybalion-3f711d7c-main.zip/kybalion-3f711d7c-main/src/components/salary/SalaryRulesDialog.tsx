import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Save, Loader2 } from "lucide-react";
import {
  useCommissionTierSettings,
  TierLevel,
  AgentTierLevel,
  AgentCommissionTierLevel,
  AgentCommissionTierBasis,
  ManagerCommissionSettings,
  CommissionTierSettings,
} from "@/hooks/useCommissionTierSettings";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";

interface SalaryRulesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Agent Transfer Tier row (minConversions, baseSalary, transferValue)
function AgentTransferTierRow({
  tier,
  onChange,
  onRemove,
  canRemove,
}: {
  tier: AgentTierLevel;
  onChange: (tier: AgentTierLevel) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  return (
    <div className="grid grid-cols-4 gap-2 items-end">
      <div>
        <Label className="text-xs">Min Conversions</Label>
        <Input
          type="number"
          value={tier.minConversions}
          onChange={(e) =>
            onChange({ ...tier, minConversions: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <div>
        <Label className="text-xs">Base Salary ($)</Label>
        <Input
          type="number"
          value={tier.baseSalary}
          onChange={(e) =>
            onChange({ ...tier, baseSalary: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <div>
        <Label className="text-xs">Transfer Value ($)</Label>
        <Input
          type="number"
          step="0.01"
          value={tier.singleTransferValue}
          onChange={(e) =>
            onChange({ ...tier, singleTransferValue: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <Button
        variant="ghost"
        size="sm"
        onClick={onRemove}
        disabled={!canRemove}
        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}

// Agent Commission Tier row (minDeposit OR minTransfers, commissionPercent)
function AgentCommissionTierRow({
  tier,
  basis,
  onChange,
  onRemove,
  canRemove,
}: {
  tier: AgentCommissionTierLevel;
  basis: AgentCommissionTierBasis;
  onChange: (tier: AgentCommissionTierLevel) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  const isTransfers = basis === "transfers";
  return (
    <div className="grid grid-cols-3 gap-2 items-end">
      <div>
        <Label className="text-xs">
          {isTransfers ? "Min Transfers" : "Min Deposit ($)"}
        </Label>
        <Input
          type="number"
          value={isTransfers ? (tier.minTransfers ?? 0) : tier.minDeposit}
          onChange={(e) =>
            onChange(
              isTransfers
                ? { ...tier, minTransfers: Number(e.target.value) }
                : { ...tier, minDeposit: Number(e.target.value) }
            )
          }
          className="h-8"
        />
      </div>
      <div>
        <Label className="text-xs">Commission (%)</Label>
        <Input
          type="number"
          step="0.1"
          value={tier.commissionPercent}
          onChange={(e) =>
            onChange({ ...tier, commissionPercent: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <Button
        variant="ghost"
        size="sm"
        onClick={onRemove}
        disabled={!canRemove}
        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}

// Standard tier row (uses minDeposit)
function TierRow({
  tier,
  onChange,
  onRemove,
  canRemove,
}: {
  tier: TierLevel;
  onChange: (tier: TierLevel) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  return (
    <div className="grid grid-cols-4 gap-2 items-end">
      <div>
        <Label className="text-xs">Min Deposit ($)</Label>
        <Input
          type="number"
          value={tier.minDeposit}
          onChange={(e) =>
            onChange({ ...tier, minDeposit: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <div>
        <Label className="text-xs">Commission (%)</Label>
        <Input
          type="number"
          step="0.1"
          value={tier.commissionPercent}
          onChange={(e) =>
            onChange({ ...tier, commissionPercent: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <div>
        <Label className="text-xs">Base Salary ($)</Label>
        <Input
          type="number"
          value={tier.baseSalary}
          onChange={(e) =>
            onChange({ ...tier, baseSalary: Number(e.target.value) })
          }
          className="h-8"
        />
      </div>
      <Button
        variant="ghost"
        size="sm"
        onClick={onRemove}
        disabled={!canRemove}
        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
      >
        <Trash2 className="h-4 w-4" />
      </Button>
    </div>
  );
}

// Agent Transfer Tier editor
function AgentTransferTierEditor({
  tiers,
  onChange,
}: {
  tiers: AgentTierLevel[];
  onChange: (tiers: AgentTierLevel[]) => void;
}) {
  const addTier = () => {
    const lastTier = tiers[tiers.length - 1];
    onChange([
      ...tiers,
      {
        minConversions: (lastTier?.minConversions || 0) + 5,
        baseSalary: (lastTier?.baseSalary || 800) + 200,
        singleTransferValue: lastTier?.singleTransferValue || 0,
      },
    ]);
  };

  const updateTier = (index: number, tier: AgentTierLevel) => {
    const newTiers = [...tiers];
    newTiers[index] = tier;
    onChange(newTiers);
  };

  const removeTier = (index: number) => {
    onChange(tiers.filter((_, i) => i !== index));
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">Transfer Tiers</CardTitle>
          <Button variant="outline" size="sm" onClick={addTier}>
            <Plus className="h-3 w-3 mr-1" />
            Add Tier
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Based on number of conversions. Determines base salary and per-transfer value.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {tiers.map((tier, index) => (
          <AgentTransferTierRow
            key={index}
            tier={tier}
            onChange={(t) => updateTier(index, t)}
            onRemove={() => removeTier(index)}
            canRemove={tiers.length > 1}
          />
        ))}
      </CardContent>
    </Card>
  );
}

// Agent Commission Tier editor
function AgentCommissionTierEditor({
  tiers,
  basis,
  onBasisChange,
  onChange,
}: {
  tiers: AgentCommissionTierLevel[];
  basis: AgentCommissionTierBasis;
  onBasisChange: (basis: AgentCommissionTierBasis) => void;
  onChange: (tiers: AgentCommissionTierLevel[]) => void;
}) {
  const isTransfers = basis === "transfers";

  const addTier = () => {
    const lastTier = tiers[tiers.length - 1];
    onChange([
      ...tiers,
      isTransfers
        ? {
            minDeposit: lastTier?.minDeposit ?? 0,
            minTransfers: (lastTier?.minTransfers ?? 0) + 5,
            commissionPercent: (lastTier?.commissionPercent || 5) + 1,
          }
        : {
            minDeposit: (lastTier?.minDeposit || 0) + 10000,
            minTransfers: lastTier?.minTransfers,
            commissionPercent: (lastTier?.commissionPercent || 5) + 1,
          },
    ]);
  };

  const updateTier = (index: number, tier: AgentCommissionTierLevel) => {
    const newTiers = [...tiers];
    newTiers[index] = tier;
    onChange(newTiers);
  };

  const removeTier = (index: number) => {
    onChange(tiers.filter((_, i) => i !== index));
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">Commission Tiers</CardTitle>
          <Button variant="outline" size="sm" onClick={addTier}>
            <Plus className="h-3 w-3 mr-1" />
            Add Tier
          </Button>
        </div>
        <div className="flex items-center justify-between gap-3 pt-2">
          <span className="text-xs text-muted-foreground">Match tier by</span>
          <ToggleGroup
            type="single"
            size="sm"
            value={basis}
            onValueChange={(v) => {
              if (v === "deposit" || v === "transfers") onBasisChange(v);
            }}
            className="bg-muted rounded-md p-0.5"
          >
            <ToggleGroupItem value="deposit" className="h-7 px-3 text-xs">
              Deposit Amount
            </ToggleGroupItem>
            <ToggleGroupItem value="transfers" className="h-7 px-3 text-xs">
              Transfer Count
            </ToggleGroupItem>
          </ToggleGroup>
        </div>
        <p className="text-xs text-muted-foreground pt-1">
          {isTransfers
            ? "Tier selected by number of conversions this month. Commission paid as % \u00d7 total deposits."
            : "Tier selected by total deposits from transferred clients. Commission paid as % \u00d7 total deposits."}
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {tiers.map((tier, index) => (
          <AgentCommissionTierRow
            key={index}
            tier={tier}
            basis={basis}
            onChange={(t) => updateTier(index, t)}
            onRemove={() => removeTier(index)}
            canRemove={tiers.length > 1}
          />
        ))}
      </CardContent>
    </Card>
  );
}

// Standard tier editor (uses minDeposit)
function TierEditor({
  title,
  tiers,
  onChange,
}: {
  title: string;
  tiers: TierLevel[];
  onChange: (tiers: TierLevel[]) => void;
}) {
  const addTier = () => {
    const lastTier = tiers[tiers.length - 1];
    onChange([
      ...tiers,
      {
        minDeposit: (lastTier?.minDeposit || 0) + 10000,
        commissionPercent: (lastTier?.commissionPercent || 5) + 1,
        baseSalary: (lastTier?.baseSalary || 800) + 200,
      },
    ]);
  };

  const updateTier = (index: number, tier: TierLevel) => {
    const newTiers = [...tiers];
    newTiers[index] = tier;
    onChange(newTiers);
  };

  const removeTier = (index: number) => {
    onChange(tiers.filter((_, i) => i !== index));
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <Button variant="outline" size="sm" onClick={addTier}>
            <Plus className="h-3 w-3 mr-1" />
            Add Tier
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {tiers.map((tier, index) => (
          <TierRow
            key={index}
            tier={tier}
            onChange={(t) => updateTier(index, t)}
            onRemove={() => removeTier(index)}
            canRemove={tiers.length > 1}
          />
        ))}
      </CardContent>
    </Card>
  );
}

// Manager/TL tier editor — supports matching by team deposit amount or team transfer count
function ManagerTierEditor({
  tiers,
  basis,
  onBasisChange,
  onChange,
}: {
  tiers: TierLevel[];
  basis: "deposit" | "transfers";
  onBasisChange: (basis: "deposit" | "transfers") => void;
  onChange: (tiers: TierLevel[]) => void;
}) {
  const isTransfers = basis === "transfers";

  const addTier = () => {
    const lastTier = tiers[tiers.length - 1];
    onChange([
      ...tiers,
      isTransfers
        ? {
            minDeposit: lastTier?.minDeposit ?? 0,
            minTransfers: (lastTier?.minTransfers ?? 0) + 5,
            commissionPercent: (lastTier?.commissionPercent || 3) + 0.5,
            baseSalary: (lastTier?.baseSalary || 1500) + 500,
          }
        : {
            minDeposit: (lastTier?.minDeposit || 0) + 25000,
            minTransfers: lastTier?.minTransfers,
            commissionPercent: (lastTier?.commissionPercent || 3) + 0.5,
            baseSalary: (lastTier?.baseSalary || 1500) + 500,
          },
    ]);
  };

  const updateTier = (index: number, tier: TierLevel) => {
    const newTiers = [...tiers];
    newTiers[index] = tier;
    onChange(newTiers);
  };

  const removeTier = (index: number) => {
    onChange(tiers.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {isTransfers ? "Team Transfer Tiers" : "Team Deposit Tiers"}
        </Label>
        <Button variant="outline" size="sm" onClick={addTier}>
          <Plus className="h-3 w-3 mr-1" />
          Add Tier
        </Button>
      </div>
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs text-muted-foreground">Match tier by</span>
        <ToggleGroup
          type="single"
          size="sm"
          value={basis}
          onValueChange={(v) => {
            if (v === "deposit" || v === "transfers") onBasisChange(v);
          }}
          className="bg-muted rounded-md p-0.5"
        >
          <ToggleGroupItem value="deposit" className="h-7 px-3 text-xs">
            Deposit Amount
          </ToggleGroupItem>
          <ToggleGroupItem value="transfers" className="h-7 px-3 text-xs">
            Transfer Count
          </ToggleGroupItem>
        </ToggleGroup>
      </div>
      <p className="text-xs text-muted-foreground">
        {isTransfers
          ? "Tier picked by total team conversions this month. Commission paid as % \u00d7 total team deposits."
          : "Tier picked by total team deposits this month. Commission paid as % \u00d7 total team deposits."}
      </p>
      {tiers.map((tier, index) => (
        <div key={index} className="grid grid-cols-4 gap-2 items-end">
          <div>
            <Label className="text-xs">
              {isTransfers ? "Min Team Transfers" : "Min Team Deposit ($)"}
            </Label>
            <Input
              type="number"
              value={isTransfers ? (tier.minTransfers ?? 0) : tier.minDeposit}
              onChange={(e) =>
                updateTier(
                  index,
                  isTransfers
                    ? { ...tier, minTransfers: Number(e.target.value) }
                    : { ...tier, minDeposit: Number(e.target.value) }
                )
              }
              className="h-8"
            />
          </div>
          <div>
            <Label className="text-xs">Commission (%)</Label>
            <Input
              type="number"
              step="0.1"
              value={tier.commissionPercent}
              onChange={(e) =>
                updateTier(index, { ...tier, commissionPercent: Number(e.target.value) })
              }
              className="h-8"
            />
          </div>
          <div>
            <Label className="text-xs">Base Salary ($)</Label>
            <Input
              type="number"
              value={tier.baseSalary}
              onChange={(e) =>
                updateTier(index, { ...tier, baseSalary: Number(e.target.value) })
              }
              className="h-8"
            />
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => removeTier(index)}
            disabled={tiers.length <= 1}
            className="h-8 w-8 p-0 text-destructive hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ))}
    </div>
  );
}

export function SalaryRulesDialog({
  open,
  onOpenChange,
}: SalaryRulesDialogProps) {
  const {
    tierSettings,
    managerSettings,
    isLoading,
    saveTierSettings,
    saveManagerSettings,
    DEFAULT_AGENT_TIERS,
    DEFAULT_AGENT_COMMISSION_TIERS,
    DEFAULT_SUPER_AGENT_TIERS,
    DEFAULT_MANAGER_TIERS,
  } = useCommissionTierSettings();

  const [localTierSettings, setLocalTierSettings] =
    useState<CommissionTierSettings | null>(null);
  const [localManagerSettings, setLocalManagerSettings] = useState<
    ManagerCommissionSettings[]
  >([]);

  // Sync local state when data loads
  useEffect(() => {
    if (tierSettings) {
      setLocalTierSettings(tierSettings);
    }
  }, [tierSettings]);

  useEffect(() => {
    if (managerSettings) {
      setLocalManagerSettings(managerSettings);
    }
  }, [managerSettings]);

  const handleSaveAgentTiers = () => {
    if (localTierSettings) {
      saveTierSettings.mutate({
        ...localTierSettings,
        agent_tiers: localTierSettings.agent_tiers,
        agent_base_salary_tiers: localTierSettings.agent_tiers,
        agent_commission_tiers: localTierSettings.agent_commission_tiers,
      });
    }
  };

  const handleSaveCloserAgentTiers = () => {
    if (localTierSettings) {
      saveTierSettings.mutate({
        ...localTierSettings,
        closer_agent_tiers: localTierSettings.closer_agent_tiers,
        closer_agent_base_salary_tiers: localTierSettings.closer_agent_tiers,
        closer_agent_commission_tiers: localTierSettings.closer_agent_commission_tiers,
        closer_agent_commission_tier_basis: localTierSettings.closer_agent_commission_tier_basis,
      });
    }
  };

  const handleSaveSuperAgentTiers = () => {
    if (localTierSettings) {
      saveTierSettings.mutate({
        ...localTierSettings,
        super_agent_tiers: localTierSettings.super_agent_tiers,
        super_agent_base_salary_tiers: localTierSettings.super_agent_tiers,
      });
    }
  };

  const handleSaveManagerSettings = (manager: ManagerCommissionSettings) => {
    saveManagerSettings.mutate(manager);
  };

  const updateManagerSetting = (
    managerId: string,
    field: keyof ManagerCommissionSettings,
    value: unknown
  ) => {
    setLocalManagerSettings((prev) =>
      prev.map((m) => (m.manager_id === managerId ? { ...m, [field]: value } : m))
    );
  };

  if (isLoading || !localTierSettings) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Salary Rules Configuration</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="agents" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="agents">Agents</TabsTrigger>
            <TabsTrigger value="closer-agents">Closer Agents</TabsTrigger>
            <TabsTrigger value="super-agents">Super Agents</TabsTrigger>
            <TabsTrigger value="managers">Managers & TLs</TabsTrigger>
          </TabsList>

          {/* Agents Tab */}
          <TabsContent value="agents" className="space-y-4 mt-4">
            <div className="text-sm text-muted-foreground mb-4">
              Configure two independent tier systems for agents: Transfer tiers (based on conversions) and Commission tiers (based on total deposits).
            </div>
            
            <AgentTransferTierEditor
              tiers={localTierSettings.agent_tiers || DEFAULT_AGENT_TIERS}
              onChange={(tiers) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, agent_tiers: tiers } : prev
                )
              }
            />

            <AgentCommissionTierEditor
              tiers={localTierSettings.agent_commission_tiers || DEFAULT_AGENT_COMMISSION_TIERS}
              basis={localTierSettings.agent_commission_tier_basis ?? "deposit"}
              onBasisChange={(basis) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, agent_commission_tier_basis: basis } : prev
                )
              }
              onChange={(tiers) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, agent_commission_tiers: tiers } : prev
                )
              }
            />

            <div className="flex justify-end">
              <Button
                onClick={handleSaveAgentTiers}
                disabled={saveTierSettings.isPending}
              >
                {saveTierSettings.isPending && (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                )}
                <Save className="h-4 w-4 mr-2" />
                Save Agent Tiers
              </Button>
            </div>
          </TabsContent>

          {/* Closer Agents Tab — independent salary set for agents flagged as closers */}
          <TabsContent value="closer-agents" className="space-y-4 mt-4">
            <div className="text-sm text-muted-foreground mb-4">
              Salary configuration for agents flagged as <strong>Closer Agent</strong> in user management.
              Same structure as Agents, with its own independent transfer and commission tiers.
            </div>

            <AgentTransferTierEditor
              tiers={localTierSettings.closer_agent_tiers || DEFAULT_AGENT_TIERS}
              onChange={(tiers) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, closer_agent_tiers: tiers } : prev
                )
              }
            />

            <AgentCommissionTierEditor
              tiers={localTierSettings.closer_agent_commission_tiers || DEFAULT_AGENT_COMMISSION_TIERS}
              basis={localTierSettings.closer_agent_commission_tier_basis ?? "deposit"}
              onBasisChange={(basis) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, closer_agent_commission_tier_basis: basis } : prev
                )
              }
              onChange={(tiers) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, closer_agent_commission_tiers: tiers } : prev
                )
              }
            />

            <div className="flex justify-end">
              <Button
                onClick={handleSaveCloserAgentTiers}
                disabled={saveTierSettings.isPending}
              >
                {saveTierSettings.isPending && (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                )}
                <Save className="h-4 w-4 mr-2" />
                Save Closer Agent Tiers
              </Button>
            </div>
          </TabsContent>

          {/* Super Agents Tab */}
          <TabsContent value="super-agents" className="space-y-4 mt-4">
            <div className="text-sm text-muted-foreground mb-4">
              Configure commission tiers for super agents based on their total
              own clients deposit amount.
            </div>
            <TierEditor
              title="Super Agent Commission Tiers"
              tiers={
                localTierSettings.super_agent_tiers || DEFAULT_SUPER_AGENT_TIERS
              }
              onChange={(tiers) =>
                setLocalTierSettings((prev) =>
                  prev ? { ...prev, super_agent_tiers: tiers } : prev
                )
              }
            />
            <div className="flex justify-end">
              <Button
                onClick={handleSaveSuperAgentTiers}
                disabled={saveTierSettings.isPending}
              >
                {saveTierSettings.isPending && (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                )}
                <Save className="h-4 w-4 mr-2" />
                Save Super Agent Tiers
              </Button>
            </div>
          </TabsContent>

          {/* Managers Tab */}
          <TabsContent value="managers" className="space-y-4 mt-4">
            <div className="text-sm text-muted-foreground mb-4">
              Configure commission tiers for each manager and team leader based on their team's
              total deposit amount from transferred clients.
            </div>

            {localManagerSettings.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  No managers or team leaders found in this tenant.
                </CardContent>
              </Card>
            ) : (
              <Accordion type="single" collapsible className="w-full">
                {localManagerSettings.map((manager) => (
                  <AccordionItem key={manager.manager_id} value={manager.manager_id}>
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center gap-3">
                        <span className="font-medium">{manager.manager_name}</span>
                        <Badge variant="outline">
                          {manager.base_salary_tiers?.length || 0} tiers
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 space-y-4">
                      <ManagerTierEditor
                        tiers={manager.base_salary_tiers || DEFAULT_MANAGER_TIERS}
                        basis={manager.tier_basis ?? "deposit"}
                        onBasisChange={(basis) =>
                          updateManagerSetting(manager.manager_id, "tier_basis", basis)
                        }
                        onChange={(tiers) =>
                          updateManagerSetting(
                            manager.manager_id,
                            "base_salary_tiers",
                            tiers
                          )
                        }
                      />

                      <div className="flex justify-end">
                        <Button
                          onClick={() => handleSaveManagerSettings(manager)}
                          disabled={saveManagerSettings.isPending}
                          size="sm"
                        >
                          {saveManagerSettings.isPending && (
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          )}
                          <Save className="h-4 w-4 mr-2" />
                          Save {manager.manager_name}
                        </Button>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
