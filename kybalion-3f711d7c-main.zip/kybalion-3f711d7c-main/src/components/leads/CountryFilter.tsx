import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { getCountryFlag, normalizeCountryName } from "@/lib/countryFlags";
import { useTenant } from "@/contexts/TenantContext";


interface CountryFilterProps {
  value: string[];
  onChange: (value: string[]) => void;
  entityType?: 'leads' | 'clients';
}

export function CountryFilter({ value, onChange, entityType = 'leads' }: CountryFilterProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  
  const { data: countries, isLoading } = useQuery({
    queryKey: ["countries", effectiveTenantId, entityType],
    queryFn: async () => {
      const rpcName =
        entityType === 'clients'
          ? 'get_distinct_client_countries'
          : 'get_distinct_lead_countries';

      const { data, error } = await supabase.rpc(rpcName as any, {
        p_admin_id: effectiveTenantId ?? null,
      });

      if (error) throw error;

      const row: any = Array.isArray(data) ? data[0] : data;
      const rawCountries: string[] = row?.countries ?? [];

      // The RPC now returns canonical country names derived from phone prefixes.
      // Normalize defensively in case of any legacy aliases, then dedupe + sort.
      const set = new Set<string>();
      rawCountries.forEach((c) => {
        const n = normalizeCountryName(c);
        if (n) set.add(n);
      });
      return Array.from(set).sort();
    },
  });

  const handleToggle = (country: string) => {
    if (value.includes(country)) {
      onChange(value.filter((c) => c !== country));
    } else {
      onChange([...value, country]);
    }
  };

  if (isLoading) {
    return (
      <div className="p-4 space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-8 w-full" />
        ))}
      </div>
    );
  }

  if (!countries || countries.length === 0) {
    return (
      <div className="p-4 text-sm text-muted-foreground">
        No countries found
      </div>
    );
  }

  const filteredCountries = countries.filter((country) =>
    country.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-80">
      <div className="p-4 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search countries..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9"
          />
        </div>
      </div>
      <div className="max-h-[300px] overflow-y-auto p-4">
        {filteredCountries.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-4">
            No countries found
          </div>
        ) : (
          <div className="space-y-2">
            {filteredCountries.map((country) => (
          <label
            key={country}
            className="flex items-center gap-2 cursor-pointer hover:bg-muted/50 p-2 rounded"
          >
            <Checkbox
              checked={value.includes(country)}
              onCheckedChange={() => handleToggle(country)}
            />
            <span className="text-lg">{getCountryFlag(country)}</span>
              <span className="text-sm">{country}</span>
            </label>
          ))}
        </div>
        )}
      </div>
    </div>
  );
}
