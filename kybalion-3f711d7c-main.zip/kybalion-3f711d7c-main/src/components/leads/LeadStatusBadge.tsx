import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useLeadStatuses, getLeadStatusConfig } from "@/hooks/useLeadStatuses";

interface LeadStatusBadgeProps {
  status: string;
  className?: string;
}

export const LeadStatusBadge = ({ status, className }: LeadStatusBadgeProps) => {
  const { data: statuses = [] } = useLeadStatuses();
  const config = getLeadStatusConfig(statuses, status);

  return (
    <Badge 
      className={cn("font-medium border-0", className)}
      style={{ 
        backgroundColor: config.color,
        color: "#fff"
      }}
    >
      {config.label}
    </Badge>
  );
};
