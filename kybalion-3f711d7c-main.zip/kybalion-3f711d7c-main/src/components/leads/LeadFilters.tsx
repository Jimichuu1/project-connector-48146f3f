import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Filter, X } from "lucide-react";
import { LeadStatus, LeadSource } from "@/types/leads";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { UserCombobox } from "@/components/ui/user-combobox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { CalendarIcon } from "lucide-react";

export interface LeadFiltersState {
  statuses: LeadStatus[];
  sources: LeadSource[];
  assignedTo: string[];
  unassigned?: boolean;
  dateFrom?: Date;
  dateTo?: Date;
  countries: string[];
}

interface LeadFiltersProps {
  filters: LeadFiltersState;
  onChange: (filters: LeadFiltersState) => void;
}

const STATUS_OPTIONS: { value: LeadStatus; label: string }[] = [
  { value: "NEW", label: "New" },
  { value: "ACTIVE", label: "Active" },
  { value: "CALLBACK", label: "Callback" },
  { value: "NOT_INTERESTED", label: "Not Interested" },
  { value: "DON'T_CALL", label: "Don't Call" },
];

const SOURCE_OPTIONS: { value: LeadSource; label: string }[] = [
  { value: "WEBSITE", label: "Website" },
  { value: "REFERRAL", label: "Referral" },
  { value: "SOCIAL_MEDIA", label: "Social Media" },
  { value: "COLD_CALL", label: "Cold Call" },
  { value: "EMAIL_CAMPAIGN", label: "Email Campaign" },
  { value: "PAID_ADS", label: "Paid Ads" },
  { value: "WEBINAR", label: "Webinar" },
  { value: "TRADE_SHOW", label: "Trade Show" },
  { value: "OTHER", label: "Other" },
];

export const LeadFilters = ({ filters, onChange }: LeadFiltersProps) => {
  const [open, setOpen] = useState(false);

  // Fetch agents and super agents for assignment filter
  const { data: usersData } = useQuery({
    queryKey: ["agents-super-agents"],
    queryFn: async () => {
      const { data: userRoles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("role", ["SUPER_AGENT", "AGENT"]);

      if (rolesError) throw rolesError;
      if (!userRoles || userRoles.length === 0) return [];

      const userIds = [...new Set(userRoles.map((r) => r.user_id))];

      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, email, avatar_url")
        .in("id", userIds);

      if (profilesError) throw profilesError;

      return profiles?.map((profile) => ({
        value: profile.id,
        label: profile.full_name || profile.email || "Unknown",
        avatar: profile.avatar_url,
      })) || [];
    },
  });

  // Fetch countries from leads
  const { data: countriesData } = useQuery({
    queryKey: ["lead-countries"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("leads")
        .select("country")
        .not("country", "is", null);

      if (error) throw error;

      const uniqueCountries = [...new Set(data.map((item) => item.country).filter(Boolean))];
      return uniqueCountries.sort();
    },
  });

  const activeFilterCount = 
    filters.statuses.length +
    filters.sources.length +
    filters.assignedTo.length +
    (filters.unassigned ? 1 : 0) +
    (filters.dateFrom || filters.dateTo ? 1 : 0) +
    filters.countries.length;

  const handleStatusToggle = (status: LeadStatus) => {
    const newStatuses = filters.statuses.includes(status)
      ? filters.statuses.filter((s) => s !== status)
      : [...filters.statuses, status];
    onChange({ ...filters, statuses: newStatuses });
  };

  const handleSourceToggle = (source: LeadSource) => {
    const newSources = filters.sources.includes(source)
      ? filters.sources.filter((s) => s !== source)
      : [...filters.sources, source];
    onChange({ ...filters, sources: newSources });
  };

  const handleAssignedToToggle = (userId: string) => {
    const newAssigned = filters.assignedTo.includes(userId)
      ? filters.assignedTo.filter((id) => id !== userId)
      : [...filters.assignedTo, userId];
    onChange({ ...filters, assignedTo: newAssigned });
  };

  const handleCountryToggle = (country: string) => {
    const newCountries = filters.countries.includes(country)
      ? filters.countries.filter((c) => c !== country)
      : [...filters.countries, country];
    onChange({ ...filters, countries: newCountries });
  };

  const clearAllFilters = () => {
    onChange({
      statuses: [],
      sources: [],
      assignedTo: [],
      unassigned: false,
      dateFrom: undefined,
      dateTo: undefined,
      countries: [],
    });
  };

  const handleUnassignedToggle = () => {
    onChange({ ...filters, unassigned: !filters.unassigned });
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm">
          <Filter className="h-4 w-4 mr-2" />
          Filters
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="ml-2 h-5 w-5 rounded-full p-0 flex items-center justify-center">
              {activeFilterCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px] overflow-y-auto">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle>Filter Leads</SheetTitle>
            {activeFilterCount > 0 && (
              <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                Clear All
              </Button>
            )}
          </div>
        </SheetHeader>

        <div className="space-y-6 mt-6">
          {/* Status Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Status</Label>
            <div className="flex flex-wrap gap-2">
              {STATUS_OPTIONS.map((option) => (
                <Badge
                  key={option.value}
                  variant={filters.statuses.includes(option.value) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => handleStatusToggle(option.value)}
                >
                  {option.label}
                  {filters.statuses.includes(option.value) && (
                    <X className="h-3 w-3 ml-1" />
                  )}
                </Badge>
              ))}
            </div>
          </div>

          {/* Source Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Source</Label>
            <div className="flex flex-wrap gap-2">
              {SOURCE_OPTIONS.map((option) => (
                <Badge
                  key={option.value}
                  variant={filters.sources.includes(option.value) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => handleSourceToggle(option.value)}
                >
                  {option.label}
                  {filters.sources.includes(option.value) && (
                    <X className="h-3 w-3 ml-1" />
                  )}
                </Badge>
              ))}
            </div>
          </div>

          {/* Assigned To Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Assigned To</Label>
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={filters.unassigned ? "default" : "outline"}
                className="cursor-pointer"
                onClick={handleUnassignedToggle}
              >
                Unassigned
                {filters.unassigned && (
                  <X className="h-3 w-3 ml-1" />
                )}
              </Badge>
              {Array.isArray(usersData) && usersData.map((user) => (
                <Badge
                  key={user.value}
                  variant={filters.assignedTo.includes(user.value) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => handleAssignedToToggle(user.value)}
                >
                  {user.label}
                  {filters.assignedTo.includes(user.value) && (
                    <X className="h-3 w-3 ml-1" />
                  )}
                </Badge>
              ))}
            </div>
          </div>

          {/* Date Range */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Created Date Range</Label>
            <div className="flex gap-2">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "justify-start text-left font-normal flex-1",
                      !filters.dateFrom && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filters.dateFrom ? format(filters.dateFrom, "PPP") : "From"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={filters.dateFrom}
                    onSelect={(date) => onChange({ ...filters, dateFrom: date })}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className={cn(
                      "justify-start text-left font-normal flex-1",
                      !filters.dateTo && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {filters.dateTo ? format(filters.dateTo, "PPP") : "To"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={filters.dateTo}
                    onSelect={(date) => onChange({ ...filters, dateTo: date })}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
            {(filters.dateFrom || filters.dateTo) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onChange({ ...filters, dateFrom: undefined, dateTo: undefined })}
              >
                Clear dates
              </Button>
            )}
          </div>

          {/* Country Filter */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Country</Label>
            <div className="flex flex-wrap gap-2">
              {Array.isArray(countriesData) && countriesData.map((country) => (
                <Badge
                  key={country}
                  variant={filters.countries.includes(country) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => handleCountryToggle(country)}
                >
                  {country}
                  {filters.countries.includes(country) && (
                    <X className="h-3 w-3 ml-1" />
                  )}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};
