import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface CreatedDateFilterProps {
  value: { from: Date | null; to: Date | null } | null;
  onChange: (value: { from: Date | null; to: Date | null } | null) => void;
}

export function CreatedDateFilter({ value, onChange }: CreatedDateFilterProps) {
  const handleFromDateSelect = (date: Date | undefined) => {
    onChange({
      from: date || null,
      to: value?.to || null,
    });
  };

  const handleToDateSelect = (date: Date | undefined) => {
    onChange({
      from: value?.from || null,
      to: date || null,
    });
  };

  return (
    <div className="p-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label className="text-sm">From Date</Label>
          <div className="text-xs text-muted-foreground mb-2">
            {value?.from ? format(value.from, "PPP") : "Select start date"}
          </div>
          <Calendar
            mode="single"
            selected={value?.from || undefined}
            onSelect={handleFromDateSelect}
            className={cn("pointer-events-auto")}
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm">To Date</Label>
          <div className="text-xs text-muted-foreground mb-2">
            {value?.to ? format(value.to, "PPP") : "Select end date"}
          </div>
          <Calendar
            mode="single"
            selected={value?.to || undefined}
            onSelect={handleToDateSelect}
            disabled={(date) => {
              if (!value?.from) return false;
              return date < value.from;
            }}
            className={cn("pointer-events-auto")}
          />
        </div>
      </div>
    </div>
  );
}
