import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Loader2, ChevronDown, ExternalLink, Download } from "lucide-react";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { clientHref, leadHref } from "@/lib/idCipher";

type CompareKey = "email" | "phone" | "name";

interface MatchedRecord {
  id: string;
  type: "Lead" | "Client";
  name: string;
  matchedValue: string;
  status: string;
}

const COLUMN_MAP: Record<CompareKey, { lead: string; client: string }> = {
  email: { lead: "email", client: "email" },
  phone: { lead: "phone", client: "home_phone" },
  name: { lead: "name", client: "name" },
};

function chunkArray<T>(arr: T[], size: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

interface CompareLeadsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CompareLeadsDialog({ open, onOpenChange }: CompareLeadsDialogProps) {
  const navigate = useNavigate();
  const [compareKey, setCompareKey] = useState<CompareKey>("email");
  const [inputText, setInputText] = useState("");
  const [isComparing, setIsComparing] = useState(false);
  const [results, setResults] = useState<MatchedRecord[] | null>(null);
  const [unmatchedItems, setUnmatchedItems] = useState<string[]>([]);
  const [totalInput, setTotalInput] = useState(0);
  const [showUnmatched, setShowUnmatched] = useState(false);

  const handleCompare = async () => {
    const values = inputText
      .split("\n")
      .map((v) => v.trim())
      .filter((v) => v.length > 0);

    if (values.length === 0) return;

    setIsComparing(true);
    setTotalInput(values.length);
    setResults(null);
    setUnmatchedItems([]);

    try {
      const { lead: leadCol, client: clientCol } = COLUMN_MAP[compareKey];
      const chunks = chunkArray(values, 500);
      let allLeads: any[] = [];
      let allClients: any[] = [];

      for (const chunk of chunks) {
        const leadsRes = await (supabase.from("leads").select("id, name, email, phone, status") as any).in(leadCol, chunk);
        const clientsRes = await (supabase.from("clients").select("id, name, email, home_phone, status") as any).in(clientCol, chunk);
        allLeads.push(...(leadsRes.data || []));
        allClients.push(...(clientsRes.data || []));
      }

      const matched: MatchedRecord[] = [];
      const matchedInputValues = new Set<string>();

      for (const lead of allLeads) {
        const val = (lead[leadCol] || "").toLowerCase();
        matched.push({
          id: lead.id,
          type: "Lead",
          name: lead.name || "",
          matchedValue: lead[leadCol] || "",
          status: lead.status || "",
        });
        matchedInputValues.add(val);
      }

      for (const client of allClients) {
        const val = (client[clientCol] || "").toLowerCase();
        matched.push({
          id: client.id,
          type: "Client",
          name: client.name || "",
          matchedValue: client[clientCol] || "",
          status: client.status || "",
        });
        matchedInputValues.add(val);
      }

      const unmatched = values.filter((v) => !matchedInputValues.has(v.toLowerCase()));
      setResults(matched);
      setUnmatchedItems(unmatched);
    } catch (err) {
      console.error("Compare error:", err);
    } finally {
      setIsComparing(false);
    }
  };

  const handleReset = () => {
    setResults(null);
    setUnmatchedItems([]);
    setInputText("");
    setTotalInput(0);
    setShowUnmatched(false);
  };

  const leadCount = results?.filter((r) => r.type === "Lead").length || 0;
  const clientCount = results?.filter((r) => r.type === "Client").length || 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Compare Leads & Clients</DialogTitle>
          <DialogDescription>Paste a list of values to find matching leads and clients.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Key selector */}
          <div>
            <label className="text-sm font-medium mb-2 block">Compare by</label>
            <ToggleGroup
              type="single"
              value={compareKey}
              onValueChange={(v) => v && setCompareKey(v as CompareKey)}
              className="justify-start"
            >
              <ToggleGroupItem value="email" size="sm">Email</ToggleGroupItem>
              <ToggleGroupItem value="phone" size="sm">Phone</ToggleGroupItem>
              <ToggleGroupItem value="name" size="sm">Lead Name</ToggleGroupItem>
            </ToggleGroup>
          </div>

          {/* Textarea */}
          <div>
            <label className="text-sm font-medium mb-2 block">Paste your list (one per line)</label>
            <Textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={compareKey === "email" ? "john@example.com\njane@example.com" : compareKey === "phone" ? "+1234567890\n+0987654321" : "John Doe\nJane Smith"}
              rows={8}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button onClick={handleCompare} disabled={isComparing || !inputText.trim()}>
              {isComparing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Compare
            </Button>
            {results && (
              <>
                <Button variant="outline" onClick={() => {
                  if (!results || results.length === 0) return;
                  const wsData = results.map((r) => ({
                    Type: r.type,
                    Name: r.name,
                    "Matched Value": r.matchedValue,
                    Status: r.status,
                  }));
                  const ws = XLSX.utils.json_to_sheet(wsData);
                  const wb = XLSX.utils.book_new();
                  XLSX.utils.book_append_sheet(wb, ws, "Matches");
                  if (unmatchedItems.length > 0) {
                    const wsUnmatched = XLSX.utils.json_to_sheet(unmatchedItems.map((v) => ({ Value: v })));
                    XLSX.utils.book_append_sheet(wb, wsUnmatched, "Unmatched");
                  }
                  XLSX.writeFile(wb, `compare-results-${compareKey}.xlsx`);
                }}>
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
                <Button variant="outline" onClick={handleReset}>
                  Reset
                </Button>
              </>
            )}
          </div>

          {/* Results */}
          {results && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Found <span className="font-semibold text-foreground">{results.length}</span> matches
                ({leadCount} leads, {clientCount} clients) out of {totalInput} items.
                {unmatchedItems.length > 0 && (
                  <> <span className="font-semibold text-foreground">{unmatchedItems.length}</span> unmatched.</>
                )}
              </p>

              {results.length > 0 && (
                <div className="border rounded-md max-h-64 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-20">Type</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Matched Value</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {results.map((r) => (
                        <TableRow key={`${r.type}-${r.id}`}>
                          <TableCell>
                            <Badge variant={r.type === "Lead" ? "secondary" : "default"} className="text-xs">
                              {r.type}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium">{r.name}</TableCell>
                          <TableCell className="text-muted-foreground text-sm">{r.matchedValue}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">{r.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => {
                                onOpenChange(false);
                                navigate(r.type === "Lead" ? leadHref(r.id) : clientHref(r.id));
                              }}
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {unmatchedItems.length > 0 && (
                <Collapsible open={showUnmatched} onOpenChange={setShowUnmatched}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground">
                      <ChevronDown className={`h-4 w-4 transition-transform ${showUnmatched ? "rotate-180" : ""}`} />
                      {unmatchedItems.length} unmatched items
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="border rounded-md p-3 max-h-40 overflow-y-auto bg-muted/50">
                      <pre className="text-xs text-muted-foreground whitespace-pre-wrap">
                        {unmatchedItems.join("\n")}
                      </pre>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
