import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, FileSpreadsheet, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { useLeadGroups } from "@/hooks/useLeadGroups";
import { getErrorMessage } from "@/types/errors";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { getCountryFromPhone } from "@/lib/phoneCountryCode";

// More lenient validation schema for CSV lead data
const leadSchema = z.object({
  name: z.string()
    .trim()
    .min(1, "Name is required")
    .max(200, "Name must be less than 200 characters"),
  email: z.string()
    .trim()
    .max(255, "Email must be less than 255 characters")
    .nullable()
    .optional()
    .transform(val => val || null)
    .refine((email) => {
      // Accept empty or any reasonable email format
      if (!email) return true;
      return /^[^\s@]+@[^\s@]+\.[^\s@]+/.test(email);
    }, "Invalid email format"),
  phone: z.string()
    .trim()
    .min(1, "Phone is required")
    .max(50, "Phone number too long"),
  country: z.string()
    .trim()
    .max(100, "Country name too long")
    .nullable()
    .optional()
    .transform(val => val || null),
  bank: z.string()
    .trim()
    .max(500, "Bank name too long")
    .nullable()
    .optional()
    .transform(val => val || null),
  kyc_note: z.string()
    .trim()
    .max(5000, "KYC note too long")
    .nullable()
    .optional()
    .transform(val => val || null),
});

// Clean and extract first email from potentially messy input
const cleanEmail = (raw: string | null | undefined): string | null => {
  if (!raw || !raw.trim()) return null;
  // Split by common separators and take first valid email
  const emails = raw.split(/[\n\r,;\s]+/).filter(e => e.includes("@"));
  return emails[0]?.trim() || null;
};

// Clean and extract first phone from potentially messy input  
const cleanPhone = (raw: string | null | undefined): string | null => {
  if (!raw) return null;
  // Split by newlines and take first one, then clean it
  const phones = raw.split(/[\n\r]+/).filter(p => p.trim());
  const firstPhone = phones[0]?.trim() || raw.trim();
  // Keep only digits, plus, and basic formatting
  return firstPhone.replace(/[^\d+\-\s()]/g, '').trim() || null;
};

interface DuplicateInfo {
  row: number;
  name: string;
  reason: string;
  matchedValue: string;
}

interface ImportResult {
  imported: number;
  duplicates: DuplicateInfo[];
  errors: string[];
  total: number;
}

interface ImportLeadsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ImportLeadsDialog = ({ open, onOpenChange }: ImportLeadsDialogProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [selectedGroupId, setSelectedGroupId] = useState<string>("");
  const [showNewGroup, setShowNewGroup] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupDescription, setNewGroupDescription] = useState("");
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  const { groups, isLoading: groupsLoading, createGroup, addLeadsToGroup } = useLeadGroups();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  // Improved CSV parser that handles quoted fields with commas/newlines
  const parseCSV = (text: string): Record<string, string | null>[] => {
    const data: Record<string, string | null>[] = [];
    const lines: string[] = [];
    let currentLine = "";
    let inQuotes = false;
    
    // Handle quoted fields that span multiple lines
    for (const char of text) {
      if (char === '"') {
        inQuotes = !inQuotes;
        currentLine += char;
      } else if (char === '\n' && !inQuotes) {
        if (currentLine.trim()) lines.push(currentLine);
        currentLine = "";
      } else if (char === '\r') {
        // Skip carriage returns
      } else {
        currentLine += char;
      }
    }
    if (currentLine.trim()) lines.push(currentLine);
    
    if (lines.length === 0) return data;
    
    // Parse header row
    const headers = parseCSVLine(lines[0]);
    
    // Parse data rows
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i]);
      const row: Record<string, string | null> = {};
      
      // Check if row has any meaningful data
      const hasData = values.some(v => v && v.trim());
      if (!hasData) continue;
      
      headers.forEach((header, index) => {
        const value = values[index]?.trim();
        row[header] = value || null;
      });
      
      data.push(row);
    }

    return data;
  };

  // Parse a single CSV line handling quoted values
  const parseCSVLine = (line: string): string[] => {
    const values: string[] = [];
    let current = "";
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          // Escaped quote
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    values.push(current.trim());
    
    return values;
  };

  const handleImport = async () => {
    if (!file) {
      toast.error("Please select a file");
      return;
    }

    setIsImporting(true);
    setImportProgress(0);

    try {
      const text = await file.text();
      const rows = parseCSV(text);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Get user's tenant (admin_id) for tenant-scoped duplicate check
      const { data: userProfile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .single();

      // Check if user is SUPER_ADMIN or TENANT_OWNER
      const { data: userRole } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      // Determine tenant ID for duplicate check
      // SUPER_ADMIN has no tenant - they can import without duplicate checks across tenants
      // TENANT_OWNER uses their own ID as tenant
      // Others use their admin_id
      const isSuperAdmin = userRole?.role === "SUPER_ADMIN";
      const isTenantOwner = userRole?.role === "TENANT_OWNER";
      const tenantId = isTenantOwner ? user.id : userProfile?.admin_id;

      console.log("Import duplicate check - Role:", userRole?.role, "TenantId:", tenantId, "IsSuperAdmin:", isSuperAdmin);

      // Build sets of existing emails and phones for fast lookup (tenant-scoped only)
      const existingEmails = new Set<string>();
      const existingPhones = new Set<string>();

      // Only check for duplicates within the same tenant
      // SUPER_ADMIN without effectiveTenantId context skips duplicate check
      // TENANT_OWNER and their users check against their tenant data
      if (tenantId) {
        // Fetch existing leads and clients within the same tenant only
        const { data: existingLeads, error: leadsError } = await supabase
          .from("leads")
          .select("email, phone")
          .eq("admin_id", tenantId);
        
        const { data: existingClients, error: clientsError } = await supabase
          .from("clients")
          .select("email, home_phone")
          .eq("admin_id", tenantId);

        console.log("Existing leads in tenant:", existingLeads?.length || 0, leadsError);
        console.log("Existing clients in tenant:", existingClients?.length || 0, clientsError);

        existingLeads?.forEach(lead => {
          if (lead.email) existingEmails.add(lead.email.toLowerCase().trim());
          if (lead.phone) existingPhones.add(lead.phone.replace(/[^\d+]/g, ''));
        });

        existingClients?.forEach(client => {
          if (client.email) existingEmails.add(client.email.toLowerCase().trim());
          if (client.home_phone) existingPhones.add(client.home_phone.replace(/[^\d+]/g, ''));
        });
      }
      
      console.log("Duplicate check sets - Emails:", existingEmails.size, "Phones:", existingPhones.size);

      // Create new group if specified
      let targetGroupId = selectedGroupId;
      if (showNewGroup && newGroupName.trim()) {
        const newGroup = await createGroup.mutateAsync({
          name: newGroupName.trim(),
          description: newGroupDescription.trim() || undefined,
        });
        targetGroupId = newGroup.id;
      }

      // Validate and sanitize each row
      interface ValidatedLead {
        lead: {
          name: string;
          email: string | null;
          phone: string | null;
          country: string | null;
          source: "OTHER";
          status: "NEW";
          created_by: string;
        };
        bank?: string;
        kyc_note?: string;
        rowIndex: number;
      }
      const validatedLeads: ValidatedLead[] = [];
      const errors: string[] = [];
      const duplicateInfos: DuplicateInfo[] = [];

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        try {
          // Get raw values with flexible header matching
          const rawName = row.name || row.Name || row.NAME || "";
          const rawEmail = row.email || row.Email || row.EMAIL || "";
          const rawPhone = row.phone || row.Phone || row.PHONE || null;
          const rawCountry = row.country || row.Country || row.COUNTRY || null;
          const rawBank = row.bank || row.Bank || row.BANK || null;
          const rawNote = row.kyc_note || row["KYC Note"] || row.kycnote || row.notes || row.Notes || row.note || row.Note || null;

          // Skip rows with no name (empty rows)
          if (!rawName?.trim()) {
            continue;
          }

          // Prepare data for validation with cleaning
          const leadData = {
            name: rawName?.trim() || "",
            email: cleanEmail(rawEmail),
            phone: cleanPhone(rawPhone),
            country: rawCountry?.trim() || null,
            bank: rawBank?.trim() || null,
            kyc_note: rawNote?.trim() || null,
          };

          // Validate with zod schema
          const validated = leadSchema.parse(leadData);

          // Check for duplicates by phone only
          const phoneNormalized = validated.phone?.replace(/[^\d+]/g, '') || null;
          
          const isDuplicatePhone = phoneNormalized && existingPhones.has(phoneNormalized);
          
          if (isDuplicatePhone) {
            duplicateInfos.push({
              row: i + 2,
              name: validated.name,
              reason: "Phone",
              matchedValue: validated.phone || "",
            });
            continue; // Skip this lead
          }

          // Add to existing sets to prevent duplicates within the import file
          if (phoneNormalized) existingPhones.add(phoneNormalized);

          // Auto-detect country from phone if not provided
          const detectedCountry = validated.country || getCountryFromPhone(phoneNormalized);

          // Add user metadata - normalize phone to digits only for consistent duplicate checking
          validatedLeads.push({
            lead: {
              name: validated.name,
              email: validated.email || null,
              phone: phoneNormalized || null, // Store normalized phone (digits + plus only)
              country: detectedCountry || null,
              source: "OTHER" as const,
              status: "NEW" as const,
              created_by: user.id,
            },
            bank: validated.bank || undefined,
            kyc_note: validated.kyc_note || undefined,
            rowIndex: i + 2, // Track original row for error reporting
          });
        } catch (error) {
          if (error instanceof z.ZodError) {
            errors.push(`Row ${i + 2}: ${error.errors[0].message}`);
          } else {
            errors.push(`Row ${i + 2}: Invalid data`);
          }
        }
      }

      // Report validation errors
      if (errors.length > 0) {
        const errorMessage = errors.length <= 5 
          ? errors.join(", ") 
          : `${errors.slice(0, 5).join(", ")} and ${errors.length - 5} more errors`;
        
        toast.error(`Validation failed: ${errorMessage}`);
        
        // If too many errors, abort
        if (errors.length > rows.length * 0.3) {
          throw new Error("Too many validation errors. Please fix your CSV file.");
        }
      }

      if (validatedLeads.length === 0) {
        if (duplicateInfos.length > 0) {
          setImportResult({
            imported: 0,
            duplicates: duplicateInfos,
            errors,
            total: rows.length,
          });
          return;
        }
        throw new Error("No valid leads to import");
      }

      // Insert leads individually to handle duplicates gracefully
      const insertedLeads: { id: string; index: number }[] = [];
      const dbDuplicates: DuplicateInfo[] = [];

      for (let i = 0; i < validatedLeads.length; i++) {
        const { lead, rowIndex } = validatedLeads[i];
        
        try {
          const { data: insertedLead, error } = await supabase
            .from("leads")
            .insert(lead)
            .select("id")
            .single();
          
          if (error) {
            // Check if it's a unique constraint violation (duplicate phone)
            if (error.code === '23505') {
              dbDuplicates.push({
                row: rowIndex || i + 2,
                name: lead.name,
                reason: "Phone (database)",
                matchedValue: lead.phone || "",
              });
              setImportProgress(Math.round(((i + 1) / validatedLeads.length) * 100));
              continue; // Skip this lead and continue with others
            }
            throw error;
          }
          
          if (insertedLead) {
            insertedLeads.push({ id: insertedLead.id, index: i });
          }
        } catch (err: unknown) {
          const errorMsg = err instanceof Error ? err.message : 'Unknown error';
          console.error(`Failed to insert lead ${lead.name}:`, err);
          errors.push(`Row ${rowIndex || i + 2}: Insert failed - ${errorMsg}`);
        }
        setImportProgress(Math.round(((i + 1) / validatedLeads.length) * 100));
      }

      // Merge duplicates from pre-check and database constraint violations
      const allDuplicates = [...duplicateInfos, ...dbDuplicates];

      // Create KYC records for successfully inserted leads
      if (insertedLeads.length > 0) {
        const kycRecords: { lead_id: string; bank_name?: string; notes?: string; created_by: string }[] = [];
        
        insertedLeads.forEach(({ id, index }) => {
          const originalData = validatedLeads[index];
          
          // Create bank record if provided
          if (originalData.bank) {
            kycRecords.push({
              lead_id: id,
              bank_name: originalData.bank,
              created_by: user.id,
            });
          }
          
          // Create note record if provided
          if (originalData.kyc_note) {
            kycRecords.push({
              lead_id: id,
              notes: originalData.kyc_note,
              created_by: user.id,
            });
          }
        });

        if (kycRecords.length > 0) {
          const { error: kycError } = await supabase
            .from("kyc_records")
            .insert(kycRecords);
          
          if (kycError) {
            console.error("Error creating KYC records:", kycError);
            toast.warning("Leads imported but some KYC records failed");
          }
        }

      }

      // Add leads to group if a group is selected (outside insertedLeads check so it always runs)
      if (targetGroupId && insertedLeads.length > 0) {
        const leadIds = insertedLeads.map(l => l.id);
        try {
          await addLeadsToGroup.mutateAsync({
            groupId: targetGroupId,
            leadIds,
          });
        } catch (groupError) {
          console.error("Error adding leads to group:", groupError);
          toast.warning("Leads imported but failed to add to group");
        }
      }

      // Set import result to show summary
      setImportResult({
        imported: insertedLeads.length,
        duplicates: allDuplicates,
        errors,
        total: rows.length,
      });
      
      toast.success(`Imported ${insertedLeads.length} leads${allDuplicates.length > 0 ? `, ${allDuplicates.length} duplicates skipped` : ''}`);
    } catch (error: unknown) {
      toast.error(getErrorMessage(error));
    } finally {
      setIsImporting(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setSelectedGroupId("");
    setShowNewGroup(false);
    setNewGroupName("");
    setNewGroupDescription("");
    setImportResult(null);
    setImportProgress(0);
  };

  const handleCloseAndRefresh = () => {
    onOpenChange(false);
    resetForm();
    window.location.reload();
  };

  const handleGroupSelect = (value: string) => {
    if (value === "new") {
      setShowNewGroup(true);
      setSelectedGroupId("");
    } else {
      setShowNewGroup(false);
      setSelectedGroupId(value);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(open) => {
      if (!open) resetForm();
      onOpenChange(open);
    }}>
      <DialogContent className="max-w-lg overflow-hidden">
        <DialogHeader>
          <DialogTitle>{importResult ? "Import Results" : "Import Leads"}</DialogTitle>
          {importResult && (
            <DialogDescription>
              Summary of the import operation
            </DialogDescription>
          )}
        </DialogHeader>

        {importResult ? (
          <div className="space-y-4">
            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-lg border border-border p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-success mb-1">
                  <CheckCircle2 className="h-4 w-4" />
                  <span className="text-lg font-bold">{importResult.imported}</span>
                </div>
                <p className="text-xs text-muted-foreground">Imported</p>
              </div>
              <div className="rounded-lg border border-border p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-warning mb-1">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-lg font-bold">{importResult.duplicates.length}</span>
                </div>
                <p className="text-xs text-muted-foreground">Duplicates</p>
              </div>
              <div className="rounded-lg border border-border p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-destructive mb-1">
                  <XCircle className="h-4 w-4" />
                  <span className="text-lg font-bold">{importResult.errors.length}</span>
                </div>
                <p className="text-xs text-muted-foreground">Errors</p>
              </div>
            </div>

            {/* Duplicates List */}
            {importResult.duplicates.length > 0 && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  Skipped Duplicates ({importResult.duplicates.length})
                </Label>
                <ScrollArea className="h-[200px] rounded-md border border-border">
                  <div className="p-3 space-y-2">
                    {importResult.duplicates.map((dup, idx) => (
                      <div key={idx} className="flex items-start justify-between text-sm py-1.5 border-b border-border last:border-0">
                        <div>
                          <span className="font-medium">{dup.name}</span>
                          <span className="text-muted-foreground ml-2 text-xs">Row {dup.row}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs px-1.5 py-0.5 rounded bg-warning/20 text-warning">
                            {dup.reason}
                          </span>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate max-w-[150px]">
                            {dup.matchedValue}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {/* Errors List */}
            {importResult.errors.length > 0 && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <XCircle className="h-4 w-4 text-destructive" />
                  Validation Errors ({importResult.errors.length})
                </Label>
                <ScrollArea className="h-[100px] rounded-md border border-border">
                  <div className="p-3 space-y-1">
                    {importResult.errors.slice(0, 20).map((err, idx) => (
                      <p key={idx} className="text-xs text-destructive">{err}</p>
                    ))}
                    {importResult.errors.length > 20 && (
                      <p className="text-xs text-muted-foreground">...and {importResult.errors.length - 20} more</p>
                    )}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4 overflow-y-auto max-h-[60vh]">
            <div className="space-y-2">
              <Label>CSV File</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  disabled={isImporting}
                />
                {file && (
                  <FileSpreadsheet className="h-5 w-5 text-success" />
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                CSV should include columns: Name, Email, Phone, Country, Bank, KYC Note
              </p>
            </div>

            <div className="space-y-2">
              <Label>Assign to Group (Optional)</Label>
              <Select 
                value={showNewGroup ? "new" : selectedGroupId} 
                onValueChange={handleGroupSelect}
                disabled={isImporting || groupsLoading}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a group or create new" />
                </SelectTrigger>
                <SelectContent className="bg-popover z-50">
                  <SelectItem value="none">No group</SelectItem>
                  <SelectItem value="new">+ Create New Group</SelectItem>
                  {groups?.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {showNewGroup && (
              <div className="space-y-3 rounded-md border border-border p-3">
                <div className="space-y-2">
                  <Label>Group Name</Label>
                  <Input
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    placeholder="Enter group name"
                    disabled={isImporting}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Description (Optional)</Label>
                  <Input
                    value={newGroupDescription}
                    onChange={(e) => setNewGroupDescription(e.target.value)}
                    placeholder="Enter description"
                    disabled={isImporting}
                  />
                </div>
              </div>
            )}

            <div className="rounded-md bg-muted p-3 text-xs">
              <p className="font-semibold mb-2">Expected CSV Format:</p>
              <code className="block whitespace-pre text-xs">
                Name,Email,Phone,Country,Bank,KYC Note{"\n"}
                John Doe,john@example.com,+1234567890,USA,Bank of America,Verified ID
              </code>
            </div>
          </div>
        )}

        {isImporting && (
          <div className="px-1">
            <Progress value={importProgress} className="h-2" />
          </div>
        )}

        <DialogFooter>
          {importResult ? (
            <Button size="sm" onClick={handleCloseAndRefresh}>
              Done
            </Button>
          ) : (
            <>
              <Button size="sm" variant="outline" onClick={() => onOpenChange(false)} disabled={isImporting}>
                Cancel
              </Button>
              <Button 
                size="sm" 
                onClick={handleImport} 
                disabled={!file || isImporting || (showNewGroup && !newGroupName.trim())}
              >
                {isImporting ? (
                  <>Importing ({importProgress}%)</>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Import Leads
                  </>
                )}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
