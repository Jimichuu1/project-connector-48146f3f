import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface LeadKYCBanksProps {
  leadId: string;
}

export const LeadKYCBanks = ({ leadId }: LeadKYCBanksProps) => {
  const { data: kycRecords, isLoading } = useQuery({
    queryKey: ['kyc-banks', leadId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kyc_records')
        .select('id, bank_name')
        .eq('lead_id', leadId)
        .not('bank_name', 'is', null)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });

  if (isLoading) {
    return <Skeleton className="h-5 w-20" />;
  }

  if (!kycRecords || kycRecords.length === 0) {
    return <span className="text-xs text-muted-foreground">-</span>;
  }

  const firstBank = kycRecords[0];
  const remainingBanks = kycRecords.slice(1);

  return (
    <div className="flex flex-wrap gap-1">
      <Badge 
        variant="secondary"
        className="text-xs px-2 py-0.5"
      >
        {firstBank.bank_name}
      </Badge>
      {remainingBanks.length > 0 && (
        <Popover>
          <PopoverTrigger asChild>
            <Badge 
              variant="outline"
              className="text-xs px-2 py-0.5 cursor-pointer hover:bg-accent transition-colors"
            >
              +{remainingBanks.length}
            </Badge>
          </PopoverTrigger>
          <PopoverContent 
            className="w-auto p-3" 
            align="start"
          >
            <div className="space-y-2">
              <h4 className="text-xs font-semibold">Additional Banks</h4>
              <div className="flex flex-wrap gap-1">
                {remainingBanks.map((record) => (
                  <Badge 
                    key={record.id} 
                    variant="secondary"
                    className="text-xs px-2 py-0.5"
                  >
                    {record.bank_name}
                  </Badge>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
};
