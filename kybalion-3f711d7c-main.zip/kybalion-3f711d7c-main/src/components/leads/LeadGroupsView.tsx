import { useState, useMemo } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { FolderOpen, Layers, Pencil, Check, X, Trash2, Plus, Shuffle, Merge } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { useLeadGroups } from "@/hooks/useLeadGroups";
import { DeleteGroupDialog } from "./DeleteGroupDialog";
import { MergeGroupsDialog } from "./MergeGroupsDialog";
import { useUserRole } from "@/hooks/useUserRole";
import { useLeadsStats } from "@/hooks/useLeadsStats";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Checkbox } from "@/components/ui/checkbox";
import { cn } from "@/lib/utils";

interface LeadGroupWithCount {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  memberCount: number;
}

interface LeadGroupsViewProps {
  onGroupSelect: (groupId: string | null, groupName: string | null) => void;
  onShuffleGroup?: (groupId: string, groupName: string) => void;
}

export function LeadGroupsView({ onGroupSelect, onShuffleGroup }: LeadGroupsViewProps) {
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [groupToDelete, setGroupToDelete] = useState<LeadGroupWithCount | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupDescription, setNewGroupDescription] = useState("");
  const [mergeMode, setMergeMode] = useState(false);
  const [selectedForMerge, setSelectedForMerge] = useState<Set<string>>(new Set());
  const [mergeDialogOpen, setMergeDialogOpen] = useState(false);

  const { groups: fetchedGroups, isLoading: groupsLoading, updateGroup, deleteGroup, createGroup, mergeGroups } = useLeadGroups();
  const { isAgent, isSuperAgent, isTenantOwner, isSuperAdmin, isManager } = useUserRole();
  
  const { totalLeads, groupCounts, isLoading: statsLoading } = useLeadsStats();

  const shouldFilterByAssignment = isAgent || isSuperAgent;
  const canManageGroups = isTenantOwner || isSuperAdmin || isManager;
  const canShuffle = canManageGroups;
  const canMerge = isTenantOwner || isSuperAdmin;

  const isLoading = groupsLoading || statsLoading;

  const groups = useMemo(() => {
    return (fetchedGroups || []).map(group => ({
      ...group,
      memberCount: groupCounts[group.id] || 0,
    }));
  }, [fetchedGroups, groupCounts]);

  const totalLeadsCount = totalLeads;

  const selectedMergeGroups = useMemo(() => {
    return groups.filter(g => selectedForMerge.has(g.id));
  }, [groups, selectedForMerge]);

  const toggleMergeSelection = (e: React.MouseEvent, groupId: string) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedForMerge(prev => {
      const next = new Set(prev);
      if (next.has(groupId)) next.delete(groupId);
      else next.add(groupId);
      return next;
    });
  };

  const handleMergeConfirm = async (newName: string) => {
    await mergeGroups.mutateAsync({
      groupIds: Array.from(selectedForMerge),
      newName,
    });
    setMergeDialogOpen(false);
    setSelectedForMerge(new Set());
    setMergeMode(false);
  };

  const handleEditClick = (e: React.MouseEvent, group: LeadGroupWithCount) => {
    e.preventDefault();
    e.stopPropagation();
    setEditingGroupId(group.id);
    setEditingName(group.name);
  };

  const handleSaveEdit = async (e: React.MouseEvent, groupId: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (!editingName.trim()) {
      toast.error("Group name cannot be empty");
      return;
    }

    try {
      await updateGroup.mutateAsync({ groupId, name: editingName.trim() });
    } catch (error) {
      // Error handled by mutation
    } finally {
      setEditingGroupId(null);
      setEditingName("");
    }
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setEditingGroupId(null);
    setEditingName("");
  };

  const handleDeleteClick = (e: React.MouseEvent, group: LeadGroupWithCount) => {
    e.preventDefault();
    e.stopPropagation();
    setGroupToDelete(group);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async (deleteLeads: boolean) => {
    if (!groupToDelete) return;

    try {
      await deleteGroup.mutateAsync({ groupId: groupToDelete.id, deleteLeads });
      setDeleteDialogOpen(false);
      setGroupToDelete(null);
    } catch (error) {
      // Error handled by mutation
    }
  };

  const handleCardClick = (groupId: string | null, groupName: string | null) => {
    if (editingGroupId || isCreating) return;
    if (mergeMode) return; // Don't navigate while in merge mode
    onGroupSelect(groupId, groupName);
  };

  const handleCreateGroup = async () => {
    if (!newGroupName.trim()) {
      toast.error("Group name is required");
      return;
    }

    try {
      await createGroup.mutateAsync({
        name: newGroupName.trim(),
        description: newGroupDescription.trim() || undefined,
      });
      setIsCreating(false);
      setNewGroupName("");
      setNewGroupDescription("");
    } catch (error) {
      // Error handled by mutation
    }
  };

  const handleCancelCreate = () => {
    setIsCreating(false);
    setNewGroupName("");
    setNewGroupDescription("");
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-4 w-48 mt-2" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-4 w-24" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <>
      {/* Merge toolbar */}
      {canMerge && groups.length >= 2 && (
        <div className="flex items-center gap-2 mb-4">
          {mergeMode ? (
            <>
              <Button
                size="sm"
                onClick={() => setMergeDialogOpen(true)}
                disabled={selectedForMerge.size < 2}
              >
                <Merge className="h-4 w-4 mr-1" />
                Merge {selectedForMerge.size > 0 ? `(${selectedForMerge.size})` : ""}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setMergeMode(false);
                  setSelectedForMerge(new Set());
                }}
              >
                Cancel
              </Button>
              <span className="text-xs text-muted-foreground ml-2">
                Select 2 or more groups to merge
              </span>
            </>
          ) : (
            <Button
              size="sm"
              variant="outline"
              onClick={() => setMergeMode(true)}
            >
              <Merge className="h-4 w-4 mr-1" />
              Merge Groups
            </Button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* All Leads - Virtual Group */}
        <Card
          className="cursor-pointer hover:shadow-lg transition-all hover:bg-muted/50"
          onClick={() => handleCardClick(null, null)}
        >
          <CardHeader>
            <div className="flex items-start justify-between">
              <Layers className="h-5 w-5 text-primary" />
              <Badge className="bg-primary text-primary-foreground">{totalLeadsCount} leads</Badge>
            </div>
            <CardTitle className="text-lg mt-2">All Leads</CardTitle>
            <CardDescription>
              View all leads across all groups
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">
              Default view
            </p>
          </CardContent>
        </Card>

        {groups.map((group) => (
          <Card
            key={group.id}
            className={cn(
              "cursor-pointer hover:shadow-lg transition-all hover:bg-muted/50",
              mergeMode && selectedForMerge.has(group.id) && "ring-2 ring-primary bg-primary/5"
            )}
            onClick={() => mergeMode ? toggleMergeSelection({ preventDefault: () => {}, stopPropagation: () => {} } as React.MouseEvent, group.id) : handleCardClick(group.id, group.name)}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  {mergeMode && (
                    <Checkbox
                      checked={selectedForMerge.has(group.id)}
                      onClick={(e) => toggleMergeSelection(e, group.id)}
                      className="mt-0.5"
                    />
                  )}
                  <FolderOpen className="h-5 w-5 text-primary" />
                </div>
                <Badge className="bg-primary text-primary-foreground">{group.memberCount} leads</Badge>
              </div>
              <div className="flex items-center gap-2 mt-2">
                {editingGroupId === group.id ? (
                  <div className="flex items-center gap-2 flex-1" onClick={e => e.stopPropagation()}>
                    <Input
                      value={editingName}
                      onChange={(e) => setEditingName(e.target.value)}
                      className="h-8 text-lg font-semibold"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleSaveEdit(e as any, group.id);
                        if (e.key === "Escape") handleCancelEdit(e as any);
                      }}
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 shrink-0"
                      onClick={(e) => handleSaveEdit(e, group.id)}
                      disabled={updateGroup.isPending}
                    >
                      <Check className="h-4 w-4 text-green-500" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 shrink-0"
                      onClick={handleCancelEdit}
                    >
                      <X className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <CardTitle className="text-lg flex-1">{group.name}</CardTitle>
                    {!mergeMode && canManageGroups && (
                      <div className="flex items-center gap-1">
                        {canShuffle && onShuffleGroup && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={(e) => {
                                  e.preventDefault();
                                  e.stopPropagation();
                                  onShuffleGroup(group.id, group.name);
                                }}
                              >
                                <Shuffle className="h-3.5 w-3.5" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Shuffle unassigned leads</TooltipContent>
                          </Tooltip>
                        )}
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7"
                          onClick={(e) => handleEditClick(e, group)}
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7"
                          onClick={(e) => handleDeleteClick(e, group)}
                        >
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </div>
              {group.description && (
                <CardDescription className="line-clamp-2">
                  {group.description}
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Created {format(new Date(group.created_at), "MMM d, yyyy")}
              </p>
            </CardContent>
          </Card>
        ))}

        {/* Create New Group Card */}
        {!shouldFilterByAssignment && !mergeMode && (
          isCreating ? (
            <Card className="border-dashed border-2 border-primary/50">
              <CardHeader className="space-y-3">
                <div className="flex items-center gap-2">
                  <Plus className="h-5 w-5 text-primary" />
                  <span className="font-semibold">New Group</span>
                </div>
                <Input
                  placeholder="Group name"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) handleCreateGroup();
                    if (e.key === "Escape") handleCancelCreate();
                  }}
                />
                <Textarea
                  placeholder="Description (optional)"
                  value={newGroupDescription}
                  onChange={(e) => setNewGroupDescription(e.target.value)}
                  rows={2}
                  className="resize-none"
                />
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    onClick={handleCreateGroup}
                    disabled={!newGroupName.trim() || createGroup.isPending}
                  >
                    {createGroup.isPending ? "Creating..." : "Create"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCancelCreate}
                  >
                    Cancel
                  </Button>
                </div>
              </CardHeader>
            </Card>
          ) : (
            <Card
              className="cursor-pointer hover:shadow-lg transition-all border-dashed border-2 border-muted-foreground/30 hover:border-primary/50 hover:bg-muted/50"
              onClick={() => setIsCreating(true)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <Plus className="h-5 w-5 text-muted-foreground" />
                </div>
                <CardTitle className="text-lg mt-2 text-muted-foreground">Create New Group</CardTitle>
                <CardDescription>
                  Click to create a new lead group
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Organize your leads
                </p>
              </CardContent>
            </Card>
          )
        )}

        {groups.length === 0 && (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <FolderOpen className="h-16 w-16 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-semibold">No Custom Groups</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Create groups to organize your leads
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {groupToDelete && (
        <DeleteGroupDialog
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          groupName={groupToDelete.name}
          memberCount={groupToDelete.memberCount}
          onConfirm={handleDeleteConfirm}
          isPending={deleteGroup.isPending}
        />
      )}

      <MergeGroupsDialog
        open={mergeDialogOpen}
        onOpenChange={setMergeDialogOpen}
        selectedGroups={selectedMergeGroups}
        onConfirm={handleMergeConfirm}
        isPending={mergeGroups.isPending}
      />
    </>
  );
}
