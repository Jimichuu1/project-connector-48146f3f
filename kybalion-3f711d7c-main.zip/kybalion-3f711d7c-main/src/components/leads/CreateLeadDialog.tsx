import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { LeadStatus, LeadSource } from "@/types/leads";
import { Loader2, AlertTriangle } from "lucide-react";
import { getAutoCountry } from "@/lib/phoneCountryCode";
import { toast } from "sonner";
import { Database } from "@/integrations/supabase/types";
import { useAuditLog } from "@/hooks/useAuditLog";

type LeadInsert = Database['public']['Tables']['leads']['Insert'];

interface CreateLeadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateLeadDialog = ({ open, onOpenChange }: CreateLeadDialogProps) => {
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();
  const { logAction } = useAuditLog();
  
  const createLead = useMutation({
    mutationFn: async (leadData: Omit<LeadInsert, 'created_by' | 'admin_id'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Auto-assign to creator if they are an agent/super_agent/team_leader
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id);
      const userRoles = (roles || []).map((r: any) => r.role);
      const shouldAutoAssign = userRoles.some((r: string) =>
        ['AGENT', 'SUPER_AGENT', 'TEAM_LEADER'].includes(r)
      ) && !userRoles.some((r: string) =>
        ['SUPER_ADMIN', 'TENANT_OWNER', 'MANAGER'].includes(r)
      );

      const { data, error } = await supabase
        .from('leads')
        .insert([{
          ...leadData,
          created_by: user.id,
          admin_id: effectiveTenantId || null,
          ...(shouldAutoAssign && !leadData.assigned_to ? { assigned_to: user.id } : {}),
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: async (data) => {
      queryClient.invalidateQueries({ queryKey: ['leads-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['leads-count-paginated'] });
      
      // Log lead creation
      logAction({
        actionType: 'lead_created',
        entityType: 'lead',
        entityId: data.id,
        details: {
          lead_name: data.name,
          lead_email: data.email,
          lead_status: data.status,
          lead_country: data.country,
        },
        adminId: effectiveTenantId,
      });

      // Send NEW_LEAD notifications to managers/tenant owners in the same tenant
      if (effectiveTenantId) {
        try {
          // Get managers and tenant owner for this tenant
          const { data: managersData } = await supabase
            .from('user_roles')
            .select('user_id')
            .in('role', ['MANAGER', 'TENANT_OWNER']);

          if (managersData && managersData.length > 0) {
            // Filter to only users in the same tenant
            const { data: profiles } = await supabase
              .from('profiles')
              .select('id')
              .in('id', managersData.map(m => m.user_id))
              .or(`admin_id.eq.${effectiveTenantId},id.eq.${effectiveTenantId}`);

            const managerIds = profiles?.map(p => p.id) || [];
            
            // Get current user to exclude from notifications
            const { data: { user } } = await supabase.auth.getUser();
            const filteredManagerIds = managerIds.filter(id => id !== user?.id);

            // Send notifications
            if (filteredManagerIds.length > 0) {
              const notifications = filteredManagerIds.map(managerId => ({
                user_id: managerId,
                type: 'NEW_LEAD' as const,
                message: `New lead "${data.name}" has been created`,
                related_entity_type: 'lead',
                related_entity_id: data.id,
                admin_id: effectiveTenantId || null,
              }));

              await supabase.from('notifications').insert(notifications);
            }
          }
        } catch (notifError) {
          console.error('Failed to send NEW_LEAD notifications:', notifError);
          // Don't fail the main operation if notifications fail
        }
      }
      
      toast.success("Lead created successfully");
    },
    onError: (error: Error) => {
      toast.error(`Failed to create lead: ${error.message}`);
    },
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    country: "",
    status: "NEW" as LeadStatus,
  });

  const [duplicateResult, setDuplicateResult] = useState<{ type: 'lead' | 'client'; name: string } | null>(null);
  const [checkingDuplicate, setCheckingDuplicate] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    setDuplicateResult(null);

    const phone = formData.phone;
    if (!phone || phone.length < 4) {
      setCheckingDuplicate(false);
      return;
    }

    setCheckingDuplicate(true);
    debounceRef.current = setTimeout(async () => {
      try {
        // Check clients
        let clientQuery = supabase.from('clients').select('id, name').eq('home_phone', phone);
        if (effectiveTenantId) clientQuery = clientQuery.eq('admin_id', effectiveTenantId);
        const { data: clients } = await clientQuery.limit(1);
        if (clients && clients.length > 0) {
          setDuplicateResult({ type: 'client', name: clients[0].name });
          setCheckingDuplicate(false);
          return;
        }

        // Check leads
        let leadQuery = supabase.from('leads').select('id, name').eq('phone', phone);
        if (effectiveTenantId) leadQuery = leadQuery.eq('admin_id', effectiveTenantId);
        const { data: leads } = await leadQuery.limit(1);
        if (leads && leads.length > 0) {
          setDuplicateResult({ type: 'lead', name: leads[0].name });
          setCheckingDuplicate(false);
          return;
        }

        setDuplicateResult(null);
      } catch (err) {
        console.error('Duplicate check failed:', err);
      } finally {
        setCheckingDuplicate(false);
      }
    }, 500);

    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [formData.phone, effectiveTenantId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check for duplicate phone in clients and leads tables
    if (formData.phone) {
      let clientQuery = supabase.from('clients').select('id, name').eq('home_phone', formData.phone);
      if (effectiveTenantId) clientQuery = clientQuery.eq('admin_id', effectiveTenantId);
      const { data: existingClients } = await clientQuery.limit(1);
      
      if (existingClients && existingClients.length > 0) {
        toast.error(`A client with this phone number already exists: ${existingClients[0].name}`);
        return;
      }

      let leadQuery = supabase.from('leads').select('id, name').eq('phone', formData.phone);
      if (effectiveTenantId) leadQuery = leadQuery.eq('admin_id', effectiveTenantId);
      const { data: existingLeads } = await leadQuery.limit(1);
      
      if (existingLeads && existingLeads.length > 0) {
        toast.error(`A lead with this phone number already exists: ${existingLeads[0].name}`);
        return;
      }
    }

    await createLead.mutateAsync({
      ...formData,
      source: "OTHER",
      is_transferred: false,
      pending_conversion: false,
      email: formData.email || undefined,
      phone: formData.phone || undefined,
      country: formData.country || undefined,
    });

    onOpenChange(false);
    setFormData({
      name: "",
      email: "",
      phone: "",
      country: "",
      status: "NEW",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Lead</DialogTitle>
          <DialogDescription>
            Add a new lead to the CRM system
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone *</Label>
              <Input
                id="phone"
                placeholder="+491512006"
                value={formData.phone}
                onChange={(e) => {
                  const formatted = e.target.value.replace(/[^\d+]/g, '');
                  const autoCountry = getAutoCountry(formData.country, formatted);
                  setFormData({ ...formData, phone: formatted, country: autoCountry });
                }}
                required
              />
              {checkingDuplicate && (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  Checking...
                </div>
              )}
              {duplicateResult && (
                <div className="flex items-start gap-1.5 mt-1 rounded-md border border-destructive/50 bg-destructive/10 px-2.5 py-1.5 text-xs text-destructive">
                  <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                  <span>
                    A <strong>{duplicateResult.type}</strong> named "<strong>{duplicateResult.name}</strong>" already has this phone number
                  </span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                value={formData.country}
                readOnly
                placeholder="Auto-detected from phone"
                className="bg-muted text-muted-foreground"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value as LeadStatus })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NEW">New</SelectItem>
                  <SelectItem value="ACTIVE">Active</SelectItem>
                  <SelectItem value="CALLBACK">Callback</SelectItem>
                  <SelectItem value="NOT_INTERESTED">Not Interested</SelectItem>
                  <SelectItem value="CALLED">Called</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <ButtonGroup>
              <Button size="sm" type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button size="sm" type="submit" disabled={createLead.isPending}>
                {createLead.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Create Lead
              </Button>
            </ButtonGroup>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};