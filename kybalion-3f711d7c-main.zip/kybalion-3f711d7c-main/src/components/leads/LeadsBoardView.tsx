import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy, arrayMove } from "@dnd-kit/sortable";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Lead, LeadStatus } from "@/types/leads";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Mail, Building2, GripVertical, PhoneCall, Send, MoreVertical, Landmark, StickyNote, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { LeadStatusBadge } from "./LeadStatusBadge";
import { toast } from "sonner";
import { leadHref } from "@/lib/idCipher";
import { useActiveLeadStatuses } from "@/hooks/useLeadStatuses";

interface LeadsBoardViewProps {
  leads: Lead[];
  onStatusChange: (leadId: string, newStatus: LeadStatus) => void;
  isAgent: boolean;
  onReorder?: (leadId: string, newPosition: number, status: LeadStatus) => void;
  onCall?: (lead: Lead) => void;
  onEmail?: (lead: Lead) => void;
  onAddBank?: (lead: Lead) => void;
  onAddNote?: (lead: Lead) => void;
  onCreateAccount?: (lead: Lead) => void;
}

// Generate a color class based on position or color value
function getColumnColor(color: string | null, index: number): string {
  if (color) {
    // Convert hex to tailwind-compatible style
    return `border-l-4`;
  }
  // Fallback colors based on position
  const colors = [
    "bg-blue-500/10 border-blue-500/20",
    "bg-green-500/10 border-green-500/20",
    "bg-yellow-500/10 border-yellow-500/20",
    "bg-purple-500/10 border-purple-500/20",
    "bg-emerald-500/10 border-emerald-500/20",
    "bg-red-500/10 border-red-500/20",
    "bg-orange-500/10 border-orange-500/20",
  ];
  return colors[index % colors.length];
}

function LeadCard({ 
  lead, 
  isAgent, 
  onCall,
  onEmail,
  onAddBank,
  onAddNote,
  onCreateAccount,
}: { 
  lead: Lead; 
  isAgent: boolean; 
  onCall?: (lead: Lead) => void;
  onEmail?: (lead: Lead) => void;
  onAddBank?: (lead: Lead) => void;
  onAddNote?: (lead: Lead) => void;
  onCreateAccount?: (lead: Lead) => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: lead.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={cn(
        "p-4 cursor-move hover:shadow-md transition-all duration-200 border-border bg-card group",
        isDragging && "opacity-50 ring-2 ring-primary"
      )}
    >
      <div className="space-y-3">
        {/* Drag Handle */}
        <div className="flex items-center justify-center -mt-2 -mx-2 mb-1">
          <GripVertical className="h-4 w-4 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors" />
        </div>
        
        {/* Header */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <Link 
              to={leadHref(lead.id)}
              className="font-semibold text-sm truncate block hover:text-primary transition-colors"
              onClick={(e) => e.stopPropagation()}
              onMouseDown={(e) => e.stopPropagation()}
            >
              {lead.name}
            </Link>
            {lead.company && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                <Building2 className="h-3 w-3" />
                {lead.company}
              </p>
            )}
          </div>
          <LeadStatusBadge status={lead.status} />
        </div>

        {/* Contact Info */}
        <div className="space-y-1.5 text-xs">
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigator.clipboard.writeText(lead.email);
              toast.success("Email copied to clipboard");
            }}
            className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors w-full"
          >
            <Mail className="h-3 w-3 flex-shrink-0" />
            <span className="truncate">{lead.email}</span>
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 border-t border-border pt-2" onClick={(e) => e.stopPropagation()}>
          {onCall && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onCall(lead);
              }}
            >
              <PhoneCall className="h-3 w-3 mr-1" />
              Call
            </Button>
          )}
          {onEmail && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onEmail(lead);
              }}
            >
              <Send className="h-3 w-3 mr-1" />
              Email
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              {onAddBank && (
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  onAddBank(lead);
                }}>
                  <Landmark className="h-3 w-3 mr-2" />
                  Add Bank
                </DropdownMenuItem>
              )}
              {onAddNote && (
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  onAddNote(lead);
                }}>
                  <StickyNote className="h-3 w-3 mr-2" />
                  Add Note
                </DropdownMenuItem>
              )}
              {onCreateAccount && (
                <DropdownMenuItem onClick={(e) => {
                  e.stopPropagation();
                  onCreateAccount(lead);
                }}>
                  <User className="h-3 w-3 mr-2" />
                  Create Account
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </Card>
  );
}

function BoardColumn({ 
  status, 
  label, 
  color, 
  leads, 
  isAgent,
  onCall,
  onEmail,
  onAddBank,
  onAddNote,
  onCreateAccount,
  statusColor,
}: { 
  status: LeadStatus; 
  label: string; 
  color: string; 
  leads: Lead[];
  isAgent: boolean;
  onCall?: (lead: Lead) => void;
  onEmail?: (lead: Lead) => void;
  onAddBank?: (lead: Lead) => void;
  onAddNote?: (lead: Lead) => void;
  onCreateAccount?: (lead: Lead) => void;
  statusColor?: string | null;
}) {
  return (
    <div className="flex flex-col flex-1">
      <div 
        className={cn("rounded-lg border p-3 mb-3", color)}
        style={statusColor ? { borderLeftColor: statusColor, borderLeftWidth: '4px' } : undefined}
      >
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm text-foreground">{label}</h3>
          <Badge variant="secondary" className="text-xs">
            {leads.length}
          </Badge>
        </div>
      </div>

      <SortableContext items={leads.map(l => l.id)} strategy={verticalListSortingStrategy}>
        <div className="flex-1 space-y-3 min-h-[200px]">
          {leads.map((lead) => (
            <LeadCard
              key={lead.id}
              lead={lead}
              isAgent={isAgent}
              onCall={onCall}
              onEmail={onEmail}
              onAddBank={onAddBank}
              onAddNote={onAddNote}
              onCreateAccount={onCreateAccount}
            />
          ))}
          {leads.length === 0 && (
            <div className="flex items-center justify-center h-32 border-2 border-dashed border-border rounded-lg">
              <p className="text-sm text-muted-foreground">No leads</p>
            </div>
          )}
        </div>
      </SortableContext>
    </div>
  );
}

export function LeadsBoardView({ 
  leads, 
  onStatusChange, 
  isAgent, 
  onReorder,
  onCall,
  onEmail,
  onAddBank,
  onAddNote,
  onCreateAccount,
}: LeadsBoardViewProps) {
  const [activeId, setActiveId] = useState<string | null>(null);
  
  // Fetch dynamic statuses from database
  const { data: statuses = [] } = useActiveLeadStatuses();
  
  // Build STATUS_COLUMNS dynamically from database
  const STATUS_COLUMNS = useMemo(() => {
    return statuses.map((s, index) => ({
      status: s.name,
      label: s.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      color: getColumnColor(s.color, index),
      statusColor: s.color,
    }));
  }, [statuses]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const leadsByStatus = useMemo(() => {
    // Create dynamic grouping based on database statuses
    const grouped: Record<string, Lead[]> = {};
    
    // Initialize all status buckets
    statuses.forEach(s => {
      grouped[s.name] = [];
    });

    leads.forEach((lead) => {
      // Only add leads with known statuses
      if (grouped[lead.status] !== undefined) {
        grouped[lead.status].push(lead);
      }
    });

    // Sort by position within each status
    Object.keys(grouped).forEach((status) => {
      grouped[status].sort((a, b) => {
        const posA = (a as any).position ?? 0;
        const posB = (b as any).position ?? 0;
        return posA - posB;
      });
    });

    return grouped;
  }, [leads, statuses]);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over) {
      setActiveId(null);
      return;
    }

    const activeIdValue = active.id as string;
    const overId = over.id as string;

    // Find the lead being dragged
    const activeLead = leads.find((l) => l.id === activeIdValue);
    if (!activeLead) {
      setActiveId(null);
      return;
    }

    // Determine the target status
    let targetStatus: LeadStatus | null = null;
    let overLead: Lead | null = null;

    // Check if dropped on a column (status)
    if (STATUS_COLUMNS.some((col) => col.status === overId)) {
      targetStatus = overId as LeadStatus;
    } else {
      // Dropped on another lead, find which column it belongs to
      overLead = leads.find((l) => l.id === overId);
      if (overLead) {
        targetStatus = overLead.status;
      }
    }

    if (!targetStatus) {
      setActiveId(null);
      return;
    }

    // Case 1: Moving to a different column (status change)
    if (activeLead.status !== targetStatus) {
      onStatusChange(activeIdValue, targetStatus);
    } 
    // Case 2: Reordering within the same column
    else if (overLead && activeLead.status === targetStatus && onReorder) {
      const columnLeads = leadsByStatus[targetStatus] || [];
      const oldIndex = columnLeads.findIndex((l) => l.id === activeIdValue);
      const newIndex = columnLeads.findIndex((l) => l.id === overId);

      if (oldIndex !== newIndex) {
        // Calculate new position
        const reorderedLeads = arrayMove(columnLeads, oldIndex, newIndex);
        
        // Update positions for all affected leads in the column
        reorderedLeads.forEach((lead, index) => {
          if (lead.id === activeIdValue) {
            onReorder(activeIdValue, index, targetStatus);
          }
        });
      }
    }

    setActiveId(null);
  };

  const handleDragCancel = () => {
    setActiveId(null);
  };

  const activeLead = activeId ? leads.find((l) => l.id === activeId) : null;

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <div className="flex gap-4 pb-4">
        {STATUS_COLUMNS.map((column) => (
            <BoardColumn
              key={column.status}
              status={column.status}
              label={column.label}
              color={column.color}
              statusColor={column.statusColor}
              leads={leadsByStatus[column.status] || []}
              isAgent={isAgent}
              onCall={onCall}
              onEmail={onEmail}
              onAddBank={onAddBank}
              onAddNote={onAddNote}
              onCreateAccount={onCreateAccount}
            />
        ))}
      </div>

      <DragOverlay>
        {activeLead ? (
          <Card className="p-4 cursor-move shadow-lg rotate-3 opacity-90 border-border bg-card">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm truncate">{activeLead.name}</h3>
                  {activeLead.company && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Building2 className="h-3 w-3" />
                      {activeLead.company}
                    </p>
                  )}
                </div>
                <LeadStatusBadge status={activeLead.status} />
              </div>
              <div className="text-xs">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Mail className="h-3 w-3" />
                  <span className="truncate">{activeLead.email}</span>
                </div>
              </div>
            </div>
          </Card>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
