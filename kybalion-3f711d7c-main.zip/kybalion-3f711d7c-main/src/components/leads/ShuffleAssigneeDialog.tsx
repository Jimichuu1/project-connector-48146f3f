import { useState, useMemo, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Shuffle, Users, Loader2 } from "lucide-react";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

interface ShuffleAssigneeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  leadIds: string[];
  mode: "bulk" | "group";
  groupId?: string;
  onComplete?: () => void;
}

export function ShuffleAssigneeDialog({
  open,
  onOpenChange,
  leadIds,
  mode,
  groupId,
  onComplete,
}: ShuffleAssigneeDialogProps) {
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [isShuffling, setIsShuffling] = useState(false);
  const queryClient = useQueryClient();

  const { data: agents = [], isLoading: agentsLoading } = useAgentsCache();

  // Calculate distribution
  const distribution = useMemo(() => {
    const leadCount = leadIds.length;
    const memberCount = selectedMembers.length;
    
    if (memberCount === 0) {
      return { perMember: {}, leadCount, memberCount: 0 };
    }

    const base = Math.floor(leadCount / memberCount);
    const remainder = leadCount % memberCount;

    const perMember: Record<string, number> = {};
    selectedMembers.forEach((memberId, index) => {
      perMember[memberId] = index < remainder ? base + 1 : base;
    });

    return { perMember, leadCount, memberCount };
  }, [leadIds.length, selectedMembers]);

  const handleMemberToggle = useCallback((memberId: string, checked: boolean) => {
    setSelectedMembers((prev) =>
      checked ? [...prev, memberId] : prev.filter((id) => id !== memberId)
    );
  }, []);

  const handleSelectAll = useCallback(() => {
    if (selectedMembers.length === agents.length) {
      setSelectedMembers([]);
    } else {
      setSelectedMembers(agents.map((a) => a.id));
    }
  }, [agents, selectedMembers.length]);

  const handleShuffle = async () => {
    if (selectedMembers.length === 0) {
      toast.error("Please select at least one team member");
      return;
    }

    if (leadIds.length === 0) {
      toast.error("No leads to shuffle");
      return;
    }

    setIsShuffling(true);

    try {
      // Shuffle leads array randomly
      const shuffledLeads = [...leadIds].sort(() => Math.random() - 0.5);

      // Create assignments using round-robin
      const updates = shuffledLeads.map((leadId, index) => ({
        id: leadId,
        assigned_to: selectedMembers[index % selectedMembers.length],
      }));

      // Batch update in chunks of 50
      const chunkSize = 50;
      for (let i = 0; i < updates.length; i += chunkSize) {
        const chunk = updates.slice(i, i + chunkSize);
        
        // Use Promise.all for parallel updates within chunk
        await Promise.all(
          chunk.map((update) =>
            supabase
              .from("leads")
              .update({ assigned_to: update.assigned_to, updated_at: new Date().toISOString() })
              .eq("id", update.id)
          )
        );
      }

      // Invalidate queries to refresh data
      await queryClient.invalidateQueries({ queryKey: ["leads"] });
      await queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });

      toast.success(`Successfully shuffled ${leadIds.length} leads to ${selectedMembers.length} team members`);
      
      onComplete?.();
      onOpenChange(false);
      setSelectedMembers([]);
    } catch (error) {
      console.error("Failed to shuffle leads:", error);
      toast.error("Failed to shuffle leads. Please try again.");
    } finally {
      setIsShuffling(false);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shuffle className="h-5 w-5" />
            Shuffle Leads to Team Members
          </DialogTitle>
          <DialogDescription>
            {mode === "bulk"
              ? `Distribute ${leadIds.length} selected leads evenly among your team members.`
              : `Distribute unassigned leads from this group to your team members.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Queue info */}
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
            <Users className="h-5 w-5 text-muted-foreground" />
            <span className="font-medium">Queue: {leadIds.length} leads</span>
          </div>

          {/* Team member selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Select team members:</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSelectAll}
                className="text-xs h-7"
              >
                {selectedMembers.length === agents.length ? "Deselect All" : "Select All"}
              </Button>
            </div>

            {agentsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : agents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No team members found
              </div>
            ) : (
              <div className="border rounded-lg divide-y max-h-64 overflow-y-auto">
                {agents.map((agent) => {
                  const isSelected = selectedMembers.includes(agent.id);
                  const leadsAssigned = distribution.perMember[agent.id] || 0;

                  return (
                    <div
                      key={agent.id}
                      className="flex items-center justify-between p-3 hover:bg-muted/50 cursor-pointer"
                      onClick={() => handleMemberToggle(agent.id, !isSelected)}
                    >
                      <div className="flex items-center gap-3">
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={(checked) =>
                            handleMemberToggle(agent.id, checked as boolean)
                          }
                          onClick={(e) => e.stopPropagation()}
                        />
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={agent.avatar || undefined} />
                          <AvatarFallback className="text-xs">
                            {getInitials(agent.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium">{agent.name}</span>
                          <span className="text-xs text-muted-foreground">{agent.email}</span>
                        </div>
                      </div>
                      {isSelected && (
                        <Badge variant="secondary" className="shrink-0">
                          → {leadsAssigned} leads
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Distribution Preview */}
          {selectedMembers.length > 0 && (
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg space-y-1">
              <div className="text-sm font-medium text-primary">Distribution Preview</div>
              <div className="text-sm text-muted-foreground">
                <div>• Total leads: {distribution.leadCount}</div>
                <div>• Selected members: {distribution.memberCount}</div>
                <div>
                  • Each receives:{" "}
                  {distribution.memberCount > 0
                    ? `~${Math.floor(distribution.leadCount / distribution.memberCount)} leads`
                    : "0 leads"}
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isShuffling}>
            Cancel
          </Button>
          <Button
            onClick={handleShuffle}
            disabled={selectedMembers.length === 0 || leadIds.length === 0 || isShuffling}
          >
            {isShuffling ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Shuffling...
              </>
            ) : (
              <>
                <Shuffle className="mr-2 h-4 w-4" />
                Shuffle
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
