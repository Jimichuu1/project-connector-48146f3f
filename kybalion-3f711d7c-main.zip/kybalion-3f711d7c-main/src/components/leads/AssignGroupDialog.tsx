import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useLeadGroups } from "@/hooks/useLeadGroups";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTenant } from "@/contexts/TenantContext";
import { useQueryClient } from "@tanstack/react-query";

interface AssignGroupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedLeadIds: string[];
  defaultMode?: "group" | "assign" | "move";
}

interface Agent {
  id: string;
  email: string;
  full_name: string | null;
}

export const AssignGroupDialog = ({ open, onOpenChange, selectedLeadIds, defaultMode = "group" }: AssignGroupDialogProps) => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [selectedGroupId, setSelectedGroupId] = useState<string>("");
  const [selectedAgentId, setSelectedAgentId] = useState<string>("");
  const [mode, setMode] = useState<"group" | "individual" | "move">(
    defaultMode === "assign" ? "individual" : defaultMode === "move" ? "move" : "group"
  );
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();

  // Update mode when defaultMode changes
  useEffect(() => {
    setMode(defaultMode === "assign" ? "individual" : defaultMode === "move" ? "move" : "group");
  }, [defaultMode]);

  const { groups, addLeadsToGroup, moveLeadsToGroup, assignGroupToAgent } = useLeadGroups();

  useEffect(() => {
    const fetchAgents = async () => {
      // Fetch all users (any role can be assigned) - filtered by tenant
      const { data: userRoles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("role", ["TENANT_OWNER", "MANAGER", "SUPER_AGENT", "AGENT"]);

      if (userRoles) {
        const agentIds = userRoles.map(ur => ur.user_id);
        
        // Build query with tenant filter
        let profilesQuery = supabase
          .from("profiles")
          .select("id, email, full_name, admin_id")
          .in("id", agentIds);
        
        // Apply tenant filter if we have a tenant context
        if (effectiveTenantId) {
          profilesQuery = profilesQuery.eq("admin_id", effectiveTenantId);
        }
        
        const { data: profiles } = await profilesQuery;

        if (profiles) {
          // Create a map of user roles for display
          const roleMap = new Map(userRoles.map(ur => [ur.user_id, ur.role]));
          const enrichedProfiles = profiles.map(p => ({
            ...p,
            full_name: `${p.full_name || p.email} (${roleMap.get(p.id)})`,
          }));
          setAgents(enrichedProfiles);
        }
      }
    };

    if (open) {
      fetchAgents();
    }
  }, [open, effectiveTenantId]);

  const handleAssign = async () => {
    if (mode === "group") {
      // Add leads to group
      if (!selectedGroupId) {
        toast.error("Please select a group");
        return;
      }

      await addLeadsToGroup.mutateAsync({
        groupId: selectedGroupId,
        leadIds: selectedLeadIds,
      });

      onOpenChange(false);
    } else if (mode === "move") {
      // Move leads to group (removes from other groups first)
      if (!selectedGroupId) {
        toast.error("Please select a group");
        return;
      }

      await moveLeadsToGroup.mutateAsync({
        groupId: selectedGroupId,
        leadIds: selectedLeadIds,
      });

      onOpenChange(false);
    } else {
      // Assign individual leads to agent (or unassign if "unassigned" selected)
      const assignValue = selectedAgentId === "unassigned" ? null : selectedAgentId;
      
      if (!selectedAgentId) {
        toast.error("Please select an agent or unassigned");
        return;
      }

      const { error } = await supabase
        .from("leads")
        .update({ assigned_to: assignValue })
        .in("id", selectedLeadIds);

      if (error) {
        toast.error("Failed to assign leads");
      } else {
        queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
        const actionText = selectedAgentId === "unassigned" ? "unassigned" : "assigned";
        toast.success(`${selectedLeadIds.length} leads ${actionText} successfully`);
        onOpenChange(false);
      }
    }
  };

  const handleAssignGroupToAgent = async () => {
    if (!selectedGroupId || !selectedAgentId) {
      toast.error("Please select both a group and an agent");
      return;
    }

    await assignGroupToAgent.mutateAsync({
      groupId: selectedGroupId,
      agentId: selectedAgentId,
    });

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {selectedLeadIds.length > 0 
              ? mode === "move" 
                ? `Move ${selectedLeadIds.length} Lead(s) to Group`
                : `Assign ${selectedLeadIds.length} Lead(s)`
              : "Assign Group to Agent"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {selectedLeadIds.length > 0 ? (
            <>
              {mode === "group" && (
                <div className="space-y-2">
                  <Label>Assignment Mode</Label>
                  <Select value={mode} onValueChange={(value: "group" | "individual" | "move") => setMode(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="group">Add to Group</SelectItem>
                      <SelectItem value="move">Move to Group</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              {(mode === "group" || mode === "move") ? (
                <div className="space-y-2">
                  <Label>{mode === "move" ? "Move to Group" : "Select Group"}</Label>
                  {mode === "move" && (
                    <p className="text-xs text-muted-foreground">
                      Leads will be removed from their current group(s) and added to the selected group.
                    </p>
                  )}
                  <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a group" />
                    </SelectTrigger>
                    <SelectContent>
                      {groups?.map((group) => (
                        <SelectItem key={group.id} value={group.id}>
                          {group.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label>Select Agent</Label>
                  <Select value={selectedAgentId} onValueChange={setSelectedAgentId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose an agent" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unassigned" className="text-muted-foreground">
                        Unassigned
                      </SelectItem>
                      {agents.map((agent) => (
                        <SelectItem key={agent.id} value={agent.id}>
                          {agent.full_name || agent.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </>
          ) : (
            <>
              <div className="space-y-2">
                <Label>Select Group</Label>
                <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a group" />
                  </SelectTrigger>
                  <SelectContent>
                    {groups?.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Select Agent</Label>
                <Select value={selectedAgentId} onValueChange={setSelectedAgentId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose an agent" />
                  </SelectTrigger>
                  <SelectContent>
                    {agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.full_name || agent.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              size="sm"
              onClick={selectedLeadIds.length > 0 ? handleAssign : handleAssignGroupToAgent}
              disabled={
                selectedLeadIds.length > 0
                  ? (mode === "group" || mode === "move") ? !selectedGroupId : !selectedAgentId
                  : !selectedGroupId || !selectedAgentId
              }
            >
              {mode === "move" ? "Move" : "Assign"}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
