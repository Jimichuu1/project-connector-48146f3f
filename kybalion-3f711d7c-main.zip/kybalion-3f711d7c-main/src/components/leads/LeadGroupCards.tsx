import { useLeadGroups } from "@/hooks/useLeadGroups";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, FolderOpen } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLeadsStats } from "@/hooks/useLeadsStats";

interface LeadGroupCardsProps {
  selectedGroup: string | null;
  onGroupSelect: (groupId: string | null, groupName: string | null) => void;
}

export const LeadGroupCards = ({ selectedGroup, onGroupSelect }: LeadGroupCardsProps) => {
  const { groups, isLoading: groupsLoading } = useLeadGroups();
  
  // Use centralized stats hook - no duplicate COUNT queries
  const { totalLeads, groupCounts, isLoading: statsLoading } = useLeadsStats();

  const isLoading = groupsLoading || statsLoading;

  if (isLoading) {
    return (
      <div className="flex gap-3 overflow-x-auto pb-4">
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-24 w-48 flex-shrink-0" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex gap-3 overflow-x-auto pb-4">
      {/* All Leads Card */}
      <Card
        className={cn(
          "p-4 flex-shrink-0 cursor-pointer transition-all hover:shadow-md",
          "min-w-[180px]",
          selectedGroup === null && "ring-2 ring-primary shadow-md"
        )}
        onClick={() => onGroupSelect(null, null)}
      >
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Users className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-muted-foreground">All Leads</p>
            <p className="text-2xl font-bold">{totalLeads}</p>
          </div>
        </div>
      </Card>

      {/* Group Cards */}
      {groups?.map(group => (
        <Card
          key={group.id}
          className={cn(
            "p-4 flex-shrink-0 cursor-pointer transition-all hover:shadow-md",
            "min-w-[180px]",
            selectedGroup === group.id && "ring-2 ring-primary shadow-md"
          )}
          onClick={() => onGroupSelect(group.id, group.name)}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-violet-500/10">
              <FolderOpen className="h-5 w-5 text-violet-500" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-muted-foreground truncate">
                {group.name}
              </p>
              <p className="text-2xl font-bold">
                {groupCounts[group.id] || 0}
              </p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};
