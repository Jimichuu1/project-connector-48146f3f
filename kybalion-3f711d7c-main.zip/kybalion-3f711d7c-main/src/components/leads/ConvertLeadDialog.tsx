import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

import { useKYC } from "@/hooks/useKYC";
import { Lead } from "@/types/leads";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuditLog } from "@/hooks/useAuditLog";
import { useAuth } from "@/contexts/AuthContext";
import { useAgentsCache } from "@/hooks/useAgentsCache";

interface ConvertLeadDialogProps {
  lead: Lead;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const roleBadgeVariant = (role: string) => {
  switch (role) {
    case "AGENT": return "success";
    case "SUPER_AGENT": return "default";
    case "TEAM_LEADER": return "secondary";
    default: return "outline";
  }
};

const roleLabel = (role: string) => {
  switch (role) {
    case "AGENT": return "Agent";
    case "SUPER_AGENT": return "Super Agent";
    case "TEAM_LEADER": return "Team Leader";
    default: return role;
  }
};

export const ConvertLeadDialog = ({ lead, open, onOpenChange }: ConvertLeadDialogProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { kycRecords } = useKYC(lead.id, 'lead');
  const { createKYCRecord } = useKYC();
  const { logAction } = useAuditLog();
  const { user } = useAuth();
  const { data: agentsData } = useAgentsCache();
  
  // Filter out current user from agents list
  const availableAgents = (agentsData || []).filter(a => a.id !== user?.id);
  
  const [bankName, setBankName] = useState("");
  const [kycNotes, setKycNotes] = useState("");
  const [balance, setBalance] = useState("");
  const [equity, setEquity] = useState("");
  const [closerAgentId, setCloserAgentId] = useState("");
  
  const [showSuccess, setShowSuccess] = useState(false);


  // Check if lead has KYC data
  const hasBankRecords = kycRecords?.some(record => record.bank_name) || false;
  const hasNoteRecords = kycRecords?.some(record => record.notes) || false;
  const existingBanks = kycRecords?.filter(r => r.bank_name).map(r => r.bank_name) || [];
  const existingNotes = kycRecords?.filter(r => r.notes).map(r => r.notes) || [];

  const isValid = 
    (hasBankRecords || bankName.trim()) &&
    (hasNoteRecords || kycNotes.trim()) &&
    balance.trim() && parseFloat(balance) > 0;

  const handleConvert = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // If KYC data is missing, create KYC records first
      if (!hasBankRecords && bankName.trim()) {
        await createKYCRecord.mutateAsync({
          entityId: lead.id,
          entityType: 'lead',
          bankName: bankName.trim(),
        });
        
        // Log bank added
        logAction({
          actionType: 'kyc_bank_added',
          entityType: 'lead',
          entityId: lead.id,
          details: {
            lead_name: lead.name,
            bank_name: bankName.trim(),
          },
          adminId: lead.admin_id,
        });
      }

      if (!hasNoteRecords && kycNotes.trim()) {
        await createKYCRecord.mutateAsync({
          entityId: lead.id,
          entityType: 'lead',
          notes: kycNotes.trim(),
        });
        
        // Log note added
        logAction({
          actionType: 'kyc_note_added',
          entityType: 'lead',
          entityId: lead.id,
          details: {
            lead_name: lead.name,
            note_preview: kycNotes.trim().substring(0, 100),
          },
          adminId: lead.admin_id,
        });
      }

      // Set lead as pending conversion and save balance/equity + closer agent
      const updateData: Record<string, any> = { 
        pending_conversion: true,
        balance: parseFloat(balance) || 0,
        equity: parseFloat(equity) || 0,
      };
      if (closerAgentId) {
        updateData.closer_agent_id = closerAgentId;
      }
      const { error } = await supabase
        .from('leads')
        .update(updateData)
        .eq('id', lead.id);

      if (error) throw error;

      // Log conversion request to audit_logs
      logAction({
        actionType: 'conversion_requested',
        entityType: 'lead',
        entityId: lead.id,
        details: {
          lead_name: lead.name,
          lead_email: lead.email,
          balance: parseFloat(balance) || 0,
          equity: parseFloat(equity) || 0,
        },
        adminId: lead.admin_id,
      });

      // Also log to lead_activities
      await supabase.from('lead_activities').insert({
        lead_id: lead.id,
        user_id: user.id,
        activity_type: 'conversion_requested',
        description: `Submitted for conversion with balance: $${balance}`,
      });

      setShowSuccess(true);
      setTimeout(() => {
        onOpenChange(false);
        navigate('/convert-queue');
        toast({
          title: "Lead sent to conversion queue",
          description: `${lead.name} is awaiting admin approval`,
        });
      }, 2000);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to submit for conversion",
        description: message,
        variant: "destructive",
      });
    }
  };

  if (showSuccess) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <CheckCircle2 className="h-16 w-16 text-success animate-in zoom-in" />
            <h3 className="text-xl font-semibold">Conversion Successful!</h3>
            <p className="text-sm text-muted-foreground text-center">
              {lead.name} has been sent to conversion queue.<br />
              Redirecting...
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit Lead for Conversion</DialogTitle>
          <DialogDescription>
            Lead will be sent to conversion queue for admin review and assignment.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Lead Summary */}
          <div className="bg-muted p-4 rounded-lg space-y-2">
            <h4 className="font-medium">Lead Summary</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Name:</span> {lead.name}
              </div>
              <div>
                <span className="text-muted-foreground">Email:</span> {lead.email}
              </div>
            </div>
          </div>


          {/* Trading Information */}
          <div className="space-y-4 border-t pt-4">
            <h4 className="font-medium">Trading Information</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="balance">
                  Initial Balance <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="balance"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={balance}
                  onChange={(e) => setBalance(e.target.value)}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Initial Balance is required for conversion
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="equity">
                  Initial Amt <span className="text-muted-foreground text-xs">(Optional)</span>
                </Label>
                <Input
                  id="equity"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={equity}
                  onChange={(e) => setEquity(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* KYC Information */}
          <div className="space-y-4 border-t pt-4">
            <h4 className="font-medium">KYC Information (Required)</h4>
            
            {/* Bank Names */}
            <div className="space-y-2">
              <Label>Bank Names</Label>
              {hasBankRecords ? (
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">
                    Existing banks for this lead:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {existingBanks.map((bank, index) => (
                      <div key={index} className="bg-primary/10 text-primary px-3 py-1 rounded-md text-sm">
                        {bank}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Input
                    id="bankName"
                    placeholder="Enter bank name *"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    At least one bank name is required for conversion
                  </p>
                </div>
              )}
            </div>

            {/* KYC Notes */}
            <div className="space-y-2">
              <Label>KYC Notes</Label>
              {hasNoteRecords ? (
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">
                    Existing notes for this lead:
                  </div>
                  <div className="space-y-2">
                    {existingNotes.map((note, index) => (
                      <div key={index} className="bg-muted p-3 rounded-md text-sm">
                        {note}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Input
                    id="kycNotes"
                    placeholder="Enter KYC notes *"
                    value={kycNotes}
                    onChange={(e) => setKycNotes(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    At least one KYC note is required for conversion
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Closer Agent (Optional) */}
          <div className="space-y-4 border-t pt-4">
            <h4 className="font-medium">Closer Agent <span className="text-muted-foreground text-xs font-normal">(Optional)</span></h4>
            <p className="text-xs text-muted-foreground">
              Select a closer agent if someone else closed this deal. Deposits will be attributed to the closer agent.
            </p>
            <Select value={closerAgentId} onValueChange={setCloserAgentId}>
              <SelectTrigger>
                <SelectValue placeholder="No closer agent (default)" />
              </SelectTrigger>
              <SelectContent className="bg-background">
                {availableAgents.map((agent) => (
                  <SelectItem key={agent.id} value={agent.id}>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-5 w-5">
                        <AvatarImage src={agent.avatar || undefined} />
                        <AvatarFallback className="text-xs">
                          {agent.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span>{agent.name}</span>
                      <Badge variant={roleBadgeVariant(agent.role) as any} className="text-[10px] px-1.5 py-0">
                        {roleLabel(agent.role)}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {closerAgentId && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setCloserAgentId("")}
                className="text-xs text-muted-foreground"
              >
                Clear selection
              </Button>
            )}
          </div>

        </div>

        <DialogFooter>
          <ButtonGroup>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleConvert}
              disabled={!isValid}
              className="bg-success hover:bg-success/90"
            >
              Submit for Conversion
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
