import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Lead } from "@/types/leads";
import { getAutoCountry } from "@/lib/phoneCountryCode";

const leadSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be less than 100 characters"),
  email: z.string().trim().email("Invalid email address").max(255, "Email must be less than 255 characters").optional().nullable().or(z.literal('')),
  phone: z.string().trim().min(1, "Phone is required").max(20, "Phone must be less than 20 characters"),
  country: z.string().trim().max(100, "Country must be less than 100 characters").optional().nullable(),
  balance: z.number().min(0, "Balance must be positive").optional().nullable(),
  equity: z.number().min(0, "Equity must be positive").optional().nullable(),
  best_contact_time: z.string().trim().max(100).optional().nullable(),
});

interface EditLeadDialogProps {
  lead: Lead;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function EditLeadDialog({ lead, open, onOpenChange }: EditLeadDialogProps) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: lead.name || "",
    email: lead.email || "",
    phone: lead.phone || "",
    country: lead.country || "",
    balance: lead.balance || 0,
    equity: lead.equity || 0,
    best_contact_time: lead.best_contact_time || "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Validate input
      const validatedData = leadSchema.parse({
        ...formData,
        phone: formData.phone || null,
        country: formData.country || null,
        balance: formData.balance || 0,
        equity: formData.equity || 0,
        best_contact_time: formData.best_contact_time || null,
      });

      const { error } = await supabase
        .from("leads")
        .update({
          name: validatedData.name,
          email: validatedData.email,
          phone: validatedData.phone,
          country: validatedData.country,
          balance: validatedData.balance,
          equity: validatedData.equity,
          best_contact_time: validatedData.best_contact_time,
        })
        .eq("id", lead.id);

      if (error) throw error;

      toast.success("Lead updated successfully");
      queryClient.invalidateQueries({ queryKey: ["leads-paginated"] });
      onOpenChange(false);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        console.error("Update error:", error);
        toast.error("Failed to update lead");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Lead</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                maxLength={100}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                maxLength={255}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => {
                  const phone = e.target.value;
                  // Auto-detect country from phone code if country is empty
                  const autoCountry = getAutoCountry(formData.country, phone);
                  setFormData({ ...formData, phone, country: autoCountry });
                }}
                required
                maxLength={20}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                value={formData.country}
                readOnly
                placeholder="Auto-detected from phone"
                className="bg-muted text-muted-foreground"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="balance">Initial Balance ($)</Label>
              <Input
                id="balance"
                type="number"
                step="0.01"
                min="0"
                value={formData.balance}
                onChange={(e) => setFormData({ ...formData, balance: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="equity">Initial Amount ($)</Label>
              <Input
                id="equity"
                type="number"
                step="0.01"
                min="0"
                value={formData.equity}
                onChange={(e) => setFormData({ ...formData, equity: parseFloat(e.target.value) || 0 })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="best_contact_time">Best Contact Time</Label>
            <Input
              id="best_contact_time"
              value={formData.best_contact_time}
              onChange={(e) => setFormData({ ...formData, best_contact_time: e.target.value })}
              placeholder="e.g., 2-4 PM EST"
              maxLength={100}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}