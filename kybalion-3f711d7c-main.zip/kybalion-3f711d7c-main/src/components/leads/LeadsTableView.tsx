import { Lead, LeadStatus } from "@/types/leads";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { User, Mail, Phone, Activity, UserCheck, Info, Layers, Calendar, Settings, AlertCircle, RefreshCw } from "lucide-react";
import { SortableTableHead, SortState, sortData } from "@/components/ui/sortable-table-head";
import { LeadStatusDropdown } from "@/components/leads/LeadStatusDropdown";
import { LeadAssignmentDropdown } from "@/components/leads/LeadAssignmentDropdown";
import { LeadKYCNotes } from "@/components/leads/LeadKYCNotes";
import { LeadGroupNameBatch } from "@/components/leads/LeadGroupNameBatch";
import { LeadRowActions } from "./LeadRowActions";
import { format } from "date-fns";
import { toast } from "sonner";
import { useMemo } from "react";
import { useLeadGroupMemberships } from "@/hooks/useLeadGroupMemberships";

interface LeadsTableViewProps {
  leads: Lead[] | undefined;
  isLoading: boolean;
  error: Error | null;
  selectedLeads: string[];
  onSelectAll: (checked: boolean) => void;
  onSelectLead: (leadId: string, checked: boolean) => void;
  sort: SortState;
  onSort: (key: string) => void;
  isAdmin: boolean;
  isManager: boolean;
  shouldShowEmail: boolean;
  shouldShowPhone: boolean;
  onNavigate: (leadId: string) => void;
  onStatusChange: (leadId: string, status: LeadStatus) => void;
  onAddBank: (lead: Lead) => void;
  onAddNote: (lead: Lead) => void;
  onCreateAccount: (lead: Lead) => void;
  onConvert: (lead: Lead) => void;
  canConvert?: boolean;
}

export function LeadsTableView({
  leads,
  isLoading,
  error,
  selectedLeads,
  onSelectAll,
  onSelectLead,
  sort,
  onSort,
  isAdmin,
  isManager,
  shouldShowEmail,
  shouldShowPhone,
  onNavigate,
  onStatusChange,
  onAddBank,
  onAddNote,
  onCreateAccount,
  onConvert,
  canConvert = true,
}: LeadsTableViewProps) {
  // Get all lead IDs for batch group name fetching
  const leadIds = useMemo(() => (leads || []).map(l => l.id), [leads]);
  const { data: groupMemberships } = useLeadGroupMemberships(leadIds);

  const sortedLeads = useMemo(() => {
    return sortData(leads || [], sort.key, sort.direction);
  }, [leads, sort.key, sort.direction]);

  const handleCopyEmail = (email: string) => {
    navigator.clipboard.writeText(email);
    toast.success("Email copied to clipboard");
  };

  const handleCopyPhone = (phone: string | null | undefined) => {
    if (!phone) return;
    const formattedPhone = phone.replace(/[^\d+]/g, "");
    navigator.clipboard.writeText(formattedPhone);
    toast.success("Phone number copied to clipboard");
  };

  return (
    <Table className="text-xs">
      <TableHeader>
        <TableRow className="border-b border-border hover:bg-transparent">
          <TableHead className="w-10 py-2 px-2">
            <Checkbox
              checked={leads && leads.length > 0 && selectedLeads.length === leads.length}
              onCheckedChange={onSelectAll}
              className="h-3.5 w-3.5"
            />
          </TableHead>
          <SortableTableHead
            sortKey="name"
            currentSort={sort}
            onSort={onSort}
            icon={<User className="h-3 w-3 text-muted-foreground" />}
            className="py-2 px-2"
          >
            Name
          </SortableTableHead>
          <SortableTableHead
            sortKey="email"
            currentSort={sort}
            onSort={onSort}
            icon={<Mail className="h-3 w-3 text-muted-foreground" />}
            className="py-2 px-2"
          >
            Email
          </SortableTableHead>
          <SortableTableHead
            sortKey="phone"
            currentSort={sort}
            onSort={onSort}
            icon={<Phone className="h-3 w-3 text-muted-foreground" />}
            className="py-2 px-2"
          >
            Phone
          </SortableTableHead>
          <SortableTableHead
            sortKey="status"
            currentSort={sort}
            onSort={onSort}
            icon={<Activity className="h-3 w-3 text-muted-foreground" />}
            className="py-2 px-2"
          >
            Status
          </SortableTableHead>
          {(isAdmin || isManager) && (
            <TableHead className="py-2 px-2">
              <div className="flex items-center gap-1.5">
                <UserCheck className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Assigned To</span>
              </div>
            </TableHead>
          )}
          <TableHead className="py-2 px-2">
            <div className="flex items-center gap-1.5">
              <Info className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Info</span>
            </div>
          </TableHead>
          <TableHead className="py-2 px-2">
            <div className="flex items-center gap-1.5">
              <Layers className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Group</span>
            </div>
          </TableHead>
          <SortableTableHead
            sortKey="created_at"
            currentSort={sort}
            onSort={onSort}
            icon={<Calendar className="h-3 w-3 text-muted-foreground" />}
            className="py-2 px-2"
          >
            Created
          </SortableTableHead>
          <TableHead
            className="sticky right-0 w-[80px] shadow-[-4px_0_8px_rgba(0,0,0,0.1)] py-2 px-2"
            style={{ backgroundColor: "#191919" }}
          >
            <div className="flex items-center gap-1.5">
              <Settings className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Actions</span>
            </div>
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {isLoading ? (
          Array.from({ length: 10 }).map((_, index) => (
            <TableRow key={index}>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-3.5" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-28" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-36" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-24" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
              {(isAdmin || isManager) && <TableCell className="py-1.5 px-2"><Skeleton className="h-4 w-16" /></TableCell>}
              <TableCell className="py-1.5 px-2"><Skeleton className="h-6 w-6" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-14" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-3.5 w-20" /></TableCell>
              <TableCell className="py-1.5 px-2"><Skeleton className="h-6 w-24" /></TableCell>
            </TableRow>
          ))
        ) : error ? (
          <TableRow>
            <TableCell colSpan={10} className="py-8">
              <Alert variant="destructive" className="max-w-lg mx-auto">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="flex items-center justify-between">
                  <span>Failed to load leads. {error.message}</span>
                  <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                    <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
                    Retry
                  </Button>
                </AlertDescription>
              </Alert>
            </TableCell>
          </TableRow>
        ) : !leads || leads.length === 0 ? (
          <TableRow>
            <TableCell colSpan={10} className="h-20 text-center text-muted-foreground">
              No leads found.
            </TableCell>
          </TableRow>
        ) : (
          sortedLeads.map((lead) => (
            <TableRow
              key={lead.id}
              className="border-b border-border hover:bg-muted/50 cursor-pointer"
              onClick={() => onNavigate(lead.id)}
            >
              <TableCell onClick={(e) => e.stopPropagation()} className="py-1.5 px-2">
                <Checkbox
                  checked={selectedLeads.includes(lead.id)}
                  onCheckedChange={(checked) => onSelectLead(lead.id, checked === true)}
                  className="h-3.5 w-3.5"
                />
              </TableCell>
              <TableCell className="font-medium py-1.5 px-2">
                <div>
                  <div className="font-semibold text-xs">{lead.name}</div>
                  {lead.company && <div className="text-[10px] text-muted-foreground">{lead.company}</div>}
                </div>
              </TableCell>
              <TableCell onClick={(e) => e.stopPropagation()} className="py-1.5 px-2">
                {shouldShowEmail ? (
                  <button
                    onClick={() => handleCopyEmail(lead.email)}
                    className="text-xs hover:text-primary transition-colors cursor-pointer"
                  >
                    {lead.email}
                  </button>
                ) : (
                  <span className="text-xs text-muted-foreground">••••••••</span>
                )}
              </TableCell>
              <TableCell onClick={(e) => e.stopPropagation()} className="py-1.5 px-2">
                {shouldShowPhone ? (
                  lead.phone ? (
                    <button
                      onClick={() => handleCopyPhone(lead.phone)}
                      className="text-xs hover:text-primary transition-colors cursor-pointer"
                    >
                      {lead.phone?.replace(/[^\d+]/g, "")}
                    </button>
                  ) : (
                    <span className="text-xs text-muted-foreground">-</span>
                  )
                ) : (
                  <span className="text-xs text-muted-foreground">••••••••</span>
                )}
              </TableCell>
              <TableCell onClick={(e) => e.stopPropagation()} className="py-1.5 px-2">
                <LeadStatusDropdown
                  status={lead.status}
                  onStatusChange={(newStatus) => onStatusChange(lead.id, newStatus)}
                />
              </TableCell>
              {(isAdmin || isManager) && (
                <TableCell onClick={(e) => e.stopPropagation()} className="py-1.5 px-2">
                  <LeadAssignmentDropdown leadId={lead.id} currentAssignedTo={lead.assigned_to || null} />
                </TableCell>
              )}
              <TableCell onClick={(e) => e.stopPropagation()} className="py-1.5 px-2">
                <LeadKYCNotes leadId={lead.id} />
              </TableCell>
              <TableCell className="py-1.5 px-2">
                <LeadGroupNameBatch groupName={groupMemberships?.get(lead.id)} />
              </TableCell>
              <TableCell className="text-xs text-muted-foreground py-1.5 px-2">
                {format(new Date(lead.created_at), "MMM d, yyyy")}
              </TableCell>
              <TableCell
                onClick={(e) => e.stopPropagation()}
                className="py-1.5 px-2 sticky right-0 bg-background w-[80px]"
              >
                <LeadRowActions
                  lead={lead}
                  canConvert={canConvert}
                  onAddBank={onAddBank}
                  onAddNote={onAddNote}
                  onCreateAccount={onCreateAccount}
                  onConvert={onConvert}
                />
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
}
