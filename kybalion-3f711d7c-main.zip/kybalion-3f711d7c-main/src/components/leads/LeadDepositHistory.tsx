import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, DollarSign } from "lucide-react";
import { format } from "date-fns";

interface LeadDepositHistoryProps {
  leadId: string;
}

export const LeadDepositHistory = ({ leadId }: LeadDepositHistoryProps) => {
  const { data: deposits, isLoading, error } = useQuery({
    queryKey: ['lead-deposits', leadId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('deposits')
        .select(`
          *,
          agent:profiles!deposits_agent_id_fkey(full_name, email),
          super_agent:profiles!deposits_super_agent_id_fkey(full_name, email)
        `)
        .eq('lead_id', leadId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load deposit history. Please try again.
        </AlertDescription>
      </Alert>
    );
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!deposits || deposits.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Deposit History
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center text-muted-foreground py-8">
          No deposits recorded yet
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Deposit History
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {deposits.map((deposit) => (
          <div
            key={deposit.id}
            className="border rounded-lg p-4 space-y-2"
          >
            <div className="flex items-center justify-between">
              <div className="text-lg font-semibold">
                ${Number(deposit.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="text-sm text-muted-foreground">
                {format(new Date(deposit.created_at), 'MMM d, yyyy h:mm a')}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground mb-1">Agent</p>
                <p className="font-medium">
                  {deposit.agent?.full_name || deposit.agent?.email || 'N/A'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {deposit.agent_percentage}% - ${Number(deposit.agent_amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
              
              <div>
                <p className="text-muted-foreground mb-1">Super Agent</p>
                <p className="font-medium">
                  {deposit.super_agent?.full_name || deposit.super_agent?.email || 'N/A'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {deposit.super_agent_percentage}% - ${Number(deposit.super_agent_amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};
