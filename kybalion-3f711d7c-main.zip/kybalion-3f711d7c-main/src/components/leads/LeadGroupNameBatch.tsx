import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface LeadGroupNameBatchProps {
  groupName: string[] | undefined;
}

export const LeadGroupNameBatch = ({ groupName }: LeadGroupNameBatchProps) => {
  if (!groupName || groupName.length === 0) {
    return <span className="text-xs text-muted-foreground">-</span>;
  }

  // Show first group, and if more exist show +N indicator
  const [firstGroup, ...rest] = groupName;
  
  if (rest.length === 0) {
    return (
      <Badge variant="outline" className="text-xs whitespace-nowrap">
        {firstGroup}
      </Badge>
    );
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center gap-1 flex-nowrap">
            <Badge variant="outline" className="text-xs whitespace-nowrap">
              {firstGroup}
            </Badge>
            <Badge variant="secondary" className="text-xs whitespace-nowrap">
              +{rest.length}
            </Badge>
          </div>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <div className="flex flex-col gap-1">
            {groupName.map((name, index) => (
              <span key={index} className="text-xs">{name}</span>
            ))}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
