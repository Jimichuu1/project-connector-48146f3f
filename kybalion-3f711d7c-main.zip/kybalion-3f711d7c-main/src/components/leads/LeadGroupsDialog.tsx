import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Users, Trash2, Plus } from "lucide-react";
import { useLeadGroups } from "@/hooks/useLeadGroups";
import { DeleteGroupDialog } from "./DeleteGroupDialog";

interface LeadGroupsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const LeadGroupsDialog = ({ open, onOpenChange }: LeadGroupsDialogProps) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [groupToDelete, setGroupToDelete] = useState<{ id: string; name: string } | null>(null);

  const { groups, isLoading, createGroup, deleteGroup } = useLeadGroups();

  const handleCreate = async () => {
    if (!name.trim()) return;

    await createGroup.mutateAsync({
      name: name.trim(),
      description: description.trim() || undefined,
    });

    setName("");
    setDescription("");
    setShowCreateForm(false);
  };

  const handleDeleteClick = (group: { id: string; name: string }) => {
    setGroupToDelete(group);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async (deleteLeads: boolean) => {
    if (!groupToDelete) return;
    await deleteGroup.mutateAsync({ groupId: groupToDelete.id, deleteLeads });
    setDeleteDialogOpen(false);
    setGroupToDelete(null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Lead Groups</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {showCreateForm ? (
            <Card className="p-4 space-y-4">
              <div className="space-y-2">
                <Label>Group Name</Label>
                <Input
                  placeholder="Enter group name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Description (Optional)</Label>
                <Textarea
                  placeholder="Enter group description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                />
              </div>
              <ButtonGroup>
                <Button size="sm" onClick={handleCreate} disabled={!name.trim() || createGroup.isPending}>
                  {createGroup.isPending ? "Creating..." : "Create Group"}
                </Button>
                <Button size="sm" variant="outline" onClick={() => setShowCreateForm(false)}>
                  Cancel
                </Button>
              </ButtonGroup>
            </Card>
          ) : (
            <Button size="sm" onClick={() => setShowCreateForm(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create New Group
            </Button>
          )}

          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            </div>
          ) : groups && groups.length > 0 ? (
            <div className="space-y-2">
              {groups.map((group) => (
                <Card key={group.id} className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-primary" />
                        <h4 className="font-semibold">{group.name}</h4>
                      </div>
                      {group.description && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {group.description}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        Created: {new Date(group.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteClick({ id: group.id, name: group.name })}
                      disabled={deleteGroup.isPending}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No lead groups created yet
            </div>
          )}
        </div>

        <DialogFooter>
          <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>

      {groupToDelete && (
        <DeleteGroupDialog
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          groupName={groupToDelete.name}
          memberCount={0}
          onConfirm={handleDeleteConfirm}
          isPending={deleteGroup.isPending}
        />
      )}
    </Dialog>
  );
};
