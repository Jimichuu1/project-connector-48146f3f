import { Lead } from "@/types/leads";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Landmark, StickyNote, User, Send } from "lucide-react";

interface LeadRowActionsProps {
  lead: Lead;
  canConvert?: boolean;
  onAddBank: (lead: Lead) => void;
  onAddNote: (lead: Lead) => void;
  onCreateAccount: (lead: Lead) => void;
  onConvert: (lead: Lead) => void;
}

export function LeadRowActions({
  lead,
  canConvert = true,
  onAddBank,
  onAddNote,
  onCreateAccount,
  onConvert,
}: LeadRowActionsProps) {
  return (
    <TooltipProvider>
      <div className="flex items-center gap-0.5">
        <DropdownMenu>
          <Tooltip>
            <TooltipTrigger asChild>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" className="h-7 w-7 p-0 [&_svg]:size-3.5">
                  <Plus />
                </Button>
              </DropdownMenuTrigger>
            </TooltipTrigger>
            <TooltipContent>Add KYC</TooltipContent>
          </Tooltip>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onAddBank(lead)} className="text-sm">
              <Landmark className="h-3.5 w-3.5 mr-2" />
              Add Bank
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAddNote(lead)} className="text-sm">
              <StickyNote className="h-3.5 w-3.5 mr-2" />
              Add Note
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCreateAccount(lead)} className="text-sm">
              <User className="h-3.5 w-3.5 mr-2" />
              Create Account
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {canConvert && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="default" className="h-7 w-7 p-0 [&_svg]:size-3.5" onClick={() => onConvert(lead)}>
                <Send className="rotate-45" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Convert</TooltipContent>
          </Tooltip>
        )}
      </div>
    </TooltipProvider>
  );
}
