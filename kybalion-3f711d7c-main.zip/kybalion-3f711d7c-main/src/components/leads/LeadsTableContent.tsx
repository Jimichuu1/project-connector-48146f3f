import { useMemo } from "react";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Landmark, StickyNote, User, Phone, Mail, Send, AlertCircle, RefreshCw, UserCheck, Info, Layers, Calendar, Settings, Building2, Activity, Globe } from "lucide-react";
import { TenantDisplay } from "@/components/ui/tenant-display";
import { leadHref } from "@/lib/idCipher";
import { LeadStatusDropdown } from "@/components/leads/LeadStatusDropdown";
import { LeadAssignmentDropdown } from "@/components/leads/LeadAssignmentDropdown";
import { LeadKYCNotes } from "@/components/leads/LeadKYCNotes";
import { LeadGroupNameBatch } from "@/components/leads/LeadGroupNameBatch";
import { SortableTableHead, sortData, SortState } from "@/components/ui/sortable-table-head";
import { Lead } from "@/types/leads";
import { getCountryCode } from "@/lib/phoneCountryCode";
import { toast } from "sonner";
import { useLeadGroupMemberships } from "@/hooks/useLeadGroupMemberships";

interface LeadsTableContentProps {
  leads: Lead[] | undefined;
  isLoading: boolean;
  error: Error | null;
  sort: SortState;
  onSort: (key: string) => void;
  selectedLeads: string[];
  onSelectAll: (checked: boolean) => void;
  onSelectLead: (leadId: string, checked: boolean) => void;
  shouldShowEmail: boolean;
  shouldShowPhone: boolean;
  isSuperAdmin: boolean;
  isTenantOwner: boolean;
  isManager: boolean;
  onAddBank: (lead: Lead) => void;
  onAddNote: (lead: Lead) => void;
  onCreateAccount: (lead: Lead) => void;
  onConvert: (lead: Lead) => void;
  canConvert?: boolean;
  onStatusChange: (leadId: string, status: string) => void;
}

export function LeadsTableContent({
  leads,
  isLoading,
  error,
  sort,
  onSort,
  selectedLeads,
  onSelectAll,
  onSelectLead,
  shouldShowEmail,
  shouldShowPhone,
  isSuperAdmin,
  isTenantOwner,
  isManager,
  onAddBank,
  onAddNote,
  onCreateAccount,
  onConvert,
  canConvert = true,
  onStatusChange,
}: LeadsTableContentProps) {
  // Memoize lead IDs for batch group name fetching
  const leadIds = useMemo(() => leads?.map(l => l.id) || [], [leads]);
  
  // Batch fetch all group names in one query instead of N+1 queries
  const { data: groupMemberships } = useLeadGroupMemberships(leadIds);

  const sortedLeads = useMemo(() => {
    return sortData(leads || [], sort.key, sort.direction);
  }, [leads, sort.key, sort.direction]);

  const showAssignedColumn = isSuperAdmin || isTenantOwner || isManager;

  return (
    <Table className="text-sm">
      <TableHeader>
        <TableRow className="border-b border-border hover:bg-transparent">
          <TableHead className="w-10 py-2">
            <Checkbox
              checked={leads && leads.length > 0 && selectedLeads.length === leads.length}
              onCheckedChange={onSelectAll}
            />
          </TableHead>
          {isSuperAdmin && (
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Building2 className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Tenant</span>
              </div>
            </TableHead>
          )}
          <SortableTableHead
            sortKey="name"
            currentSort={sort}
            onSort={onSort}
            icon={<User className="h-3 w-3 text-muted-foreground" />}
          >
            Name
          </SortableTableHead>
          {shouldShowEmail && (
            <SortableTableHead
              sortKey="email"
              currentSort={sort}
              onSort={onSort}
              icon={<Mail className="h-3 w-3 text-muted-foreground" />}
            >
              Email
            </SortableTableHead>
          )}
          {shouldShowPhone && (
            <SortableTableHead
              sortKey="phone"
              currentSort={sort}
              onSort={onSort}
              icon={<Phone className="h-3 w-3 text-muted-foreground" />}
            >
              Phone
            </SortableTableHead>
          )}
          <SortableTableHead
            sortKey="status"
            currentSort={sort}
            onSort={onSort}
            icon={<Activity className="h-3 w-3 text-muted-foreground" />}
          >
            Status
          </SortableTableHead>
          {showAssignedColumn && (
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <UserCheck className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Assigned To</span>
              </div>
            </TableHead>
          )}
          <TableHead className="py-2">
            <div className="flex items-center gap-1.5">
              <Info className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Info</span>
            </div>
          </TableHead>
          <SortableTableHead
            sortKey="country"
            currentSort={sort}
            onSort={onSort}
            icon={<Globe className="h-3 w-3 text-muted-foreground" />}
          >
            Country
          </SortableTableHead>
          <TableHead className="py-2">
            <div className="flex items-center gap-1.5">
              <Layers className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Group</span>
            </div>
          </TableHead>
          <SortableTableHead
            sortKey="created_at"
            currentSort={sort}
            onSort={onSort}
            icon={<Calendar className="h-3 w-3 text-muted-foreground" />}
          >
            Created
          </SortableTableHead>
          <TableHead
            className="sticky right-0 w-[90px] py-2 shadow-[-4px_0_8px_rgba(0,0,0,0.1)]"
            style={{ backgroundColor: '#191919' }}
          >
            <div className="flex items-center gap-1.5">
              <Settings className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Actions</span>
            </div>
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {isLoading ? (
          Array.from({ length: 10 }).map((_, index) => (
            <TableRow key={index}>
              <TableCell className="py-1.5"><Skeleton className="h-3 w-3" /></TableCell>
              {isSuperAdmin && <TableCell className="py-1.5"><Skeleton className="h-4 w-16" /></TableCell>}
              <TableCell className="py-1.5">
                <div className="space-y-1">
                  <Skeleton className="h-3 w-28" />
                  <Skeleton className="h-2 w-20" />
                </div>
              </TableCell>
              {shouldShowEmail && <TableCell className="py-1.5"><Skeleton className="h-3 w-32" /></TableCell>}
              {shouldShowPhone && <TableCell className="py-1.5"><Skeleton className="h-3 w-24" /></TableCell>}
              <TableCell className="py-1.5"><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
              {showAssignedColumn && <TableCell className="py-1.5"><Skeleton className="h-4 w-16" /></TableCell>}
              <TableCell className="py-1.5"><Skeleton className="h-6 w-6" /></TableCell>
              <TableCell className="py-1.5"><Skeleton className="h-3 w-14" /></TableCell>
              <TableCell className="py-1.5"><Skeleton className="h-3 w-20" /></TableCell>
              <TableCell className="py-1.5"><Skeleton className="h-6 w-24" /></TableCell>
            </TableRow>
          ))
        ) : error ? (
          <TableRow>
            <TableCell colSpan={10} className="py-12">
              <Alert variant="destructive" className="max-w-lg mx-auto">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="flex items-center justify-between">
                  <span>Failed to load leads. {error.message}</span>
                  <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Retry
                  </Button>
                </AlertDescription>
              </Alert>
            </TableCell>
          </TableRow>
        ) : !leads || leads.length === 0 ? (
          <TableRow>
            <TableCell colSpan={10} className="h-24 text-center text-muted-foreground">
              No leads found.
            </TableCell>
          </TableRow>
        ) : (
          sortedLeads.map((lead) => (
            <TableRow
              key={lead.id}
              className="border-b border-border hover:bg-muted/50"
            >
              <TableCell className="py-1.5">
                <Checkbox
                  checked={selectedLeads.includes(lead.id)}
                  onCheckedChange={(checked) => onSelectLead(lead.id, checked === true)}
                />
              </TableCell>
              {isSuperAdmin && (
                <TableCell className="py-1.5">
                  <TenantDisplay adminId={lead.admin_id} />
                </TableCell>
              )}
              <TableCell className="font-medium py-1.5 max-w-[160px]">
                <Link
                  to={leadHref(lead.id)}
                  className="truncate block font-semibold text-[14px] hover:text-primary transition-colors"
                  title={lead.name}
                >
                  {lead.name}
                </Link>
              </TableCell>
              {shouldShowEmail && (
                <TableCell className="py-1.5 max-w-[160px]">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(lead.email);
                      toast.success("Email copied to clipboard");
                    }}
                    className="truncate block w-full text-left hover:text-primary transition-colors cursor-pointer"
                    title={lead.email}
                  >
                    {lead.email}
                  </button>
                </TableCell>
              )}
              {shouldShowPhone && (
                <TableCell className="py-1.5">
                  {lead.phone ? (
                    <button
                      onClick={() => {
                        const formattedPhone = lead.phone?.replace(/[^\d+]/g, "") || "";
                        navigator.clipboard.writeText(formattedPhone);
                        toast.success("Phone number copied to clipboard");
                      }}
                      className="hover:text-primary transition-colors cursor-pointer"
                    >
                      {lead.phone?.replace(/[^\d+]/g, "")}
                    </button>
                  ) : (
                    <span className="text-muted-foreground">-</span>
                  )}
                </TableCell>
              )}
              <TableCell className="py-1.5">
                <LeadStatusDropdown
                  status={lead.status}
                  onStatusChange={(newStatus) => onStatusChange(lead.id, newStatus)}
                />
              </TableCell>
              {showAssignedColumn && (
                <TableCell className="py-1.5">
                  <LeadAssignmentDropdown leadId={lead.id} currentAssignedTo={lead.assigned_to || null} />
                </TableCell>
              )}
              <TableCell className="py-1.5">
                <LeadKYCNotes leadId={lead.id} />
              </TableCell>
              <TableCell className="py-1.5">
                {lead.country ? getCountryCode(lead.country) : <span className="text-muted-foreground">-</span>}
              </TableCell>
              <TableCell className="py-1.5">
                <LeadGroupNameBatch groupName={groupMemberships?.get(lead.id)} />
              </TableCell>
              <TableCell className="text-muted-foreground py-1.5">
                {format(new Date(lead.created_at), 'MMM d, yyyy')}
              </TableCell>
              <TableCell
                className="py-1.5 sticky right-0 bg-background w-[90px]"
              >
                <TooltipProvider>
                  <div className="flex items-center gap-0.5">
                    <DropdownMenu>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <DropdownMenuTrigger asChild>
                            <Button variant="secondary" className="h-7 w-7 p-0 [&_svg]:size-3.5">
                              <Plus />
                            </Button>
                          </DropdownMenuTrigger>
                        </TooltipTrigger>
                        <TooltipContent>Add KYC</TooltipContent>
                      </Tooltip>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onAddBank(lead)} className="text-sm">
                          <Landmark className="h-3.5 w-3.5 mr-2" />
                          Add Bank
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onAddNote(lead)} className="text-sm">
                          <StickyNote className="h-3.5 w-3.5 mr-2" />
                          Add Note
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onCreateAccount(lead)} className="text-sm">
                          <User className="h-3.5 w-3.5 mr-2" />
                          Create Account
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>

                    {canConvert && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="default" className="h-7 w-7 p-0 [&_svg]:size-3.5" onClick={() => onConvert(lead)}>
                            <Send className="rotate-45" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Convert</TooltipContent>
                      </Tooltip>
                    )}
                  </div>
                </TooltipProvider>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
}
