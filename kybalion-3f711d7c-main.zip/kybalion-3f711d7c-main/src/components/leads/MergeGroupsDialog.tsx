import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Merge } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface MergeGroup {
  id: string;
  name: string;
  memberCount: number;
}

interface MergeGroupsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedGroups: MergeGroup[];
  onConfirm: (newName: string) => Promise<void>;
  isPending: boolean;
}

export const MergeGroupsDialog = ({
  open,
  onOpenChange,
  selectedGroups,
  onConfirm,
  isPending,
}: MergeGroupsDialogProps) => {
  const [newName, setNewName] = useState("");

  const totalLeads = selectedGroups.reduce((sum, g) => sum + g.memberCount, 0);

  const handleConfirm = async () => {
    if (!newName.trim()) return;
    await onConfirm(newName.trim());
    setNewName("");
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!isPending) { onOpenChange(v); setNewName(""); } }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Merge className="h-5 w-5" />
            Merge Groups
          </DialogTitle>
          <DialogDescription>
            Merge {selectedGroups.length} groups into a new group. All leads will be moved to the new group and the original groups will be deleted.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div>
            <Label className="text-xs text-muted-foreground mb-2 block">Groups to merge</Label>
            <div className="flex flex-wrap gap-2">
              {selectedGroups.map((g) => (
                <Badge key={g.id} variant="secondary" className="text-xs">
                  {g.name} ({g.memberCount})
                </Badge>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Total: {totalLeads} leads
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="merge-name">New group name</Label>
            <Input
              id="merge-name"
              placeholder="Enter name for merged group"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter" && newName.trim()) handleConfirm();
              }}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => { onOpenChange(false); setNewName(""); }} disabled={isPending}>
            Cancel
          </Button>
          <Button size="sm" onClick={handleConfirm} disabled={isPending || !newName.trim()}>
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Merging...
              </>
            ) : (
              `Merge ${selectedGroups.length} Groups`
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
