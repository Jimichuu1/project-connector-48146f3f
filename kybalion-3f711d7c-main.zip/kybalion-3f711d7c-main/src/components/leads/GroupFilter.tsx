import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { useTenant } from "@/contexts/TenantContext";

interface GroupFilterProps {
  value: string[];
  onChange: (value: string[]) => void;
}

export function GroupFilter({ value, onChange }: GroupFilterProps) {
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  
  const { data: groupsData, isLoading } = useQuery({
    queryKey: ['lead-groups-filter', effectiveTenantId],
    queryFn: async () => {
      let query = supabase
        .from('lead_groups')
        .select('id, name')
        .order('name');
      
      // Filter by tenant
      if (!isSuperAdmin && effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      } else if (isSuperAdmin && effectiveTenantId) {
        query = query.eq('admin_id', effectiveTenantId);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      
      return data || [];
    },
  });

  const handleToggle = (groupId: string) => {
    if (value.includes(groupId)) {
      onChange(value.filter(id => id !== groupId));
    } else {
      onChange([...value, groupId]);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-2 p-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 w-32" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-2 p-2 max-h-[300px] overflow-y-auto">
      {groupsData?.map(group => (
        <div key={group.id} className="flex items-center gap-2">
          <Checkbox
            id={`group-${group.id}`}
            checked={value.includes(group.id)}
            onCheckedChange={() => handleToggle(group.id)}
          />
          <label
            htmlFor={`group-${group.id}`}
            className="flex-1 cursor-pointer text-sm"
          >
            {group.name}
          </label>
        </div>
      ))}
      {(!groupsData || groupsData.length === 0) && (
        <div className="text-sm text-muted-foreground text-center py-4">
          No groups found
        </div>
      )}
    </div>
  );
}
