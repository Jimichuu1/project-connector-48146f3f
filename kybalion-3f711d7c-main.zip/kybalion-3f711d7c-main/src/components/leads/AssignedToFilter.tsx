import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Search, UserX, Users } from "lucide-react";
import { UserDisplay } from "@/components/ui/user-display";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";
import { useAuth } from "@/contexts/AuthContext";

interface AssignedToFilterProps {
  value: string[];
  onChange: (value: string[]) => void;
  entityType?: "leads" | "clients";
}

const UNASSIGNED_VALUE = "unassigned";

type AgentWithRole = {
  id: string;
  name: string;
  avatar: string | null;
  role: "AGENT" | "SUPER_AGENT" | "UNKNOWN";
};

export function AssignedToFilter({ value, onChange, entityType = "leads" }: AssignedToFilterProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  const { isManager, isTenantOwner } = useUserData();
  const { user } = useAuth();

  const allAgentsRef = useRef<HTMLButtonElement>(null);
  const allSuperAgentsRef = useRef<HTMLButtonElement>(null);

  const { data: usersData, isLoading } = useQuery({
    queryKey: ['assigned-users-filter', entityType, effectiveTenantId, isManager, isTenantOwner, user?.id],
    queryFn: async () => {
      const PAGE_SIZE = 1000;
      let assignedUserIds: string[] = [];

      const fetchAssignedIds = async (table: "leads" | "clients") => {
        let offset = 0;
        const ids: string[] = [];
        // eslint-disable-next-line no-constant-condition
        while (true) {
          let q = supabase
            .from(table)
            .select("assigned_to")
            .not("assigned_to", "is", null);

          if (effectiveTenantId) {
            q = q.eq("admin_id", effectiveTenantId);
          }

          const { data, error } = await q.range(offset, offset + PAGE_SIZE - 1);
          if (error) throw error;

          const pageIds = (data || []).map((row: any) => row.assigned_to).filter(Boolean) as string[];
          ids.push(...pageIds);

          if (!data || data.length < PAGE_SIZE) break;
          offset += PAGE_SIZE;
        }

        return [...new Set(ids)];
      };

      if (entityType === "clients") {
        assignedUserIds = await fetchAssignedIds("clients");
        if (assignedUserIds.length > 0) {
          const { data: superAgentRoles, error: rolesError } = await supabase
            .from("user_roles")
            .select("user_id")
            .eq("role", "SUPER_AGENT")
            .in("user_id", assignedUserIds);
          if (rolesError) throw rolesError;
          assignedUserIds = superAgentRoles?.map((r) => r.user_id) || [];
        }
      } else {
        assignedUserIds = await fetchAssignedIds("leads");
      }

      if (assignedUserIds.length === 0) return { agents: [] as AgentWithRole[] };

      // Fetch profiles
      let profilesQuery = supabase
        .from('profiles')
        .select('id, full_name, email, avatar_url, admin_id, created_by')
        .in('id', assignedUserIds);

      if (isManager && !isTenantOwner && user?.id) {
        profilesQuery = profilesQuery.eq('created_by', user.id);
      }

      const { data: profiles, error: profilesError } = await profilesQuery;
      if (profilesError) throw profilesError;

      const profileIds = (profiles || []).map(p => p.id);

      // Fetch roles for these users
      let roleMap = new Map<string, string>();
      if (profileIds.length > 0) {
        const { data: roles, error: rolesError } = await supabase
          .from("user_roles")
          .select("user_id, role")
          .in("role", ["AGENT", "SUPER_AGENT"])
          .in("user_id", profileIds);
        if (rolesError) throw rolesError;
        (roles || []).forEach((r) => {
          roleMap.set(r.user_id, r.role);
        });
      }

      const agents: AgentWithRole[] = (profiles || []).map(profile => ({
        id: profile.id,
        name: profile.full_name || profile.email || 'Unknown',
        avatar: profile.avatar_url,
        role: (roleMap.get(profile.id) as "AGENT" | "SUPER_AGENT") || "UNKNOWN",
      }));

      // Sort: Agents first, then Super Agents, alphabetically within each group
      agents.sort((a, b) => {
        const roleOrder = { AGENT: 0, SUPER_AGENT: 1, UNKNOWN: 2 };
        const orderDiff = (roleOrder[a.role] ?? 2) - (roleOrder[b.role] ?? 2);
        if (orderDiff !== 0) return orderDiff;
        return a.name.localeCompare(b.name);
      });

      return { agents };
    },
    enabled: effectiveTenantId !== undefined,
  });

  const allAgents = usersData?.agents || [];
  const agentIds = allAgents.filter(u => u.role === "AGENT").map(u => u.id);
  const superAgentIds = allAgents.filter(u => u.role === "SUPER_AGENT").map(u => u.id);

  const selectedAgentCount = agentIds.filter(id => value.includes(id)).length;
  const selectedSuperAgentCount = superAgentIds.filter(id => value.includes(id)).length;

  const allAgentsSelected = agentIds.length > 0 && selectedAgentCount === agentIds.length;
  const someAgentsSelected = selectedAgentCount > 0 && !allAgentsSelected;
  const allSuperAgentsSelected = superAgentIds.length > 0 && selectedSuperAgentCount === superAgentIds.length;
  const someSuperAgentsSelected = selectedSuperAgentCount > 0 && !allSuperAgentsSelected;

  // Set indeterminate state on checkboxes
  useEffect(() => {
    if (allAgentsRef.current) {
      const indicator = allAgentsRef.current.querySelector('[data-state]');
      if (indicator) {
        (indicator as HTMLElement).dataset.state = someAgentsSelected ? 'indeterminate' : allAgentsSelected ? 'checked' : 'unchecked';
      }
    }
  }, [someAgentsSelected, allAgentsSelected]);

  useEffect(() => {
    if (allSuperAgentsRef.current) {
      const indicator = allSuperAgentsRef.current.querySelector('[data-state]');
      if (indicator) {
        (indicator as HTMLElement).dataset.state = someSuperAgentsSelected ? 'indeterminate' : allSuperAgentsSelected ? 'checked' : 'unchecked';
      }
    }
  }, [someSuperAgentsSelected, allSuperAgentsSelected]);

  const handleToggle = (userId: string) => {
    if (value.includes(userId)) {
      onChange(value.filter(id => id !== userId));
    } else {
      onChange([...value, userId]);
    }
  };

  const handleToggleAllAgents = () => {
    if (allAgentsSelected) {
      onChange(value.filter(id => !agentIds.includes(id)));
    } else {
      const newValue = [...new Set([...value, ...agentIds])];
      onChange(newValue);
    }
  };

  const handleToggleAllSuperAgents = () => {
    if (allSuperAgentsSelected) {
      onChange(value.filter(id => !superAgentIds.includes(id)));
    } else {
      const newValue = [...new Set([...value, ...superAgentIds])];
      onChange(newValue);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-2 p-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-8 w-32" />
          </div>
        ))}
      </div>
    );
  }

  const filteredAgents = allAgents.filter((user) =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const showUnassigned = searchQuery === "" || "unassigned".includes(searchQuery.toLowerCase());
  const showAllAgents = agentIds.length > 0 && (searchQuery === "" || "all agents".includes(searchQuery.toLowerCase()));
  const showAllSuperAgents = superAgentIds.length > 0 && (searchQuery === "" || "all super agents".includes(searchQuery.toLowerCase()));

  const getRoleBadge = (role: string) => {
    if (role === "AGENT") {
      return (
        <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-green-100 text-green-700">
          Agent
        </span>
      );
    }
    if (role === "SUPER_AGENT") {
      return (
        <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-blue-100 text-blue-700">
          Super Agent
        </span>
      );
    }
    return null;
  };

  return (
    <div className="w-80">
      <div className="p-4 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9"
          />
        </div>
      </div>
      <div className="space-y-2 p-4 max-h-[300px] overflow-y-auto">
        {/* Unassigned option */}
        {showUnassigned && (
          <div className="flex items-center gap-2">
            <Checkbox
              id="user-unassigned"
              checked={value.includes(UNASSIGNED_VALUE)}
              onCheckedChange={() => handleToggle(UNASSIGNED_VALUE)}
            />
            <label
              htmlFor="user-unassigned"
              className="flex-1 cursor-pointer flex items-center gap-2"
            >
              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                <UserX className="h-4 w-4 text-muted-foreground" />
              </div>
              <span className="text-sm font-medium">Unassigned</span>
            </label>
          </div>
        )}

        {/* All Agents group checkbox */}
        {showAllAgents && (
          <div className="flex items-center gap-2 py-1">
            <Checkbox
              id="group-all-agents"
              checked={allAgentsSelected ? true : someAgentsSelected ? "indeterminate" : false}
              onCheckedChange={handleToggleAllAgents}
            />
            <label
              htmlFor="group-all-agents"
              className="flex-1 cursor-pointer flex items-center gap-2"
            >
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                <Users className="h-4 w-4 text-green-700" />
              </div>
              <span className="text-sm font-semibold">All Agents</span>
              <span className="text-xs text-muted-foreground">({agentIds.length})</span>
            </label>
          </div>
        )}

        {/* All Super Agents group checkbox */}
        {showAllSuperAgents && (
          <div className="flex items-center gap-2 py-1">
            <Checkbox
              id="group-all-super-agents"
              checked={allSuperAgentsSelected ? true : someSuperAgentsSelected ? "indeterminate" : false}
              onCheckedChange={handleToggleAllSuperAgents}
            />
            <label
              htmlFor="group-all-super-agents"
              className="flex-1 cursor-pointer flex items-center gap-2"
            >
              <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                <Users className="h-4 w-4 text-blue-700" />
              </div>
              <span className="text-sm font-semibold">All Super Agents</span>
              <span className="text-xs text-muted-foreground">({superAgentIds.length})</span>
            </label>
          </div>
        )}

        {/* Separator if group checkboxes shown */}
        {(showAllAgents || showAllSuperAgents) && filteredAgents.length > 0 && (
          <div className="border-t border-border my-1" />
        )}

        {filteredAgents.length === 0 && !showUnassigned ? (
          <div className="text-sm text-muted-foreground text-center py-4">
            No users found
          </div>
        ) : (
          filteredAgents.map(user => (
            <div key={user.id} className="flex items-center gap-2">
              <Checkbox
                id={`user-${user.id}`}
                checked={value.includes(user.id)}
                onCheckedChange={() => handleToggle(user.id)}
              />
              <label
                htmlFor={`user-${user.id}`}
                className="flex-1 cursor-pointer flex items-center gap-2"
              >
                <UserDisplay
                  name={user.name}
                  avatar={user.avatar}
                />
                {getRoleBadge(user.role)}
              </label>
            </div>
          ))
        )}
      </div>
      {(!usersData || usersData.agents.length === 0) && !showUnassigned && (
        <div className="text-sm text-muted-foreground text-center py-4">
          No {entityType === "clients" ? "super agents" : "users"} with assigned {entityType} found
        </div>
      )}
    </div>
  );
}

export { UNASSIGNED_VALUE };
