import { useState } from "react";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Trash2, FolderOutput } from "lucide-react";

interface DeleteGroupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  groupName: string;
  memberCount: number;
  onConfirm: (deleteLeads: boolean) => void;
  isPending: boolean;
}

export const DeleteGroupDialog = ({
  open,
  onOpenChange,
  groupName,
  memberCount,
  onConfirm,
  isPending,
}: DeleteGroupDialogProps) => {
  const [deleteOption, setDeleteOption] = useState<"extract" | "delete">("extract");

  const handleConfirm = () => {
    onConfirm(deleteOption === "delete");
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Group "{groupName}"</AlertDialogTitle>
          <AlertDialogDescription>
            This group contains {memberCount} lead{memberCount !== 1 ? "s" : ""}. 
            Choose what to do with the leads:
          </AlertDialogDescription>
        </AlertDialogHeader>

        <RadioGroup
          value={deleteOption}
          onValueChange={(value) => setDeleteOption(value as "extract" | "delete")}
          className="space-y-3 py-4"
        >
          <div className="flex items-start space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50 cursor-pointer">
            <RadioGroupItem value="extract" id="extract" className="mt-0.5" />
            <Label htmlFor="extract" className="flex-1 cursor-pointer">
              <div className="flex items-center gap-2 font-medium">
                <FolderOutput className="h-4 w-4 text-primary" />
                Extract leads to All Leads
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Remove the group but keep all leads accessible in "All Leads"
              </p>
            </Label>
          </div>

          <div className="flex items-start space-x-3 p-3 rounded-lg border border-destructive/50 hover:bg-destructive/10 cursor-pointer">
            <RadioGroupItem value="delete" id="delete" className="mt-0.5" />
            <Label htmlFor="delete" className="flex-1 cursor-pointer">
              <div className="flex items-center gap-2 font-medium text-destructive">
                <Trash2 className="h-4 w-4" />
                Delete group with all leads
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Permanently delete the group and all {memberCount} lead{memberCount !== 1 ? "s" : ""} in it
              </p>
            </Label>
          </div>
        </RadioGroup>

        <AlertDialogFooter>
          <AlertDialogCancel disabled={isPending}>Cancel</AlertDialogCancel>
          <Button
            variant={deleteOption === "delete" ? "destructive" : "default"}
            onClick={handleConfirm}
            disabled={isPending}
          >
            {isPending ? "Processing..." : deleteOption === "delete" ? "Delete All" : "Remove Group"}
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
