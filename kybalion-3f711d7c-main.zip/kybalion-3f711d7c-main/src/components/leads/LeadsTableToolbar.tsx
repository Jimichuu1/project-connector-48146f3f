import { Plus, TableIcon, KanbanSquare, Layers, UserCheck, Globe, Calendar, Activity, Upload, FileDown, ChevronDown, X, GitCompareArrows, Download } from "lucide-react";
import { useState } from "react";
import { AssignedToFilter } from "./AssignedToFilter";
import { GroupFilter } from "./GroupFilter";
import { CountryFilter } from "./CountryFilter";
import { CreatedDateFilter } from "./CreatedDateFilter";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger, DropdownMenuItem } from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { LeadStatus } from "@/types/leads";
import { Badge } from "@/components/ui/badge";
import { SearchFilter } from "@/components/filters/SearchFilter";
import { useActiveLeadStatuses } from "@/hooks/useLeadStatuses";

export interface FilterValues {
  assignedTo: string[];
  country: string[];
  groupIds: string[];
  createdAt: {
    from: Date | null;
    to: Date | null;
  } | null;
  unassigned?: boolean;
}
interface LeadsTableToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  selectedStatuses: LeadStatus[];
  onStatusesChange: (statuses: LeadStatus[]) => void;
  onExport: () => void;
  onCCExport?: () => void;
  onDownloadTemplate: () => void;
  onImport: () => void;
  onAddLead: () => void;
  onCompare?: () => void;
  filterValues?: FilterValues;
  onFilterValuesChange?: (values: FilterValues) => void;
  viewMode?: "table" | "board" | "groups";
  onViewModeChange?: (mode: "table" | "board" | "groups") => void;
  isAgent?: boolean;
  isRestrictedRole?: boolean;
  isAdmin?: boolean;
}

export function LeadsTableToolbar({
  search,
  onSearchChange,
  selectedStatuses,
  onStatusesChange,
  onExport,
  onCCExport,
  onDownloadTemplate,
  onImport,
  onAddLead,
  onCompare,
  viewMode = "table",
  onViewModeChange,
  isRestrictedRole = false,
  isAdmin = false
}: LeadsTableToolbarProps) {
  const toggleStatus = (status: LeadStatus) => {
    if (selectedStatuses.includes(status)) {
      onStatusesChange(selectedStatuses.filter(s => s !== status));
    } else {
      onStatusesChange([...selectedStatuses, status]);
    }
  };

  return <div className="flex items-center justify-between py-4 border-b border-border">
      <div className="flex items-center gap-2">
        <ToggleGroup type="single" value={viewMode} onValueChange={value => value && onViewModeChange?.(value as "table" | "board" | "groups")}>
          <ToggleGroupItem value="table" aria-label="Table view" size="sm" className="gap-2">
            <TableIcon className="h-4 w-4" />
            Table
          </ToggleGroupItem>
          <ToggleGroupItem value="board" aria-label="Board view" size="sm" className="gap-2">
            <KanbanSquare className="h-4 w-4" />
            Board
          </ToggleGroupItem>
          <ToggleGroupItem value="groups" aria-label="Groups view" size="sm" className="gap-2">
            <Layers className="h-4 w-4" />
            Groups
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="flex items-center gap-2">
        <SearchFilter
          value={search}
          onChange={onSearchChange}
          placeholder="Search leads..."
        />

        {!isRestrictedRole && (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Upload className="h-4 w-4 mr-1" />
                  Import
                  <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover">
                <DropdownMenuItem onClick={onDownloadTemplate}>
                  <FileDown className="h-4 w-4 mr-2" />
                  Download Template
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onImport}>
                  <Upload className="h-4 w-4 mr-2" />
                  Import Data
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {isAdmin && (
              <>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4 mr-1" />
                      Export
                      <ChevronDown className="h-3 w-3 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover">
                    <DropdownMenuItem onClick={onExport}>
                      <Download className="h-4 w-4 mr-2" />
                      Export Leads
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onCCExport}>
                      <Download className="h-4 w-4 mr-2" />
                      Export for CC
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button variant="ghost" size="sm" onClick={onCompare}>
                  <GitCompareArrows className="h-4 w-4 mr-1" />
                  Compare
                </Button>
              </>
            )}
          </>
        )}
        <Button size="sm" onClick={onAddLead} className="gap-2">
          Add Lead
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    </div>;
}

const AVAILABLE_FILTERS = [{
  value: "assigned_to",
  label: "Assigned To",
  icon: UserCheck
}, {
  value: "country",
  label: "Country",
  icon: Globe
}, {
  value: "group",
  label: "Group",
  icon: Layers
}, {
  value: "created_at",
  label: "Created Date",
  icon: Calendar
}] as const;

export function LeadsTableFilters({
  selectedStatuses,
  onStatusesChange,
  filterValues = {
    assignedTo: [],
    country: [],
    groupIds: [],
    createdAt: null,
    unassigned: false
  },
  onFilterValuesChange,
  isAgent = false
}: Pick<LeadsTableToolbarProps, "selectedStatuses" | "onStatusesChange" | "filterValues" | "onFilterValuesChange" | "isAgent">) {
  const [filterPopoverOpen, setFilterPopoverOpen] = useState<string | null>(null);
  
  // Fetch dynamic statuses from database
  const { data: statuses = [] } = useActiveLeadStatuses();
  const STATUS_OPTIONS = statuses.map(s => ({
    value: s.name,
    label: s.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())
  }));

  // Filter available filters based on user role
  const availableFilters = AVAILABLE_FILTERS.filter(filter => {
    // Hide "Assigned To" filter for agents
    if (isAgent && filter.value === "assigned_to") {
      return false;
    }
    return true;
  });

  const toggleStatus = (status: LeadStatus) => {
    if (selectedStatuses.includes(status)) {
      onStatusesChange(selectedStatuses.filter(s => s !== status));
    } else {
      onStatusesChange([...selectedStatuses, status]);
    }
  };

  const getFilterValueCount = (filter: string): number | string => {
    switch (filter) {
      case "assigned_to":
        return filterValues.assignedTo.length;
      case "country":
        return filterValues.country.length;
      case "group":
        return filterValues.groupIds.length;
      case "created_at":
        return filterValues.createdAt !== null ? "•" : 0;
      default:
        return 0;
    }
  };

  const hasAnyFilters = 
    selectedStatuses.length > 0 ||
    filterValues.assignedTo.length > 0 ||
    filterValues.country.length > 0 ||
    filterValues.groupIds.length > 0 ||
    filterValues.createdAt !== null;

  const clearAllFilters = () => {
    onStatusesChange([]);
    if (onFilterValuesChange) {
      onFilterValuesChange({
        assignedTo: [],
        country: [],
        groupIds: [],
        createdAt: null,
        unassigned: false
      });
    }
  };

  return <div className="flex items-center gap-2 py-3 border-b border-border">
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className={`gap-2 rounded-full ${selectedStatuses.length > 0 ? 'bg-primary/10 border-primary/50 pr-2' : 'bg-background'}`}>
            <Activity className="h-4 w-4" />
            <span className={selectedStatuses.length > 0 ? "text-primary-foreground font-medium" : "text-muted-foreground"}>Status</span>
            {selectedStatuses.length > 0 && <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                {selectedStatuses.length}
              </Badge>}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-48 p-0">
          <div className="border-b border-border p-2">
            <span className="font-medium text-sm">Status</span>
          </div>
          <div className="p-1 max-h-64 overflow-y-auto">
            {statuses.map(status => (
              <label
                key={status.name}
                className="flex items-center gap-2 px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selectedStatuses.includes(status.name)}
                  onChange={() => toggleStatus(status.name)}
                  className="h-4 w-4 rounded border-border"
                />
                {status.color && (
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: status.color }}
                  />
                )}
                <span className="text-sm">
                  {status.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                </span>
              </label>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      {availableFilters.map(filter => {
        const FilterIcon = filter.icon;
        const valueCount = getFilterValueCount(filter.value);
        const hasValue = valueCount !== 0 && valueCount !== "0";

        return <Popover key={filter.value} open={filterPopoverOpen === filter.value} onOpenChange={open => setFilterPopoverOpen(open ? filter.value : null)}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className={`gap-2 rounded-full ${hasValue ? 'bg-primary/10 border-primary/50 pr-2' : 'bg-background'}`}>
                {FilterIcon && <FilterIcon className="h-4 w-4" />}
                <span className={hasValue ? "text-primary-foreground font-medium" : "text-muted-foreground"}>{filter.label}</span>
                {hasValue && <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                    {valueCount}
                  </Badge>}
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="p-0">
              <div className="border-b border-border p-2 flex items-center justify-between">
                <span className="font-medium text-sm">{filter.label}</span>
              </div>
              {filter.value === "assigned_to" && onFilterValuesChange && <AssignedToFilter value={filterValues.assignedTo} onChange={newValue => onFilterValuesChange({
            ...filterValues,
            assignedTo: newValue
          })} />}
              {filter.value === "group" && onFilterValuesChange && <GroupFilter value={filterValues.groupIds} onChange={newValue => onFilterValuesChange({
            ...filterValues,
            groupIds: newValue
          })} />}
              {filter.value === "country" && onFilterValuesChange && <CountryFilter value={filterValues.country} onChange={newValue => onFilterValuesChange({
            ...filterValues,
            country: newValue
          })} />}
              {filter.value === "created_at" && onFilterValuesChange && <CreatedDateFilter value={filterValues.createdAt} onChange={newValue => onFilterValuesChange({
            ...filterValues,
            createdAt: newValue
          })} />}
            </PopoverContent>
          </Popover>;
      })}

      {hasAnyFilters && (
        <Button variant="ghost" size="sm" className="gap-2 rounded-full text-muted-foreground" onClick={clearAllFilters}>
          <X className="h-4 w-4" />
          Clear filters
        </Button>
      )}
    </div>;
}
