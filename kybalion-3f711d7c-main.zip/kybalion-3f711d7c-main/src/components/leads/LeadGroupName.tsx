import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useTenant } from "@/contexts/TenantContext";

interface LeadGroupNameProps {
  leadId: string;
}

export const LeadGroupName = ({ leadId }: LeadGroupNameProps) => {
  const { effectiveTenantId } = useTenant();
  
  const { data: groupData, isLoading } = useQuery({
    queryKey: ['lead-group-name', leadId, effectiveTenantId],
    queryFn: async () => {
      // First get the group membership
      const { data: membership, error: membershipError } = await supabase
        .from('lead_group_members')
        .select('group_id')
        .eq('lead_id', leadId)
        .limit(1)
        .maybeSingle();
      
      if (membershipError || !membership) {
        return null;
      }
      
      // Then get the group name separately to avoid RLS join issues
      const { data: group, error: groupError } = await supabase
        .from('lead_groups')
        .select('name')
        .eq('id', membership.group_id)
        .maybeSingle();
      
      if (groupError || !group) {
        return null;
      }
      
      return { groupName: group.name };
    },
    staleTime: 30000, // 30 seconds - data updates are infrequent
  });

  if (isLoading) {
    return <Skeleton className="h-5 w-20" />;
  }

  if (!groupData || !groupData.groupName) {
    return <span className="text-xs text-muted-foreground">-</span>;
  }

  return (
    <Badge variant="outline" className="text-xs">
      {groupData.groupName}
    </Badge>
  );
};