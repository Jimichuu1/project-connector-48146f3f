import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Download, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import { Lead } from "@/types/leads";
import { exportLeadsCCToCSV } from "@/lib/exportCsv";

interface ExportLeadsButtonProps {
  leads: Lead[] | undefined;
}

export const ExportLeadsButton = ({ leads }: ExportLeadsButtonProps) => {
  const handleExport = () => {
    if (!leads || leads.length === 0) {
      toast.error("No leads to export");
      return;
    }

    // Separate leads by DON'T_CALL status
    const dontCallLeads = leads.filter(lead => lead.status === "DON'T_CALL");
    const otherLeads = leads.filter(lead => lead.status !== "DON'T_CALL");

    // Create CSV content
    const headers = [
      "Name",
      "Email",
      "Phone",
      "Country",
      "Company",
      "Job Title",
      "Status",
      "Created At",
    ];

    const createCSV = (leadsData: Lead[]) => {
      const rows = leadsData.map(lead => [
        lead.name,
        lead.email,
        lead.phone || "",
        lead.country || "",
        lead.company || "",
        lead.job_title || "",
        lead.status,
        new Date(lead.created_at).toLocaleDateString(),
      ]);

      return [
        headers.join(","),
        ...rows.map(row => row.map(cell => `"${cell}"`).join(",")),
      ].join("\n");
    };

    // Export other leads
    if (otherLeads.length > 0) {
      const csvContent = createCSV(otherLeads);
      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `leads-export-${new Date().toISOString().split("T")[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }

    // Export DON'T_CALL leads separately
    if (dontCallLeads.length > 0) {
      const csvContent = createCSV(dontCallLeads);
      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `leads-dont-call-${new Date().toISOString().split("T")[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }

    toast.success(`Exported ${otherLeads.length} leads${dontCallLeads.length > 0 ? ` and ${dontCallLeads.length} don't call leads` : ""}`);
  };

  const handleCCExport = () => {
    exportLeadsCCToCSV(leads);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="sm" variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export
          <ChevronDown className="h-3 w-3 ml-1" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleExport}>
          Export Leads
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleCCExport}>
          Export for CC
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
