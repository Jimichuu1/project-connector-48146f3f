import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Lead } from "@/types/leads";

interface ConvertLeadButtonProps {
  lead: Lead;
  onSuccess?: () => void;
}

export function ConvertLeadButton({ lead, onSuccess }: ConvertLeadButtonProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [hasKYC, setHasKYC] = useState(false);
  const [bankName, setBankName] = useState("");
  const [kycNotes, setKycNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [checkingKYC, setCheckingKYC] = useState(false);

  const checkKYCRequirements = async () => {
    setCheckingKYC(true);
    try {
      const { data, error } = await supabase
        .from("kyc_records")
        .select("id, bank_name, notes")
        .eq("lead_id", lead.id)
        .single();

      if (error || !data || !data.bank_name || !data.notes) {
        setHasKYC(false);
      } else {
        setHasKYC(true);
      }
    } catch (err) {
      setHasKYC(false);
    } finally {
      setCheckingKYC(false);
    }
  };

  const handleConvertClick = async () => {
    await checkKYCRequirements();
    setShowDialog(true);
  };

  const handleSubmitConversion = async () => {
    setIsLoading(true);
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error("Not authenticated");

      // If missing KYC, create it
      if (!hasKYC && (!bankName || !kycNotes)) {
        toast.error("Please fill in both Bank Name and KYC Notes");
        setIsLoading(false);
        return;
      }

      if (!hasKYC) {
        const { error: kycError } = await supabase
          .from("kyc_records")
          .insert({
            lead_id: lead.id,
            bank_name: bankName,
            notes: kycNotes,
            created_by: user.user.id,
            status: "PENDING",
          });

        if (kycError) throw kycError;
      }

      // Mark lead as pending conversion
      const { error: updateError } = await supabase
        .from("leads")
        .update({ pending_conversion: true })
        .eq("id", lead.id);

      if (updateError) throw updateError;

      toast.success("Lead added to conversion queue!");
      setShowDialog(false);
      onSuccess?.();
    } catch (error) {
      console.error("Conversion error:", error);
      const message = error instanceof Error ? error.message : "Failed to add lead to conversion queue";
      toast.error(message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Button
        size="sm"
        onClick={(e) => {
          e.stopPropagation();
          handleConvertClick();
        }}
        disabled={checkingKYC}
      >
        <ArrowRight className="h-4 w-4 mr-1" />
        Convert
      </Button>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Convert Lead to Client</DialogTitle>
            <DialogDescription>
              {hasKYC
                ? "This lead has all required KYC information. Confirm to add to conversion queue."
                : "Please provide required KYC information before converting."}
            </DialogDescription>
          </DialogHeader>

          {!hasKYC && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="bankName">Bank Name *</Label>
                <Input
                  id="bankName"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="Enter bank name"
                />
              </div>
              <div>
                <Label htmlFor="kycNotes">KYC Notes *</Label>
                <Textarea
                  id="kycNotes"
                  value={kycNotes}
                  onChange={(e) => setKycNotes(e.target.value)}
                  placeholder="Enter KYC verification notes"
                  rows={4}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button size="sm" variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleSubmitConversion} disabled={isLoading}>
              {isLoading ? "Processing..." : "Confirm Convert"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
