import { useState, ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { UserCombobox, UserOption } from "@/components/ui/user-combobox";
import { useTenant } from "@/contexts/TenantContext";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import { Lead } from "@/types/leads";

interface LeadAssignmentDropdownProps {
  leadId: string;
  currentAssignedTo: string | null;
  onAssignmentChange?: () => void;
}

export const LeadAssignmentDropdown = ({ 
  leadId, 
  currentAssignedTo,
  onAssignmentChange 
}: LeadAssignmentDropdownProps) => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();
  const [isUpdating, setIsUpdating] = useState(false);
  const [optimisticValue, setOptimisticValue] = useState<string | null>(null);

  // Use cached agents for instant loading
  const { data: agents, isLoading } = useAgentsCache();

  const handleAssignmentChange = async (newAssignedTo: string) => {
    if (!user) return;
    
    const isUnassigning = newAssignedTo === 'unassigned';
    const actualValue = isUnassigning ? null : newAssignedTo;
    
    // Optimistic update - show change immediately
    setOptimisticValue(newAssignedTo);
    setIsUpdating(true);
    
    // Optimistically update the leads cache
    queryClient.setQueriesData(
      { queryKey: ['leads-paginated'] },
      (old: Lead[] | undefined) => {
        if (!old) return old;
        return old.map(lead => 
          lead.id === leadId 
            ? { ...lead, assigned_to: actualValue, is_transferred: !isUnassigning && !!currentAssignedTo }
            : lead
        );
      }
    );

    try {
      if (isUnassigning) {
        // For unassignment, use direct update (RPC has issues with null)
        const { error } = await supabase
          .from('leads')
          .update({ 
            assigned_to: null,
            is_transferred: false,
            updated_at: new Date().toISOString()
          })
          .eq('id', leadId);

        if (error) throw error;
      } else {
        // For assignment, use database function for atomic operation
        const { error } = await supabase.rpc('assign_lead_to_agent', {
          p_lead_id: leadId,
          p_agent_id: actualValue,
          p_user_id: user.id,
          p_tenant_id: effectiveTenantId,
        });

        if (error) throw error;

        // Send LEAD_ASSIGNED notification to the assigned agent
        const { data: leadData } = await supabase
          .from('leads')
          .select('name')
          .eq('id', leadId)
          .single();

        const { error: notificationError } = await supabase.from('notifications').insert({
          user_id: actualValue,
          type: 'LEAD_ASSIGNED',
          message: `Lead "${leadData?.name || 'Unknown'}" has been assigned to you`,
          related_entity_type: 'lead',
          related_entity_id: leadId,
          admin_id: effectiveTenantId || null,
        });

        if (notificationError) {
          console.error('Failed to send lead assignment notification:', notificationError);
        }
      }

      toast.success(isUnassigning ? 'Lead unassigned' : 'Lead assignment updated');
      onAssignmentChange?.();
    } catch (error) {
      // Rollback optimistic update on error
      setOptimisticValue(null);
      queryClient.invalidateQueries({ queryKey: ['leads-paginated'] });
      console.error('Error updating assignment:', error);
      toast.error(isUnassigning ? 'Failed to unassign lead' : 'Failed to update assignment');
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return <Skeleton className="h-8 w-32" />;
  }

  const getRoleBadge = (role: string): ReactNode => {
    if (role === "AGENT") {
      return (
        <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-green-100 text-green-700">
          Agent
        </span>
      );
    }
    if (role === "SUPER_AGENT") {
      return (
        <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-blue-100 text-blue-700">
          Super Agent
        </span>
      );
    }
    if (role === "TEAM_LEADER") {
      return (
        <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-cyan-100 text-cyan-700">
          Team Leader
        </span>
      );
    }
    return null;
  };

  const options: UserOption[] = [
    { value: 'unassigned', label: 'Unassigned' },
    ...((agents || []).map(agent => ({
      value: agent.id,
      label: agent.name,
      avatar: agent.avatar,
      badge: getRoleBadge(agent.role),
    })))
  ];

  // Use optimistic value if set, otherwise current value
  const displayValue = optimisticValue ?? (currentAssignedTo || 'unassigned');

  return isUpdating ? (
    <Skeleton className="h-9 w-full max-w-[200px]" />
  ) : (
    <UserCombobox
      options={options}
      value={displayValue}
      onValueChange={handleAssignmentChange}
      placeholder="Select agent..."
      searchPlaceholder="Search agents..."
      emptyText="No agent found"
    />
  );
};
