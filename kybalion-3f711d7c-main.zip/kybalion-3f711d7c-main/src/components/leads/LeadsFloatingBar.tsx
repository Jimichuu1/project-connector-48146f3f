import { FloatingSelectionBar } from "@/components/ui/floating-selection-bar";
import { RefreshCcw, Users, FolderPlus, FolderSync, Trash2, Shuffle } from "lucide-react";
import { UseMutationResult } from "@tanstack/react-query";
import { useActiveLeadStatuses } from "@/hooks/useLeadStatuses";

interface LeadsFloatingBarProps {
  selectedLeads: string[];
  onClear: () => void;
  isAdmin: boolean;
  hasManagerAccess: boolean;
  bulkUpdateStatus: UseMutationResult<any, Error, { leadIds: string[]; status: string }, unknown>;
  bulkDeleteLeads: UseMutationResult<any, Error, string[], unknown>;
  onAssign: () => void;
  onAddToGroup: () => void;
  onMoveToGroup: () => void;
  onShuffle?: () => void;
}

export function LeadsFloatingBar({
  selectedLeads,
  onClear,
  isAdmin,
  hasManagerAccess,
  bulkUpdateStatus,
  bulkDeleteLeads,
  onAssign,
  onAddToGroup,
  onMoveToGroup,
  onShuffle,
}: LeadsFloatingBarProps) {
  const { data: statuses = [] } = useActiveLeadStatuses();

  const handleStatusChange = async (status: string) => {
    const leadIds = [...selectedLeads];
    onClear();
    
    try {
      await bulkUpdateStatus.mutateAsync({ leadIds, status });
    } catch {
      // Error handled by mutation
    }
  };

  const handleDelete = async () => {
    if (selectedLeads.length === 0) return;
    
    const leadIds = [...selectedLeads];
    onClear();
    
    try {
      await bulkDeleteLeads.mutateAsync(leadIds);
    } catch {
      // Error handled by mutation
    }
  };

  const statusOptions = statuses.map((s) => ({
    label: s.name,
    value: s.name,
    onClick: () => handleStatusChange(s.name),
  }));

  const dropdownActions = [
    {
      label: "Change Status",
      icon: <RefreshCcw className="h-4 w-4" />,
      options: statusOptions,
    },
  ];

  // Only managers and above can use Assign, Add to Group, Move to Group, Shuffle, Delete
  const actions = hasManagerAccess
    ? [
        {
          label: "Assign",
          icon: <Users className="h-4 w-4" />,
          onClick: onAssign,
        },
        {
          label: "Shuffle",
          icon: <Shuffle className="h-4 w-4" />,
          onClick: onShuffle,
        },
        {
          label: "Add to Group",
          icon: <FolderPlus className="h-4 w-4" />,
          onClick: onAddToGroup,
        },
        {
          label: "Move to Group",
          icon: <FolderSync className="h-4 w-4" />,
          onClick: onMoveToGroup,
        },
        ...(isAdmin
          ? [
              {
                label: "Delete",
                icon: <Trash2 className="h-4 w-4" />,
                variant: "destructive" as const,
                onClick: handleDelete,
              },
            ]
          : []),
      ]
    : [];

  return (
    <FloatingSelectionBar
      selectedCount={selectedLeads.length}
      onClear={onClear}
      dropdownActions={dropdownActions}
      actions={actions}
    />
  );
}
