import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { UserDisplay } from "@/components/ui/user-display";
import { ConvertedByDisplay } from "@/components/clients/ConvertedByDisplay";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Mail, User, DollarSign, Calendar, UserCheck, Wallet, Building2, Phone, Copy, FolderOpen } from "lucide-react";
import { TenantDisplay } from "@/components/ui/tenant-display";
import { toast } from "sonner";

const copyToClipboard = (text: string, label: string) => {
  navigator.clipboard.writeText(text).then(() => {
    toast.success(`${label} copied to clipboard`);
  }).catch(() => {
    toast.error("Failed to copy");
  });
};

export interface ConvertedClient {
  id: string;
  name: string;
  email: string;
  home_phone?: string | null;
  balance: number | null;
  equity: number | null;
  assigned_to: string | null;
  join_date: string;
  converted_from_lead_id: string | null;
  created_by: string;
  transferring_agent_id: string | null;
  closer_agent_id?: string | null;
  admin_id?: string | null;
  lead_group_names?: string[];
  super_agent_profile?: {
    full_name: string | null;
    email: string;
    avatar_url?: string | null;
  };
  transferring_agent_profile?: {
    full_name: string | null;
    email: string;
    avatar_url?: string | null;
  };
  closer_agent_profile?: {
    full_name: string | null;
    email: string;
    avatar_url?: string | null;
  };
}

interface ConvertedClientsTableProps {
  clients: ConvertedClient[];
  deposits: Record<string, number>;
  isAdmin: boolean;
  isAgent: boolean;
  isSuperAgent: boolean;
  isSuperAdminView?: boolean;
  isTenantOwner?: boolean;
  isManager?: boolean;
  shouldShowEmail?: boolean;
  shouldShowPhone?: boolean;
}

export const ConvertedClientsTable = ({
  clients,
  deposits,
  isAdmin,
  isAgent,
  isSuperAgent,
  isSuperAdminView = false,
  isTenantOwner = false,
  isManager = false,
  shouldShowEmail = true,
  shouldShowPhone = true,
}: ConvertedClientsTableProps) => {
  // Determine if phone column should be visible (Tenant Owner, Manager, or Super Admin)
  const showPhoneColumn = isTenantOwner || isManager || isSuperAdminView;

  // Show lead group column for admin roles
  const showLeadGroupColumn = isAdmin || isSuperAdminView || isTenantOwner || isManager;

  const getColumnCount = () => {
    let count = 6; // Base columns (Client Name, Email, Initial Balance, Initial Amount, Deposit, Date)
    if (showPhoneColumn) count += 1;
    if (showLeadGroupColumn) count += 1;
    if (isSuperAdminView) count += 2;
    if (isAdmin && !isSuperAdminView) count += 2;
    if (isSuperAgent && !isAgent && !isAdmin && !isSuperAdminView) count += 1;
    if (isAgent && !isSuperAgent && !isAdmin && !isSuperAdminView) count += 1;
    // Closer column
    if (isAdmin || isSuperAdminView || (isSuperAgent && !isAgent)) count += 1;
    return count;
  };

  return (
    <div className="rounded-md">
      <Table>
        <TableHeader>
          <TableRow className="border-b border-border hover:bg-transparent">
            {isSuperAdminView && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <Building2 className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Tenant</span>
                </div>
              </TableHead>
            )}
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <User className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Client Name</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Mail className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Email</span>
              </div>
            </TableHead>
            {/* Phone: visible to Tenant Owner, Manager, and Super Admin */}
            {showPhoneColumn && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <Phone className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Phone</span>
                </div>
              </TableHead>
            )}
            {/* Transferring Agent: visible to Admin, Super Admin, and Super Agent (NOT agents) */}
            {(isAdmin || isSuperAdminView || (isSuperAgent && !isAgent)) && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <User className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Trans. Agent</span>
                </div>
              </TableHead>
            )}
            {/* Super Agent: visible to Admin and Agent (NOT super agents viewing their own clients) */}
            {(isAdmin || (isAgent && !isSuperAgent)) && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <UserCheck className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Super Agent</span>
                </div>
              </TableHead>
            )}
            {/* Closer Agent: visible to Admin, Super Admin, and Super Agent */}
            {(isAdmin || isSuperAdminView || (isSuperAgent && !isAgent)) && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <UserCheck className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Closer</span>
                </div>
              </TableHead>
            )}
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <DollarSign className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Int. Balance</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Wallet className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Int. Amount</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <DollarSign className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Deposit</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Date</span>
              </div>
            </TableHead>
            {/* Lead Group: visible to admin roles - last column */}
            {showLeadGroupColumn && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <FolderOpen className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Lead Group</span>
                </div>
              </TableHead>
            )}
          </TableRow>
        </TableHeader>
        <TableBody>
          {clients.length === 0 ? (
            <TableRow>
              <TableCell colSpan={getColumnCount()} className="text-center">
                No converted clients yet
              </TableCell>
            </TableRow>
          ) : (
            clients.map((client) => (
              <TableRow key={client.id}>
                {isSuperAdminView && (
                  <TableCell className="py-2">
                    <TenantDisplay adminId={client.admin_id} />
                  </TableCell>
                )}
                <TableCell className="font-medium py-2 whitespace-nowrap">
                  <button
                    onClick={() => copyToClipboard(client.name, "Name")}
                    className="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer group"
                  >
                    {client.name}
                    <Copy className="h-3 w-3 opacity-0 group-hover:opacity-50 transition-opacity" />
                  </button>
                </TableCell>
                <TableCell className="py-2">
                  {shouldShowEmail ? (
                    <button
                      onClick={() => copyToClipboard(client.email, "Email")}
                      className="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer group"
                    >
                      {client.email}
                      <Copy className="h-3 w-3 opacity-0 group-hover:opacity-50 transition-opacity" />
                    </button>
                  ) : (
                    <span className="text-muted-foreground">••••••••</span>
                  )}
                </TableCell>
                {/* Phone: visible to Tenant Owner, Manager, and Super Admin */}
                {showPhoneColumn && (
                  <TableCell className="py-2">
                    {client.home_phone ? (
                      <button
                        onClick={() => copyToClipboard(client.home_phone!, "Phone")}
                        className="flex items-center gap-1 hover:text-primary transition-colors cursor-pointer group"
                      >
                        {client.home_phone}
                        <Copy className="h-3 w-3 opacity-0 group-hover:opacity-50 transition-opacity" />
                      </button>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                {/* Transferring Agent: visible to Admin, Super Admin, and Super Agent (NOT agents) */}
                {(isAdmin || isSuperAdminView || (isSuperAgent && !isAgent)) && (
                  <TableCell className="py-2">
                    {client.transferring_agent_profile ? (
                      <UserDisplay
                        name={client.transferring_agent_profile.full_name || client.transferring_agent_profile.email}
                        avatar={client.transferring_agent_profile.avatar_url}
                      />
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                {/* Super Agent */}
                {(isAdmin || (isAgent && !isSuperAgent)) && (
                  <TableCell className="py-2">
                    {client.super_agent_profile ? (
                      <UserDisplay
                        name={client.super_agent_profile.full_name || client.super_agent_profile.email}
                        avatar={client.super_agent_profile.avatar_url}
                      />
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                {/* Closer Agent */}
                {(isAdmin || isSuperAdminView || (isSuperAgent && !isAgent)) && (
                  <TableCell className="py-2">
                    {client.closer_agent_profile ? (
                      <UserDisplay
                        name={client.closer_agent_profile.full_name || client.closer_agent_profile.email}
                        avatar={client.closer_agent_profile.avatar_url}
                      />
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                <TableCell className="py-2">
                  {client.balance != null ? `$${client.balance.toLocaleString()}` : "-"}
                </TableCell>
                <TableCell className="py-2">
                  {client.equity != null ? `$${client.equity.toLocaleString()}` : "-"}
                </TableCell>
                <TableCell className="py-2">
                  {deposits[client.id] ? `$${deposits[client.id].toLocaleString()}` : "$0"}
                </TableCell>
                <TableCell className="py-2 whitespace-nowrap">
                  {format(new Date(client.join_date), "MMM d, yyyy")}
                </TableCell>
                {/* Lead Group - last column */}
                {showLeadGroupColumn && (
                  <TableCell className="py-2">
                    {client.lead_group_names && client.lead_group_names.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {client.lead_group_names.map((name, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {name}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
