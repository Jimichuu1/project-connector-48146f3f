import { Button } from "@/components/ui/button";
import { UserCheck, User, Calendar, Plus } from "lucide-react";
import { useState, useEffect } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { AssignedToFilter } from "@/components/leads/AssignedToFilter";
import { CreatedDateFilter } from "@/components/leads/CreatedDateFilter";

export interface ConvertedFilterValues {
  agentIds: string[];
  convertedByIds: string[];
  superAgentIds: string[];
  convertedDate: {
    from: Date | null;
    to: Date | null;
  } | null;
}

interface ConvertedClientsFiltersProps {
  isAdmin: boolean;
  filterValues?: ConvertedFilterValues;
  onFilterValuesChange?: (values: ConvertedFilterValues) => void;
}

const AVAILABLE_FILTERS = [
  {
    value: "agent",
    label: "Agent",
    icon: User,
    requiresAdmin: true,
  },
  {
    value: "super_agent",
    label: "Super Agent",
    icon: UserCheck,
    requiresAdmin: true,
  },
  {
    value: "converted_by",
    label: "Converted By",
    icon: UserCheck,
    requiresAdmin: false,
  },
  {
    value: "converted_date",
    label: "Converted Date",
    icon: Calendar,
    requiresAdmin: false,
  },
] as const;

export function ConvertedClientsFilters({
  isAdmin,
  filterValues = {
    agentIds: [],
    convertedByIds: [],
    superAgentIds: [],
    convertedDate: null,
  },
  onFilterValuesChange,
}: ConvertedClientsFiltersProps) {
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [addFilterOpen, setAddFilterOpen] = useState(false);
  const [filterPopoverOpen, setFilterPopoverOpen] = useState<string | null>(null);

  // Filter available filters based on user role
  const availableFilters = AVAILABLE_FILTERS.filter((filter) => {
    if (filter.requiresAdmin && !isAdmin) {
      return false;
    }
    return true;
  });

  // Automatically show filters that have values
  useEffect(() => {
    const filtersWithValues: string[] = [];
    if (filterValues.agentIds.length > 0) {
      filtersWithValues.push("agent");
    }
    if (filterValues.superAgentIds.length > 0) {
      filtersWithValues.push("super_agent");
    }
    if (filterValues.convertedByIds.length > 0) {
      filtersWithValues.push("converted_by");
    }
    if (filterValues.convertedDate !== null) {
      filtersWithValues.push("converted_date");
    }
    setActiveFilters(filtersWithValues);
  }, [filterValues]);

  const addFilter = (filterValue: string) => {
    if (!activeFilters.includes(filterValue)) {
      setActiveFilters([...activeFilters, filterValue]);
    }
    setAddFilterOpen(false);
  };

  const removeFilter = (filterValue: string) => {
    setActiveFilters(activeFilters.filter((f) => f !== filterValue));
    // Clear filter values when removing
    if (onFilterValuesChange) {
      const newValues = { ...filterValues };
      switch (filterValue) {
        case "agent":
          newValues.agentIds = [];
          break;
        case "super_agent":
          newValues.superAgentIds = [];
          break;
        case "converted_by":
          newValues.convertedByIds = [];
          break;
        case "converted_date":
          newValues.convertedDate = null;
          break;
      }
      onFilterValuesChange(newValues);
    }
  };

  return (
    <div className="flex items-center gap-2 py-3 border-b border-border">
      {activeFilters.map((filter) => {
        const filterConfig = availableFilters.find((f) => f.value === filter);
        const FilterIcon = filterConfig?.icon;
        const hasValue = (() => {
          switch (filter) {
            case "agent":
              return filterValues.agentIds.length > 0;
            case "super_agent":
              return filterValues.superAgentIds.length > 0;
            case "converted_by":
              return filterValues.convertedByIds.length > 0;
            case "converted_date":
              return filterValues.convertedDate !== null;
            default:
              return false;
          }
        })();

        return (
          <Popover
            key={filter}
            open={filterPopoverOpen === filter}
            onOpenChange={(open) => setFilterPopoverOpen(open ? filter : null)}
          >
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={`gap-2 rounded-full ${
                  hasValue ? "bg-primary/10 border-primary/50 pr-2" : "bg-background"
                }`}
              >
                {FilterIcon && <FilterIcon className="h-4 w-4" />}
                <span className={hasValue ? "text-primary font-medium" : "text-muted-foreground"}>
                  {filterConfig?.label}
                </span>
                  {hasValue && (
                    <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                      {filter === "agent"
                        ? filterValues.agentIds.length
                        : filter === "super_agent"
                        ? filterValues.superAgentIds.length
                        : filter === "converted_by"
                        ? filterValues.convertedByIds.length
                        : "•"}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="p-0">
              <div className="border-b border-border p-2 flex items-center justify-between">
                <span className="font-medium text-sm">{filterConfig?.label}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeFilter(filter)}
                  className="h-6 text-xs"
                >
                  Remove
                </Button>
              </div>
              {filter === "agent" && onFilterValuesChange && (
                <AssignedToFilter
                  value={filterValues.agentIds}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      agentIds: newValue,
                    })
                  }
                />
              )}
              {filter === "super_agent" && onFilterValuesChange && (
                <AssignedToFilter
                  value={filterValues.superAgentIds}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      superAgentIds: newValue,
                    })
                  }
                  entityType="clients"
                />
              )}
              {filter === "converted_by" && onFilterValuesChange && (
                <AssignedToFilter
                  value={filterValues.convertedByIds}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      convertedByIds: newValue,
                    })
                  }
                />
              )}
              {filter === "converted_date" && onFilterValuesChange && (
                <CreatedDateFilter
                  value={filterValues.convertedDate}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      convertedDate: newValue,
                    })
                  }
                />
              )}
            </PopoverContent>
          </Popover>
        );
      })}

      <Popover open={addFilterOpen} onOpenChange={setAddFilterOpen}>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-2 rounded-full text-muted-foreground">
            <Plus className="h-4 w-4" />
            Add filter
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-56 p-2">
          <div className="space-y-1">
            {availableFilters.map((filter) => {
              const FilterIcon = filter.icon;
              return (
                <Button
                  key={filter.value}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start text-left gap-2"
                  onClick={() => addFilter(filter.value)}
                  disabled={activeFilters.includes(filter.value)}
                >
                  {FilterIcon && <FilterIcon className="h-4 w-4" />}
                  {filter.label}
                </Button>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
