import { ListChecks, CheckCircle2, Download, ChevronDown } from "lucide-react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { SearchFilter } from "@/components/filters/SearchFilter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { exportConvertedClientsToCSV, exportConvertedClientsCCToCSV } from "@/lib/exportCsv";
import type { ConvertedClient } from "./ConvertedClientsTable";

interface ConvertedClientsToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  viewMode: "pending" | "converted";
  onViewModeChange: (mode: "pending" | "converted") => void;
  clients?: ConvertedClient[];
  deposits?: Record<string, number>;
}

export function ConvertedClientsToolbar({
  search,
  onSearchChange,
  viewMode,
  onViewModeChange,
  clients,
  deposits,
}: ConvertedClientsToolbarProps) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-border">
      <div className="flex items-center gap-2">
        <ToggleGroup
          type="single"
          value={viewMode}
          onValueChange={(value) => value && onViewModeChange(value as "pending" | "converted")}
        >
          <ToggleGroupItem value="pending" aria-label="Pending view" size="sm" className="gap-2">
            <ListChecks className="h-4 w-4" />
            Pending
          </ToggleGroupItem>
          <ToggleGroupItem value="converted" aria-label="Converted view" size="sm" className="gap-2">
            <CheckCircle2 className="h-4 w-4" />
            Converted
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="flex items-center gap-2">
        <SearchFilter
          value={search}
          onChange={onSearchChange}
          placeholder="Search..."
        />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="sm" variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
              <ChevronDown className="h-3 w-3 ml-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => exportConvertedClientsToCSV(clients || [], deposits || {})}>
              Export Clients
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => exportConvertedClientsCCToCSV(clients || [])}>
              Export for CC
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}
