import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { SuperAgentUser } from "@/types/supabase-helpers";

interface ConvertDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  leadName: string;
  superAgents: SuperAgentUser[];
  selectedAgent: string;
  onSelectAgent: (agentId: string) => void;
  onConfirm: () => void;
  isConverting: boolean;
}

export const ConvertDialog = ({
  open,
  onOpenChange,
  leadName,
  superAgents,
  selectedAgent,
  onSelectAgent,
  onConfirm,
  isConverting,
}: ConvertDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Convert to Client</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Convert <strong>{leadName}</strong> to a client and assign to a user.
          </p>
          <div>
            <Label>Assign to User</Label>
            <Select value={selectedAgent} onValueChange={onSelectAgent}>
              <SelectTrigger>
                <SelectValue placeholder="Select user" />
              </SelectTrigger>
              <SelectContent className="bg-background">
                {superAgents.length === 0 ? (
                  <div className="p-2 text-sm text-muted-foreground">
                    No super agents available for this tenant
                  </div>
                ) : (
                  superAgents.map((agent) => (
                    <SelectItem key={agent.user_id} value={agent.user_id}>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={agent.profiles?.avatar_url || undefined} />
                          <AvatarFallback className="text-xs">
                            {(agent.profiles?.full_name || agent.profiles?.email || "U").charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span>{agent.profiles?.full_name || agent.profiles?.email}</span>
                        <span className="text-muted-foreground text-xs">({agent.role})</span>
                      </div>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={onConfirm} disabled={isConverting || !selectedAgent}>
            {isConverting ? "Converting..." : "Convert to Client"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
