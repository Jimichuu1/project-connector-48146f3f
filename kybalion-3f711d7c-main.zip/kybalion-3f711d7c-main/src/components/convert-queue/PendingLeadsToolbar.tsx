import { ListChecks, CheckCircle2 } from "lucide-react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { SearchFilter } from "@/components/filters/SearchFilter";

interface PendingLeadsToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  viewMode: "pending" | "converted";
  onViewModeChange: (mode: "pending" | "converted") => void;
}

export function PendingLeadsToolbar({
  search,
  onSearchChange,
  viewMode,
  onViewModeChange,
}: PendingLeadsToolbarProps) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-border">
      <div className="flex items-center gap-2">
        <ToggleGroup
          type="single"
          value={viewMode}
          onValueChange={(value) => value && onViewModeChange(value as "pending" | "converted")}
        >
          <ToggleGroupItem value="pending" aria-label="Pending view" size="sm" className="gap-2">
            <ListChecks className="h-4 w-4" />
            Pending
          </ToggleGroupItem>
          <ToggleGroupItem value="converted" aria-label="Converted view" size="sm" className="gap-2">
            <CheckCircle2 className="h-4 w-4" />
            Converted
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="flex items-center gap-2">
        <SearchFilter
          value={search}
          onChange={onSearchChange}
          placeholder="Search..."
        />
      </div>
    </div>
  );
}
