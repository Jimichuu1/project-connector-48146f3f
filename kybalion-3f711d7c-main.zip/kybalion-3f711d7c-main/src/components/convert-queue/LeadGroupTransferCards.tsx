import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Users, FolderOpen } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ClientLike {
  id: string;
  lead_group_names?: string[];
  join_date?: string;
}

interface LeadGroupTransferCardsProps {
  clients: ClientLike[];
  deposits: Record<string, number>;
}

const NO_GROUP_KEY = "__no_group__";
const ALL_TIME = "__all__";

function currentMonthKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

const MONTH_LABEL_FMT = new Intl.DateTimeFormat("en-US", {
  month: "long",
  year: "numeric",
});

function monthKeyFromDate(value?: string): string | null {
  if (!value) return null;
  const d = new Date(value);
  if (isNaN(d.getTime())) return null;
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabel(key: string): string {
  const [year, month] = key.split("-").map(Number);
  return MONTH_LABEL_FMT.format(new Date(year, month - 1, 1));
}

export function LeadGroupTransferCards({ clients, deposits }: LeadGroupTransferCardsProps) {
  const [selectedMonth, setSelectedMonth] = useState<string>(() => currentMonthKey());

  const monthOptions = useMemo(() => {
    const set = new Set<string>();
    for (const c of clients) {
      const key = monthKeyFromDate(c.join_date);
      if (key) set.add(key);
    }
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [clients]);

  const filteredClients = useMemo(() => {
    if (selectedMonth === ALL_TIME) return clients;
    return clients.filter((c) => monthKeyFromDate(c.join_date) === selectedMonth);
  }, [clients, selectedMonth]);

  const groups = useMemo(() => {
    const map = new Map<string, { name: string; count: number; total: number }>();
    for (const client of filteredClients) {
      const depositAmount = deposits[client.id] || 0;
      const names = client.lead_group_names && client.lead_group_names.length > 0
        ? client.lead_group_names
        : [NO_GROUP_KEY];
      for (const rawName of names) {
        const key = rawName;
        const display = rawName === NO_GROUP_KEY ? "No Group" : rawName;
        const existing = map.get(key);
        if (existing) {
          existing.count += 1;
          existing.total += depositAmount;
        } else {
          map.set(key, { name: display, count: 1, total: depositAmount });
        }
      }
    }
    return Array.from(map.entries())
      .map(([key, value]) => ({ key, ...value }))
      .sort((a, b) => b.count - a.count || b.total - a.total);
  }, [filteredClients, deposits]);

  const formatAmount = (amount: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(amount);

  const totalClients = groups.reduce((sum, g) => sum + g.count, 0);
  const totalDeposits = groups.reduce((sum, g) => sum + g.total, 0);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-baseline gap-2 flex-wrap">
          <h3 className="text-sm font-semibold text-foreground">Transfers by Lead Group</h3>
          <span className="text-xs text-muted-foreground">
            {groups.length} {groups.length === 1 ? "group" : "groups"} · {totalClients} clients · {formatAmount(totalDeposits)}
          </span>
        </div>
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-[180px] h-8 text-xs">
            <SelectValue placeholder="Filter by month" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_TIME}>All time</SelectItem>
            {monthOptions.map((key) => (
              <SelectItem key={key} value={key}>
                {monthLabel(key)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {groups.length === 0 ? (
        <Card className="p-6 text-center text-sm text-muted-foreground bg-card border">
          No transfers in the selected period.
        </Card>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {groups.map((group) => {
            const isNoGroup = group.key === NO_GROUP_KEY;
            return (
              <Card
                key={group.key}
                className="group relative overflow-hidden p-4 bg-card hover:bg-accent/30 transition-colors border"
              >
                <div className="flex items-center gap-2 min-w-0 mb-4">
                  <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md ${isNoGroup ? "bg-muted text-muted-foreground" : "bg-primary/10 text-primary"}`}>
                    <FolderOpen className="h-4 w-4" />
                  </div>
                  <p className="text-sm font-semibold text-foreground truncate" title={group.name}>
                    {group.name}
                  </p>
                </div>
                <div className="flex items-end justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-3xl font-bold text-foreground tabular-nums leading-none">
                        {group.count}
                      </span>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span className="text-[11px] uppercase tracking-wider text-muted-foreground mt-1 block">
                      {group.count === 1 ? "Client" : "Clients"}
                    </span>
                  </div>
                  <div className="text-right min-w-0">
                    <div className="text-sm font-semibold text-foreground tabular-nums truncate">
                      {formatAmount(group.total)}
                    </div>
                    <span className="text-[11px] uppercase tracking-wider text-muted-foreground mt-1 block">
                      Deposits
                    </span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
