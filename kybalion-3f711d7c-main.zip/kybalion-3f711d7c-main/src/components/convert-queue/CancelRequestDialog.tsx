import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface CancelRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  leadName: string;
  onConfirm: () => void;
}

export const CancelRequestDialog = ({
  open,
  onOpenChange,
  leadName,
  onConfirm,
}: CancelRequestDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Cancel Conversion Request</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Are you sure you want to cancel the conversion request for <strong>{leadName}</strong>?
            The lead will return to your leads list.
          </p>
        </div>
        <DialogFooter>
          <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
            No, Keep It
          </Button>
          <Button size="sm" variant="destructive" onClick={onConfirm}>
            Yes, Cancel Request
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
