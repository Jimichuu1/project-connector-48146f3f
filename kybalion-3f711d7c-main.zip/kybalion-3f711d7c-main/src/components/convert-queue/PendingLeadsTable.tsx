import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { UserDisplay } from "@/components/ui/user-display";
import { format } from "date-fns";
import { ArrowRight, X, Mail, User, Phone, UserCheck, Calendar, DollarSign, Wallet, Building2 } from "lucide-react";
import { TenantDisplay } from "@/components/ui/tenant-display";

export interface PendingLead {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  balance: number | null;
  equity: number | null;
  created_at: string;
  created_by: string;
  assigned_to: string | null;
  transferring_agent_id: string | null;
  admin_id?: string | null;
  closer_agent_id?: string | null;
  transferring_agent?: {
    id: string;
    full_name: string | null;
    email: string;
    avatar_url?: string | null;
  };
  closer_agent?: {
    id: string;
    full_name: string | null;
    email: string;
    avatar_url?: string | null;
  };
  lead_group_names?: string[];
}

interface PendingLeadsTableProps {
  leads: PendingLead[];
  isLoading: boolean;
  isAgent: boolean;
  isSuperAdmin?: boolean;
  shouldShowEmail?: boolean;
  shouldShowPhone?: boolean;
  canConvert?: boolean;
  onCancelRequest: (lead: PendingLead) => void;
  onConvert: (lead: PendingLead) => void;
}

export const PendingLeadsTable = ({
  leads,
  isLoading,
  isAgent,
  isSuperAdmin = false,
  shouldShowEmail = true,
  shouldShowPhone = true,
  canConvert = true,
  onCancelRequest,
  onConvert,
}: PendingLeadsTableProps) => {
  return (
    <div className="rounded-md">
      <Table>
        <TableHeader>
          <TableRow className="border-b border-border hover:bg-transparent">
            {isSuperAdmin && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <Building2 className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Tenant</span>
                </div>
              </TableHead>
            )}
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <User className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Name</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Mail className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Email</span>
              </div>
            </TableHead>
            {!isAgent && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <Phone className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Phone</span>
                </div>
              </TableHead>
            )}
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <DollarSign className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Int. Balance</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Wallet className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Int. Amount</span>
              </div>
            </TableHead>
            {!isAgent && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <UserCheck className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Trans. Agent</span>
                </div>
              </TableHead>
            )}
            {!isAgent && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <UserCheck className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Closer</span>
                </div>
              </TableHead>
            )}
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Date</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <span className="text-muted-foreground">Actions</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
               <TableCell colSpan={isAgent ? 6 : (isSuperAdmin ? 10 : 9)} className="text-center py-2">
                Loading...
              </TableCell>
            </TableRow>
          ) : leads.length === 0 ? (
            <TableRow>
              <TableCell colSpan={isAgent ? 6 : (isSuperAdmin ? 10 : 9)} className="text-center py-2">
                No pending conversions
              </TableCell>
            </TableRow>
          ) : (
            leads.map((lead) => (
              <TableRow key={lead.id}>
                {isSuperAdmin && (
                  <TableCell className="py-2">
                    <TenantDisplay adminId={lead.admin_id} />
                  </TableCell>
                )}
                <TableCell className="font-medium py-2">{lead.name}</TableCell>
                <TableCell className="py-2">
                  {shouldShowEmail ? lead.email : <span className="text-muted-foreground">••••••••</span>}
                </TableCell>
                {!isAgent && (
                  <TableCell className="py-2">
                    {shouldShowPhone ? (lead.phone || "-") : <span className="text-muted-foreground">••••••••</span>}
                  </TableCell>
                )}
                <TableCell className="py-2">
                  {lead.balance != null ? `$${lead.balance.toLocaleString()}` : "-"}
                </TableCell>
                <TableCell className="py-2">
                  {lead.equity != null ? `$${lead.equity.toLocaleString()}` : "-"}
                </TableCell>
                {!isAgent && (
                  <TableCell className="py-2">
                    {lead.transferring_agent ? (
                      <UserDisplay
                        name={lead.transferring_agent.full_name || "Unknown"}
                        avatar={lead.transferring_agent.avatar_url}
                      />
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                {!isAgent && (
                  <TableCell className="py-2">
                    {lead.closer_agent ? (
                      <UserDisplay
                        name={lead.closer_agent.full_name || "Unknown"}
                        avatar={lead.closer_agent.avatar_url}
                      />
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                )}
                <TableCell className="py-2">
                  {format(new Date(lead.created_at), "MMM d, yyyy")}
                </TableCell>
                <TableCell className="py-2">
                  <div className="flex gap-2">
                    {isAgent ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onCancelRequest(lead)}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Cancel Request
                      </Button>
                    ) : canConvert ? (
                      <Button
                        size="sm"
                        onClick={() => onConvert(lead)}
                      >
                        <ArrowRight className="h-4 w-4 mr-1" />
                        Convert
                      </Button>
                    ) : (
                      <span className="text-muted-foreground text-sm">View only</span>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};
