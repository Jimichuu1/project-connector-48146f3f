import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LucideIcon } from "lucide-react";

interface MultiSelectOption {
  value: string;
  label: string;
}

interface MultiSelectFilterProps {
  icon: LucideIcon;
  label: string;
  options: MultiSelectOption[];
  selectedValues: string[];
  onToggle: (value: string) => void;
}

export const MultiSelectFilter = ({
  icon: Icon,
  label,
  options,
  selectedValues,
  onToggle,
}: MultiSelectFilterProps) => {
  const isActive = selectedValues.length > 0;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={`gap-2 rounded-full ${
            isActive
              ? "bg-primary/10 border-primary/50 pr-2"
              : "bg-background"
          }`}
        >
          <Icon className="h-4 w-4" />
          <span
            className={
              isActive ? "text-primary-foreground font-medium" : "text-muted-foreground"
            }
          >
            {label}
          </span>
          {isActive && (
            <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
              {selectedValues.length}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-48 bg-background z-50 max-h-[60vh] overflow-y-auto">
        {options.map((option) => (
          <DropdownMenuCheckboxItem
            key={option.value}
            checked={selectedValues.includes(option.value)}
            onCheckedChange={() => onToggle(option.value)}
          >
            {option.label}
          </DropdownMenuCheckboxItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
