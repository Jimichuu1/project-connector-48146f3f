import { ReactNode } from "react";

interface FilterBarProps {
  children: ReactNode;
}

export const FilterBar = ({ children }: FilterBarProps) => {
  return (
    <div className="flex items-center justify-between gap-2 py-3 w-full">
      {children}
    </div>
  );
};
