import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";

interface TenantFilterProps {
  value: string[];
  onChange: (value: string[]) => void;
}

export function TenantFilter({ value, onChange }: TenantFilterProps) {
  const { data: tenants, isLoading } = useQuery({
    queryKey: ['tenants-filter'],
    queryFn: async () => {
      // Get all tenant owners (users with TENANT_OWNER role)
      const { data: tenantOwners, error } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'TENANT_OWNER');
      
      if (error) throw error;
      
      if (!tenantOwners || tenantOwners.length === 0) {
        return [];
      }
      
      // Get profile info for tenant owners
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .in('id', tenantOwners.map(t => t.user_id));
      
      if (profilesError) throw profilesError;
      
      return profiles || [];
    },
  });

  const handleToggle = (tenantId: string) => {
    if (value.includes(tenantId)) {
      onChange(value.filter(id => id !== tenantId));
    } else {
      onChange([...value, tenantId]);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-2 p-2">
        {[1, 2, 3].map(i => (
          <div key={i} className="flex items-center gap-2">
            <Skeleton className="h-4 w-4" />
            <Skeleton className="h-4 w-32" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-2 p-2 max-h-[300px] overflow-y-auto">
      {tenants?.map(tenant => (
        <div key={tenant.id} className="flex items-center gap-2">
          <Checkbox
            id={`tenant-${tenant.id}`}
            checked={value.includes(tenant.id)}
            onCheckedChange={() => handleToggle(tenant.id)}
          />
          <label
            htmlFor={`tenant-${tenant.id}`}
            className="flex-1 cursor-pointer text-sm"
          >
            {tenant.full_name || tenant.email}
          </label>
        </div>
      ))}
      {(!tenants || tenants.length === 0) && (
        <div className="text-sm text-muted-foreground text-center py-4">
          No tenants found
        </div>
      )}
    </div>
  );
}
