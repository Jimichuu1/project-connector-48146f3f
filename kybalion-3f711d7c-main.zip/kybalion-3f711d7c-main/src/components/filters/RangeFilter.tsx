import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Slider } from "@/components/ui/slider";
import { LucideIcon } from "lucide-react";

interface RangeFilterProps {
  icon: LucideIcon;
  label: string;
  min: number;
  max: number;
  step: number;
  value: [number, number];
  isActive: boolean;
  onChange: (values: number[]) => void;
  onClear: () => void;
  formatValue?: (value: number) => string;
}

export const RangeFilter = ({
  icon: Icon,
  label,
  min,
  max,
  step,
  value,
  isActive,
  onChange,
  onClear,
  formatValue = (v) => v.toLocaleString(),
}: RangeFilterProps) => {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={`gap-2 rounded-full ${
            isActive ? "bg-primary/10 border-primary/50 pr-2" : "bg-background"
          }`}
        >
          <Icon className="h-4 w-4" />
          <span
            className={
              isActive ? "text-primary-foreground font-medium" : "text-muted-foreground"
            }
          >
            {label}
          </span>
          {isActive && (
            <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
              {formatValue(value[0])} - {formatValue(value[1])}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-80 bg-background z-50">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Amount Range</Label>
            <Slider
              min={min}
              max={max}
              step={step}
              value={value}
              onValueChange={onChange}
              className="w-full"
            />
          </div>
          <div className="flex gap-2">
            <div className="flex-1">
              <Label className="text-xs">Min</Label>
              <Input
                type="number"
                value={value[0]}
                onChange={(e) =>
                  onChange([parseInt(e.target.value) || min, value[1]])
                }
                className="h-8"
              />
            </div>
            <div className="flex-1">
              <Label className="text-xs">Max</Label>
              <Input
                type="number"
                value={value[1]}
                onChange={(e) =>
                  onChange([value[0], parseInt(e.target.value) || max])
                }
                className="h-8"
              />
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onClear}
            className="w-full"
          >
            Clear Filter
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
};
