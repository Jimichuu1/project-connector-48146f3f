import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import { usePartnerApiCallLog } from "@/hooks/usePartnerApi";

export function RecentCallsTable() {
  const { data, isLoading } = usePartnerApiCallLog(20);
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent calls</CardTitle>
        <CardDescription>Last 20 outbound calls to the partner site.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8" />
                <TableHead>Endpoint</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Caller</TableHead>
                <TableHead>When</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading && (
                <TableRow><TableCell colSpan={5} className="text-center py-6 text-muted-foreground">Loading...</TableCell></TableRow>
              )}
              {!isLoading && (!data || data.length === 0) && (
                <TableRow><TableCell colSpan={5} className="text-center py-6 text-muted-foreground">No calls yet.</TableCell></TableRow>
              )}
              {(data ?? []).map((row) => {
                const isOpen = expanded === row.id;
                const ok = row.response_status != null && row.response_status >= 200 && row.response_status < 300;
                return (
                  <>
                    <TableRow key={row.id} className="cursor-pointer" onClick={() => setExpanded(isOpen ? null : row.id)}>
                      <TableCell>
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                          {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </Button>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{row.endpoint}</TableCell>
                      <TableCell>
                        <Badge variant={ok ? "default" : "destructive"}>
                          {row.response_status ?? "ERR"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{row.caller_name ?? row.caller_user_id.slice(0, 8)}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(row.created_at), "MMM d, HH:mm:ss")}
                      </TableCell>
                    </TableRow>
                    {isOpen && (
                      <TableRow key={row.id + "-detail"}>
                        <TableCell colSpan={5} className="bg-muted/30">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-2">
                            <div>
                              <div className="text-xs font-medium mb-1">Request</div>
                              <pre className="bg-background border rounded-md p-2 text-xs font-mono overflow-x-auto max-h-60">
                                {JSON.stringify(row.request_payload, null, 2)}
                              </pre>
                            </div>
                            <div>
                              <div className="text-xs font-medium mb-1">Response</div>
                              <pre className="bg-background border rounded-md p-2 text-xs font-mono overflow-x-auto max-h-60">
                                {JSON.stringify(row.response_body, null, 2)}
                              </pre>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
