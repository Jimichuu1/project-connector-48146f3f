import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Copy } from "lucide-react";
import { toast } from "sonner";

const PARTNER_BASE = "https://tvlhwgwftujrecxkmixj.supabase.co/functions/v1";

function CodeBlock({ value }: { value: string }) {
  return (
    <div className="relative group mt-1">
      <pre className="bg-muted/50 border rounded-md p-3 text-xs font-mono overflow-x-auto whitespace-pre">{value}</pre>
      <Button
        size="sm"
        variant="ghost"
        className="absolute top-1.5 right-1.5 h-7 w-7 p-0"
        onClick={() => {
          navigator.clipboard.writeText(value);
          toast.success("Copied");
        }}
      >
        <Copy className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

export function IntegrationGuide() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Integration guide</CardTitle>
        <CardDescription>
          Reference for the partner endpoints. All calls from Kybalion are proxied through a backend
          function so the API key never reaches the browser.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="multiple" className="w-full">
          <AccordionItem value="endpoints">
            <AccordionTrigger>Endpoints</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-1 text-sm">
                <div><code>POST {PARTNER_BASE}/api-create-user</code></div>
                <div><code>POST {PARTNER_BASE}/api-create-transaction</code></div>
                <div><code>POST {PARTNER_BASE}/api-create-user-with-deposit</code></div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                All requests require the header <code>x-api-key: lk_live_...</code>.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="create-user">
            <AccordionTrigger>api-create-user — payload & response</AccordionTrigger>
            <AccordionContent>
              <CodeBlock value={`{
  "email": "u@x.com",
  "password": "strongpass1",
  "display_name": "Jane",     // optional
  "phone": "+15551234567",    // optional
  "country": "Canada"          // optional
}
→ { "user_id": "...", "email": "..." }`} />
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="create-transaction">
            <AccordionTrigger>api-create-transaction — payload & response</AccordionTrigger>
            <AccordionContent>
              <CodeBlock value={`{
  "user_id": "..." ,            // OR "user_email": "u@x.com"
  "type": "deposit|withdrawal|send|receive|buy|swap",
  "token": "BTC",
  "amount": 0.5,
  "usd_value": 32000,
  "status": "pending|completed",
  "tx_hash": "?",                // optional
  "from_address": "?",           // optional
  "network": "?"                 // optional
}
→ { "transaction_id": "...", "tx_ref": "TX-abc12345" }`} />
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="create-user-with-deposit">
            <AccordionTrigger>api-create-user-with-deposit — payload & response</AccordionTrigger>
            <AccordionContent>
              <CodeBlock value={`{
  "email": "u@x.com",
  "password": "strongpass1",
  "display_name": "Jane",
  "deposit": {
    "token": "USDT",
    "amount": 1000,
    "usd_value": 1000,
    "status": "completed",
    "tx_hash": "?",
    "from_address": "?",
    "network": "?"
  }
}
→ { "user_id": "...", "email": "...", "transaction_id": "...", "tx_ref": "TX-..." }`} />
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="curl">
            <AccordionTrigger>Direct curl example (server-side only!)</AccordionTrigger>
            <AccordionContent>
              <p className="text-xs text-muted-foreground mb-2">
                ⚠️ Never call these endpoints from a browser. Always proxy through your backend.
              </p>
              <CodeBlock value={`curl -X POST ${PARTNER_BASE}/api-create-user-with-deposit \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: lk_live_xxxxxxxxxxxxxxxxxxxxxxxx" \\
  -d '{"email":"u@x.com","password":"strongpass1","display_name":"Jane","deposit":{"token":"USDT","amount":1000,"usd_value":1000,"status":"completed"}}'`} />
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
