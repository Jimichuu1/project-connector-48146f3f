import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePartnerApiCall, PartnerCallResult } from "@/hooks/usePartnerApi";
import { toast } from "sonner";
import { ResponsePanel } from "./ResponsePanel";

interface Props {
  endpoint: "create-user" | "create-user-with-deposit";
  withDeposit?: boolean;
}

export function CreateUserForm({ endpoint, withDeposit = false }: Props) {
  const call = usePartnerApiCall();
  const [result, setResult] = useState<PartnerCallResult | null>(null);
  const [form, setForm] = useState({
    email: "",
    password: "",
    display_name: "",
    phone: "",
    country: "",
    deposit_token: "BTC",
    deposit_amount: "",
    deposit_usd_value: "",
    deposit_status: "completed",
    deposit_tx_hash: "",
    deposit_from_address: "",
    deposit_network: "",
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      toast.error("Email and password are required");
      return;
    }

    const payload: Record<string, any> = {
      email: form.email.trim(),
      password: form.password,
    };
    if (form.display_name.trim()) payload.display_name = form.display_name.trim();
    if (form.phone.trim()) payload.phone = form.phone.trim();
    if (form.country.trim()) payload.country = form.country.trim();

    if (withDeposit) {
      const amount = Number(form.deposit_amount);
      const usd = Number(form.deposit_usd_value);
      if (!form.deposit_token || !Number.isFinite(amount) || !Number.isFinite(usd)) {
        toast.error("Deposit token, amount and USD value are required");
        return;
      }
      const deposit: Record<string, any> = {
        token: form.deposit_token.trim(),
        amount,
        usd_value: usd,
        status: form.deposit_status,
      };
      if (form.deposit_tx_hash.trim()) deposit.tx_hash = form.deposit_tx_hash.trim();
      if (form.deposit_from_address.trim()) deposit.from_address = form.deposit_from_address.trim();
      if (form.deposit_network.trim()) deposit.network = form.deposit_network.trim();
      payload.deposit = deposit;
    }

    const res = await call.mutateAsync({ endpoint, payload });
    setResult(res);
    if (res.status >= 200 && res.status < 300) {
      toast.success("Request sent successfully");
    } else {
      toast.error(`Partner returned ${res.status}`);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{withDeposit ? "Create user with initial deposit" : "Create user"}</CardTitle>
        <CardDescription>
          {withDeposit
            ? "Creates a partner user and records an initial deposit in one call."
            : "Creates a new user on the partner site."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label>Email *</Label>
              <Input type="email" value={form.email} onChange={set("email")} required />
            </div>
            <div className="space-y-1">
              <Label>Password *</Label>
              <Input type="password" value={form.password} onChange={set("password")} required minLength={8} />
            </div>
            <div className="space-y-1">
              <Label>Display name</Label>
              <Input value={form.display_name} onChange={set("display_name")} />
            </div>
            <div className="space-y-1">
              <Label>Phone</Label>
              <Input value={form.phone} onChange={set("phone")} />
            </div>
            <div className="space-y-1 md:col-span-2">
              <Label>Country</Label>
              <Input value={form.country} onChange={set("country")} />
            </div>
          </div>

          {withDeposit && (
            <div className="rounded-md border p-4 space-y-4">
              <div className="text-sm font-medium">Initial deposit</div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label>Token *</Label>
                  <Input value={form.deposit_token} onChange={set("deposit_token")} placeholder="BTC" required />
                </div>
                <div className="space-y-1">
                  <Label>Status *</Label>
                  <Select value={form.deposit_status} onValueChange={(v) => setForm((f) => ({ ...f, deposit_status: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">pending</SelectItem>
                      <SelectItem value="completed">completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Amount *</Label>
                  <Input type="number" step="any" value={form.deposit_amount} onChange={set("deposit_amount")} required />
                </div>
                <div className="space-y-1">
                  <Label>USD value *</Label>
                  <Input type="number" step="any" value={form.deposit_usd_value} onChange={set("deposit_usd_value")} required />
                </div>
                <div className="space-y-1">
                  <Label>Tx hash</Label>
                  <Input value={form.deposit_tx_hash} onChange={set("deposit_tx_hash")} />
                </div>
                <div className="space-y-1">
                  <Label>Network</Label>
                  <Input value={form.deposit_network} onChange={set("deposit_network")} placeholder="e.g. TRC20" />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <Label>From address</Label>
                  <Input value={form.deposit_from_address} onChange={set("deposit_from_address")} />
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end">
            <Button type="submit" disabled={call.isPending}>
              {call.isPending ? "Sending..." : "Send request"}
            </Button>
          </div>
        </form>

        {result && <ResponsePanel result={result} className="mt-4" />}
      </CardContent>
    </Card>
  );
}
