import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { usePartnerApiCall, PartnerCallResult } from "@/hooks/usePartnerApi";
import { toast } from "sonner";
import { ResponsePanel } from "./ResponsePanel";

const TX_TYPES = ["deposit", "withdrawal", "send", "receive", "buy", "swap"] as const;

export function CreateTransactionForm() {
  const call = usePartnerApiCall();
  const [result, setResult] = useState<PartnerCallResult | null>(null);
  const [form, setForm] = useState({
    user_email: "",
    user_id: "",
    type: "deposit" as (typeof TX_TYPES)[number],
    token: "USDT",
    amount: "",
    usd_value: "",
    status: "completed",
    tx_hash: "",
    from_address: "",
    network: "",
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.user_email && !form.user_id) {
      toast.error("Provide either user email or user id");
      return;
    }
    const amount = Number(form.amount);
    const usd = Number(form.usd_value);
    if (!Number.isFinite(amount) || !Number.isFinite(usd)) {
      toast.error("Amount and USD value must be numbers");
      return;
    }

    const payload: Record<string, any> = {
      type: form.type,
      token: form.token.trim(),
      amount,
      usd_value: usd,
      status: form.status,
    };
    if (form.user_id.trim()) payload.user_id = form.user_id.trim();
    if (form.user_email.trim()) payload.user_email = form.user_email.trim();
    if (form.tx_hash.trim()) payload.tx_hash = form.tx_hash.trim();
    if (form.from_address.trim()) payload.from_address = form.from_address.trim();
    if (form.network.trim()) payload.network = form.network.trim();

    const res = await call.mutateAsync({ endpoint: "create-transaction", payload });
    setResult(res);
    if (res.status >= 200 && res.status < 300) toast.success("Transaction created");
    else toast.error(`Partner returned ${res.status}`);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create transaction</CardTitle>
        <CardDescription>Records a transaction for an existing partner user.</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label>User email</Label>
              <Input type="email" value={form.user_email} onChange={set("user_email")} />
            </div>
            <div className="space-y-1">
              <Label>or User ID</Label>
              <Input value={form.user_id} onChange={set("user_id")} />
            </div>
            <div className="space-y-1">
              <Label>Type *</Label>
              <Select value={form.type} onValueChange={(v) => setForm((f) => ({ ...f, type: v as any }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TX_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Status *</Label>
              <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">pending</SelectItem>
                  <SelectItem value="completed">completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Token *</Label>
              <Input value={form.token} onChange={set("token")} required />
            </div>
            <div className="space-y-1">
              <Label>Network</Label>
              <Input value={form.network} onChange={set("network")} placeholder="e.g. TRC20" />
            </div>
            <div className="space-y-1">
              <Label>Amount *</Label>
              <Input type="number" step="any" value={form.amount} onChange={set("amount")} required />
            </div>
            <div className="space-y-1">
              <Label>USD value *</Label>
              <Input type="number" step="any" value={form.usd_value} onChange={set("usd_value")} required />
            </div>
            <div className="space-y-1">
              <Label>Tx hash</Label>
              <Input value={form.tx_hash} onChange={set("tx_hash")} />
            </div>
            <div className="space-y-1">
              <Label>From address</Label>
              <Input value={form.from_address} onChange={set("from_address")} />
            </div>
          </div>

          <div className="flex justify-end">
            <Button type="submit" disabled={call.isPending}>
              {call.isPending ? "Sending..." : "Send request"}
            </Button>
          </div>
        </form>

        {result && <ResponsePanel result={result} className="mt-4" />}
      </CardContent>
    </Card>
  );
}
