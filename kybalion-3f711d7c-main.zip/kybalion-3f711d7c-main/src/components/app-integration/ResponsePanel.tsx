import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { PartnerCallResult } from "@/hooks/usePartnerApi";

interface Props {
  result: PartnerCallResult;
  className?: string;
}

export function ResponsePanel({ result, className }: Props) {
  const ok = result.status >= 200 && result.status < 300;
  const text = JSON.stringify(result.body, null, 2);

  return (
    <div className={cn("rounded-md border bg-muted/40", className)}>
      <div className="flex items-center justify-between border-b px-3 py-2">
        <div className="flex items-center gap-2 text-sm">
          <span className="font-medium">Response</span>
          <Badge variant={ok ? "default" : "destructive"}>HTTP {result.status}</Badge>
        </div>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            navigator.clipboard.writeText(text);
            toast.success("Copied");
          }}
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </div>
      <pre className="p-3 text-xs font-mono overflow-x-auto max-h-80">{text}</pre>
    </div>
  );
}
