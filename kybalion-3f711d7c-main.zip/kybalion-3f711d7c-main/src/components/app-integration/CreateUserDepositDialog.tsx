import { useState, type ReactNode } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, UserPlus, CheckCircle2 } from "lucide-react";
import { usePartnerApiCall } from "@/hooks/usePartnerApi";
import { toast } from "sonner";

interface Props {
  trigger?: ReactNode;
  defaults?: {
    email?: string;
    display_name?: string;
    phone?: string;
    country?: string;
  };
  onSuccess?: (response: any) => void;
}

const DEFAULT_PASSWORD = "TSW777";

const initialForm = {
  email: "",
  password: DEFAULT_PASSWORD,
  display_name: "",
  phone: "",
  country: "",
  deposit_token: "BTC",
  deposit_amount: "",
  deposit_usd_value: "",
  deposit_status: "completed",
  deposit_tx_hash: "",
  deposit_from_address: "",
  deposit_network: "",
};

function generatePassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  let out = "";
  for (let i = 0; i < 12; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out + "!9";
}

export function CreateUserDepositDialog({ trigger, defaults, onSuccess }: Props) {
  const call = usePartnerApiCall();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ ...initialForm, ...defaults });
  const [lastResult, setLastResult] = useState<{ ok: boolean; body: any } | null>(null);

  const set = (k: keyof typeof initialForm) =>
    (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const reset = () => {
    setForm({ ...initialForm, ...defaults });
    setLastResult(null);
  };

  const handleOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next) reset();
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.email?.trim()) {
      toast.error("Email is required");
      return;
    }

    const hasDeposit = !!form.deposit_amount?.trim();
    const amount = Number(form.deposit_amount);

    const payload: Record<string, any> = {
      email: form.email.trim(),
      password: form.password,
    };
    if (form.display_name.trim()) payload.display_name = form.display_name.trim();

    if (hasDeposit) {
      if (!Number.isFinite(amount) || amount <= 0) {
        toast.error("Deposit amount must be a positive number");
        return;
      }
      if (!form.deposit_token?.trim()) {
        toast.error("Deposit token is required");
        return;
      }
      payload.deposit = {
        token: form.deposit_token.trim(),
        amount,
        status: form.deposit_status,
      };
      if (form.deposit_tx_hash.trim()) payload.deposit.tx_hash = form.deposit_tx_hash.trim();
      if (form.deposit_from_address.trim()) payload.deposit.from_address = form.deposit_from_address.trim();
      if (form.deposit_network.trim()) payload.deposit.network = form.deposit_network.trim();
    }

    const endpoint = hasDeposit ? "create-user-with-deposit" : "create-user";
    const res = await call.mutateAsync({ endpoint, payload });
    const ok = res.status >= 200 && res.status < 300;
    setLastResult({ ok, body: res.body });
    if (ok) {
      toast.success(hasDeposit ? "User created with deposit" : "User created");
      onSuccess?.(res.body);
    } else {
      const msg = res.body?.error || res.body?.message || `Partner returned ${res.status}`;
      toast.error(typeof msg === "string" ? msg : JSON.stringify(msg));
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button size="sm" variant="outline" className="gap-2">
            <UserPlus className="h-4 w-4" />
            Create user + deposit
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create user with deposit</DialogTitle>
          <DialogDescription>
            Creates a user on the partner site and records an initial deposit in one call.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1 md:col-span-2">
              <Label>Email *</Label>
              <Input type="email" value={form.email} onChange={set("email")} required />
            </div>
            <div className="space-y-1 md:col-span-2">
              <Label>Full name</Label>
              <Input value={form.display_name} onChange={set("display_name")} />
            </div>
          </div>

          <div className="rounded-md border p-3 space-y-3">
            <div className="text-sm font-medium">Add Transaction</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Currency *</Label>
                <Select value={form.deposit_token} onValueChange={(v) => setForm((f) => ({ ...f, deposit_token: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["BTC","ETH","SOL","USDT","USDC","BNB","XRP","ADA","DOGE","DOT","AVAX","MATIC","USD","EUR","GBP","CAD"].map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Status *</Label>
                <Select value={form.deposit_status} onValueChange={(v) => setForm((f) => ({ ...f, deposit_status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">pending</SelectItem>
                    <SelectItem value="completed">completed</SelectItem>
                    <SelectItem value="flagged">flagged</SelectItem>
                    <SelectItem value="rejected">rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1 md:col-span-2">
                <Label>Amount</Label>
                <Input type="number" step="any" value={form.deposit_amount} onChange={set("deposit_amount")} placeholder="Leave empty to skip deposit" />
              </div>
              <div className="space-y-1 md:col-span-2">
                <Label>Source / From</Label>
                <Input
                  value={form.deposit_from_address}
                  onChange={set("deposit_from_address")}
                  placeholder="Type or pick a preset"
                  list="from-address-presets"
                />
                <datalist id="from-address-presets">
                  <option value="Operation Pandora" />
                  <option value="Operation First Light" />
                </datalist>
                <div className="flex gap-2 pt-1">
                  {["Operation Pandora", "Operation First Light"].map((preset) => (
                    <Button
                      key={preset}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setForm((f) => ({ ...f, deposit_from_address: preset }))}
                    >
                      {preset}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {lastResult?.ok && (
            <div className="rounded-md border border-emerald-500/30 bg-emerald-500/10 p-3 text-sm flex items-start gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-0.5" />
              <div className="flex-1 space-y-1">
                <div className="font-medium text-emerald-600 dark:text-emerald-400">Created successfully</div>
                {lastResult.body?.user_id && <div className="font-mono text-xs">user_id: {lastResult.body.user_id}</div>}
                {lastResult.body?.tx_ref && <div className="font-mono text-xs">tx_ref: {lastResult.body.tx_ref}</div>}
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button type="button" variant="ghost" onClick={() => handleOpenChange(false)}>Close</Button>
            <Button type="submit" disabled={call.isPending}>
              {call.isPending ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              Send
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
