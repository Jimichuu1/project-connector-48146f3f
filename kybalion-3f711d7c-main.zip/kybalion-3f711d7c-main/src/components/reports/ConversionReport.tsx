import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, Users, Target } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import type { ConversionMetrics, ConversionByAgent, TransferBySuperAgent } from "@/types/reports";
import { useLeadStatuses } from "@/hooks/useLeadStatuses";
import { useTenantSettings } from "@/hooks/useTenantSettings";

interface ConversionReportProps {
  data: ConversionMetrics | null;
  isLoading?: boolean;
  showAgentConversions?: boolean;
  isTenantOwner?: boolean;
}

const agentChartConfig = {
  converted: {
    label: "Converted",
    color: "hsl(var(--primary))",
  },
};

const superAgentChartConfig = {
  clients_received: {
    label: "Clients Received",
    color: "hsl(var(--primary))",
  },
};

export const ConversionReport = ({ data, isLoading, showAgentConversions = false, isTenantOwner = false }: ConversionReportProps) => {
  // Statuses still used by non-TO branches
  useLeadStatuses();

  // Tenant target — used to compute progress for TO cards
  const { settings: tenantSettings } = useTenantSettings();
  const conversionTarget = useMemo(() => {
    const t = (tenantSettings as { conversion_target_per_agent?: number } | null)?.conversion_target_per_agent;
    return typeof t === "number" && t > 0 ? t : 28;
  }, [tenantSettings]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-4 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!data) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load conversion data. Please try again.
        </AlertDescription>
      </Alert>
    );
  }

  // Top summary cards (shared)
  const summaryCards = (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="bg-primary text-primary-foreground">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{data.total_leads}</div>
        </CardContent>
      </Card>
      <Card className="bg-primary text-primary-foreground">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Converted (Period)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{data.total_converted}</div>
        </CardContent>
      </Card>
      <Card className="bg-primary text-primary-foreground">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{data.total_clients ?? 0}</div>
        </CardContent>
      </Card>
    </div>
  );

  // ------- Tenant Owner: cards-only layout with progress bars -------
  if (isTenantOwner) {
    const agents = (data.conversion_by_agent ?? [])
      .slice()
      .sort((a, b) => b.converted - a.converted);

    return (
      <div className="space-y-6">
        {summaryCards}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Conversions by Agent
              <span className="ml-auto text-xs text-muted-foreground font-normal">
                Target: {conversionTarget} per agent
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {agents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No conversions yet for this period</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {agents.map((agent: ConversionByAgent) => {
                  const converted = agent.converted ?? 0;
                  const deposits = Number(agent.total_deposits ?? 0);
                  const pct = Math.min(100, (converted / conversionTarget) * 100);
                  const reached = converted >= conversionTarget;
                  return (
                    <div
                      key={agent.agent_id}
                      className="rounded-lg border bg-card p-4 space-y-3"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-medium text-sm truncate">{agent.agent_name}</div>
                        {reached && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                            Goal ✓
                          </span>
                        )}
                      </div>

                      <div className="space-y-1.5">
                        <Progress value={pct} className="h-2" />
                        <div className="flex items-baseline justify-between text-xs">
                          <span className="text-muted-foreground">
                            {converted} / {conversionTarget}
                          </span>
                          <span className="font-semibold text-primary">
                            {pct.toFixed(0)}%
                          </span>
                        </div>
                      </div>

                      <div className="pt-1 border-t border-border/50">
                        <div className="text-xs text-muted-foreground">Deposits</div>
                        <div className="text-base font-semibold">
                          {formatCurrency(deposits)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!data) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load conversion data. Please try again.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {summaryCards}

      {(data.conversion_by_agent && data.conversion_by_agent.length > 0) || showAgentConversions ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Conversions by Agent
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.conversion_by_agent && data.conversion_by_agent.length > 0 ? (
              <>
                <ChartContainer
                  config={agentChartConfig}
                  className="w-full mb-6"
                  style={{ height: Math.max(300, Math.min(data.conversion_by_agent.length, 10) * 35) }}
                >
                  <BarChart
                    data={data.conversion_by_agent.slice(0, 10)}
                    accessibilityLayer
                    layout="vertical"
                    barCategoryGap={5}
                  >
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis type="number" tickLine={false} axisLine={false} />
                    <YAxis
                      type="category"
                      dataKey="agent_name"
                      tickLine={false}
                      axisLine={false}
                      width={120}
                      interval={0}
                      className="text-muted-foreground text-xs"
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="converted" fill="var(--color-converted)" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ChartContainer>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                  {data.conversion_by_agent.map((agent: ConversionByAgent) => (
                    <div key={agent.agent_id} className="rounded-lg border bg-card p-3 space-y-1">
                      <div className="font-medium text-sm truncate">{agent.agent_name}</div>
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="text-xs text-muted-foreground">Converted</span>
                        <span className="text-sm font-semibold text-primary">{agent.converted}</span>
                      </div>
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="text-xs text-muted-foreground">Rate</span>
                        <span className="text-xs">{agent.conversion_rate.toFixed(1)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No agent conversions yet for this period</p>
              </div>
            )}
          </CardContent>
        </Card>
      ) : null}

      {data.transfers_by_super_agent && data.transfers_by_super_agent.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Clients Received by Super Agent
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={superAgentChartConfig}
              className="w-full mb-6"
              style={{ height: Math.max(300, (data.transfers_by_super_agent?.length ?? 0) * 35) }}
            >
              <BarChart
                data={data.transfers_by_super_agent}
                accessibilityLayer
                layout="vertical"
                barCategoryGap={5}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis type="number" tickLine={false} axisLine={false} />
                <YAxis
                  type="category"
                  dataKey="super_agent_name"
                  tickLine={false}
                  axisLine={false}
                  width={120}
                  interval={0}
                  className="text-muted-foreground text-xs"
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="clients_received" fill="var(--color-clients_received)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ChartContainer>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
              {data.transfers_by_super_agent.map((sa: TransferBySuperAgent) => (
                <div key={sa.super_agent_id} className="rounded-lg border bg-card p-3 space-y-1">
                  <div className="font-medium text-sm truncate">{sa.super_agent_name}</div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-xs text-muted-foreground">Clients</span>
                    <span className="text-sm font-semibold text-primary">{sa.clients_received}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
