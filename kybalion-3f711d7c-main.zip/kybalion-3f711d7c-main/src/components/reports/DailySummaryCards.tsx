import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { startOfDay, endOfDay, format } from "date-fns";
import { Users, DollarSign, Receipt, CalendarIcon, UserPlus } from "lucide-react";
import { cn } from "@/lib/utils";

interface DailySummary {
  totalConversions: number;
  totalDepositAmount: number;
  depositCount: number;
  liveClientsCreated: number;
}

export function DailySummaryCards() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const { effectiveTenantId } = useTenant();
  const dayStart = startOfDay(selectedDate).toISOString();
  const dayEnd = endOfDay(selectedDate).toISOString();

  const { data, isLoading } = useQuery({
    queryKey: ['daily-summary', effectiveTenantId, dayStart],
    queryFn: async (): Promise<DailySummary> => {
      // Fetch conversions (clients converted from leads)
      let conversionsQuery = supabase
        .from('clients')
        .select('id', { count: 'exact', head: true })
        .not('converted_from_lead_id', 'is', null)
        .gte('created_at', dayStart)
        .lte('created_at', dayEnd);

      if (effectiveTenantId) {
        conversionsQuery = conversionsQuery.eq('admin_id', effectiveTenantId);
      }

      const { count: conversionsCount } = await conversionsQuery;

      // Fetch approved deposits
      let depositsQuery = supabase
        .from('deposits')
        .select('amount')
        .eq('status', 'approved')
        .gte('created_at', dayStart)
        .lte('created_at', dayEnd);

      if (effectiveTenantId) {
        depositsQuery = depositsQuery.eq('admin_id', effectiveTenantId);
      }

      const { data: deposits } = await depositsQuery;

      const totalDepositAmount = deposits?.reduce((sum, d) => sum + (d.amount || 0), 0) || 0;
      const depositCount = deposits?.length || 0;

      // Fetch live clients created on the selected day
      // Live clients = manually created clients (not converted from leads)
      let liveClientsQuery = supabase
        .from('clients')
        .select('id', { count: 'exact', head: true })
        .is('converted_from_lead_id', null)
        .gte('created_at', dayStart)
        .lte('created_at', dayEnd);

      if (effectiveTenantId) {
        liveClientsQuery = liveClientsQuery.eq('admin_id', effectiveTenantId);
      }

      const { count: liveClientsCount } = await liveClientsQuery;

      return {
        totalConversions: conversionsCount || 0,
        totalDepositAmount,
        depositCount,
        liveClientsCreated: liveClientsCount || 0,
      };
    },
    staleTime: 1000 * 60 * 5,
  });

  const isToday = format(selectedDate, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
  const dateLabel = isToday ? "Today" : format(selectedDate, "MMM d, yyyy");

  const cards = [
    {
      title: `${dateLabel}'s Conversions`,
      value: data?.totalConversions || 0,
      icon: Users,
      description: "Leads converted to clients",
    },
    {
      title: `${dateLabel}'s Deposit Amount`,
      value: `$${(data?.totalDepositAmount || 0).toLocaleString()}`,
      icon: DollarSign,
      description: "Total approved deposits",
    },
    {
      title: `${dateLabel}'s Deposits`,
      value: data?.depositCount || 0,
      icon: Receipt,
      description: "Number of deposits",
    },
    {
      title: `${dateLabel}'s Direct Clients`,
      value: data?.liveClientsCreated || 0,
      icon: UserPlus,
      description: "Clients created directly (not from leads)",
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Daily Summary</h3>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <CalendarIcon className="h-4 w-4" />
              {format(selectedDate, "MMM d, yyyy")}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              disabled={(date) => date > new Date()}
              initialFocus
              className={cn("p-3 pointer-events-auto")}
            />
          </PopoverContent>
        </Popover>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-20" />
                <Skeleton className="h-3 w-16 mt-1" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-4">
          {cards.map((card) => (
            <Card key={card.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                <card.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground">{card.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
