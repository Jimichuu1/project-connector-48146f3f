import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useDeposits, DepositWithProfiles } from "@/hooks/useDeposits";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { DateRangePicker } from "@/components/reports/DateRangePicker";
import { DateRange } from "@/types/reports";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Download, DollarSign, TrendingUp, ChevronRight, Check, X as XIcon, Search } from "lucide-react";
import { format, startOfMonth, endOfMonth, subMonths, startOfWeek, endOfWeek, subDays, startOfDay, endOfDay } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { useUserRole } from "@/hooks/useUserRole";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { useCommissionTierSettings } from "@/hooks/useCommissionTierSettings";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/utils";

import { toast } from "sonner";

interface DepositsReportProps {
  startDate: Date;
  endDate: Date;
}

interface AgentTotal {
  agent_id: string;
  agent_name: string;
  avatar_url?: string | null;
  total_amount: number;
  deposit_count: number;
  total_agent_amount: number;
}

interface SuperAgentTotal {
  super_agent_id: string;
  super_agent_name: string;
  avatar_url?: string | null;
  total_amount: number;
  deposit_count: number;
  total_super_agent_amount: number;
  tier_index: number;
  tier_total: number;
  tier_percent: number;
  transfers_received: number;
  upsale_ratio: number;
}

export const DepositsReport = ({ startDate, endDate }: DepositsReportProps) => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const { isManager, isTenantOwner, isSuperAdmin } = useUserRole();
  const { teamMemberIds, agentIds: managerAgentIds, superAgentIds: managerSuperAgentIds } = useManagerTeam();
  const isManagerOrTL = isManager;
  // Tier settings for the month containing endDate (so cards reflect the displayed period)
  const tierMonth = format(endDate, "yyyy-MM");
  const { tierSettings } = useCommissionTierSettings(tierMonth);
  // Only Tenant Owner and Super Admin can approve deposits (not Manager)
  const canApproveDeposits = isTenantOwner || isSuperAdmin;
  const today = new Date();
  const [dateRange, setDateRange] = useState<DateRange>({
    from: startDate,
    to: endDate,
  });
  const [selectedPreset, setSelectedPreset] = useState<string>("custom");
  const [selectedAgent, setSelectedAgent] = useState<string>("all");
  const [selectedSuperAgent, setSelectedSuperAgent] = useState<string>("all");
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [selectedUserName, setSelectedUserName] = useState<string>("");
  const [userType, setUserType] = useState<"agent" | "super_agent">("agent");
  const [isAgent, setIsAgent] = useState(false);
  const [pendingApproval, setPendingApproval] = useState<DepositWithProfiles | null>(null);
  const [pendingRejection, setPendingRejection] = useState<string | null>(null);
  
  const [tableSearch, setTableSearch] = useState("");
  const [tableStatusFilter, setTableStatusFilter] = useState<string>("all");
  const [tableAgentFilter, setTableAgentFilter] = useState<string>("all");
  const [tableSAFilter, setTableSAFilter] = useState<string>("all");
  

  // Sync with parent date range
  useEffect(() => {
    setDateRange({ from: startDate, to: endDate });
    setSelectedPreset("custom");
  }, [startDate, endDate]);

  const { deposits, isLoading: depositsLoading } = useDeposits(dateRange.from, dateRange.to);

  useEffect(() => {
    const checkUserRole = async () => {
      if (user) {
        const { data: roles } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id);
        
        if (roles) {
          const isAgentRole = roles.some(r => r.role === "AGENT") && !roles.some(r => ["TENANT_OWNER", "MANAGER", "SUPER_AGENT"].includes(r.role));
          setIsAgent(isAgentRole);
          
          // Auto-select current user for agents
          if (isAgentRole && user.id) {
            setSelectedAgent(user.id);
          }
        }
      }
    };
    checkUserRole();
  }, [user]);

  // Date preset handlers
  const handleDatePreset = (preset: string) => {
    setSelectedPreset(preset);
    const today = new Date();
    
    switch (preset) {
      case "all-time":
        setDateRange({ from: new Date(2020, 0, 1), to: endOfMonth(today) });
        break;
      case "today":
        setDateRange({ from: startOfDay(today), to: endOfDay(today) });
        break;
      case "yesterday":
        const yesterday = subDays(today, 1);
        setDateRange({ from: startOfDay(yesterday), to: endOfDay(yesterday) });
        break;
      case "week":
        setDateRange({ from: startOfWeek(today), to: endOfWeek(today) });
        break;
      case "month":
        setDateRange({ from: startOfMonth(today), to: endOfMonth(today) });
        break;
    }
  };

  // Fetch all agents and super agents (including TENANT_OWNER who can act as super agents)
  // For managers, only show their team members
  const { data: agents } = useQuery({
    queryKey: ["agents", effectiveTenantId, isManagerOrTL, managerAgentIds, managerSuperAgentIds],
    queryFn: async () => {
      // For managers/TLs, use their team member IDs directly
      if (isManagerOrTL && teamMemberIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, full_name, email, admin_id, avatar_url")
          .in("id", teamMemberIds);
        
        if (!profiles || profiles.length === 0) return { agents: [], superAgents: [] };

        const { data: agentRoles } = await supabase
          .from("user_roles")
          .select("user_id, role")
          .in("role", ["AGENT", "SUPER_AGENT"])
          .in("user_id", teamMemberIds);

        if (!agentRoles) return { agents: [], superAgents: [] };

        const agentIds = agentRoles.filter(r => r.role === "AGENT").map((r) => r.user_id);
        const superAgentIds = agentRoles.filter(r => r.role === "SUPER_AGENT").map((r) => r.user_id);

        const agentsList = profiles.filter(p => agentIds.includes(p.id));
        const superAgentsList = profiles.filter(p => superAgentIds.includes(p.id));

        return { agents: agentsList, superAgents: superAgentsList };
      }

      // For non-managers, get all tenant users
      let profilesQuery = supabase
        .from("profiles")
        .select("id, full_name, email, admin_id, avatar_url");

      // Filter by tenant - must match admin_id OR be the tenant owner themselves
      if (effectiveTenantId) {
        profilesQuery = profilesQuery.or(`admin_id.eq.${effectiveTenantId},id.eq.${effectiveTenantId}`);
      }

      const { data: profiles } = await profilesQuery;
      if (!profiles || profiles.length === 0) return { agents: [], superAgents: [] };

      const tenantUserIds = profiles.map(p => p.id);

      // Then get roles only for those tenant users
      const { data: agentRoles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("role", ["AGENT", "SUPER_AGENT", "TENANT_OWNER"])
        .in("user_id", tenantUserIds);

      if (!agentRoles) return { agents: [], superAgents: [] };

      const agentIds = agentRoles.filter(r => r.role === "AGENT").map((r) => r.user_id);
      const superAgentIds = agentRoles.filter(r => r.role === "SUPER_AGENT" || r.role === "TENANT_OWNER").map((r) => r.user_id);

      const agentsList = profiles.filter(p => agentIds.includes(p.id));
      const superAgentsList = profiles.filter(p => superAgentIds.includes(p.id));

      return { agents: agentsList, superAgents: superAgentsList };
    },
  });

  // Filter deposits - For agents, show deposits where they are the agent
  // For super agents, also include deposits where they are the split_super_agent
  // For managers, filter to only show their team's deposits
  const filteredDeposits =
    deposits?.filter((deposit) => {
      if (isAgent && user?.id) {
        // Agents see deposits where they are the agent_id, closer_agent_id, super_agent_id, or split_super_agent_id
        return deposit.agent_id === user.id || deposit.closer_agent_id === user.id || deposit.super_agent_id === user.id || deposit.split_super_agent_id === user.id;
      }
      
      // For managers, filter to team members only
      if (isManagerOrTL && teamMemberIds.length > 0) {
        const isTeamDeposit = 
          (deposit.agent_id && teamMemberIds.includes(deposit.agent_id)) ||
          (deposit.super_agent_id && teamMemberIds.includes(deposit.super_agent_id)) ||
          (deposit.split_super_agent_id && teamMemberIds.includes(deposit.split_super_agent_id));
        if (!isTeamDeposit) return false;
      }
      
      if (selectedAgent !== "all" && deposit.agent_id !== selectedAgent) return false;
      if (selectedSuperAgent !== "all" && deposit.super_agent_id !== selectedSuperAgent && deposit.split_super_agent_id !== selectedSuperAgent) return false;
      return true;
    }) || [];

  // Calculate agent totals - include all agents even with $0
  const agentTotals: AgentTotal[] = [];
  const agentMap = new Map<string, AgentTotal>();

  // Initialize all agents with $0
  (agents?.agents || []).forEach((agent) => {
    agentMap.set(agent.id, {
      agent_id: agent.id,
      agent_name: agent.full_name || agent.email,
      avatar_url: (agent as any).avatar_url ?? null,
      total_amount: 0,
      deposit_count: 0,
      total_agent_amount: 0,
    });
  });

  // Update with actual deposit data
  // When closer_agent_id exists, split 50/50 between transferring agent and closer agent
  // GATED by counts_for_agent: agent attribution only counts when toggled ON.
  filteredDeposits.forEach((deposit) => {
    if (!(deposit as { counts_for_agent?: boolean }).counts_for_agent) return;

    const depositAmount = Number(deposit.amount);
    const hasCloser = !!deposit.closer_agent_id;

    // Transferring agent (agent_id)
    if (deposit.agent_id) {
      const agentTotal = agentMap.get(deposit.agent_id);
      if (agentTotal) {
        // If closer exists, transferring agent gets 50%, otherwise full amount
        agentTotal.total_amount += hasCloser ? depositAmount / 2 : depositAmount;
        agentTotal.deposit_count += hasCloser ? 0.5 : 1;
        agentTotal.total_agent_amount += Number(deposit.agent_amount);
      }
    }

    // Closer agent gets 50% of deposit
    if (hasCloser) {
      const closerTotal = agentMap.get(deposit.closer_agent_id!);
      if (closerTotal) {
        closerTotal.total_amount += depositAmount / 2;
        closerTotal.deposit_count += 0.5;
        closerTotal.total_agent_amount += 0; // closer doesn't get agent_amount
      }
    }
  });

  agentMap.forEach((value) => agentTotals.push(value));
  agentTotals.sort((a, b) => b.total_amount - a.total_amount);

  // Calculate super agent totals - include all super agents even with $0
  const superAgentTotals: SuperAgentTotal[] = [];
  const superAgentMap = new Map<string, SuperAgentTotal>();

  const makeSuperAgentTotal = (id: string, name: string, avatar_url?: string | null): SuperAgentTotal => ({
    super_agent_id: id,
    super_agent_name: name,
    avatar_url: avatar_url ?? null,
    total_amount: 0,
    deposit_count: 0,
    total_super_agent_amount: 0,
    tier_index: 0,
    tier_total: 0,
    tier_percent: 0,
    transfers_received: 0,
    upsale_ratio: 0,
  });

  // Initialize all super agents with $0 (or only connected ones for agents)
  if (isAgent && user?.id) {
    // For agents, only show super agents they're connected to through deposits
    const connectedSuperAgentIds = new Set<string>();
    filteredDeposits.forEach((deposit) => {
      if (deposit.agent_id === user.id && deposit.super_agent_id) {
        connectedSuperAgentIds.add(deposit.super_agent_id);
      }
    });
    
    (agents?.superAgents || [])
      .filter(sa => connectedSuperAgentIds.has(sa.id))
      .forEach((superAgent) => {
        superAgentMap.set(superAgent.id, makeSuperAgentTotal(superAgent.id, superAgent.full_name || superAgent.email, (superAgent as any).avatar_url));
      });
  } else {
    // For non-agents, show all super agents
    (agents?.superAgents || []).forEach((superAgent) => {
      superAgentMap.set(superAgent.id, makeSuperAgentTotal(superAgent.id, superAgent.full_name || superAgent.email, (superAgent as any).avatar_url));
    });
  }

  // Update with actual deposit data - Super agents get their portion based on split
  filteredDeposits.forEach((deposit) => {
    const hasSplit = deposit.split_super_agent_id && deposit.split_super_agent_id !== null;
    const depositAmount = Number(deposit.amount);
    
    // Working Super Agent (primary) - gets 100% of deposit if no split, 50% if split
    if (deposit.super_agent_id) {
      let superAgentTotal = superAgentMap.get(deposit.super_agent_id);
      
      // If super agent not in map yet, add them dynamically from deposit data
      if (!superAgentTotal) {
        const superAgentProfile = deposit.super_agent;
        superAgentTotal = makeSuperAgentTotal(
          deposit.super_agent_id,
          superAgentProfile?.full_name || superAgentProfile?.email || "Unknown",
          (superAgentProfile as any)?.avatar_url
        );
        superAgentMap.set(deposit.super_agent_id, superAgentTotal);
      }
      
      // Report shows deposit amount attributed to this super agent
      const theirAmount = hasSplit ? depositAmount / 2 : depositAmount;
      superAgentTotal.total_amount += theirAmount;
      superAgentTotal.deposit_count += 1;
      superAgentTotal.total_super_agent_amount += Number(deposit.super_agent_amount);
    }
    
    // Split Super Agent - gets 50% of deposit amount
    if (hasSplit) {
      let splitAgentTotal = superAgentMap.get(deposit.split_super_agent_id!);
      
      // If split agent not in map yet, add them dynamically from deposit data
      if (!splitAgentTotal) {
        const splitAgentProfile = deposit.split_super_agent;
        splitAgentTotal = makeSuperAgentTotal(
          deposit.split_super_agent_id!,
          splitAgentProfile?.full_name || splitAgentProfile?.email || "Unknown",
          (splitAgentProfile as any)?.avatar_url
        );
        superAgentMap.set(deposit.split_super_agent_id!, splitAgentTotal);
      }
      
      // Split agent gets 50% of deposit amount for report
      splitAgentTotal.total_amount += depositAmount / 2;
      splitAgentTotal.deposit_count += 1;
      splitAgentTotal.total_super_agent_amount += Number(deposit.split_super_agent_amount);
    }
  });

  superAgentMap.forEach((value) => superAgentTotals.push(value));

  // Fixed current-month bounds — Transfers metric always reflects this calendar month
  const lastMonthStart = useMemo(() => startOfMonth(new Date()), []);
  const lastMonthEnd = useMemo(() => endOfMonth(new Date()), []);
  const lastMonthKey = format(lastMonthStart, "yyyy-MM");

  // Fetch transfers received per super agent for LAST MONTH (clients converted to this SA)
  const { data: receivedTransfers } = useQuery({
    queryKey: ["sa-transfers-received-last-month", effectiveTenantId, lastMonthKey],
    enabled: !!effectiveTenantId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("id, conversion_super_agent_id, created_at")
        .eq("admin_id", effectiveTenantId!)
        .not("conversion_super_agent_id", "is", null)
        .gte("created_at", lastMonthStart.toISOString())
        .lte("created_at", lastMonthEnd.toISOString());
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch LAST MONTH deposits (used only for Upsale numerator so it stays consistent with Transfers)
  const { data: lastMonthDeposits } = useQuery({
    queryKey: ["sa-deposits-last-month", effectiveTenantId, lastMonthKey],
    enabled: !!effectiveTenantId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("deposits")
        .select("client_id, super_agent_id, split_super_agent_id, created_at, status")
        .eq("admin_id", effectiveTenantId!)
        .eq("status", "approved")
        .gte("created_at", lastMonthStart.toISOString())
        .lte("created_at", lastMonthEnd.toISOString());
      if (error) throw error;
      return data || [];
    },
  });

  // Compute transfers received per SA + which client_ids were received
  const transfersBySA = new Map<string, Set<string>>();
  (receivedTransfers || []).forEach((c) => {
    if (!c.conversion_super_agent_id) return;
    const set = transfersBySA.get(c.conversion_super_agent_id) || new Set<string>();
    set.add(c.id);
    transfersBySA.set(c.conversion_super_agent_id, set);
  });

  // Compute deposited client_ids per SA from filtered deposits (used for visible Deposits field)
  const depositedClientsBySA = new Map<string, Set<string>>();
  filteredDeposits.forEach((d) => {
    const ids = [d.super_agent_id, d.split_super_agent_id].filter(Boolean) as string[];
    ids.forEach((saId) => {
      const set = depositedClientsBySA.get(saId) || new Set<string>();
      if (d.client_id) set.add(d.client_id);
      depositedClientsBySA.set(saId, set);
    });
  });

  // Last-month deposited client_ids per SA — used only for Upsale numerator so it lines up with Transfers
  const lastMonthDepositedClientsBySA = new Map<string, Set<string>>();
  (lastMonthDeposits || []).forEach((d) => {
    const ids = [d.super_agent_id, d.split_super_agent_id].filter(Boolean) as string[];
    ids.forEach((saId) => {
      const set = lastMonthDepositedClientsBySA.get(saId) || new Set<string>();
      if (d.client_id) set.add(d.client_id);
      lastMonthDepositedClientsBySA.set(saId, set);
    });
  });

  // Sort tiers ascending by minDeposit so index = "skip" (0-based)
  const sortedSATiers = [...(tierSettings?.super_agent_base_salary_tiers || [])].sort(
    (a, b) => a.minDeposit - b.minDeposit
  );
  const tierTotal = sortedSATiers.length;

  // Enrich each super agent total with tier_index, transfers_received, upsale_ratio
  superAgentTotals.forEach((sa) => {
    // Tier index from total deposits attributed to this SA
    let idx = 0;
    for (let i = 0; i < sortedSATiers.length; i++) {
      if (sa.total_amount >= sortedSATiers[i].minDeposit) idx = i;
    }
    sa.tier_index = idx;
    sa.tier_total = tierTotal;
    sa.tier_percent = sortedSATiers[idx]?.commissionPercent ?? 0;

    const received = transfersBySA.get(sa.super_agent_id);
    sa.transfers_received = received ? received.size : 0;

    // Upsale ratio uses last-month deposits to stay consistent with last-month transfers
    const lastMonthDepositedSet = lastMonthDepositedClientsBySA.get(sa.super_agent_id) || new Set<string>();
    const depositedFromReceived = received
      ? [...lastMonthDepositedSet].filter((cid) => received.has(cid)).length
      : 0;
    sa.upsale_ratio = sa.transfers_received > 0
      ? (depositedFromReceived / sa.transfers_received) * 100
      : 0;
  });

  superAgentTotals.sort((a, b) => b.total_amount - a.total_amount);

  // Get deposits for selected user (include split super agent)
  const userDeposits: DepositWithProfiles[] = selectedUserId
    ? filteredDeposits.filter((d) =>
        userType === "agent" 
          ? d.agent_id === selectedUserId 
          : (d.super_agent_id === selectedUserId || d.split_super_agent_id === selectedUserId)
      )
    : [];

  // Sorted and table-filtered deposits for the main table
  const sortedFilteredDeposits = useMemo(() => {
    let result = [...filteredDeposits];
    
    // Apply table-specific filters
    if (tableSearch) {
      const search = tableSearch.toLowerCase();
      result = result.filter(d => 
        (d.client?.name || "").toLowerCase().includes(search) ||
        (d.agent?.full_name || d.agent?.email || "").toLowerCase().includes(search) ||
        (d.super_agent?.full_name || d.super_agent?.email || "").toLowerCase().includes(search)
      );
    }
    if (tableStatusFilter !== "all") {
      result = result.filter(d => d.status === tableStatusFilter);
    }
    if (tableAgentFilter !== "all") {
      result = result.filter(d => d.agent_id === tableAgentFilter || d.closer_agent_id === tableAgentFilter);
    }
    if (tableSAFilter !== "all") {
      result = result.filter(d => d.super_agent_id === tableSAFilter || d.split_super_agent_id === tableSAFilter);
    }
    
    return result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }, [filteredDeposits, tableSearch, tableStatusFilter, tableAgentFilter, tableSAFilter]);


  // Calculate summary stats
  const totalDeposits = filteredDeposits.reduce((sum, d) => sum + Number(d.amount), 0);
  const totalAgentEarnings = filteredDeposits.reduce((sum, d) => sum + Number(d.agent_amount), 0);
  const totalSuperAgentEarnings = filteredDeposits.reduce(
    (sum, d) => sum + Number(d.super_agent_amount) + Number(d.split_super_agent_amount || 0),
    0
  );

  // Export to CSV
  const handleExport = () => {
    const headers = [
      "Agent ID",
      "Agent Name",
      "Total Deposits",
      "Deposit Count",
      "Agent Earnings",
      "Super Agent ID",
      "Super Agent Name",
      "Super Agent Earnings",
    ];

    const rows = filteredDeposits.map((deposit) => [
      deposit.agent_id || "",
      deposit.agent?.full_name || deposit.agent?.email || "",
      deposit.amount,
      "1",
      deposit.agent_amount,
      deposit.super_agent_id || "",
      deposit.super_agent?.full_name || deposit.super_agent?.email || "",
      deposit.super_agent_amount,
    ]);

    const csv = [headers, ...rows].map((row) => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `deposits-report-${format(dateRange.from, "yyyy-MM-dd")}-to-${format(dateRange.to, "yyyy-MM-dd")}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Handle approve/reject
  const confirmApprove = async () => {
    if (!pendingApproval) return;

    try {
      const { error } = await supabase
        .from("deposits")
        .update({
          status: "approved",
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
        })
        .eq("id", pendingApproval.id);

      if (error) throw error;

      // Send DEPOSIT_APPROVED notifications to involved agents
      const approvalNotifications = [];
      if (pendingApproval.super_agent_id) {
        approvalNotifications.push({
          user_id: pendingApproval.super_agent_id,
          type: "DEPOSIT_APPROVED" as const,
          message: `Your deposit of $${pendingApproval.amount} for ${pendingApproval.client?.name || 'client'} has been approved`,
          related_entity_type: "deposit",
          related_entity_id: pendingApproval.id,
          admin_id: pendingApproval.admin_id,
        });
      }
      if (pendingApproval.split_super_agent_id) {
        approvalNotifications.push({
          user_id: pendingApproval.split_super_agent_id,
          type: "DEPOSIT_APPROVED" as const,
          message: `A split deposit of $${Number(pendingApproval.amount) / 2} for ${pendingApproval.client?.name || 'client'} has been approved`,
          related_entity_type: "deposit",
          related_entity_id: pendingApproval.id,
          admin_id: pendingApproval.admin_id,
        });
      }
      // NOTE: Transferring/closer agent notifications are gated by the
      // `counts_for_agent` toggle and sent by the DB trigger
      // `notify_agent_on_deposit_counted_trg` only when a Tenant Owner /
      // Super Admin flips it ON.
      if (approvalNotifications.length > 0) {
        await supabase.from("notifications").insert(approvalNotifications);
      }

      toast.success("Deposit approved successfully");

      setPendingApproval(null);

      // Refresh deposits list
      window.location.reload();
    } catch (error) {
      console.error("Error approving deposit:", error);
      toast.error("Failed to approve deposit");
    }
  };

  const confirmReject = async () => {
    if (!pendingRejection) return;

    try {
      const { error } = await supabase
        .from("deposits")
        .update({
          status: "rejected",
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
        })
        .eq("id", pendingRejection);

      if (error) throw error;

      toast.success("Deposit rejected");
      setPendingRejection(null);

      // Refresh deposits list
      window.location.reload();
    } catch (error) {
      console.error("Error rejecting deposit:", error);
      toast.error("Failed to reject deposit");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-muted-foreground text-sm">
            {isAgent 
              ? "Your deposit totals and earnings from assigned leads"
              : "Monthly deposit totals by agent and super agent"
            }
          </p>
        </div>
        <Button onClick={handleExport} size="sm">
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* Filters - Hidden for agents */}
      {!isAgent && (
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <Select value={selectedAgent} onValueChange={setSelectedAgent}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Agents" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Agents</SelectItem>
                {(agents?.agents || []).map((agent) => (
                  <SelectItem key={agent.id} value={agent.id}>
                    {agent.full_name || agent.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedSuperAgent} onValueChange={setSelectedSuperAgent}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Super Agents" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Super Agents</SelectItem>
                {(agents?.superAgents || []).map((agent) => (
                  <SelectItem key={agent.id} value={agent.id}>
                    {agent.full_name || agent.email}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant={selectedPreset === "all-time" ? "default" : "outline"}
            size="sm"
            onClick={() => handleDatePreset("all-time")}
          >
            All time
          </Button>
          <Button
            variant={selectedPreset === "today" ? "default" : "outline"}
            size="sm"
            onClick={() => handleDatePreset("today")}
          >
            Today
          </Button>
          <Button
            variant={selectedPreset === "yesterday" ? "default" : "outline"}
            size="sm"
            onClick={() => handleDatePreset("yesterday")}
          >
            Yesterday
          </Button>
          <Button
            variant={selectedPreset === "week" ? "default" : "outline"}
            size="sm"
            onClick={() => handleDatePreset("week")}
          >
            Week
          </Button>
          <Button
            variant={selectedPreset === "month" ? "default" : "outline"}
            size="sm"
            onClick={() => handleDatePreset("month")}
          >
            Month
          </Button>
          <Button
            variant={selectedPreset === "custom" ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPreset("custom")}
          >
            Custom
          </Button>
        </div>

          {selectedPreset === "custom" && (
            <DateRangePicker
              value={dateRange}
              onChange={(range) => {
                setDateRange(range);
                setSelectedPreset("custom");
              }}
            />
          )}
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-2 border-primary bg-primary shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-primary-foreground">Total Deposits</CardTitle>
            <DollarSign className="h-5 w-5 text-primary-foreground" />
          </CardHeader>
          <CardContent>
            {depositsLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-3xl font-bold text-primary-foreground">{formatCurrency(totalDeposits)}</div>
                <p className="text-xs text-primary-foreground/80">
                  {filteredDeposits.length} deposits
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-2 border-primary bg-primary shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-primary-foreground">Total Deposits</CardTitle>
            <TrendingUp className="h-5 w-5 text-primary-foreground" />
          </CardHeader>
          <CardContent>
            {depositsLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-3xl font-bold text-primary-foreground">{filteredDeposits.length}</div>
                <p className="text-xs text-primary-foreground/80">Deposit count</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="border-2 border-primary bg-primary shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-primary-foreground">Avg Deal Size</CardTitle>
            <TrendingUp className="h-5 w-5 text-primary-foreground" />
          </CardHeader>
          <CardContent>
            {depositsLoading ? (
              <Skeleton className="h-8 w-32" />
            ) : (
              <>
                <div className="text-3xl font-bold text-primary-foreground">
                  {formatCurrency(filteredDeposits.length > 0 ? totalDeposits / filteredDeposits.length : 0)}
                </div>
                <p className="text-xs text-primary-foreground/80">Per deposit</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Super Agent Totals Cards */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">
          {isAgent ? "Connected Super Agents" : "Totals by Super Agent"}
        </h2>
        {isAgent && superAgentTotals.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            No connected super agents yet. Super agents will appear here when deposits are created for leads you worked on.
          </div>
        ) : depositsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : superAgentTotals.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            No super agent data available
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {superAgentTotals.map((superAgent) => (
              <Card
                key={superAgent.super_agent_id}
                className={cn(
                  "cursor-pointer transition-all hover:shadow-md",
                  superAgent.total_super_agent_amount > 0
                    ? "border-primary/50 hover:border-primary bg-primary/5"
                    : "hover:border-primary opacity-60"
                )}
                onClick={() => {
                  setSelectedUserId(superAgent.super_agent_id);
                  setSelectedUserName(superAgent.super_agent_name);
                  setUserType("super_agent");
                }}
              >
                <CardContent className="p-4 space-y-3">
                  {/* Header: name + chevron */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <Avatar className="h-9 w-9 flex-shrink-0">
                        <AvatarImage src={superAgent.avatar_url || undefined} alt={superAgent.super_agent_name} />
                        <AvatarFallback className="text-xs">
                          {superAgent.super_agent_name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <h3 className="font-semibold text-base truncate" title={superAgent.super_agent_name}>
                        {superAgent.super_agent_name}
                      </h3>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  </div>

                  {/* Primary amount */}
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">
                      Earnings
                    </p>
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="font-bold text-xl text-foreground">
                        {formatCurrency(superAgent.total_super_agent_amount)}
                      </span>
                      <Badge
                        className="bg-primary text-primary-foreground font-medium text-xs"
                        title="Deposits count"
                      >
                        {superAgent.deposit_count} dep.
                      </Badge>
                    </div>
                  </div>

                  {/* Metrics grid */}
                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border/60">
                    <div className="space-y-0.5" title="Commission % from current Salary Configuration tier">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">Tier</p>
                      <p className="text-sm font-semibold text-foreground">
                        {superAgent.tier_total > 0
                          ? `${superAgent.tier_percent}%`
                          : "—"}
                      </p>
                    </div>
                    <div className="space-y-0.5" title="Transfers received this month">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">Transfers</p>
                      <p className="text-sm font-semibold text-foreground">{superAgent.transfers_received}</p>
                    </div>
                    <div className="space-y-0.5" title="Deposits made by this super agent">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">Deposits</p>
                      <p className="text-sm font-semibold text-foreground">{superAgent.deposit_count}</p>
                    </div>
                    <div className="space-y-0.5" title="Upsale ratio (this month): deposited clients / received transfers">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">Upsale</p>
                      <p className={cn(
                        "text-sm font-semibold",
                        superAgent.upsale_ratio >= 50 ? "text-primary" : "text-foreground"
                      )}>
                        {superAgent.transfers_received > 0
                          ? `${superAgent.upsale_ratio.toFixed(0)}%`
                          : "—"}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Agent Totals Cards */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Totals by Agent</h2>
        {depositsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : agentTotals.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">No agent data available</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {agentTotals.map((agent) => (
              <Card
                key={agent.agent_id}
                className={cn(
                  "cursor-pointer transition-all hover:shadow-md",
                  agent.total_amount > 0
                    ? "border-primary/50 hover:border-primary bg-primary/5"
                    : "hover:border-primary opacity-60"
                )}
                onClick={() => {
                  setSelectedUserId(agent.agent_id);
                  setSelectedUserName(agent.agent_name);
                  setUserType("agent");
                }}
              >
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <Avatar className="h-9 w-9 flex-shrink-0">
                        <AvatarImage src={agent.avatar_url || undefined} alt={agent.agent_name} />
                        <AvatarFallback className="text-xs">
                          {agent.agent_name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <h3 className="font-semibold text-base truncate" title={agent.agent_name}>{agent.agent_name}</h3>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  </div>
                  <div>
                    <p className="text-[11px] uppercase tracking-wide text-muted-foreground font-medium">
                      Total Deposits
                    </p>
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="font-bold text-xl text-foreground">
                        {formatCurrency(agent.total_amount)}
                      </span>
                      <Badge className="bg-primary text-primary-foreground font-medium text-xs">
                        {agent.deposit_count} dep.
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* All Monthly Deposits Table - Tenant Owner & Super Admin only */}
      {(isTenantOwner || isSuperAdmin) && filteredDeposits.length > 0 && (
        <Card className="mt-6">
          <CardHeader className="space-y-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">All Monthly Deposits</CardTitle>
              <span className="text-sm text-muted-foreground">{sortedFilteredDeposits.length} deposits</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search client, agent..."
                  value={tableSearch}
                  onChange={(e) => setTableSearch(e.target.value)}
                  className="pl-8 h-9"
                />
              </div>
              <Select value={tableStatusFilter} onValueChange={setTableStatusFilter}>
                <SelectTrigger className="w-[130px] h-9">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
              <Select value={tableAgentFilter} onValueChange={setTableAgentFilter}>
                <SelectTrigger className="w-[160px] h-9">
                  <SelectValue placeholder="Agent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Agents</SelectItem>
                  {(agents?.agents || []).map((agent) => (
                    <SelectItem key={agent.id} value={agent.id}>
                      {agent.full_name || agent.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={tableSAFilter} onValueChange={setTableSAFilter}>
                <SelectTrigger className="w-[160px] h-9">
                  <SelectValue placeholder="Super Agent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Super Agents</SelectItem>
                  {(agents?.superAgents || []).map((sa) => (
                    <SelectItem key={sa.id} value={sa.id}>
                      {sa.full_name || sa.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Agent</TableHead>
                  <TableHead>Super Agent</TableHead>
                  <TableHead>Split SA</TableHead>
                  <TableHead className="text-right">Agent Earnings</TableHead>
                  <TableHead className="text-right">SA Earnings</TableHead>
                  <TableHead>Exchanges</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedFilteredDeposits.map((deposit) => (
                  <TableRow key={deposit.id}>
                    <TableCell className="text-sm whitespace-nowrap">
                      {format(new Date(deposit.created_at), "MMM dd, yyyy")}
                    </TableCell>
                    <TableCell className="font-medium">
                      {deposit.client?.name || "N/A"}
                    </TableCell>
                    <TableCell className="font-semibold">
                      {formatCurrency(Number(deposit.amount))}
                    </TableCell>
                    <TableCell className="text-sm">
                      {deposit.agent?.full_name || deposit.agent?.email || "N/A"}
                    </TableCell>
                    <TableCell className="text-sm">
                      {deposit.super_agent?.full_name || deposit.super_agent?.email || "N/A"}
                    </TableCell>
                    <TableCell className="text-sm">
                      {deposit.split_super_agent_id
                        ? (deposit.split_super_agent?.full_name || deposit.split_super_agent?.email || "N/A")
                        : "—"}
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatCurrency(Number(deposit.agent_amount))}
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatCurrency(Number(deposit.super_agent_amount) + Number(deposit.split_super_agent_amount || 0))}
                    </TableCell>
                    <TableCell>
                      {deposit.exchanges && deposit.exchanges.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {deposit.exchanges.map((exchange) => (
                            <Badge key={exchange} variant="outline" className="text-xs">
                              {exchange}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">None</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          deposit.status === "approved"
                            ? "default"
                            : deposit.status === "rejected"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {deposit.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}


      <Dialog open={!!selectedUserId} onOpenChange={() => setSelectedUserId(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedUserName} - Detailed Deposits ({userType === "agent" ? "Agent" : "Super Agent"})
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">Total Deposits</div>
                  <div className="text-2xl font-bold">
                    ${userDeposits.reduce((sum, d) => sum + Number(d.amount), 0).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">Count</div>
                  <div className="text-2xl font-bold">{userDeposits.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm text-muted-foreground">Earnings</div>
                  <div className="text-2xl font-bold">
                    $
                    {userDeposits
                      .reduce(
                        (sum, d) =>
                          sum +
                          Number(
                            userType === "agent" ? d.agent_amount : d.super_agent_amount
                          ),
                        0
                      )
                      .toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Agent</TableHead>
                      <TableHead>Super Agent</TableHead>
                      <TableHead>Split</TableHead>
                      <TableHead className="text-right">Earnings</TableHead>
                      <TableHead>Exchanges</TableHead>
                      <TableHead>Status</TableHead>
                      
                      {canApproveDeposits && <TableHead className="text-right">Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userDeposits.map((deposit) => (
                      <TableRow key={deposit.id}>
                        <TableCell className="text-sm">
                          {format(new Date(deposit.created_at), "MMM dd, yyyy")}
                        </TableCell>
                        <TableCell className="font-medium">
                          {deposit.client?.name || "N/A"}
                        </TableCell>
                        <TableCell className="font-semibold">
                          ${Number(deposit.amount).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-sm">
                          {deposit.agent?.full_name || deposit.agent?.email || "N/A"}
                        </TableCell>
                        <TableCell className="text-sm">
                          {deposit.super_agent?.full_name ||
                            deposit.super_agent?.email ||
                            "N/A"}
                        </TableCell>
                        <TableCell className="text-sm">
                          {deposit.agent_percentage}% / {deposit.super_agent_percentage}%
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          $
                          {Number(
                            userType === "agent"
                              ? deposit.agent_amount
                              : deposit.super_agent_amount
                          ).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {deposit.exchanges && deposit.exchanges.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {deposit.exchanges.map((exchange) => (
                                <Badge key={exchange} variant="outline" className="text-xs">
                                  {exchange}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">None</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              deposit.status === "approved"
                                ? "default"
                                : deposit.status === "rejected"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {deposit.status}
                          </Badge>
                        </TableCell>
                        {canApproveDeposits && (
                          <TableCell className="text-right">
                            {deposit.status === "pending" && (
                              <div className="flex justify-end gap-1">
                                <Button
                                  size="sm"
                                  variant="default"
                                  onClick={() => setPendingApproval(deposit)}
                                  className="h-7 px-2"
                                >
                                  <Check className="h-3 w-3 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => setPendingRejection(deposit.id)}
                                  className="h-7 px-2"
                                >
                                  <XIcon className="h-3 w-3 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>


      {/* Approve Confirmation Dialog */}
      <AlertDialog open={!!pendingApproval} onOpenChange={() => setPendingApproval(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Approve Deposit</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to approve this deposit of ${Number(pendingApproval?.amount || 0).toLocaleString()}?
              <div className="mt-4 space-y-2 text-sm">
                <div><strong>Agent:</strong> {pendingApproval?.agent?.full_name || pendingApproval?.agent?.email}</div>
                <div><strong>Super Agent:</strong> {pendingApproval?.super_agent?.full_name || pendingApproval?.super_agent?.email}</div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmApprove}>Approve Deposit</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reject Confirmation Dialog */}
      <AlertDialog open={!!pendingRejection} onOpenChange={() => setPendingRejection(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reject Deposit</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this deposit? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmReject} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Reject Deposit
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
