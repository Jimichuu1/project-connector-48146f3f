import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useAdminSettings } from "@/hooks/useAdminSettings";
import {
  startOfMonth,
  endOfMonth,
  format,
  eachDayOfInterval,
  getDay,
  isBefore,
  isAfter,
} from "date-fns";
import {
  DollarSign,
  TrendingUp,
  Users,
  CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Wallet,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function MonthlySummaryCards() {
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());
  const { effectiveTenantId } = useTenant();
  const { settings } = useAdminSettings();

  const monthStart = startOfMonth(selectedMonth).toISOString();
  const monthEnd = endOfMonth(selectedMonth).toISOString();
  const holidayDates = new Set<string>(
    (settings?.holiday_dates as string[]) || []
  );

  // Count working days up to today (or end of month if past)
  const today = new Date();
  const monthEndDate = endOfMonth(selectedMonth);
  const countUpTo = isAfter(today, monthEndDate) ? monthEndDate : today;
  const countFrom = startOfMonth(selectedMonth);

  const workingDays = isBefore(countUpTo, countFrom)
    ? 0
    : eachDayOfInterval({ start: countFrom, end: countUpTo }).filter((d) => {
        const dow = getDay(d);
        const key = format(d, "yyyy-MM-dd");
        return dow !== 0 && dow !== 6 && !holidayDates.has(key);
      }).length;

  const { data, isLoading } = useQuery({
    queryKey: ["monthly-summary", effectiveTenantId, monthStart, workingDays],
    queryFn: async () => {
      // 1. Clients converted this month
      let clientsQuery = supabase
        .from("clients")
        .select("id")
        .not("converted_from_lead_id", "is", null)
        .gte("created_at", monthStart)
        .lte("created_at", monthEnd);

      if (effectiveTenantId) {
        clientsQuery = clientsQuery.eq("admin_id", effectiveTenantId);
      }

      const { data: convertedThisMonth } = await clientsQuery;
      const totalConversions = convertedThisMonth?.length || 0;
      const convertedThisMonthIds = convertedThisMonth?.map((c) => c.id) || [];

      // 2. ALL converted clients (any time)
      let allConvertedQuery = supabase
        .from("clients")
        .select("id")
        .not("converted_from_lead_id", "is", null);

      if (effectiveTenantId) {
        allConvertedQuery = allConvertedQuery.eq("admin_id", effectiveTenantId);
      }

      const { data: allConvertedClients } = await allConvertedQuery;
      const allConvertedIds = allConvertedClients?.map((c) => c.id) || [];

      let allConvertedDepositsThisMonth = 0;
      let allConvertedDepositsThisMonthCount = 0;
      let thisMonthConvertedDeposits = 0;
      let thisMonthConvertedDepositsCount = 0;

      const chunkSize = 100;

      // Card #1: this month's deposits from ALL converted clients
      if (allConvertedIds.length > 0) {
        for (let i = 0; i < allConvertedIds.length; i += chunkSize) {
          const chunk = allConvertedIds.slice(i, i + chunkSize);
          let q = supabase
            .from("deposits")
            .select("amount")
            .eq("status", "approved")
            .in("client_id", chunk)
            .gte("created_at", monthStart)
            .lte("created_at", monthEnd);

          if (effectiveTenantId) q = q.eq("admin_id", effectiveTenantId);
          const { data: deposits } = await q;
          allConvertedDepositsThisMonth +=
            deposits?.reduce((sum, d) => sum + (d.amount || 0), 0) || 0;
          allConvertedDepositsThisMonthCount += deposits?.length || 0;
        }
      }

      // Card #2: this month's deposits from THIS MONTH's converted clients
      if (convertedThisMonthIds.length > 0) {
        for (let i = 0; i < convertedThisMonthIds.length; i += chunkSize) {
          const chunk = convertedThisMonthIds.slice(i, i + chunkSize);
          let q = supabase
            .from("deposits")
            .select("amount")
            .eq("status", "approved")
            .in("client_id", chunk)
            .gte("created_at", monthStart)
            .lte("created_at", monthEnd);

          if (effectiveTenantId) q = q.eq("admin_id", effectiveTenantId);
          const { data: deposits } = await q;
          thisMonthConvertedDeposits +=
            deposits?.reduce((sum, d) => sum + (d.amount || 0), 0) || 0;
          thisMonthConvertedDepositsCount += deposits?.length || 0;
        }
      }

      const avgDailyConversion =
        workingDays > 0 ? totalConversions / workingDays : 0;
      const avgDailyDeposit =
        workingDays > 0 ? thisMonthConvertedDeposits / workingDays : 0;

      return {
        allConvertedDepositsThisMonth,
        allConvertedDepositsThisMonthCount,
        thisMonthConvertedDeposits,
        thisMonthConvertedDepositsCount,
        totalConversions,
        avgDailyConversion,
        avgDailyDeposit,
        workingDays,
      };
    },
    staleTime: 1000 * 60 * 5,
  });

  const monthLabel = format(selectedMonth, "MMMM yyyy");

  const prevMonth = () => {
    setSelectedMonth(
      (prev) => new Date(prev.getFullYear(), prev.getMonth() - 1, 1)
    );
  };
  const nextMonth = () => {
    const next = new Date(
      selectedMonth.getFullYear(),
      selectedMonth.getMonth() + 1,
      1
    );
    if (!isAfter(next, endOfMonth(new Date()))) {
      setSelectedMonth(next);
    }
  };

  const cards = [
    {
      title: "All Converted Clients — Deposits This Month",
      value: `$${(data?.allConvertedDepositsThisMonth || 0).toLocaleString()}`,
      icon: Wallet,
      description: `${data?.allConvertedDepositsThisMonthCount || 0} approved deposits from all converted clients`,
    },
    {
      title: "This Month's Converted — Deposits This Month",
      value: `$${(data?.thisMonthConvertedDeposits || 0).toLocaleString()}`,
      icon: DollarSign,
      description: `${data?.thisMonthConvertedDepositsCount || 0} deposits from ${data?.totalConversions || 0} newly converted clients`,
    },
    {
      title: "Avg Daily Conversion",
      value: (data?.avgDailyConversion || 0).toFixed(1),
      icon: Users,
      description: `Over ${data?.workingDays || 0} working days`,
    },
    {
      title: "Avg Daily Deposit",
      value: `$${(data?.avgDailyDeposit || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`,
      icon: TrendingUp,
      description: `Over ${data?.workingDays || 0} working days`,
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Monthly Summary</h3>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" className="gap-2 min-w-[140px]">
            <CalendarIcon className="h-4 w-4" />
            {monthLabel}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={nextMonth}
            disabled={isAfter(
              new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1, 1),
              endOfMonth(new Date())
            )}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-20" />
                <Skeleton className="h-3 w-16 mt-1" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-4">
          {cards.map((card) => (
            <Card key={card.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {card.title}
                </CardTitle>
                <card.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{card.value}</div>
                <p className="text-xs text-muted-foreground">
                  {card.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
