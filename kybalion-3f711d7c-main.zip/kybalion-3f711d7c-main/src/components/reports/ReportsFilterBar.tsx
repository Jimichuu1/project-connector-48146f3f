import { useState } from "react";
import { Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { DateRange } from "@/types/reports";

interface ReportsFilterBarProps {
  dateRange: DateRange;
  onDateRangeChange: (range: DateRange) => void;
}

const getMonthPresets = () => {
  const now = new Date();
  return [
    { value: "this_month", label: format(now, "MMMM"), getValue: () => ({ from: startOfMonth(now), to: endOfMonth(now) }) },
    { value: "last_month", label: format(subMonths(now, 1), "MMMM"), getValue: () => ({ from: startOfMonth(subMonths(now, 1)), to: endOfMonth(subMonths(now, 1)) }) },
    { value: "2_months_ago", label: format(subMonths(now, 2), "MMMM"), getValue: () => ({ from: startOfMonth(subMonths(now, 2)), to: endOfMonth(subMonths(now, 2)) }) },
    { value: "3_months_ago", label: format(subMonths(now, 3), "MMMM"), getValue: () => ({ from: startOfMonth(subMonths(now, 3)), to: endOfMonth(subMonths(now, 3)) }) },
  ];
};

type MonthPreset = ReturnType<typeof getMonthPresets>[0];

export function ReportsFilterBar({ dateRange, onDateRangeChange }: ReportsFilterBarProps) {
  const [filterPopoverOpen, setFilterPopoverOpen] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);

  const monthPresets = getMonthPresets();
  const hasDateFilter = dateRange.from !== null && dateRange.to !== null;

  const handlePresetClick = (preset: MonthPreset) => {
    setSelectedPreset(preset.value);
    onDateRangeChange(preset.getValue());
  };

  const handleCustomDateSelect = (range: { from?: Date; to?: Date } | undefined) => {
    if (!range) return;
    
    setSelectedPreset("custom");
    onDateRangeChange({ 
      from: range.from || dateRange.from, 
      to: range.to || range.from || dateRange.to 
    });
  };

  const clearDateFilter = () => {
    setSelectedPreset(null);
    onDateRangeChange({
      from: startOfMonth(new Date()),
      to: endOfMonth(new Date()),
    });
    setFilterPopoverOpen(false);
  };

  const getDateLabel = () => {
    if (selectedPreset && selectedPreset !== "custom") {
      const preset = monthPresets.find(p => p.value === selectedPreset);
      return preset?.label || "Month";
    }
    if (dateRange.from && dateRange.to) {
      return `${format(dateRange.from, "MMM d")} - ${format(dateRange.to, "MMM d")}`;
    }
    return "Month";
  };

  return (
    <div className="flex items-center gap-2 py-3 border-b border-border">
      <Popover open={filterPopoverOpen} onOpenChange={setFilterPopoverOpen}>
        <PopoverTrigger asChild>
          <Button 
            variant="outline" 
            size="sm" 
            className={`gap-2 rounded-full ${hasDateFilter ? 'bg-primary/10 border-primary/50 pr-2' : 'bg-background'}`}
          >
            <Calendar className="h-4 w-4" />
            <span className={hasDateFilter ? "text-primary-foreground font-medium" : "text-muted-foreground"}>
              {getDateLabel()}
            </span>
            {hasDateFilter && (
              <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                •
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-auto p-0">
          <div className="border-b border-border p-2 flex items-center justify-between">
            <span className="font-medium text-sm">Select Month</span>
            <Button variant="ghost" size="sm" onClick={clearDateFilter} className="h-6 text-xs">
              Clear
            </Button>
          </div>
          <div className="p-3 space-y-3">
            <div className="flex flex-wrap gap-2">
              {monthPresets.map((preset) => (
                <Button
                  key={preset.value}
                  variant={selectedPreset === preset.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePresetClick(preset)}
                >
                  {preset.label}
                </Button>
              ))}
            </div>
            <div className="text-xs text-muted-foreground">
              {format(dateRange.from, "PPP")} - {format(dateRange.to, "PPP")}
            </div>
            <CalendarComponent
              mode="range"
              selected={{ from: dateRange.from, to: dateRange.to }}
              onSelect={handleCustomDateSelect}
              numberOfMonths={2}
              className="pointer-events-auto"
            />
          </div>
        </PopoverContent>
      </Popover>
      
      {hasDateFilter && selectedPreset && (
        <Button
          variant="ghost"
          size="sm"
          onClick={clearDateFilter}
          className="text-xs text-muted-foreground hover:text-foreground"
        >
          Clear all
        </Button>
      )}
    </div>
  );
}
