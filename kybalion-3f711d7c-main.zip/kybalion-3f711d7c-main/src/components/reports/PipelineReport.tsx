import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import type { PipelineMetrics, DealsByStage } from "@/types/reports";

interface PipelineReportProps {
  data: PipelineMetrics | null;
  isLoading?: boolean;
}

const stageNames: Record<string, string> = {
  'UPCOMING_SALE': 'Upcoming Sale',
  'STUCK': 'Stuck',
  'FLIPPED': 'Flipped',
  'DEPOSIT': 'Deposit',
};

const chartConfig = {
  total_value: {
    label: "Total Value",
    color: "hsl(var(--primary))",
  },
  deal_count: {
    label: "Deal Count",
    color: "hsl(var(--muted-foreground))",
  },
};

export const PipelineReport = ({ data, isLoading }: PipelineReportProps) => {
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-4 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!data) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load pipeline data. Please try again.
        </AlertDescription>
      </Alert>
    );
  }
  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary text-primary-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Pipeline Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(data.total_pipeline_value)}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-primary text-primary-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Avg Opportunity Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(data.total_opportunities > 0 ? data.total_pipeline_value / data.total_opportunities : 0)}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-primary text-primary-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Opportunities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {data.total_opportunities || 0}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Pipeline Value by Stage</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[300px] w-full">
              <BarChart data={data.deals_by_stage} accessibilityLayer>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="stage" 
                  tickLine={false}
                  axisLine={false}
                  className="text-muted-foreground"
                />
                <YAxis 
                  tickLine={false}
                  axisLine={false}
                  className="text-muted-foreground"
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <ChartLegend content={<ChartLegendContent />} />
                <Bar 
                  dataKey="total_value" 
                  fill="var(--color-total_value)" 
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="deal_count" 
                  fill="var(--color-deal_count)" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Pipeline Analysis by Stage</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Stage</TableHead>
                <TableHead>Deal Count</TableHead>
                <TableHead>Total Value</TableHead>
                <TableHead>Avg Value</TableHead>
                
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.deals_by_stage?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground">
                    No data available for the selected period
                  </TableCell>
                </TableRow>
              ) : (
                data.deals_by_stage?.map((stage: DealsByStage) => (
                  <TableRow key={stage.stage}>
                    <TableCell className="font-medium">
                      {stageNames[stage.stage] || stage.stage}
                    </TableCell>
                    <TableCell>{stage.deal_count}</TableCell>
                    <TableCell className="font-semibold text-primary">
                      {formatCurrency(stage.total_value)}
                    </TableCell>
                    <TableCell>{formatCurrency(stage.avg_value)}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
