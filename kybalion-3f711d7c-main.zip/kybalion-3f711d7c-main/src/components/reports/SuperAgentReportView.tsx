import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, TrendingUp, Users2, BarChart3 } from "lucide-react";
import { format } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { isValidUUID } from "@/lib/uuidUtils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { cn, formatCurrency } from "@/lib/utils";
import { PipelineReport } from "./PipelineReport";
import { useReportsData } from "@/hooks/useReportsData";

interface SuperAgentReportViewProps {
  startDate: Date;
  endDate: Date;
}

interface TeamMemberDeposit {
  user_id: string;
  user_name: string;
  total_deposits: number;
  earnings: number;
  deposit_count: number;
}

interface SADeposit {
  id: string;
  client_id: string;
  amount: number;
  agent_id: string | null;
  super_agent_id: string | null;
  split_super_agent_id: string | null;
  agent_percentage: number;
  super_agent_percentage: number;
  agent_amount: number;
  super_agent_amount: number;
  split_super_agent_amount: number | null;
  status: string;
  created_at: string;
  exchanges: string[] | null;
  // Enriched
  client_name?: string;
  agent_name?: string;
  splitting_partner_name?: string;
}

export const SuperAgentReportView = ({ startDate, endDate }: SuperAgentReportViewProps) => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const [showTeamDepositsDialog, setShowTeamDepositsDialog] = useState(false);
  const { pipelineData, pipelineLoading } = useReportsData(startDate, endDate);

  // Dedicated deposits query - simple select, no joins
  const { data: myDeposits = [], isLoading: depositsLoading } = useQuery({
    queryKey: ["sa-report-deposits", user?.id, effectiveTenantId, startDate, endDate],
    queryFn: async () => {
      if (!user?.id || !isValidUUID(effectiveTenantId)) return [];

      const { data: rawDeposits, error } = await supabase
        .from("deposits")
        .select("id, client_id, amount, agent_id, super_agent_id, split_super_agent_id, agent_percentage, super_agent_percentage, agent_amount, super_agent_amount, split_super_agent_amount, status, created_at, exchanges")
        .eq("status", "approved")
        .eq("admin_id", effectiveTenantId!)
        .or(`super_agent_id.eq.${user.id},split_super_agent_id.eq.${user.id}`)
        .gte("created_at", startDate.toISOString())
        .lte("created_at", endDate.toISOString())
        .order("created_at", { ascending: false });

      if (error) throw error;
      if (!rawDeposits || rawDeposits.length === 0) return [];

      // Collect all IDs for separate lookups
      const clientIds = [...new Set(rawDeposits.map(d => d.client_id))];
      const profileIds = [...new Set([
        ...rawDeposits.filter(d => d.agent_id).map(d => d.agent_id!),
        ...rawDeposits.filter(d => d.super_agent_id).map(d => d.super_agent_id!),
        ...rawDeposits.filter(d => d.split_super_agent_id).map(d => d.split_super_agent_id!),
      ])];

      // Fetch clients (via SECURITY DEFINER RPC so SAs can see names of clients
      // they have historical attribution on, without exposing them on the Clients page)
      // and profiles in parallel.
      const [clientsRes, profilesRes] = await Promise.all([
        supabase.rpc("get_attributed_client_names", { p_client_ids: clientIds }),
        profileIds.length > 0
          ? supabase.from("profiles").select("id, full_name, email").in("id", profileIds)
          : Promise.resolve({ data: [] }),
      ]);

      const clientMap = new Map(((clientsRes.data as Array<{ id: string; name: string }> | null) || []).map(c => [c.id, c.name]));
      const profileMap = new Map((profilesRes.data || []).map(p => [p.id, p.full_name || p.email || "Unknown"]));

      return rawDeposits.map(d => {
        let splittingPartnerName = "None";
        if (d.super_agent_id === user.id && d.split_super_agent_id) {
          splittingPartnerName = profileMap.get(d.split_super_agent_id) || "Unknown";
        } else if (d.split_super_agent_id === user.id && d.super_agent_id) {
          splittingPartnerName = profileMap.get(d.super_agent_id) || "Unknown";
        }

        return {
          ...d,
          client_name: clientMap.get(d.client_id) || "Unknown Client",
          agent_name: d.agent_id ? (profileMap.get(d.agent_id) || "N/A") : "N/A",
          splitting_partner_name: splittingPartnerName,
        };
      }) as SADeposit[];
    },
    enabled: !!user?.id && isValidUUID(effectiveTenantId),
    staleTime: 2 * 60 * 1000,
  });

  // Get current user's profile
  const { data: userProfile } = useQuery({
    queryKey: ["user-profile", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .eq("id", user.id)
        .single();
      return data;
    },
    enabled: !!user?.id,
  });

  // Get team members' deposit stats (SUPER_AGENTS only in tenant)
  const { data: teamDeposits, isLoading: teamLoading } = useQuery({
    queryKey: ["team-deposits-super-agents", effectiveTenantId, startDate, endDate, user?.id],
    queryFn: async () => {
      if (!isValidUUID(effectiveTenantId)) return [];
      
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email, admin_id")
        .or(`admin_id.eq.${effectiveTenantId},id.eq.${effectiveTenantId}`);
      
      if (!profiles) return [];
      
      const tenantUserIds = profiles.map(p => p.id);
      
      const { data: userRoles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .eq("role", "SUPER_AGENT")
        .in("user_id", tenantUserIds);
      
      if (!userRoles) return [];
      
      const teamUserIds = userRoles.map(r => r.user_id);
      const teamProfiles = profiles.filter(p => teamUserIds.includes(p.id));
      
      const teamStats: TeamMemberDeposit[] = [];
      
      for (const member of teamProfiles) {
        if (member.id === user?.id) continue;
        
        const { data: memberDeposits } = await supabase
          .from("deposits")
          .select("amount, super_agent_amount, split_super_agent_amount, super_agent_id, split_super_agent_id")
          .or(`super_agent_id.eq.${member.id},split_super_agent_id.eq.${member.id}`)
          .eq("status", "approved")
          .gte("created_at", startDate.toISOString())
          .lte("created_at", endDate.toISOString());
        
        if (!memberDeposits || memberDeposits.length === 0) continue;
        
        const totalDeposits = memberDeposits.reduce((sum, d) => sum + Number(d.amount), 0);
        const earnings = memberDeposits.reduce((sum, d) => {
          if (d.super_agent_id === member.id) {
            return sum + Number(d.super_agent_amount);
          } else if (d.split_super_agent_id === member.id) {
            return sum + Number(d.split_super_agent_amount || 0);
          }
          return sum;
        }, 0);
        
        teamStats.push({
          user_id: member.id,
          user_name: member.full_name || member.email || "Unknown",
          total_deposits: totalDeposits,
          earnings,
          deposit_count: memberDeposits.length,
        });
      }
      
      return teamStats.sort((a, b) => b.total_deposits - a.total_deposits);
    },
    enabled: isValidUUID(effectiveTenantId),
  });

  // Calculate my stats from dedicated query
  const myTotalDeposits = myDeposits.reduce((sum, d) => sum + Number(d.amount), 0);
  const myEarnings = myDeposits.reduce((sum, d) => {
    if (d.super_agent_id === user?.id) {
      return sum + Number(d.super_agent_amount);
    } else if (d.split_super_agent_id === user?.id) {
      return sum + Number(d.split_super_agent_amount || 0);
    }
    return sum;
  }, 0);
  const myDepositCount = myDeposits.length;

  const teamTotalEarnings = (teamDeposits || []).reduce((sum, t) => sum + t.earnings, 0);

  const userName = userProfile?.full_name || userProfile?.email || "My";

  if (depositsLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary text-primary-foreground">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <DollarSign className="h-8 w-8 opacity-80" />
            </div>
            <div className="text-3xl font-bold mt-2">{formatCurrency(myTotalDeposits)}</div>
            <p className="text-sm opacity-80">My Total Deposits</p>
          </CardContent>
        </Card>

        <Card className="bg-secondary">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="text-3xl font-bold mt-2">{formatCurrency(myEarnings)}</div>
            <p className="text-sm text-muted-foreground">My Total Earnings</p>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:border-primary/50 transition-colors"
          onClick={() => setShowTeamDepositsDialog(true)}
        >
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <Users2 className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="text-3xl font-bold mt-2">{formatCurrency(teamTotalEarnings + myEarnings)}</div>
            <p className="text-sm text-muted-foreground">Total Team Earnings (Click for details)</p>
          </CardContent>
        </Card>
      </div>

      {/* My Detailed Deposits - Direct Display */}
      <Card>
        <CardHeader>
          <CardTitle>{userName} - Detailed Deposits (Super Agent)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Total Deposits</div>
                <div className="text-2xl font-bold">{formatCurrency(myTotalDeposits)}</div>
              </CardContent>
            </Card>
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Count</div>
                <div className="text-2xl font-bold">{myDepositCount}</div>
              </CardContent>
            </Card>
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">My Total Earnings</div>
                <div className="text-2xl font-bold">{formatCurrency(myEarnings)}</div>
              </CardContent>
            </Card>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Agent</TableHead>
                  <TableHead>Splitting Super Agent</TableHead>
                  <TableHead>Split</TableHead>
                  <TableHead className="text-right">My Earnings</TableHead>
                  <TableHead>Exchanges</TableHead>
                  <TableHead>Status</TableHead>
                  
                </TableRow>
              </TableHeader>
              <TableBody>
                {myDeposits.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center text-muted-foreground py-8">
                      No deposits found for the selected period
                    </TableCell>
                  </TableRow>
                ) : (
                  myDeposits.map((deposit) => {
                    const myEarning = deposit.super_agent_id === user?.id 
                      ? Number(deposit.super_agent_amount)
                      : Number(deposit.split_super_agent_amount || 0);
                    
                    return (
                      <TableRow key={deposit.id}>
                        <TableCell className="text-sm">
                          {format(new Date(deposit.created_at), "MMM dd, yyyy")}
                        </TableCell>
                        <TableCell className="font-medium">
                          {deposit.client_name}
                        </TableCell>
                        <TableCell className="font-semibold">
                          ${Number(deposit.amount).toLocaleString()}
                        </TableCell>
                        <TableCell className="text-sm">
                          {deposit.agent_name}
                        </TableCell>
                        <TableCell className="text-sm">
                          {deposit.splitting_partner_name}
                        </TableCell>
                        <TableCell className="text-sm">
                          {deposit.agent_percentage}% / {deposit.super_agent_percentage}%
                        </TableCell>
                        <TableCell className="text-right font-semibold text-primary">
                          ${myEarning.toLocaleString()}
                        </TableCell>
                        <TableCell>
                          {deposit.exchanges && deposit.exchanges.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {deposit.exchanges.map((exchange) => (
                                <Badge key={exchange} variant="outline" className="text-xs">
                                  {exchange}
                                </Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">None</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              deposit.status === "approved"
                                ? "default"
                                : deposit.status === "rejected"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {deposit.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Pipeline Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            My Pipeline Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <PipelineReport data={pipelineData} isLoading={pipelineLoading} />
        </CardContent>
      </Card>

      {/* Team Deposits Dialog */}
      <Dialog open={showTeamDepositsDialog} onOpenChange={setShowTeamDepositsDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Team Super Agents - Deposit Details</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Team Total Earnings</div>
                <div className="text-2xl font-bold">{formatCurrency(teamTotalEarnings)}</div>
              </CardContent>
            </Card>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Team Member</TableHead>
                    <TableHead className="text-center">Deposits</TableHead>
                    <TableHead className="text-right">Total Amount</TableHead>
                    <TableHead className="text-right">Earnings</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {!teamDeposits || teamDeposits.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        No team member deposits found for the selected period
                      </TableCell>
                    </TableRow>
                  ) : (
                    teamDeposits.map((member) => (
                      <TableRow key={member.user_id}>
                        <TableCell className="font-medium">{member.user_name}</TableCell>
                        <TableCell className="text-center">
                          <Badge className="bg-primary text-primary-foreground">
                            {member.deposit_count}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {formatCurrency(member.total_deposits)}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-primary">
                          {formatCurrency(member.earnings)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
