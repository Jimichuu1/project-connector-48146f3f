import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { DollarSign, TrendingUp, Users2, UserCheck } from "lucide-react";
import { format, startOfDay, endOfDay } from "date-fns";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { isValidUUID } from "@/lib/uuidUtils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";

interface AgentReportViewProps {
  startDate: Date;
  endDate: Date;
}

interface TeamMemberConversion {
  user_id: string;
  user_name: string;
  converted_count: number;
  total_deposits: number;
}

interface AgentDeposit {
  id: string;
  client_id: string;
  amount: number;
  agent_id: string | null;
  super_agent_id: string | null;
  split_super_agent_id: string | null;
  agent_percentage: number;
  super_agent_percentage: number;
  agent_amount: number;
  super_agent_amount: number;
  split_super_agent_amount: number | null;
  status: string;
  created_at: string;
  exchanges: string[] | null;
  // Enriched fields
  client_name?: string;
  super_agent_name?: string;
}

export const AgentReportView = ({ startDate, endDate }: AgentReportViewProps) => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();

  // Dedicated deposits query - simple select, no joins, bypasses RLS on clients
  const { data: myDeposits = [], isLoading: depositsLoading } = useQuery({
    queryKey: ["agent-report-deposits", user?.id, effectiveTenantId, startDate, endDate],
    queryFn: async () => {
      if (!user?.id || !effectiveTenantId) return [];

      const { data: rawDeposits, error } = await supabase
        .from("deposits")
        .select("id, client_id, amount, agent_id, closer_agent_id, super_agent_id, split_super_agent_id, agent_percentage, super_agent_percentage, agent_amount, super_agent_amount, split_super_agent_amount, status, created_at, exchanges, counts_for_agent")
        .or(`agent_id.eq.${user.id},closer_agent_id.eq.${user.id}`)
        .eq("status", "approved")
        .eq("counts_for_agent", true)
        .eq("admin_id", effectiveTenantId)
        .gte("created_at", startDate.toISOString())
        .lte("created_at", endDate.toISOString())
        .order("created_at", { ascending: false });

      if (error) throw error;
      if (!rawDeposits || rawDeposits.length === 0) return [];

      // Fetch client names separately
      const clientIds = [...new Set(rawDeposits.map(d => d.client_id))];
      const { data: clients } = await supabase
        .from("clients")
        .select("id, name")
        .in("id", clientIds);
      const clientMap = new Map((clients || []).map(c => [c.id, c.name]));

      // Fetch super agent names separately
      const saIds = [...new Set(rawDeposits.filter(d => d.super_agent_id).map(d => d.super_agent_id!))] ;
      let saMap = new Map<string, string>();
      if (saIds.length > 0) {
        const { data: saProfiles } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", saIds);
        saMap = new Map((saProfiles || []).map(p => [p.id, p.full_name || p.email]));
      }

      return rawDeposits.map(d => ({
        ...d,
        client_name: clientMap.get(d.client_id) || "Unknown Client",
        super_agent_name: d.super_agent_id ? (saMap.get(d.super_agent_id) || "N/A") : "N/A",
      })) as AgentDeposit[];
    },
    enabled: !!user?.id && isValidUUID(effectiveTenantId),
    staleTime: 2 * 60 * 1000,
  });

  // Get current user's profile
  const { data: userProfile } = useQuery({
    queryKey: ["user-profile", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .eq("id", user.id)
        .single();
      return data;
    },
    enabled: !!user?.id,
  });

  // Get my converted clients count using RPC function that bypasses RLS
  const { data: myConversions } = useQuery({
    queryKey: ["my-conversions", user?.id, effectiveTenantId, startDate, endDate],
    queryFn: async () => {
      if (!user?.id || !effectiveTenantId) return { count: 0, totalDeposits: 0 };
      
      const { data, error } = await supabase.rpc("get_agent_conversion_count", {
        p_agent_id: user.id,
        p_admin_id: effectiveTenantId,
        p_start_date: startDate.toISOString(),
        p_end_date: endDate.toISOString(),
      });
      
      if (error) {
        console.error("Error fetching my conversions:", error);
        return { count: 0, totalDeposits: 0 };
      }
      
      const result = data?.[0];
      return { 
        count: Number(result?.converted_count) || 0, 
        totalDeposits: Number(result?.total_deposits) || 0 
      };
    },
    enabled: !!user?.id && !!effectiveTenantId,
  });

  // Get ALL team members' conversion stats using RPC function
  const { data: teamConversions, isLoading: teamLoading } = useQuery({
    queryKey: ["team-conversions", effectiveTenantId, startDate, endDate],
    queryFn: async () => {
      if (!effectiveTenantId) return [];
      
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("id, full_name, email, admin_id")
        .eq("admin_id", effectiveTenantId);
      
      if (profilesError || !profiles || profiles.length === 0) return [];
      
      const tenantUserIds = profiles.map(p => p.id);
      
      const { data: agentRoles, error: rolesError } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .eq("role", "AGENT")
        .in("user_id", tenantUserIds);
      
      if (rolesError || !agentRoles || agentRoles.length === 0) return [];
      
      const agentIds = agentRoles.map(r => r.user_id);
      const agentProfiles = profiles.filter(p => agentIds.includes(p.id));
      
      const teamStats: TeamMemberConversion[] = [];
      
      for (const agent of agentProfiles) {
        const { data, error } = await supabase.rpc("get_agent_conversion_count", {
          p_agent_id: agent.id,
          p_admin_id: effectiveTenantId,
          p_start_date: startDate.toISOString(),
          p_end_date: endDate.toISOString(),
        });
        
        if (error) {
          console.error("Error fetching conversions for agent:", agent.full_name, error);
        }
        
        const result = data?.[0];
        teamStats.push({
          user_id: agent.id,
          user_name: agent.full_name || agent.email,
          converted_count: Number(result?.converted_count) || 0,
          total_deposits: Number(result?.total_deposits) || 0,
        });
      }
      
      return teamStats.sort((a, b) => b.converted_count - a.converted_count);
    },
    enabled: !!effectiveTenantId,
  });




  // Calculate stats from dedicated query - split 50/50 when closer agent is involved
  const totalDeposits = myDeposits.reduce((sum, d) => {
    const amount = Number(d.amount);
    const hasCloser = !!(d as any).closer_agent_id;
    return sum + (hasCloser ? amount / 2 : amount);
  }, 0);
  const totalEarnings = myDeposits.reduce((sum, d) => sum + Number(d.agent_amount), 0);
  const depositCount = myDeposits.reduce((sum, d) => {
    const hasCloser = !!(d as any).closer_agent_id;
    return sum + (hasCloser ? 0.5 : 1);
  }, 0);

  // Team totals
  const teamTotalConversions = (teamConversions || []).reduce((sum, t) => sum + t.converted_count, 0);
  const teamTotalDeposits = (teamConversions || []).reduce((sum, t) => sum + t.total_deposits, 0);
  
  const myConversionCount = teamConversions?.find(t => t.user_id === user?.id)?.converted_count || myConversions?.count || 0;

  const userName = userProfile?.full_name || userProfile?.email || "My";

  if (depositsLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-primary text-primary-foreground">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <DollarSign className="h-8 w-8 opacity-80" />
            </div>
            <div className="text-3xl font-bold mt-2">{formatCurrency(totalDeposits)}</div>
            <p className="text-sm opacity-80">My Total Deposits</p>
          </CardContent>
        </Card>

        <Card className="bg-secondary">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="text-3xl font-bold mt-2">{formatCurrency(totalEarnings)}</div>
            <p className="text-sm text-muted-foreground">My Earnings</p>
          </CardContent>
        </Card>

        <Card className="border-primary/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <UserCheck className="h-8 w-8 text-primary" />
            </div>
            <div className="text-3xl font-bold mt-2">{myConversionCount}</div>
            <p className="text-sm text-muted-foreground">My Conversions</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <Users2 className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="text-3xl font-bold mt-2">{teamTotalConversions}</div>
            <p className="text-sm text-muted-foreground">Team Total Conversions</p>
          </CardContent>
        </Card>
      </div>

      {/* My Detailed Report - Direct Display */}
      <Card>
        <CardHeader>
          <CardTitle>{userName} - Detailed Report (Agent)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Total Deposits</div>
                <div className="text-2xl font-bold">{formatCurrency(totalDeposits)}</div>
              </CardContent>
            </Card>
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Count</div>
                <div className="text-2xl font-bold">{depositCount}</div>
              </CardContent>
            </Card>
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Earnings</div>
                <div className="text-2xl font-bold">{formatCurrency(totalEarnings)}</div>
              </CardContent>
            </Card>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Super Agent</TableHead>
                  <TableHead>Split</TableHead>
                  <TableHead className="text-right">Earnings</TableHead>
                  <TableHead>Exchanges</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {myDeposits.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      No deposits found for the selected period
                    </TableCell>
                  </TableRow>
                ) : (
                  myDeposits.map((deposit) => (
                    <TableRow key={deposit.id}>
                      <TableCell className="text-sm">
                        {format(new Date(deposit.created_at), "MMM dd, yyyy")}
                      </TableCell>
                      <TableCell className="font-medium">
                        {deposit.client_name}
                      </TableCell>
                      <TableCell className="font-semibold">
                        ${Number(deposit.amount).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-sm">
                        {deposit.super_agent_name}
                      </TableCell>
                      <TableCell className="text-sm">
                        {deposit.agent_percentage}% / {deposit.super_agent_percentage}%
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        ${Number(deposit.agent_amount).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        {deposit.exchanges && deposit.exchanges.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {deposit.exchanges.map((exchange) => (
                              <Badge key={exchange} variant="outline" className="text-xs">
                                {exchange}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">None</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            deposit.status === "approved"
                              ? "default"
                              : deposit.status === "rejected"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {deposit.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Team Conversions Report - Always show */}
      <Card>
        <CardHeader>
          <CardTitle>Team Members Conversions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Team Total Conversions</div>
                <div className="text-2xl font-bold">{teamTotalConversions}</div>
              </CardContent>
            </Card>
            <Card className="bg-muted/50">
              <CardContent className="pt-4">
                <div className="text-sm text-muted-foreground">Team Total Deposits</div>
                <div className="text-2xl font-bold">{formatCurrency(teamTotalDeposits)}</div>
              </CardContent>
            </Card>
          </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Team Member</TableHead>
                    <TableHead className="text-center">Conversions</TableHead>
                    <TableHead className="text-right">Total Deposits</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(teamConversions || []).length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center text-muted-foreground py-8">
                        No team members found
                      </TableCell>
                    </TableRow>
                  ) : (
                    teamConversions?.map((member) => (
                      <TableRow key={member.user_id} className={member.user_id === user?.id ? "bg-primary/5" : ""}>
                        <TableCell className="font-medium">
                          {member.user_name}
                          {member.user_id === user?.id && (
                            <Badge variant="outline" className="ml-2 text-xs">You</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className="bg-primary text-primary-foreground">
                            {member.converted_count}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {formatCurrency(member.total_deposits)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
    </div>
  );
};
