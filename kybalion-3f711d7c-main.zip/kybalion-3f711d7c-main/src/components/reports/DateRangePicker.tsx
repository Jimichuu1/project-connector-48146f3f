import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Filter, X } from "lucide-react";
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isToday, isYesterday, isSameDay, startOfDay, endOfDay } from "date-fns";
import { DateRange } from "@/types/reports";

interface DateRangePickerProps {
  value: DateRange;
  onChange: (range: DateRange) => void;
}

type PresetType = "today" | "yesterday" | "week" | "month" | "custom";

export const DateRangePicker = ({ value, onChange }: DateRangePickerProps) => {
  const [open, setOpen] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<PresetType | null>(null);

  const presets: { label: string; value: PresetType; getValue: () => DateRange }[] = [
    {
      label: "Today",
      value: "today",
      getValue: () => ({ from: startOfDay(new Date()), to: endOfDay(new Date()) }),
    },
    {
      label: "Yesterday",
      value: "yesterday",
      getValue: () => {
        const yesterday = subDays(new Date(), 1);
        return { from: startOfDay(yesterday), to: endOfDay(yesterday) };
      },
    },
    {
      label: "This Week",
      value: "week",
      getValue: () => ({
        from: startOfWeek(new Date()),
        to: endOfWeek(new Date()),
      }),
    },
    {
      label: "This Month",
      value: "month",
      getValue: () => ({
        from: startOfMonth(new Date()),
        to: endOfMonth(new Date()),
      }),
    },
  ];

  const handlePresetSelect = (preset: typeof presets[0]) => {
    setSelectedPreset(preset.value);
    onChange(preset.getValue());
  };

  const handleCustomDateSelect = (range: { from?: Date; to?: Date } | undefined) => {
    if (range?.from) {
      setSelectedPreset("custom");
      onChange({ 
        from: range.from, 
        to: range.to || range.from 
      });
    }
  };

  const clearFilters = () => {
    setSelectedPreset(null);
    onChange({
      from: subDays(new Date(), 30),
      to: new Date(),
    });
  };

  const getActiveFilterLabel = (): string | null => {
    if (!selectedPreset) return null;
    if (selectedPreset === "custom") {
      return `${format(value.from, "MMM d")} - ${format(value.to, "MMM d")}`;
    }
    const preset = presets.find(p => p.value === selectedPreset);
    return preset?.label || null;
  };

  const activeFilterLabel = getActiveFilterLabel();
  const hasActiveFilter = selectedPreset !== null;

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm">
          <Filter className="h-4 w-4 mr-2" />
          Filters
          {hasActiveFilter && (
            <Badge variant="secondary" className="ml-2 h-5 min-w-5 rounded-full px-1.5 flex items-center justify-center text-xs">
              1
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px] overflow-y-auto">
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle>Filter Reports</SheetTitle>
            {hasActiveFilter && (
              <Button variant="ghost" size="sm" onClick={clearFilters}>
                Clear All
              </Button>
            )}
          </div>
        </SheetHeader>

        <div className="space-y-6 mt-6">
          {/* Date Range Presets */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">Date Range</Label>
            <div className="flex flex-wrap gap-2">
              {presets.map((preset) => (
                <Badge
                  key={preset.value}
                  variant={selectedPreset === preset.value ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => handlePresetSelect(preset)}
                >
                  {preset.label}
                  {selectedPreset === preset.value && (
                    <X className="h-3 w-3 ml-1" />
                  )}
                </Badge>
              ))}
              <Badge
                variant={selectedPreset === "custom" ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setSelectedPreset("custom")}
              >
                Custom Range
                {selectedPreset === "custom" && (
                  <X className="h-3 w-3 ml-1" />
                )}
              </Badge>
            </div>
          </div>

          {/* Custom Date Range Calendar */}
          <div className="space-y-3">
            <Label className="text-sm font-semibold">
              {selectedPreset === "custom" ? "Select Custom Range" : "Or Pick Custom Dates"}
            </Label>
            <div className="text-sm text-muted-foreground mb-2">
              {format(value.from, "PPP")} - {format(value.to, "PPP")}
            </div>
            <div className="border rounded-lg p-3 bg-background">
              <Calendar
                mode="range"
                selected={{ from: value.from, to: value.to }}
                onSelect={handleCustomDateSelect}
                numberOfMonths={1}
                className="pointer-events-auto"
              />
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};
