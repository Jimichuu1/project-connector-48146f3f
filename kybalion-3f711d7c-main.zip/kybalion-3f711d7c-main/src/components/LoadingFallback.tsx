import { useEffect, useState } from "react";
import { Loader2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface LoadingFallbackProps {
  message?: string;
}

/**
 * Loading fallback for React.Suspense boundaries.
 * After 8 seconds, surfaces a "Reload" escape hatch so users are never trapped on a stuck spinner.
 */
export const LoadingFallback = ({ message = "Loading..." }: LoadingFallbackProps) => {
  const [stuck, setStuck] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setStuck(true), 8000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] p-8">
      <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
      <p className="text-muted-foreground text-sm">{message}</p>
      {stuck && (
        <div className="mt-6 flex flex-col items-center gap-3">
          <p className="text-xs text-muted-foreground">Still loading… something seems slow.</p>
          <Button size="sm" variant="outline" onClick={() => window.location.reload()}>
            <RefreshCw className="h-3.5 w-3.5 mr-2" />
            Reload
          </Button>
        </div>
      )}
    </div>
  );
};

/**
 * Compact loading fallback for smaller content areas
 */
export const CompactLoadingFallback = () => {
  return (
    <div className="flex items-center justify-center p-4">
      <Loader2 className="h-5 w-5 animate-spin text-primary" />
    </div>
  );
};
