import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  History, User, Edit, Trash2, Plus, UserCheck, 
  ArrowRightLeft, FileText, DollarSign, Phone, Mail,
  Shield, CheckCircle, XCircle, Clock, ChevronDown,
  Monitor, Globe, ArrowRight
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { useState } from "react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface ActivityLogProps {
  entityType: "lead" | "client";
  entityId: string;
}

interface CombinedActivity {
  id: string;
  type: "audit" | "activity";
  action: string;
  description: string;
  created_at: string;
  user_name: string;
  ip_address: string | null;
  user_agent: string | null;
  raw_details: Record<string, unknown> | null;
}

type ActionCategory = "create" | "update" | "delete" | "status" | "assign" | "document" | "deposit" | "other";

const getActionCategory = (actionType: string): ActionCategory => {
  const type = actionType.toLowerCase();
  if (type.includes("create") || type.includes("add")) return "create";
  if (type.includes("update") || type.includes("edit") || type.includes("change")) return "update";
  if (type.includes("delete") || type.includes("remove") || type.includes("reject")) return "delete";
  if (type.includes("status") || type.includes("pipeline") || type.includes("approve")) return "status";
  if (type.includes("assign") || type.includes("transfer") || type.includes("convert")) return "assign";
  if (type.includes("document") || type.includes("file")) return "document";
  if (type.includes("deposit") || type.includes("payment")) return "deposit";
  return "other";
};

const getActionIcon = (actionType: string) => {
  const type = actionType.toLowerCase();
  if (type.includes("create") || type.includes("add")) return Plus;
  if (type.includes("update") || type.includes("edit") || type.includes("change")) return Edit;
  if (type.includes("delete") || type.includes("remove")) return Trash2;
  if (type.includes("assign") || type.includes("transfer")) return ArrowRightLeft;
  if (type.includes("convert")) return UserCheck;
  if (type.includes("document") || type.includes("file")) return FileText;
  if (type.includes("deposit") || type.includes("payment")) return DollarSign;
  if (type.includes("call")) return Phone;
  if (type.includes("email")) return Mail;
  if (type.includes("status") || type.includes("pipeline")) return ArrowRight;
  if (type.includes("approve")) return CheckCircle;
  if (type.includes("reject")) return XCircle;
  if (type.includes("login") || type.includes("auth")) return Shield;
  return Clock;
};

const getCategoryStyles = (category: ActionCategory) => {
  switch (category) {
    case "create":
      return { bg: "bg-emerald-500/10", border: "border-emerald-500/30", icon: "text-emerald-500", dot: "bg-emerald-500" };
    case "update":
      return { bg: "bg-blue-500/10", border: "border-blue-500/30", icon: "text-blue-500", dot: "bg-blue-500" };
    case "delete":
      return { bg: "bg-destructive/10", border: "border-destructive/30", icon: "text-destructive", dot: "bg-destructive" };
    case "status":
      return { bg: "bg-amber-500/10", border: "border-amber-500/30", icon: "text-amber-500", dot: "bg-amber-500" };
    case "assign":
      return { bg: "bg-violet-500/10", border: "border-violet-500/30", icon: "text-violet-500", dot: "bg-violet-500" };
    case "document":
      return { bg: "bg-cyan-500/10", border: "border-cyan-500/30", icon: "text-cyan-500", dot: "bg-cyan-500" };
    case "deposit":
      return { bg: "bg-green-500/10", border: "border-green-500/30", icon: "text-green-500", dot: "bg-green-500" };
    default:
      return { bg: "bg-muted", border: "border-border", icon: "text-muted-foreground", dot: "bg-muted-foreground" };
  }
};

const formatActionLabel = (action: string): string => {
  return action
    .replace(/_/g, " ")
    .toLowerCase()
    .split(" ")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

// Generate human-readable description from action and details
const getReadableDescription = (action: string, details: Record<string, unknown> | null): string => {
  if (!details) return "";
  
  const actionLower = action.toLowerCase();
  
  // Extract common fields
  const oldStatus = details.old_status as string | undefined;
  const newStatus = details.new_status as string | undefined;
  const clientName = (details.client_name || details.lead_name) as string | undefined;
  const branchName = (details.branch_name || details.name) as string | undefined;
  const bankName = details.bank_name as string | undefined;
  const fileName = details.file_name as string | undefined;
  const amount = details.amount as number | undefined;
  const assignedTo = details.assigned_to_name as string | undefined;
  const changes = details.changes as Record<string, unknown> | undefined;
  const oldValue = details.old_value as number | undefined;
  const newValue = details.new_value as number | undefined;
  const value = details.value as number | undefined;
  const branchValue = details.branch_value as number | undefined;
  const depositAmount = details.deposit_amount as number | undefined;
  
  // Get the best available value
  const displayValue = value || branchValue || depositAmount || amount;

  // Status/Pipeline changes - most common
  if (oldStatus && newStatus) {
    const valueInfo = displayValue ? ` • Value: $${displayValue.toLocaleString()}` : "";
    return `Status: "${formatStatus(oldStatus)}" → "${formatStatus(newStatus)}"${valueInfo}`;
  }

  // Value changes with status
  if (oldValue !== undefined && newValue !== undefined && oldValue !== newValue) {
    return `Value updated: $${oldValue.toLocaleString()} → $${newValue.toLocaleString()}`;
  }

  // Opportunity/Branch actions
  if (actionLower.includes("pipeline") || actionLower.includes("opportunity") || actionLower.includes("branch")) {
    if (actionLower.includes("created")) {
      const valueStr = displayValue ? ` • Value: $${displayValue.toLocaleString()}` : "";
      const statusStr = details.status ? ` • Status: ${formatStatus(details.status as string)}` : "";
      return `New pipeline opportunity${branchName ? `: "${branchName}"` : ""}${valueStr}${statusStr}`;
    }
    if (actionLower.includes("deleted")) {
      const valueStr = displayValue ? ` • Value: $${displayValue.toLocaleString()}` : "";
      const statusStr = details.branch_status ? ` • Status: ${formatStatus(details.branch_status as string)}` : "";
      return `Removed opportunity${branchName ? `: "${branchName}"` : ""}${valueStr}${statusStr}`;
    }
    if (actionLower.includes("updated") && changes) {
      const changedFields = Object.entries(changes)
        .map(([key, val]) => {
          if (key === "value" || key === "amount") {
            return `${formatStatus(key)}: $${Number(val).toLocaleString()}`;
          }
          if (key === "status") {
            return `${formatStatus(key)}: ${formatStatus(String(val))}`;
          }
          return `${formatStatus(key)}: ${val}`;
        })
        .join(" • ");
      return `Updated: ${changedFields}`;
    }
  }

  // KYC/Bank/Note actions
  if (actionLower.includes("kyc") || actionLower.includes("bank") || actionLower.includes("note")) {
    if (actionLower.includes("bank") && (actionLower.includes("add") || actionLower.includes("create"))) {
      return `Added new bank account${bankName ? `: "${bankName}"` : ""}`;
    }
    if (actionLower.includes("note") && (actionLower.includes("add") || actionLower.includes("create"))) {
      return "Added new KYC note";
    }
    if (actionLower.includes("delete")) {
      return `Removed KYC record${bankName ? `: "${bankName}"` : ""}`;
    }
    if (actionLower.includes("update")) {
      return `Updated KYC information${bankName ? ` for "${bankName}"` : ""}`;
    }
  }

  // Document actions
  if (actionLower.includes("document") || actionLower.includes("file")) {
    if (actionLower.includes("upload") || actionLower.includes("create")) {
      return `Uploaded document${fileName ? `: "${fileName}"` : ""}`;
    }
    if (actionLower.includes("delete")) {
      return `Removed document${fileName ? `: "${fileName}"` : ""}`;
    }
  }

  // Assignment actions
  if (actionLower.includes("assign")) {
    return `Assigned${clientName ? ` "${clientName}"` : ""} to ${assignedTo || "new user"}`;
  }

  // Client/Lead record actions
  if (actionLower.includes("client") || actionLower.includes("lead")) {
    if (actionLower.includes("update") && changes) {
      const changedFields = Object.keys(changes).map(k => formatStatus(k)).join(", ");
      return `Updated fields: ${changedFields}`;
    }
    if (actionLower.includes("delete")) {
      return `Deleted record${clientName ? `: "${clientName}"` : ""}`;
    }
    if (actionLower.includes("create")) {
      return `Created new record${clientName ? `: "${clientName}"` : ""}`;
    }
  }

  // Deposit actions
  if (actionLower.includes("deposit")) {
    if (actionLower.includes("approve")) {
      return `Approved deposit${amount ? ` of $${amount.toLocaleString()}` : ""}`;
    }
    if (actionLower.includes("reject")) {
      return `Rejected deposit request`;
    }
    if (actionLower.includes("create")) {
      return `Submitted deposit${amount ? ` of $${amount.toLocaleString()}` : ""}`;
    }
  }

  // Conversion actions
  if (actionLower.includes("convert")) {
    const requestedBy = details.requested_by_name as string | undefined;
    const transferringAgent = details.transferring_agent_name as string | undefined;
    const balance = details.balance as number | undefined;
    const equity = details.equity as number | undefined;
    const valueInfo = balance != null ? ` • Balance: $${balance.toLocaleString()}` : "";
    const equityInfo = equity != null ? ` • Equity: $${equity.toLocaleString()}` : "";

    if (actionLower.includes("requested")) {
      return `Requested conversion to client${clientName ? ` for "${clientName}"` : ""}${valueInfo}${equityInfo}`;
    }
    if (actionLower.includes("confirmed")) {
      const agentInfo = transferringAgent || requestedBy;
      return `Conversion confirmed${clientName ? ` for "${clientName}"` : ""}${agentInfo ? ` • Requested by: ${agentInfo}` : ""}${valueInfo}`;
    }
    return `Converted to client${clientName ? `: "${clientName}"` : ""}`;
  }

  // If we have changes object, summarize it
  if (changes && Object.keys(changes).length > 0) {
    const changedFields = Object.entries(changes)
      .slice(0, 3)
      .map(([key, value]) => `${formatStatus(key)}: ${value}`)
      .join(", ");
    const more = Object.keys(changes).length > 3 ? ` (+${Object.keys(changes).length - 3} more)` : "";
    return `${changedFields}${more}`;
  }

  return "";
};

const formatStatus = (status: string): string => {
  return status
    .replace(/_/g, " ")
    .toLowerCase()
    .split(" ")
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

export function ActivityLog({ entityType, entityId }: ActivityLogProps) {
  // Fetch all activity data
  const { data: allActivities = [], isLoading } = useQuery({
    queryKey: ["activity-log", entityType, entityId],
    queryFn: async (): Promise<CombinedActivity[]> => {
      // Fetch audit logs for this entity
      const { data: auditLogs } = await supabase
        .from("audit_logs")
        .select("*")
        .eq("entity_type", entityType)
        .eq("entity_id", entityId)
        .order("created_at", { ascending: false })
        .limit(100);

      // Fetch entity-specific activities
      let entityActivities: Array<{
        id: string;
        activity_type: string;
        description: string;
        created_at: string;
        user_id: string;
      }> | null = null;

      if (entityType === "lead") {
        const { data } = await supabase
          .from("lead_activities")
          .select("id, activity_type, description, created_at, user_id")
          .eq("lead_id", entityId)
          .order("created_at", { ascending: false })
          .limit(100);
        entityActivities = data;
      } else {
        const { data } = await supabase
          .from("client_activities")
          .select("id, activity_type, description, created_at, user_id")
          .eq("client_id", entityId)
          .order("created_at", { ascending: false })
          .limit(100);
        entityActivities = data;
      }

      // Collect all user IDs (including transferring_agent from conversion details)
      const auditUserIds = auditLogs?.map(log => log.user_id) || [];
      const activityUserIds = entityActivities?.map(a => a.user_id) || [];
      const referencedUserIds: string[] = [];
      (auditLogs || []).forEach(log => {
        const d = log.details as Record<string, unknown> | null;
        if (d?.transferring_agent && typeof d.transferring_agent === 'string') {
          referencedUserIds.push(d.transferring_agent);
        }
        if (d?.assigned_super_agent && typeof d.assigned_super_agent === 'string') {
          referencedUserIds.push(d.assigned_super_agent);
        }
      });
      const allUserIds = [...new Set([...auditUserIds, ...activityUserIds, ...referencedUserIds])];

      // Fetch user profiles
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .in("id", allUserIds);

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

      // Transform audit logs — enrich details with resolved names
      const auditActivities: CombinedActivity[] = (auditLogs || []).map(log => {
        const profile = profileMap.get(log.user_id);
        const details = log.details as Record<string, unknown> | null;
        // Enrich conversion details with resolved agent names
        let enrichedDetails = details;
        if (details) {
          const transferringId = details.transferring_agent as string | undefined;
          const superAgentId = details.assigned_super_agent as string | undefined;
          if (transferringId || superAgentId) {
            enrichedDetails = { ...details };
            if (transferringId) {
              const tp = profileMap.get(transferringId);
              (enrichedDetails as Record<string, unknown>).transferring_agent_name = tp?.full_name || tp?.email || null;
            }
            if (superAgentId) {
              const sp = profileMap.get(superAgentId);
              (enrichedDetails as Record<string, unknown>).assigned_super_agent_name = sp?.full_name || sp?.email || null;
            }
          }
        }
        return {
          id: log.id,
          type: "audit",
          action: log.action_type,
          description: getReadableDescription(log.action_type, enrichedDetails),
          created_at: log.created_at,
          user_name: profile?.full_name || profile?.email || "System",
          ip_address: log.ip_address,
          user_agent: log.user_agent,
          raw_details: enrichedDetails,
        };
      });

      // Transform entity activities
      const entityActivityList: CombinedActivity[] = (entityActivities || []).map(activity => {
        const profile = profileMap.get(activity.user_id);
        return {
          id: activity.id,
          type: "activity",
          action: activity.activity_type,
          description: activity.description,
          created_at: activity.created_at,
          user_name: profile?.full_name || profile?.email || "System",
          ip_address: null,
          user_agent: null,
          raw_details: null,
        };
      });

      // Combine and sort
      return [...auditActivities, ...entityActivityList]
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    },
  });

  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3 border-b border-border/50">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <div className="p-1.5 rounded-md bg-primary/10">
            <History className="h-4 w-4 text-primary" />
          </div>
          Activity Log
          {allActivities.length > 0 && (
            <Badge variant="outline" className="ml-auto font-medium text-foreground">
              {allActivities.length} events
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[450px]">
          {isLoading ? (
            <div className="p-4 space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex gap-4 animate-pulse">
                  <div className="flex flex-col items-center">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <Skeleton className="w-0.5 flex-1 mt-2" />
                  </div>
                  <div className="flex-1 space-y-2 pb-6">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          ) : allActivities.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted/50 flex items-center justify-center">
                <History className="h-8 w-8 opacity-50" />
              </div>
              <p className="text-sm font-medium">No activity recorded yet</p>
              <p className="text-xs mt-1 text-muted-foreground/70">Actions on this record will appear here</p>
            </div>
          ) : (
            <div className="p-4">
              {allActivities.map((activity, index) => {
                const category = getActionCategory(activity.action);
                const styles = getCategoryStyles(category);
                const Icon = getActionIcon(activity.action);
                const isLast = index === allActivities.length - 1;
                
                return (
                  <div key={activity.id} className="flex gap-4 group">
                    {/* Timeline */}
                    <div className="flex flex-col items-center">
                      <div className={cn(
                        "relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-200",
                        styles.bg,
                        styles.border,
                        "group-hover:scale-110"
                      )}>
                        <Icon className={cn("h-4 w-4", styles.icon)} />
                      </div>
                      {!isLast && (
                        <div className="w-0.5 flex-1 bg-border/50 my-2" />
                      )}
                    </div>
                    
                    {/* Content */}
                    <div className={cn("flex-1 pb-6", isLast && "pb-2")}>
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={cn(
                              "text-sm font-semibold",
                              styles.icon
                            )}>
                              {formatActionLabel(activity.action)}
                            </span>
                            <span className="text-xs text-muted-foreground px-2 py-0.5 bg-muted/50 rounded-full">
                              {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
                            </span>
                          </div>
                          
                          {/* Smart description - re-compute from raw_details for best display */}
                          {(() => {
                            const smartDesc = activity.raw_details 
                              ? getReadableDescription(activity.action, activity.raw_details)
                              : "";
                            const displayDesc = smartDesc || activity.description;
                            
                            // Check if it's a status change with old/new status
                            const oldStatus = activity.raw_details?.old_status as string | undefined;
                            const newStatus = activity.raw_details?.new_status as string | undefined;
                            
                            // Check for amount/value - try all possible field names
                            const activityAmount = (
                              activity.raw_details?.amount || 
                              activity.raw_details?.value || 
                              activity.raw_details?.branch_value ||
                              activity.raw_details?.deposit_amount ||
                              activity.raw_details?.new_value
                            ) as number | undefined;
                            
                            // Check for value change
                            const oldValue = activity.raw_details?.old_value as number | undefined;
                            const newValue = activity.raw_details?.new_value as number | undefined;
                            const hasValueChange = oldValue !== undefined && newValue !== undefined && oldValue !== newValue;
                            
                            if (oldStatus && newStatus) {
                              return (
                                <div className="space-y-2 mt-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="text-sm px-2 py-0.5 bg-muted rounded text-muted-foreground">
                                      {formatStatus(oldStatus)}
                                    </span>
                                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                                    <span className={cn("text-sm px-2 py-0.5 rounded font-medium", styles.bg, styles.icon)}>
                                      {formatStatus(newStatus)}
                                    </span>
                                    {activityAmount && (
                                      <span className="text-sm font-semibold text-green-500 flex items-center gap-1 ml-2">
                                        <DollarSign className="h-3.5 w-3.5" />
                                        {activityAmount.toLocaleString()}
                                      </span>
                                    )}
                                  </div>
                                  {hasValueChange && (
                                    <div className="flex items-center gap-2 text-sm">
                                      <span className="text-muted-foreground">Value:</span>
                                      <span className="text-muted-foreground">${oldValue.toLocaleString()}</span>
                                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                                      <span className="text-green-500 font-medium">${newValue.toLocaleString()}</span>
                                    </div>
                                  )}
                                </div>
                              );
                            }
                            
                            return (
                              <div className="space-y-2 mt-1">
                                {displayDesc && (
                                  <p className="text-sm text-foreground/80 leading-relaxed">
                                    {displayDesc}
                                  </p>
                                )}
                                {activityAmount && !displayDesc?.includes("$") && (
                                  <div className="flex items-center gap-1.5">
                                    <DollarSign className="h-3.5 w-3.5 text-green-500" />
                                    <span className="text-sm font-semibold text-green-500">
                                      ${activityAmount.toLocaleString()}
                                    </span>
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      </div>
                      
                      {/* Meta info */}
                      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <User className="h-3 w-3" />
                          <span className="font-medium">{activity.user_name}</span>
                        </div>
                        <span className="text-muted-foreground/30">•</span>
                        <span>{format(new Date(activity.created_at), "MMM d, h:mm a")}</span>
                      </div>
                      
                      {/* Technical details - collapsible */}
                      {(activity.ip_address || activity.user_agent || (activity.raw_details && Object.keys(activity.raw_details).length > 0)) && (
                        <Collapsible className="mt-3">
                          <CollapsibleTrigger className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors group/trigger">
                            <ChevronDown className="h-3 w-3 transition-transform group-data-[state=open]/trigger:rotate-180" />
                            <span>Technical details</span>
                          </CollapsibleTrigger>
                          <CollapsibleContent className="mt-2 space-y-2 animate-fade-in">
                            {(activity.ip_address || activity.user_agent) && (
                              <div className="p-3 rounded-lg bg-muted/30 border border-border/50 space-y-2">
                                {activity.ip_address && (
                                  <div className="flex items-center gap-2 text-xs">
                                    <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                                    <span className="text-muted-foreground">IP:</span>
                                    <code className="font-mono text-foreground/70 bg-background/50 px-1.5 py-0.5 rounded">
                                      {activity.ip_address}
                                    </code>
                                  </div>
                                )}
                                {activity.user_agent && (
                                  <div className="flex items-start gap-2 text-xs">
                                    <Monitor className="h-3.5 w-3.5 text-muted-foreground mt-0.5" />
                                    <span className="text-muted-foreground">Device:</span>
                                    <span className="text-foreground/70 break-all" title={activity.user_agent}>
                                      {activity.user_agent.substring(0, 80)}{activity.user_agent.length > 80 ? "..." : ""}
                                    </span>
                                  </div>
                                )}
                              </div>
                            )}
                            
                            {activity.raw_details && Object.keys(activity.raw_details).length > 0 && (
                              <div className="p-3 rounded-lg bg-muted/30 border border-border/50">
                                <div className="text-xs text-muted-foreground mb-2">Raw data</div>
                                <pre className="text-xs font-mono text-foreground/70 overflow-auto max-h-32 whitespace-pre-wrap">
                                  {JSON.stringify(activity.raw_details, null, 2)}
                                </pre>
                              </div>
                            )}
                          </CollapsibleContent>
                        </Collapsible>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
