import { useState, useEffect } from "react";
import { Search, Users, UserPlus, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { clientHref, leadHref } from "@/lib/idCipher";
import { Badge } from "@/components/ui/badge";
import { useTenant } from "@/contexts/TenantContext";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";

type SearchResult = {
  id: string;
  type: "lead" | "client";
  name: string;
  email: string;
  status?: string;
  country?: string;
};

export function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { effectiveTenantId } = useTenant();

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  // Clear query when dialog closes
  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  useEffect(() => {
    if (!query || query.length < 2) {
      setResults([]);
      return;
    }

    const searchTimer = setTimeout(async () => {
      setLoading(true);
      try {
        const searchTerm = `%${query}%`;

        let leadsQuery = supabase
          .from("leads")
          .select("id, name, email, phone, status, country")
          .or(`name.ilike.${searchTerm},email.ilike.${searchTerm},phone.ilike.${searchTerm}`)
          .limit(5);

        let clientsQuery = supabase
          .from("clients")
          .select("id, name, email, status, country")
          .or(`name.ilike.${searchTerm},email.ilike.${searchTerm}`)
          .limit(5);

        // Tenant scoping
        if (effectiveTenantId) {
          leadsQuery = leadsQuery.eq("admin_id", effectiveTenantId);
          clientsQuery = clientsQuery.eq("admin_id", effectiveTenantId);
        }

        const [{ data: leads }, { data: clients }] = await Promise.all([
          leadsQuery,
          clientsQuery,
        ]);

        const searchResults: SearchResult[] = [
          ...(leads?.map((lead) => ({
            id: lead.id,
            type: "lead" as const,
            name: lead.name,
            email: lead.email || "",
            status: lead.status || undefined,
            country: lead.country || undefined,
          })) || []),
          ...(clients?.map((client) => ({
            id: client.id,
            type: "client" as const,
            name: client.name,
            email: client.email || "",
            status: client.status || undefined,
            country: client.country || undefined,
          })) || []),
        ];

        setResults(searchResults);
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => clearTimeout(searchTimer);
  }, [query, effectiveTenantId]);

  const handleSelect = (result: SearchResult) => {
    setOpen(false);
    if (result.type === "lead") {
      navigate(leadHref(result.id));
    } else {
      navigate(clientHref(result.id));
    }
  };

  const leadResults = results.filter((r) => r.type === "lead");
  const clientResults = results.filter((r) => r.type === "client");
  const isMac = typeof navigator !== "undefined" && navigator.platform?.toUpperCase().includes("MAC");

  return (
    <>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="default"
            size="icon"
            className="h-9 w-9 bg-primary hover:bg-primary/90"
            onClick={() => setOpen(true)}
          >
            <Search className="h-4 w-4" />
            <span className="sr-only">Search</span>
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <span>Search</span>
          <kbd className="ml-2 pointer-events-none inline-flex h-5 select-none items-center gap-0.5 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
            {isMac ? "⌘" : "Ctrl"}K
          </kbd>
        </TooltipContent>
      </Tooltip>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="overflow-hidden p-0 shadow-lg max-w-lg">
          <VisuallyHidden>
            <DialogTitle>Global Search</DialogTitle>
          </VisuallyHidden>
          <Command shouldFilter={false} className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5">
            <CommandInput
              placeholder="Search leads, clients..."
              value={query}
              onValueChange={setQuery}
            />
            <CommandList>
              {loading && (
                <div className="flex items-center justify-center py-6">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  <span className="ml-2 text-sm text-muted-foreground">Searching...</span>
                </div>
              )}
              {!loading && results.length === 0 && query.length >= 2 && (
                <CommandEmpty>No results found.</CommandEmpty>
              )}
              {!loading && query.length < 2 && (
                <div className="py-8 text-center">
                  <Search className="mx-auto h-8 w-8 text-muted-foreground/40" />
                  <p className="mt-2 text-sm text-muted-foreground">
                    Type at least 2 characters to search
                  </p>
                </div>
              )}
              {!loading && leadResults.length > 0 && (
                <CommandGroup heading="Leads">
                  {leadResults.map((result) => (
                    <CommandItem
                      key={result.id}
                      value={result.id}
                      onSelect={() => handleSelect(result)}
                      className="cursor-pointer"
                    >
                      <UserPlus className="mr-2 h-4 w-4 text-muted-foreground shrink-0" />
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="font-medium truncate">{result.name}</span>
                        <span className="text-xs text-muted-foreground truncate">
                          {result.email}
                          {result.country && ` • ${result.country}`}
                        </span>
                      </div>
                      {result.status && (
                        <Badge variant="outline" className="ml-2 shrink-0 text-xs">
                          {result.status}
                        </Badge>
                      )}
                    </CommandItem>
                  ))}
                </CommandGroup>
              )}
              {!loading && clientResults.length > 0 && (
                <CommandGroup heading="Clients">
                  {clientResults.map((result) => (
                    <CommandItem
                      key={result.id}
                      value={result.id}
                      onSelect={() => handleSelect(result)}
                      className="cursor-pointer"
                    >
                      <Users className="mr-2 h-4 w-4 text-muted-foreground shrink-0" />
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="font-medium truncate">{result.name}</span>
                        <span className="text-xs text-muted-foreground truncate">
                          {result.email}
                          {result.country && ` • ${result.country}`}
                        </span>
                      </div>
                      {result.status && (
                        <Badge variant="outline" className="ml-2 shrink-0 text-xs">
                          {result.status}
                        </Badge>
                      )}
                    </CommandItem>
                  ))}
                </CommandGroup>
              )}
            </CommandList>
          </Command>
        </DialogContent>
      </Dialog>
    </>
  );
}
