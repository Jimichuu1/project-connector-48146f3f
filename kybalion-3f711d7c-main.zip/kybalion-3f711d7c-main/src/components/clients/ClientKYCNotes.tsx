import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Info } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

interface ClientKYCNotesProps {
  clientId: string;
}

export const ClientKYCNotes = ({ clientId }: ClientKYCNotesProps) => {
  const { data: kycRecords, isLoading } = useQuery({
    queryKey: ['kyc-records-client', clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('kyc_records')
        .select('id, notes, bank_name, created_at')
        .eq('client_id', clientId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });

  const banks = kycRecords?.filter(record => record.bank_name) || [];
  const notes = kycRecords?.filter(record => record.notes) || [];

  if (isLoading) {
    return <Skeleton className="h-8 w-8" />;
  }

  const totalCount = banks.length + notes.length;

  if (!kycRecords || totalCount === 0) {
    return (
      <Button 
        variant="ghost" 
        size="icon"
        className="h-8 w-8 opacity-30 cursor-default"
        disabled
      >
        <Info className="h-4 w-4" />
      </Button>
    );
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon"
          className="h-8 w-8 relative"
        >
          <Info className="h-4 w-4" />
          {totalCount > 0 && (
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] font-medium text-primary-foreground flex items-center justify-center">
              {totalCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          {banks.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Banks</h4>
              <div className="flex flex-wrap gap-2">
                {banks.map((bank) => (
                  <div
                    key={bank.id}
                    className="inline-flex items-center rounded-md bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground"
                  >
                    {bank.bank_name}
                  </div>
                ))}
              </div>
            </div>
          )}
          {notes.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">KYC Notes</h4>
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {notes.map((note) => (
                  <div key={note.id} className="space-y-1 pb-3 border-b last:border-0 last:pb-0">
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(note.created_at), 'MMM d, yyyy')}
                    </p>
                    <p className="text-sm">{note.notes}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};
