import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { UserDisplay } from "@/components/ui/user-display";

interface ConvertedByDisplayProps {
  userId: string;
}

export const ConvertedByDisplay = ({ userId }: ConvertedByDisplayProps) => {
  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email, avatar_url')
        .eq('id', userId)
        .maybeSingle();
      
      if (error) return null;
      return data;
    },
    enabled: !!userId,
  });

  if (isLoading) {
    return <Skeleton className="h-8 w-32" />;
  }

  if (!profile) {
    return <span className="text-muted-foreground text-sm">Unknown</span>;
  }

  return (
    <UserDisplay 
      name={profile.full_name || profile.email || 'Unknown'} 
      avatar={profile.avatar_url}
    />
  );
};
