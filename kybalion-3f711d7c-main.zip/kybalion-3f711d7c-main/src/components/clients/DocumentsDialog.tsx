import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DocumentUpload } from "@/components/documents/DocumentUpload";
import { DocumentList } from "@/components/documents/DocumentList";

interface DocumentsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entityId: string;
  entityType: 'lead' | 'client';
}

export const DocumentsDialog = ({ open, onOpenChange, entityId, entityType }: DocumentsDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Documents</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <DocumentUpload entityId={entityId} entityType={entityType} />
          <DocumentList entityId={entityId} entityType={entityType} />
        </div>
      </DialogContent>
    </Dialog>
  );
};
