import { useMemo } from "react";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import { Client, ClientStatus } from "@/types/clients";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { User, Mail, Phone, Activity, UserCheck, Globe, Layers, Settings, Building2, Info, Clock, History, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { TenantDisplay } from "@/components/ui/tenant-display";
import { SortableTableHead, SortState, sortData } from "@/components/ui/sortable-table-head";
import { ClientStatusDropdown } from "@/components/clients/ClientStatusDropdown";
import { ClientAssignmentDropdown } from "@/components/clients/ClientAssignmentDropdown";
import { ConvertedByDisplay } from "@/components/clients/ConvertedByDisplay";
import { ClientGroupDisplay } from "@/components/clients/ClientGroupDisplay";
import { ClientRowActions } from "./ClientRowActions";
import { clientHref } from "@/lib/idCipher";
import { ClientKYCNotes } from "./ClientKYCNotes";
import { LocalTimeDisplay } from "@/components/ui/local-time-display";

import { getCountryFromPhone, getCountryCode } from "@/lib/phoneCountryCode";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useFavouriteClients } from "@/hooks/useFavouriteClients";
import { useUserData } from "@/contexts/UserDataContext";

interface ClientsTableViewProps {
  clients: Client[];
  isLoading: boolean;
  selectedClients: string[];
  onSelectAll: (checked: boolean) => void;
  onSelectClient: (clientId: string, checked: boolean) => void;
  sort: SortState;
  onSort: (key: string) => void;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  isManager: boolean;
  shouldShowEmail: boolean;
  shouldShowPhone: boolean;
  onAddBank: (client: Client) => void;
  onAddNote: (client: Client) => void;
  onCreateAccount: (client: Client) => void;
  depositedClientIds?: Set<string>;
  showFavouriteColumn?: boolean;
}

export function ClientsTableView({
  clients,
  isLoading,
  selectedClients,
  onSelectAll,
  onSelectClient,
  sort,
  onSort,
  isSuperAdmin,
  isAdmin,
  isManager,
  shouldShowEmail,
  shouldShowPhone,
  onAddBank,
  onAddNote,
  onCreateAccount,
  depositedClientIds,
  showFavouriteColumn = false,
}: ClientsTableViewProps) {
  const { isTenantOwner: isTO, isSuperAdmin: isSA } = useUserData();
  const canFavourite = showFavouriteColumn || isTO || isSA;
  const { favouriteIds, toggleFavourite } = useFavouriteClients();
  const sortedClients = useMemo(() => {
    return sortData(clients, sort.key, sort.direction);
  }, [clients, sort.key, sort.direction]);

  const handleCopyEmail = (email: string) => {
    navigator.clipboard.writeText(email);
    toast.success("Email copied to clipboard");
  };

  const handleCopyPhone = (phone: string | null) => {
    if (phone) {
      navigator.clipboard.writeText(phone);
      toast.success("Phone copied to clipboard");
    }
  };

  const handleStatusChange = async (clientId: string, newStatus: ClientStatus) => {
    try {
      const { error } = await supabase.from("clients").update({ status: newStatus }).eq("id", clientId);
      if (error) throw error;
      toast.success("Client status updated");
    } catch (error) {
      console.error("Error updating client status:", error);
      toast.error("Failed to update client status");
    }
  };

  return (
    <div className="rounded-md">
      <Table className="text-sm">
        <TableHeader>
          <TableRow>
            <TableHead className="w-10 py-2">
              <Checkbox
                checked={clients.length > 0 && selectedClients.length === clients.length}
                onCheckedChange={onSelectAll}
              />
            </TableHead>
            {canFavourite && (
              <TableHead className="w-10 py-2">
                <Star className="h-3 w-3 text-muted-foreground" />
              </TableHead>
            )}
            {isSuperAdmin && (
              <TableHead className="py-2">
                <div className="flex items-center gap-1.5">
                  <Building2 className="h-3 w-3 text-muted-foreground" />
                  <span className="text-muted-foreground">Tenant</span>
                </div>
              </TableHead>
            )}
            <SortableTableHead sortKey="name" currentSort={sort} onSort={onSort} icon={<User className="h-3 w-3 text-muted-foreground" />}>
              Name
            </SortableTableHead>
            <SortableTableHead sortKey="email" currentSort={sort} onSort={onSort} icon={<Mail className="h-3 w-3 text-muted-foreground" />}>
              Email
            </SortableTableHead>
            <SortableTableHead sortKey="home_phone" currentSort={sort} onSort={onSort} icon={<Phone className="h-3 w-3 text-muted-foreground" />}>
              Phone
            </SortableTableHead>
            <TableHead className="py-2 w-[60px]">
              <div className="flex items-center gap-1.5">
                <Clock className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Time</span>
              </div>
            </TableHead>
            <SortableTableHead sortKey="status" currentSort={sort} onSort={onSort} icon={<Activity className="h-3 w-3 text-muted-foreground" />}>
              Status
            </SortableTableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <UserCheck className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">{isAdmin || isManager ? "Assigned" : "Agent"}</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Info className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Notes</span>
              </div>
            </TableHead>
            <TableHead className="py-2">
              <div className="flex items-center gap-1.5">
                <Layers className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Group</span>
              </div>
            </TableHead>
            <SortableTableHead sortKey="updated_at" currentSort={sort} onSort={onSort} icon={<History className="h-3 w-3 text-muted-foreground" />}>
              Action
            </SortableTableHead>
            <SortableTableHead sortKey="country" currentSort={sort} onSort={onSort} icon={<Globe className="h-3 w-3 text-muted-foreground" />}>
              Country
            </SortableTableHead>
            <TableHead className="sticky right-0 py-2 shadow-[-4px_0_8px_rgba(0,0,0,0.1)]" style={{ backgroundColor: "#191919" }} />
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={12} className="text-center py-1.5">Loading clients...</TableCell>
            </TableRow>
          ) : clients.length === 0 ? (
            <TableRow>
              <TableCell colSpan={12} className="text-center py-1.5">No clients found</TableCell>
            </TableRow>
          ) : (
            sortedClients.map((client) => {
              const hasDeposit = depositedClientIds?.has(client.id);
              return (
              <TableRow
                key={client.id}
                className={cn(
                  "hover:bg-muted/50",
                  hasDeposit && "border-l-4 border-l-green-500 bg-green-500/5"
                )}
              >
                <TableCell className="py-1.5">
                  <Checkbox
                    checked={selectedClients.includes(client.id)}
                    onCheckedChange={(checked) => onSelectClient(client.id, checked === true)}
                  />
                </TableCell>
                {canFavourite && (
                  <TableCell className="py-1.5">
                    <button
                      onClick={(e) => { e.stopPropagation(); toggleFavourite.mutate(client.id); }}
                      className="hover:scale-110 transition-transform"
                    >
                      <Star
                        className={cn(
                          "h-4 w-4",
                          favouriteIds.has(client.id)
                            ? "text-yellow-500 fill-yellow-500"
                            : "text-muted-foreground"
                        )}
                      />
                    </button>
                  </TableCell>
                )}
                {isSuperAdmin && (
                  <TableCell className="py-1.5">
                    <TenantDisplay adminId={client.admin_id} />
                  </TableCell>
                )}
                <TableCell className="font-medium py-1.5 max-w-[160px]">
                  <Link
                    to={clientHref(client.id)}
                    className="truncate block font-semibold text-[14px] hover:text-primary transition-colors"
                    title={client.name}
                  >
                    {client.name}
                  </Link>
                </TableCell>
                <TableCell
                  className="py-1.5 max-w-[160px]"
                >
                  {shouldShowEmail ? (
                    <button
                      onClick={() => handleCopyEmail(client.email)}
                      className="truncate block w-full text-left hover:text-primary transition-colors cursor-pointer"
                      title={client.email}
                    >
                      {client.email}
                    </button>
                  ) : (
                    <span className="text-muted-foreground">••••••••</span>
                  )}
                </TableCell>
                <TableCell
                  className="py-1.5"
                >
                  {shouldShowPhone ? (
                    <button
                      onClick={() => handleCopyPhone(client.home_phone)}
                      className="hover:text-primary transition-colors cursor-pointer"
                    >
                      {client.home_phone || "-"}
                    </button>
                  ) : (
                    <span className="text-muted-foreground">••••••••</span>
                  )}
                </TableCell>
                <TableCell className="py-1.5">
                  <LocalTimeDisplay phone={client.home_phone} />
                </TableCell>
                <TableCell className="py-1.5">
                  <ClientStatusDropdown
                    status={client.status}
                    onStatusChange={(newStatus) => handleStatusChange(client.id, newStatus)}
                  />
                </TableCell>
                <TableCell className="py-1.5">
                  {isAdmin || isManager ? (
                    <ClientAssignmentDropdown clientId={client.id} currentAssignedTo={client.assigned_to || null} />
                  ) : (client as any).transferring_agent ? (
                    <ConvertedByDisplay userId={(client as any).transferring_agent} />
                  ) : (
                    <span className="text-muted-foreground">-</span>
                  )}
                </TableCell>
                <TableCell className="py-1.5">
                  <ClientKYCNotes clientId={client.id} />
                </TableCell>
                <TableCell className="py-1.5">
                  <ClientGroupDisplay clientId={client.id} />
                </TableCell>
                <TableCell className="py-1.5 whitespace-nowrap text-muted-foreground">
                  {client.updated_at ? format(new Date(client.updated_at), "d MMM, HH:mm") : "-"}
                </TableCell>
                <TableCell className="py-1.5">{getCountryCode(getCountryFromPhone(client.home_phone)) || "-"}</TableCell>
                <TableCell
                  className="py-1.5 sticky right-0 bg-background shadow-[-4px_0_8px_rgba(0,0,0,0.1)]"
                >
                  <ClientRowActions
                    client={client}
                    onAddBank={onAddBank}
                    onAddNote={onAddNote}
                    onCreateAccount={onCreateAccount}
                  />
                </TableCell>
              </TableRow>
            )})
          )}
        </TableBody>
      </Table>
    </div>
  );
}
