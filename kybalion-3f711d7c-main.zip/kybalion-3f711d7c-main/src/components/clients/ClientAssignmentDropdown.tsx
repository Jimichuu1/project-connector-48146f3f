import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { UserCombobox, UserOption } from "@/components/ui/user-combobox";
import { useTenant } from "@/contexts/TenantContext";
import { useUserRole } from "@/hooks/useUserRole";

interface ClientAssignmentDropdownProps {
  clientId: string;
  currentAssignedTo: string | null;
  onAssignmentChange?: () => void;
}

export const ClientAssignmentDropdown = ({ 
  clientId, 
  currentAssignedTo,
  onAssignmentChange 
}: ClientAssignmentDropdownProps) => {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const { isManager } = useUserRole();
  const queryClient = useQueryClient();
  const [isUpdating, setIsUpdating] = useState(false);

  // Fetch super agents only - filtered by tenant and manager's team
  const { data: usersData, isLoading } = useQuery({
    queryKey: ['super-agents-only', effectiveTenantId, isManager, user?.id],
    queryFn: async () => {
      // Get only SUPER_AGENT user_ids from user_roles
      const { data: userRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .eq('role', 'SUPER_AGENT');
      
      if (rolesError) throw rolesError;
      if (!userRoles || userRoles.length === 0) return { users: [] };
      
      const userIds = [...new Set(userRoles.map(r => r.user_id))];
      
      // Get profiles for those user_ids - filter by tenant using admin_id
      let profilesQuery = supabase
        .from('profiles')
        .select('id, full_name, email, avatar_url, admin_id, created_by');
      
      if (effectiveTenantId) {
        profilesQuery = profilesQuery.eq('admin_id', effectiveTenantId);
      }
      
      // If manager, only show team members created by this manager
      if (isManager && user?.id) {
        profilesQuery = profilesQuery.eq('created_by', user.id);
      }
      
      const { data: profiles, error: profilesError } = await profilesQuery;
      
      if (profilesError) throw profilesError;
      
      // Filter to only include super agents from userIds
      const filteredProfiles = (profiles || []).filter(p => userIds.includes(p.id));
      
      const users = filteredProfiles.map(profile => ({
        id: profile.id,
        name: `${profile.full_name || profile.email || 'Unknown'}`,
        avatar: profile.avatar_url,
      }));

      return { users };
    },
  });

  const handleAssignmentChange = async (newAssignedTo: string) => {
    if (!user) return;
    
    setIsUpdating(true);
    try {
      const isUnassigning = newAssignedTo === 'unassigned';
      const actualAssignedTo = isUnassigning ? null : newAssignedTo;

      const { error } = await supabase
        .from('clients')
        .update({ 
          assigned_to: actualAssignedTo,
          admin_id: effectiveTenantId || null,
        })
        .eq('id', clientId);

      if (error) throw error;

      // Send CLIENT_ASSIGNED notification to the assigned super agent
      if (!isUnassigning && actualAssignedTo) {
        const { data: clientData } = await supabase
          .from('clients')
          .select('name')
          .eq('id', clientId)
          .single();

        const { error: notificationError } = await supabase.from('notifications').insert({
          user_id: actualAssignedTo,
          type: 'CLIENT_ASSIGNED',
          message: `Client "${clientData?.name || 'Unknown'}" has been assigned to you`,
          related_entity_type: 'client',
          related_entity_id: clientId,
          admin_id: effectiveTenantId || null,
        });

        if (notificationError) {
          console.error('Failed to send client assignment notification:', notificationError);
        }
      }

      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast.success(isUnassigning ? 'Client unassigned' : 'Client assignment updated');
      onAssignmentChange?.();
    } catch (error) {
      console.error('Error updating assignment:', error);
      toast.error('Failed to update assignment');
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return <Skeleton className="h-8 w-32" />;
  }

  const options: UserOption[] = [
    { value: 'unassigned', label: 'Unassigned' },
    ...((usersData?.users || []).map(user => ({
      value: user.id,
      label: user.name,
      avatar: user.avatar,
    })))
  ];

  return isUpdating ? (
    <Skeleton className="h-9 w-full max-w-[200px]" />
  ) : (
    <UserCombobox
      options={options}
      value={currentAssignedTo || 'unassigned'}
      onValueChange={handleAssignmentChange}
      placeholder="Select super agent..."
      searchPlaceholder="Search super agents..."
      emptyText="No super agent found"
    />
  );
};
