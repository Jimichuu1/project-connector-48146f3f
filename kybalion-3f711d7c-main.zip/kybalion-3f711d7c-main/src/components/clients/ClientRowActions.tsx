import { Client } from "@/types/clients";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Plus, Landmark, StickyNote, User } from "lucide-react";

interface ClientRowActionsProps {
  client: Client;
  onAddBank: (client: Client) => void;
  onAddNote: (client: Client) => void;
  onCreateAccount: (client: Client) => void;
}

export function ClientRowActions({
  client,
  onAddBank,
  onAddNote,
  onCreateAccount,
}: ClientRowActionsProps) {
  return (
    <TooltipProvider>
      <div className="flex items-center gap-0.5">
        <DropdownMenu>
          <Tooltip>
            <TooltipTrigger asChild>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" className="h-7 w-7 p-0 [&_svg]:size-3.5">
                  <Plus />
                </Button>
              </DropdownMenuTrigger>
            </TooltipTrigger>
            <TooltipContent>Add KYC</TooltipContent>
          </Tooltip>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onAddBank(client)} className="text-sm">
              <Landmark className="h-3.5 w-3.5 mr-2" />
              Add Bank
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAddNote(client)} className="text-sm">
              <StickyNote className="h-3.5 w-3.5 mr-2" />
              Add Note
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onCreateAccount(client)} className="text-sm">
              <User className="h-3.5 w-3.5 mr-2" />
              Create Account
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </TooltipProvider>
  );
}
