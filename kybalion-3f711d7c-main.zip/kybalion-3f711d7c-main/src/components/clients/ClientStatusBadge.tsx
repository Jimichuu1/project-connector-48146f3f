import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useClientStatuses, getClientStatusConfig } from "@/hooks/useClientStatuses";

interface ClientStatusBadgeProps {
  status: string;
  className?: string;
}

export const ClientStatusBadge = ({ status, className }: ClientStatusBadgeProps) => {
  const { data: statuses = [] } = useClientStatuses();
  const config = getClientStatusConfig(statuses, status);

  return (
    <Badge 
      className={cn("font-medium border-0", className)}
      style={{ 
        backgroundColor: config.color,
        color: "#fff"
      }}
    >
      {config.label}
    </Badge>
  );
};
