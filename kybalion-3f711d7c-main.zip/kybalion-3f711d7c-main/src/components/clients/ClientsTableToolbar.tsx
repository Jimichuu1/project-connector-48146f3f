import { TableIcon, KanbanSquare, Download, UserPlus, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { SearchFilter } from "@/components/filters/SearchFilter";

interface ClientsTableToolbarProps {
  search: string;
  onSearchChange: (value: string) => void;
  onExport: () => void;
  onAddClient: () => void;
  onImport?: () => void;
  viewMode?: "table" | "board";
  onViewModeChange?: (mode: "table" | "board") => void;
  isRestrictedRole?: boolean;
  isAdmin?: boolean;
}

export function ClientsTableToolbar({
  search,
  onSearchChange,
  onExport,
  onAddClient,
  onImport,
  viewMode = "table",
  onViewModeChange,
  isRestrictedRole = false,
  isAdmin = false
}: ClientsTableToolbarProps) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-border">
      <div className="flex items-center gap-2">
        <ToggleGroup
          type="single"
          value={viewMode}
          onValueChange={(value) => value && onViewModeChange?.(value as "table" | "board")}
        >
          <ToggleGroupItem value="table" aria-label="Table view" size="sm" className="gap-2">
            <TableIcon className="h-4 w-4" />
            Table
          </ToggleGroupItem>
          <ToggleGroupItem value="board" aria-label="Board view" size="sm" className="gap-2">
            <KanbanSquare className="h-4 w-4" />
            Board
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="flex items-center gap-2">
        <SearchFilter
          value={search}
          onChange={onSearchChange}
          placeholder="Search clients..."
        />

        {!isRestrictedRole && (
          <>
            {isAdmin && (
              <>
                <Button variant="ghost" size="sm" onClick={onImport}>
                  <Upload className="h-4 w-4 mr-1" />
                  Import
                </Button>
                <Button variant="ghost" size="sm" onClick={onExport}>
                  <Download className="h-4 w-4 mr-1" />
                  Export
                </Button>
              </>
            )}
            <Button size="sm" onClick={onAddClient} className="gap-2">
              Add Client
              <UserPlus className="h-4 w-4" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
