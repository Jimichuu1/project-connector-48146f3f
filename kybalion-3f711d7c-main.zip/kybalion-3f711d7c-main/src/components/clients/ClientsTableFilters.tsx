import { useState } from "react";
import { UserCheck, Globe, Activity, Building2, FolderOpen, X, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { AssignedToFilter } from "@/components/leads/AssignedToFilter";
import { CountryFilter } from "@/components/leads/CountryFilter";
import { TenantFilter } from "@/components/filters/TenantFilter";
import { ClientGroupFilter } from "@/components/clients/ClientGroupFilter";
import { useActiveClientStatuses } from "@/hooks/useClientStatuses";
import { ClientStatus } from "@/types/clients";

export interface ClientFilterValues {
  assignedTo: string[];
  country: string[];
  tenant: string[];
  group: string[];
  hasDeposited?: boolean;
}

interface ClientsTableFiltersProps {
  selectedStatuses: ClientStatus[];
  onStatusesChange: (statuses: ClientStatus[]) => void;
  filterValues?: ClientFilterValues;
  onFilterValuesChange?: (values: ClientFilterValues) => void;
  isAgent?: boolean;
  isSuperAdmin?: boolean;
}

const AVAILABLE_FILTERS = [
  { value: "tenant", label: "Tenant", icon: Building2, superAdminOnly: true },
  { value: "group", label: "Group", icon: FolderOpen, superAdminOnly: false },
  { value: "assigned_to", label: "Assigned To", icon: UserCheck, superAdminOnly: false },
  { value: "country", label: "Country", icon: Globe, superAdminOnly: false },
] as const;

export function ClientsTableFilters({
  selectedStatuses,
  onStatusesChange,
  filterValues = { assignedTo: [], country: [], tenant: [], group: [] },
  onFilterValuesChange,
  isAgent = false,
  isSuperAdmin = false,
}: ClientsTableFiltersProps) {
  const [filterPopoverOpen, setFilterPopoverOpen] = useState<string | null>(null);
  
  // Fetch dynamic statuses from database
  const { data: statuses = [] } = useActiveClientStatuses();
  const STATUS_OPTIONS = statuses.map(s => ({
    value: s.name,
    label: s.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())
  }));

  // Filter available filters based on user role
  const availableFilters = AVAILABLE_FILTERS.filter((filter) => {
    if (filter.superAdminOnly && !isSuperAdmin) {
      return false;
    }
    if (isAgent && filter.value === "assigned_to") {
      return false;
    }
    return true;
  });

  const toggleStatus = (status: ClientStatus) => {
    if (selectedStatuses.includes(status)) {
      onStatusesChange(selectedStatuses.filter((s) => s !== status));
    } else {
      onStatusesChange([...selectedStatuses, status]);
    }
  };

  const getFilterValueCount = (filter: string): number => {
    switch (filter) {
      case "tenant":
        return filterValues.tenant.length;
      case "group":
        return filterValues.group.length;
      case "assigned_to":
        return filterValues.assignedTo.length;
      case "country":
        return filterValues.country.length;
      default:
        return 0;
    }
  };

  const hasAnyFilters = 
    selectedStatuses.length > 0 ||
    filterValues.assignedTo.length > 0 ||
    filterValues.country.length > 0 ||
    filterValues.tenant.length > 0 ||
    filterValues.group.length > 0 ||
    filterValues.hasDeposited === true;

  const clearAllFilters = () => {
    onStatusesChange([]);
    if (onFilterValuesChange) {
      onFilterValuesChange({
        assignedTo: [],
        country: [],
        tenant: [],
        group: [],
        hasDeposited: undefined,
      });
    }
  };

  const toggleDeposited = () => {
    if (onFilterValuesChange) {
      onFilterValuesChange({
        ...filterValues,
        hasDeposited: filterValues.hasDeposited ? undefined : true,
      });
    }
  };

  return (
    <div className="flex items-center gap-2 py-3 border-b border-border">
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className={`gap-2 rounded-full ${
              selectedStatuses.length > 0 ? "bg-primary/10 border-primary/50 pr-2" : "bg-background"
            }`}
          >
            <Activity className="h-4 w-4" />
            <span className={selectedStatuses.length > 0 ? "text-primary-foreground font-medium" : "text-muted-foreground"}>
              Status
            </span>
            {selectedStatuses.length > 0 && (
              <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                {selectedStatuses.length}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-48 p-0">
          <div className="border-b border-border p-2">
            <span className="font-medium text-sm">Status</span>
          </div>
          <div className="p-1 max-h-64 overflow-y-auto">
            {statuses.map((status) => (
              <label
                key={status.name}
                className="flex items-center gap-2 px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selectedStatuses.includes(status.name)}
                  onChange={() => toggleStatus(status.name)}
                  className="h-4 w-4 rounded border-border"
                />
                {status.color && (
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: status.color }}
                  />
                )}
                <span className="text-sm">
                  {status.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                </span>
              </label>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      {/* Deposited Toggle */}
      <Button
        variant="outline"
        size="sm"
        className={`gap-2 rounded-full ${
          filterValues.hasDeposited ? "bg-green-500/20 border-green-500/50 text-green-400" : "bg-background"
        }`}
        onClick={toggleDeposited}
      >
        <DollarSign className="h-4 w-4" />
        <span className={filterValues.hasDeposited ? "font-medium" : "text-muted-foreground"}>
          Deposited
        </span>
      </Button>

      {availableFilters.map((filter) => {
        const FilterIcon = filter.icon;
        const valueCount = getFilterValueCount(filter.value);
        const hasValue = valueCount > 0;

        return (
          <Popover key={filter.value} open={filterPopoverOpen === filter.value} onOpenChange={(open) => setFilterPopoverOpen(open ? filter.value : null)}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className={`gap-2 rounded-full ${hasValue ? "bg-primary/10 border-primary/50 pr-2" : "bg-background"}`}
              >
                {FilterIcon && <FilterIcon className="h-4 w-4" />}
                <span className={hasValue ? "text-primary-foreground font-medium" : "text-muted-foreground"}>
                  {filter.label}
                </span>
                {hasValue && (
                  <Badge variant="default" className="ml-1 text-xs h-5 px-1.5">
                    {valueCount}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="p-0">
              <div className="border-b border-border p-2 flex items-center justify-between">
                <span className="font-medium text-sm">{filter.label}</span>
              </div>
              {filter.value === "tenant" && onFilterValuesChange && (
                <TenantFilter
                  value={filterValues.tenant}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      tenant: newValue,
                    })
                  }
                />
              )}
              {filter.value === "group" && onFilterValuesChange && (
                <ClientGroupFilter
                  value={filterValues.group}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      group: newValue,
                    })
                  }
                />
              )}
              {filter.value === "assigned_to" && onFilterValuesChange && (
                <AssignedToFilter
                  value={filterValues.assignedTo}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      assignedTo: newValue,
                    })
                  }
                  entityType="clients"
                />
              )}
              {filter.value === "country" && onFilterValuesChange && (
                <CountryFilter
                  value={filterValues.country}
                  onChange={(newValue) =>
                    onFilterValuesChange({
                      ...filterValues,
                      country: newValue,
                    })
                  }
                  entityType="clients"
                />
              )}
            </PopoverContent>
          </Popover>
        );
      })}

      {hasAnyFilters && (
        <Button variant="ghost" size="sm" className="gap-2 rounded-full text-muted-foreground" onClick={clearAllFilters}>
          <X className="h-4 w-4" />
          Clear filters
        </Button>
      )}
    </div>
  );
}
