import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useToast } from "@/hooks/use-toast";
import { ClientStatus } from "@/types/clients";
import { useClientGroups } from "@/hooks/useClientGroups";
import { Loader2 } from "lucide-react";
import { useAuditLog } from "@/hooks/useAuditLog";

interface CreateClientDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateClientDialog = ({ open, onOpenChange }: CreateClientDialogProps) => {
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();
  const { toast } = useToast();
  const { getSystemGroupIds, addClientToGroup } = useClientGroups();
  const { logAction } = useAuditLog();
  
  const [isLive, setIsLive] = useState(true);
  
  const createClient = useMutation({
    mutationFn: async (clientData: Record<string, any>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase
        .from('clients')
        .insert([{ 
          ...clientData, 
          created_by: user.id,
          admin_id: effectiveTenantId || null 
        } as any])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: async (data) => {
      // Add to appropriate group based on Live checkbox
      try {
        const groupIds = await getSystemGroupIds();
        if (groupIds) {
          const targetGroupId = isLive ? groupIds.liveGroupId : groupIds.convertedGroupId;
          await addClientToGroup.mutateAsync({ 
            clientId: data.id, 
            groupId: targetGroupId 
          });
        }
      } catch (groupError) {
        console.error("Failed to add client to group:", groupError);
        // Don't fail the whole operation if group assignment fails
      }

      queryClient.invalidateQueries({ queryKey: ['clients-paginated'] });
      queryClient.invalidateQueries({ queryKey: ['clients-count'] });
      
      // Log client creation
      logAction({
        actionType: 'client_created',
        entityType: 'client',
        entityId: data.id,
        details: {
          client_name: data.name,
          client_email: data.email,
          client_status: data.status,
          is_live: isLive,
          client_country: data.country,
        },
        adminId: effectiveTenantId,
      });
      
      toast({
        title: "Client created",
        description: "The client has been successfully created.",
      });
    },
    onError: (error: unknown) => {
      const message = error instanceof Error ? error.message : "An unexpected error occurred";
      toast({
        title: "Failed to create client",
        description: message,
        variant: "destructive",
      });
    },
  });
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    home_phone: "",
    country: "",
    status: "ACTIVE" as ClientStatus,
    balance: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    await createClient.mutateAsync({
      name: formData.name,
      email: formData.email,
      home_phone: formData.home_phone || undefined,
      country: formData.country || undefined,
      status: formData.status,
      balance: formData.balance ? parseFloat(formData.balance) : 0,
      join_date: new Date().toISOString(),
      open_trades: 0,
      deposits: 0,
    });

    onOpenChange(false);
    setFormData({
      name: "",
      email: "",
      home_phone: "",
      country: "",
      status: "ACTIVE",
      balance: "",
    });
    setIsLive(true);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Client</DialogTitle>
          <DialogDescription>
            Add a new client to the CRM system
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="home_phone">Phone *</Label>
              <Input
                id="home_phone"
                placeholder="+491512006"
                value={formData.home_phone}
                onChange={(e) => {
                  const formatted = e.target.value.replace(/[^\d+]/g, '');
                  setFormData({ ...formData, home_phone: formatted });
                }}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value as ClientStatus })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ACTIVE">Active</SelectItem>
                  <SelectItem value="FLIPPED">Flipped</SelectItem>
                  <SelectItem value="FREELOADER">Freeloader</SelectItem>
                  <SelectItem value="NO_ANSWER">No Answer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="balance">Balance</Label>
              <Input
                id="balance"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={formData.balance}
                onChange={(e) => setFormData({ ...formData, balance: e.target.value })}
              />
            </div>
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <Checkbox
              id="isLive"
              checked={isLive}
              onCheckedChange={(checked) => setIsLive(checked === true)}
            />
            <Label 
              htmlFor="isLive" 
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
            >
              Live
            </Label>
            <span className="text-xs text-muted-foreground">
              (Uncheck to mark as Converted)
            </span>
          </div>

          <div className="flex justify-end pt-4">
            <ButtonGroup>
              <Button size="sm" type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button size="sm" type="submit" disabled={createClient.isPending}>
                {createClient.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Create Client
              </Button>
            </ButtonGroup>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
