import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Client, ClientStatus } from "@/types/clients";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Mail, Building2, GripVertical, PhoneCall, Send, MoreVertical, Landmark, StickyNote, User } from "lucide-react";
import { clientHref } from "@/lib/idCipher";
import { cn } from "@/lib/utils";
import { ClientStatusBadge } from "./ClientStatusBadge";
import { ConvertedByDisplay } from "./ConvertedByDisplay";
import { toast } from "sonner";
import { useActiveClientStatuses } from "@/hooks/useClientStatuses";

interface ClientsBoardViewProps {
  clients: Client[];
  onStatusChange: (clientId: string, newStatus: ClientStatus) => void;
  isAgent: boolean;
  isSuperAgent?: boolean;
  onCall?: (client: Client) => void;
  onEmail?: (client: Client) => void;
  onAddBank?: (client: Client) => void;
  onAddNote?: (client: Client) => void;
  onCreateAccount?: (client: Client) => void;
}

// Generate a color class based on position or color value
function getColumnColor(color: string | null, index: number): string {
  if (color) {
    return `border-l-4`;
  }
  // Fallback colors based on position
  const colors = [
    "bg-green-500/10 border-green-500/20",
    "bg-red-500/10 border-red-500/20",
    "bg-purple-500/10 border-purple-500/20",
    "bg-orange-500/10 border-orange-500/20",
    "bg-blue-500/10 border-blue-500/20",
    "bg-yellow-500/10 border-yellow-500/20",
  ];
  return colors[index % colors.length];
}

function ClientCard({
  client,
  isAgent,
  isSuperAgent,
  onCall,
  onEmail,
  onAddBank,
  onAddNote,
  onCreateAccount,
}: {
  client: Client;
  isAgent: boolean;
  isSuperAgent?: boolean;
  onCall?: (client: Client) => void;
  onEmail?: (client: Client) => void;
  onAddBank?: (client: Client) => void;
  onAddNote?: (client: Client) => void;
  onCreateAccount?: (client: Client) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: client.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={cn(
        "p-4 cursor-move hover:shadow-md transition-all duration-200 border-border bg-card group",
        isDragging && "opacity-50 ring-2 ring-primary"
      )}
    >
      <div className="space-y-3">
        {/* Drag Handle */}
        <div className="flex items-center justify-center -mt-2 -mx-2 mb-1">
          <GripVertical className="h-4 w-4 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors" />
        </div>

        {/* Header */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <Link 
              to={clientHref(client.id)}
              className="font-semibold text-sm truncate block hover:text-primary transition-colors"
              onClick={(e) => e.stopPropagation()}
              onMouseDown={(e) => e.stopPropagation()}
            >
              {client.name}
            </Link>
            {client.country && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                <Building2 className="h-3 w-3" />
                {client.country}
              </p>
            )}
          </div>
          <ClientStatusBadge status={client.status} />
        </div>

        {/* Contact Info */}
        <div className="space-y-1.5 text-xs">
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigator.clipboard.writeText(client.email);
              toast.success("Email copied to clipboard");
            }}
            className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors w-full"
          >
            <Mail className="h-3 w-3 flex-shrink-0" />
            <span className="truncate">{client.email}</span>
          </button>
        </div>

        {/* Converted By (for Super Agents) */}
        {isSuperAgent && (
          <div className="pt-2 border-t border-border" onClick={(e) => e.stopPropagation()}>
            <p className="text-xs text-muted-foreground mb-1">Converted By</p>
            <ConvertedByDisplay userId={client.created_by} />
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-1 border-t border-border pt-2" onClick={(e) => e.stopPropagation()}>
          {onCall && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onCall(client);
              }}
            >
              <PhoneCall className="h-3 w-3 mr-1" />
              Call
            </Button>
          )}
          {onEmail && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 px-2 text-xs flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onEmail(client);
              }}
            >
              <Send className="h-3 w-3 mr-1" />
              Email
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => e.stopPropagation()}>
                <MoreVertical className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              {onAddBank && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddBank(client);
                  }}
                >
                  <Landmark className="h-3 w-3 mr-2" />
                  Add Bank
                </DropdownMenuItem>
              )}
              {onAddNote && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddNote(client);
                  }}
                >
                  <StickyNote className="h-3 w-3 mr-2" />
                  Add Note
                </DropdownMenuItem>
              )}
              {onCreateAccount && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onCreateAccount(client);
                  }}
                >
                  <User className="h-3 w-3 mr-2" />
                  Create Account
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </Card>
  );
}

function BoardColumn({
  status,
  label,
  color,
  clients,
  isAgent,
  isSuperAgent,
  onCall,
  onEmail,
  onAddBank,
  onAddNote,
  onCreateAccount,
  statusColor,
}: {
  status: ClientStatus;
  label: string;
  color: string;
  clients: Client[];
  isAgent: boolean;
  isSuperAgent?: boolean;
  onCall?: (client: Client) => void;
  onEmail?: (client: Client) => void;
  onAddBank?: (client: Client) => void;
  onAddNote?: (client: Client) => void;
  onCreateAccount?: (client: Client) => void;
  statusColor?: string | null;
}) {
  return (
    <div className="flex flex-col flex-1">
      <div 
        className={cn("rounded-lg border p-3 mb-3", color)}
        style={statusColor ? { borderLeftColor: statusColor, borderLeftWidth: '4px' } : undefined}
      >
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-sm text-foreground">{label}</h3>
          <Badge variant="secondary" className="text-xs">
            {clients.length}
          </Badge>
        </div>
      </div>

      <SortableContext items={clients.map((c) => c.id)} strategy={verticalListSortingStrategy}>
        <div className="flex-1 space-y-3 min-h-[200px]">
          {clients.map((client) => (
            <ClientCard
              key={client.id}
              client={client}
              isAgent={isAgent}
              isSuperAgent={isSuperAgent}
              onCall={onCall}
              onEmail={onEmail}
              onAddBank={onAddBank}
              onAddNote={onAddNote}
              onCreateAccount={onCreateAccount}
            />
          ))}
          {clients.length === 0 && (
            <div className="flex items-center justify-center h-32 border-2 border-dashed border-border rounded-lg">
              <p className="text-sm text-muted-foreground">No clients</p>
            </div>
          )}
        </div>
      </SortableContext>
    </div>
  );
}

export function ClientsBoardView({
  clients,
  onStatusChange,
  isAgent,
  isSuperAgent,
  onCall,
  onEmail,
  onAddBank,
  onAddNote,
  onCreateAccount,
}: ClientsBoardViewProps) {
  const [activeId, setActiveId] = useState<string | null>(null);
  
  // Fetch dynamic statuses from database
  const { data: statuses = [] } = useActiveClientStatuses();
  
  // Build STATUS_COLUMNS dynamically from database
  const STATUS_COLUMNS = useMemo(() => {
    return statuses.map((s, index) => ({
      status: s.name,
      label: s.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()),
      color: getColumnColor(s.color, index),
      statusColor: s.color,
    }));
  }, [statuses]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const clientsByStatus = useMemo(() => {
    // Create dynamic grouping based on database statuses
    const grouped: Record<string, Client[]> = {};
    
    // Initialize all status buckets
    statuses.forEach(s => {
      grouped[s.name] = [];
    });

    clients.forEach((client) => {
      // Only add clients with known statuses to avoid undefined errors
      if (grouped[client.status] !== undefined) {
        grouped[client.status].push(client);
      }
    });

    return grouped;
  }, [clients, statuses]);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over) {
      setActiveId(null);
      return;
    }

    const activeIdValue = active.id as string;
    const overId = over.id as string;

    const activeClient = clients.find((c) => c.id === activeIdValue);
    if (!activeClient) {
      setActiveId(null);
      return;
    }

    let targetStatus: ClientStatus | null = null;

    if (STATUS_COLUMNS.some((col) => col.status === overId)) {
      targetStatus = overId as ClientStatus;
    } else {
      const overClient = clients.find((c) => c.id === overId);
      if (overClient) {
        targetStatus = overClient.status;
      }
    }

    if (!targetStatus) {
      setActiveId(null);
      return;
    }

    if (activeClient.status !== targetStatus) {
      onStatusChange(activeIdValue, targetStatus);
    }

    setActiveId(null);
  };

  const handleDragCancel = () => {
    setActiveId(null);
  };

  const activeClient = activeId ? clients.find((c) => c.id === activeId) : null;

  return (
    <DndContext sensors={sensors} onDragStart={handleDragStart} onDragEnd={handleDragEnd} onDragCancel={handleDragCancel}>
      <div className="flex gap-4 pb-4">
        {STATUS_COLUMNS.map((column) => (
          <BoardColumn
            key={column.status}
            status={column.status}
            label={column.label}
            color={column.color}
            statusColor={column.statusColor}
            clients={clientsByStatus[column.status] || []}
            isAgent={isAgent}
            isSuperAgent={isSuperAgent}
            onCall={onCall}
            onEmail={onEmail}
            onAddBank={onAddBank}
            onAddNote={onAddNote}
            onCreateAccount={onCreateAccount}
          />
        ))}
      </div>

      <DragOverlay>
        {activeClient ? (
          <Card className="p-4 cursor-move shadow-lg rotate-3 opacity-90 border-border bg-card">
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-sm truncate">{activeClient.name}</h3>
                  {activeClient.country && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Building2 className="h-3 w-3" />
                      {activeClient.country}
                    </p>
                  )}
                </div>
                <ClientStatusBadge status={activeClient.status} />
              </div>
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <Mail className="h-3 w-3" />
                  <span className="truncate">{activeClient.email}</span>
                </div>
              </div>
            </div>
          </Card>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
