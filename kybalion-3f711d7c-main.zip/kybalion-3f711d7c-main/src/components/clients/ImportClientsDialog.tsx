import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, FileSpreadsheet, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import { getErrorMessage } from "@/types/errors";
import { ScrollArea } from "@/components/ui/scroll-area";

// Validation schema for CSV client data
const clientSchema = z.object({
  name: z.string()
    .trim()
    .min(1, "Name is required")
    .max(200, "Name must be less than 200 characters"),
  email: z.string()
    .trim()
    .max(255, "Email must be less than 255 characters")
    .nullable()
    .optional()
    .transform(val => val || null)
    .refine((email) => {
      // Accept empty or any reasonable email format
      if (!email) return true;
      return /^[^\s@]+@[^\s@]+\.[^\s@]+/.test(email);
    }, "Invalid email format"),
  home_phone: z.string()
    .trim()
    .min(1, "Phone is required")
    .max(50, "Phone number too long"),
  country: z.string()
    .trim()
    .max(100, "Country name too long")
    .nullable()
    .optional()
    .transform(val => val || null),
  balance: z.number().nullable().optional(),
  equity: z.number().nullable().optional(),
  bank: z.string()
    .trim()
    .max(500, "Bank name too long")
    .nullable()
    .optional()
    .transform(val => val || null),
  kyc_note: z.string()
    .trim()
    .max(5000, "KYC note too long")
    .nullable()
    .optional()
    .transform(val => val || null),
});

// Clean and extract first email from potentially messy input
const cleanEmail = (raw: string | null | undefined): string | null => {
  if (!raw || !raw.trim()) return null;
  const emails = raw.split(/[\n\r,;\s]+/).filter(e => e.includes("@"));
  return emails[0]?.trim() || null;
};

// Clean and extract first phone from potentially messy input  
const cleanPhone = (raw: string | null | undefined): string | null => {
  if (!raw) return null;
  const phones = raw.split(/[\n\r]+/).filter(p => p.trim());
  const firstPhone = phones[0]?.trim() || raw.trim();
  return firstPhone.replace(/[^\d+\-\s()]/g, '').trim() || null;
};

// Parse number from string
const parseNumber = (raw: string | null | undefined): number | null => {
  if (!raw) return null;
  const cleaned = raw.replace(/[^0-9.-]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
};

interface DuplicateInfo {
  row: number;
  name: string;
  reason: string;
  matchedValue: string;
}

interface ImportResult {
  imported: number;
  duplicates: DuplicateInfo[];
  errors: string[];
  total: number;
}

interface ImportClientsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ImportClientsDialog = ({ open, onOpenChange }: ImportClientsDialogProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  // Improved CSV parser that handles quoted fields with commas/newlines
  const parseCSV = (text: string): Record<string, string | null>[] => {
    const data: Record<string, string | null>[] = [];
    const lines: string[] = [];
    let currentLine = "";
    let inQuotes = false;
    
    for (const char of text) {
      if (char === '"') {
        inQuotes = !inQuotes;
        currentLine += char;
      } else if (char === '\n' && !inQuotes) {
        if (currentLine.trim()) lines.push(currentLine);
        currentLine = "";
      } else if (char === '\r') {
        // Skip carriage returns
      } else {
        currentLine += char;
      }
    }
    if (currentLine.trim()) lines.push(currentLine);
    
    if (lines.length === 0) return data;
    
    const headers = parseCSVLine(lines[0]);
    
    for (let i = 1; i < lines.length; i++) {
      const values = parseCSVLine(lines[i]);
      const row: Record<string, string | null> = {};
      
      const hasData = values.some(v => v && v.trim());
      if (!hasData) continue;
      
      headers.forEach((header, index) => {
        const value = values[index]?.trim();
        row[header] = value || null;
      });
      
      data.push(row);
    }

    return data;
  };

  const parseCSVLine = (line: string): string[] => {
    const values: string[] = [];
    let current = "";
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        values.push(current.trim());
        current = "";
      } else {
        current += char;
      }
    }
    values.push(current.trim());
    
    return values;
  };

  const handleImport = async () => {
    if (!file) {
      toast.error("Please select a file");
      return;
    }

    setIsImporting(true);

    try {
      const text = await file.text();
      const rows = parseCSV(text);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Get user's tenant (admin_id) for tenant-scoped duplicate check
      const { data: userProfile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .single();

      const { data: userRole } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      const isSuperAdmin = userRole?.role === "SUPER_ADMIN";
      const isTenantOwner = userRole?.role === "TENANT_OWNER";
      const tenantId = isTenantOwner ? user.id : userProfile?.admin_id;

      // Build sets of existing emails and phones for fast lookup
      const existingEmails = new Set<string>();
      const existingPhones = new Set<string>();

      if (tenantId) {
        const { data: existingLeads } = await supabase
          .from("leads")
          .select("email, phone")
          .eq("admin_id", tenantId);
        
        const { data: existingClients } = await supabase
          .from("clients")
          .select("email, home_phone")
          .eq("admin_id", tenantId);

        existingLeads?.forEach(lead => {
          if (lead.email) existingEmails.add(lead.email.toLowerCase().trim());
          if (lead.phone) existingPhones.add(lead.phone.replace(/[^\d+]/g, ''));
        });

        existingClients?.forEach(client => {
          if (client.email) existingEmails.add(client.email.toLowerCase().trim());
          if (client.home_phone) existingPhones.add(client.home_phone.replace(/[^\d+]/g, ''));
        });
      }

      interface ValidatedClient {
        client: {
          name: string;
          email: string | null;
          home_phone: string;
          country: string | null;
          balance: number | null;
          equity: number | null;
          source: "OTHER";
          status: "ACTIVE";
          pipeline_status: "PROSPECT";
          created_by: string;
          join_date: string;
          deposits: number;
          open_trades: number;
        };
        bank?: string;
        kyc_note?: string;
      }
      const validatedClients: ValidatedClient[] = [];
      const errors: string[] = [];
      const duplicateInfos: DuplicateInfo[] = [];

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        try {
          const rawName = row.name || row.Name || row.NAME || "";
          const rawEmail = row.email || row.Email || row.EMAIL || "";
          const rawPhone = row.phone || row.Phone || row.PHONE || row.home_phone || row["Home Phone"] || null;
          const rawCountry = row.country || row.Country || row.COUNTRY || null;
          const rawBalance = row.balance || row.Balance || row.BALANCE || null;
          const rawEquity = row.equity || row.Equity || row.EQUITY || row.initial_amt || row["Initial Amt"] || null;
          const rawBank = row.bank || row.Bank || row.BANK || null;
          const rawNote = row.kyc_note || row["KYC Note"] || row.kycnote || row.notes || row.Notes || row.note || row.Note || null;

          // Skip rows with no name (empty rows)
          if (!rawName?.trim()) {
            continue;
          }

          const clientData = {
            name: rawName?.trim() || "",
            email: cleanEmail(rawEmail) || null,
            home_phone: cleanPhone(rawPhone) || "",
            country: rawCountry?.trim() || null,
            balance: parseNumber(rawBalance),
            equity: parseNumber(rawEquity),
            bank: rawBank?.trim() || null,
            kyc_note: rawNote?.trim() || null,
          };

          const validated = clientSchema.parse(clientData);

          // Check for duplicates by phone only (phone is now required)
          const phoneNormalized = validated.home_phone.replace(/[^\d+]/g, '');
          
          const isDuplicatePhone = existingPhones.has(phoneNormalized);
          
          if (isDuplicatePhone) {
            duplicateInfos.push({
              row: i + 2,
              name: validated.name,
              reason: "Phone",
              matchedValue: validated.home_phone,
            });
            continue;
          }

          // Add to existing sets to prevent duplicates within the import file
          existingPhones.add(phoneNormalized);
          if (validated.email) existingEmails.add(validated.email.toLowerCase().trim());

          validatedClients.push({
            client: {
              name: validated.name,
              email: validated.email || null,
              home_phone: phoneNormalized,
              country: validated.country || null,
              balance: validated.balance || null,
              equity: validated.equity || null,
              source: "OTHER" as const,
              status: "ACTIVE" as const,
              pipeline_status: "PROSPECT" as const,
              created_by: user.id,
              join_date: new Date().toISOString().split('T')[0],
              deposits: 0,
              open_trades: 0,
            },
            bank: validated.bank || undefined,
            kyc_note: validated.kyc_note || undefined,
          });
        } catch (error) {
          if (error instanceof z.ZodError) {
            errors.push(`Row ${i + 2}: ${error.errors[0].message}`);
          } else {
            errors.push(`Row ${i + 2}: Invalid data`);
          }
        }
      }

      if (errors.length > 0) {
        const errorMessage = errors.length <= 5 
          ? errors.join(", ") 
          : `${errors.slice(0, 5).join(", ")} and ${errors.length - 5} more errors`;
        
        toast.error(`Validation failed: ${errorMessage}`);
        
        if (errors.length > rows.length * 0.3) {
          throw new Error("Too many validation errors. Please fix your CSV file.");
        }
      }

      if (validatedClients.length === 0) {
        if (duplicateInfos.length > 0) {
          setImportResult({
            imported: 0,
            duplicates: duplicateInfos,
            errors,
            total: rows.length,
          });
          return;
        }
        throw new Error("No valid clients to import");
      }

      const clientsToInsert = validatedClients.map(v => v.client);
      const { data: insertedClients, error } = await supabase
        .from("clients")
        .insert(clientsToInsert)
        .select("id");

      if (error) throw error;

      // Create KYC records for bank and notes
      if (insertedClients) {
        const kycRecords: { client_id: string; bank_name?: string; notes?: string; created_by: string }[] = [];
        
        insertedClients.forEach((insertedClient, index) => {
          const originalData = validatedClients[index];
          
          if (originalData.bank) {
            kycRecords.push({
              client_id: insertedClient.id,
              bank_name: originalData.bank,
              created_by: user.id,
            });
          }
          
          if (originalData.kyc_note) {
            kycRecords.push({
              client_id: insertedClient.id,
              notes: originalData.kyc_note,
              created_by: user.id,
            });
          }
        });

        if (kycRecords.length > 0) {
          const { error: kycError } = await supabase
            .from("kyc_records")
            .insert(kycRecords);
          
          if (kycError) {
            console.error("Error creating KYC records:", kycError);
            toast.warning("Clients imported but some KYC records failed");
          }
        }
      }

      setImportResult({
        imported: validatedClients.length,
        duplicates: duplicateInfos,
        errors,
        total: rows.length,
      });
      
      toast.success(`Imported ${validatedClients.length} clients`);
    } catch (error: unknown) {
      toast.error(getErrorMessage(error));
    } finally {
      setIsImporting(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setImportResult(null);
  };

  const handleCloseAndRefresh = () => {
    onOpenChange(false);
    resetForm();
    window.location.reload();
  };

  return (
    <Dialog open={open} onOpenChange={(open) => {
      if (!open) resetForm();
      onOpenChange(open);
    }}>
      <DialogContent className="max-w-lg overflow-hidden">
        <DialogHeader>
          <DialogTitle>{importResult ? "Import Results" : "Import Clients"}</DialogTitle>
          {importResult && (
            <DialogDescription>
              Summary of the import operation
            </DialogDescription>
          )}
        </DialogHeader>

        {importResult ? (
          <div className="space-y-4">
            {/* Summary Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-lg border border-border p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-success mb-1">
                  <CheckCircle2 className="h-4 w-4" />
                  <span className="text-lg font-bold">{importResult.imported}</span>
                </div>
                <p className="text-xs text-muted-foreground">Imported</p>
              </div>
              <div className="rounded-lg border border-border p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-warning mb-1">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-lg font-bold">{importResult.duplicates.length}</span>
                </div>
                <p className="text-xs text-muted-foreground">Duplicates</p>
              </div>
              <div className="rounded-lg border border-border p-3 text-center">
                <div className="flex items-center justify-center gap-1 text-destructive mb-1">
                  <XCircle className="h-4 w-4" />
                  <span className="text-lg font-bold">{importResult.errors.length}</span>
                </div>
                <p className="text-xs text-muted-foreground">Errors</p>
              </div>
            </div>

            {/* Duplicates List */}
            {importResult.duplicates.length > 0 && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-warning" />
                  Skipped Duplicates ({importResult.duplicates.length})
                </Label>
                <ScrollArea className="h-[200px] rounded-md border border-border">
                  <div className="p-3 space-y-2">
                    {importResult.duplicates.map((dup, idx) => (
                      <div key={idx} className="flex items-start justify-between text-sm py-1.5 border-b border-border last:border-0">
                        <div>
                          <span className="font-medium">{dup.name}</span>
                          <span className="text-muted-foreground ml-2 text-xs">Row {dup.row}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs px-1.5 py-0.5 rounded bg-warning/20 text-warning">
                            {dup.reason}
                          </span>
                          <p className="text-xs text-muted-foreground mt-0.5 truncate max-w-[150px]">
                            {dup.matchedValue}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {/* Errors List */}
            {importResult.errors.length > 0 && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <XCircle className="h-4 w-4 text-destructive" />
                  Validation Errors ({importResult.errors.length})
                </Label>
                <ScrollArea className="h-[100px] rounded-md border border-border">
                  <div className="p-3 space-y-1">
                    {importResult.errors.slice(0, 20).map((err, idx) => (
                      <p key={idx} className="text-xs text-destructive">{err}</p>
                    ))}
                    {importResult.errors.length > 20 && (
                      <p className="text-xs text-muted-foreground">...and {importResult.errors.length - 20} more</p>
                    )}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4 overflow-y-auto max-h-[60vh]">
            <div className="space-y-2">
              <Label>CSV File</Label>
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  disabled={isImporting}
                />
                {file && (
                  <FileSpreadsheet className="h-5 w-5 text-success" />
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                CSV should include columns: Name, Email, Phone, Country, Balance, Equity, Bank, KYC Note
              </p>
            </div>

            <div className="rounded-md bg-muted p-3 text-xs">
              <p className="font-semibold mb-2">Expected CSV Format:</p>
              <code className="block whitespace-pre text-xs">
                Name,Email,Phone,Country,Balance,Equity,Bank,KYC Note{"\n"}
                John Doe,john@example.com,+1234567890,USA,5000,10000,Bank of America,Verified ID
              </code>
            </div>
          </div>
        )}

        <DialogFooter>
          {importResult ? (
            <Button size="sm" onClick={handleCloseAndRefresh}>
              Done
            </Button>
          ) : (
            <>
              <Button size="sm" variant="outline" onClick={() => onOpenChange(false)} disabled={isImporting}>
                Cancel
              </Button>
              <Button 
                size="sm" 
                onClick={handleImport} 
                disabled={!file || isImporting}
              >
                {isImporting ? (
                  <>Importing...</>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Import Clients
                  </>
                )}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
