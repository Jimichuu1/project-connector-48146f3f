import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useClientGroups } from "@/hooks/useClientGroups";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface AssignClientGroupDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedClientIds: string[];
}

export const AssignClientGroupDialog = ({ 
  open, 
  onOpenChange, 
  selectedClientIds, 
}: AssignClientGroupDialogProps) => {
  const [selectedGroup, setSelectedGroup] = useState<"converted" | "live">("live");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [groupIds, setGroupIds] = useState<{ convertedGroupId: string; liveGroupId: string } | null>(null);
  const [isLoadingGroups, setIsLoadingGroups] = useState(false);

  const { moveClientsToGroup, getSystemGroupIds } = useClientGroups();

  // Ensure system groups exist when dialog opens
  useEffect(() => {
    if (open) {
      setSelectedGroup("live");
      setIsLoadingGroups(true);
      getSystemGroupIds().then((ids) => {
        setGroupIds(ids);
        setIsLoadingGroups(false);
      });
    }
  }, [open]);

  const handleAssign = async () => {
    if (!groupIds) return;
    
    const targetGroupId = selectedGroup === "converted" ? groupIds.convertedGroupId : groupIds.liveGroupId;
    
    if (!targetGroupId) return;

    setIsSubmitting(true);
    try {
      await moveClientsToGroup.mutateAsync({
        groupId: targetGroupId,
        clientIds: selectedClientIds,
      });
      onOpenChange(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            Move {selectedClientIds.length} Client(s) to Group
          </DialogTitle>
        </DialogHeader>

        {isLoadingGroups ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <Label>Select Group</Label>
            <RadioGroup 
              value={selectedGroup} 
              onValueChange={(value) => setSelectedGroup(value as "converted" | "live")}
              className="grid grid-cols-2 gap-4"
            >
              <Label
                htmlFor="live"
                className={cn(
                  "flex flex-col items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer transition-colors",
                  selectedGroup === "live" && "border-primary bg-primary/5"
                )}
              >
                <RadioGroupItem value="live" id="live" className="sr-only" />
                <span className="text-lg font-semibold">Live</span>
                <span className="text-xs text-muted-foreground mt-1">Active clients</span>
              </Label>
              <Label
                htmlFor="converted"
                className={cn(
                  "flex flex-col items-center justify-center rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground cursor-pointer transition-colors",
                  selectedGroup === "converted" && "border-primary bg-primary/5"
                )}
              >
                <RadioGroupItem value="converted" id="converted" className="sr-only" />
                <span className="text-lg font-semibold">Converted</span>
                <span className="text-xs text-muted-foreground mt-1">From leads</span>
              </Label>
            </RadioGroup>
          </div>
        )}

        <DialogFooter>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              size="sm"
              onClick={handleAssign}
              disabled={isSubmitting || isLoadingGroups || !groupIds}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Moving...
                </>
              ) : (
                `Move to ${selectedGroup === "live" ? "Live" : "Converted"}`
              )}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};