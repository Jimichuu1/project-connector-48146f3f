import { FloatingSelectionBar } from "@/components/ui/floating-selection-bar";
import { RefreshCcw, Users, UserMinus, Trash2, FolderPlus } from "lucide-react";
import { UseMutationResult } from "@tanstack/react-query";
import { useActiveClientStatuses } from "@/hooks/useClientStatuses";

interface ClientsFloatingBarProps {
  selectedClients: string[];
  onClear: () => void;
  isAdmin: boolean;
  isManager: boolean;
  canDelete?: boolean;
  onAssign: () => void;
  onUnassign: () => void;
  onAssignToGroup: () => void;
  bulkUpdateStatus: UseMutationResult<any, Error, { clientIds: string[]; status: string }, unknown>;
  bulkDeleteClients: UseMutationResult<any, Error, string[], unknown>;
}

export function ClientsFloatingBar({
  selectedClients,
  onClear,
  isAdmin,
  isManager,
  canDelete = false,
  onAssign,
  onUnassign,
  onAssignToGroup,
  bulkUpdateStatus,
  bulkDeleteClients,
}: ClientsFloatingBarProps) {
  const { data: statuses = [] } = useActiveClientStatuses();
  
  const handleStatusChange = async (status: string) => {
    const clientIds = [...selectedClients];
    onClear();
    
    try {
      await bulkUpdateStatus.mutateAsync({ clientIds, status });
    } catch {
      // Error handled by mutation
    }
  };

  const handleDelete = async () => {
    if (selectedClients.length === 0) return;
    
    const clientIds = [...selectedClients];
    onClear();
    
    try {
      await bulkDeleteClients.mutateAsync(clientIds);
    } catch {
      // Error handled by mutation
    }
  };

  const statusOptions = statuses.map((s) => ({
    label: s.name,
    value: s.name,
    onClick: () => handleStatusChange(s.name),
  }));

  const dropdownActions = [
    {
      label: "Change Status",
      icon: <RefreshCcw className="h-4 w-4" />,
      options: statusOptions,
    },
  ];

  const actions = [
    ...((isAdmin || isManager)
      ? [
          {
            label: "Assign",
            icon: <Users className="h-4 w-4" />,
            onClick: onAssign,
          },
          {
            label: "Unassign",
            icon: <UserMinus className="h-4 w-4" />,
            onClick: onUnassign,
          },
          {
            label: "Group",
            icon: <FolderPlus className="h-4 w-4" />,
            onClick: onAssignToGroup,
          },
        ]
      : []),
    ...(canDelete
      ? [
          {
            label: "Delete",
            icon: <Trash2 className="h-4 w-4" />,
            variant: "destructive" as const,
            onClick: handleDelete,
          },
        ]
      : []),
  ];

  return (
    <FloatingSelectionBar
      selectedCount={selectedClients.length}
      onClear={onClear}
      dropdownActions={dropdownActions}
      actions={actions}
    />
  );
}
