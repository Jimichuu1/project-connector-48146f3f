import { ClientStatus } from "@/types/clients";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface ClientStatusDropdownProps {
  status: ClientStatus;
  onStatusChange: (status: ClientStatus) => void;
  disabled?: boolean;
}

interface StatusConfig {
  name: string;
  color: string;
  is_active: boolean;
}

export function ClientStatusDropdown({ status, onStatusChange, disabled }: ClientStatusDropdownProps) {
  const [open, setOpen] = useState(false);
  const [statuses, setStatuses] = useState<StatusConfig[]>([]);

  useEffect(() => {
    const fetchStatuses = async () => {
      const { data } = await supabase
        .from("client_statuses")
        .select("name, color, is_active")
        .eq("is_active", true)
        .order("position");
      
      if (data) setStatuses(data);
    };
    fetchStatuses();
  }, []);

  // Find current status config from database or use fallback
  const currentConfig = statuses.find(s => s.name === status);
  const bgColor = currentConfig?.color || "#6366f1";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          size="sm"
          variant="ghost"
          disabled={disabled}
          className={cn(
            "h-6 px-2 gap-1 rounded-full text-xs font-semibold cursor-pointer transition-all border-0",
            disabled && "cursor-not-allowed opacity-50"
          )}
          style={{ backgroundColor: bgColor, color: "#000" }}
          onClick={(e) => e.stopPropagation()}
        >
          {status.replace(/_/g, " ")}
          <ChevronDown className="h-3 w-3" />
        </Button>
      </PopoverTrigger>
      <PopoverContent 
        className="w-48 p-2" 
        align="start"
        onCloseAutoFocus={(e) => e.preventDefault()}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="space-y-1">
          {statuses.map((statusConfig) => (
            <Button
              key={statusConfig.name}
              size="sm"
              variant="ghost"
              className={cn(
                "w-full justify-start text-sm gap-2",
                status === statusConfig.name && "bg-accent"
              )}
              onClick={(e) => {
                e.stopPropagation();
                onStatusChange(statusConfig.name as ClientStatus);
                setOpen(false);
              }}
            >
              <span 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: statusConfig.color }}
              />
              {statusConfig.name.replace(/_/g, " ")}
            </Button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}