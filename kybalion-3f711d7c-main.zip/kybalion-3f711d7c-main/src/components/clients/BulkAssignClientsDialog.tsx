import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTenant } from "@/contexts/TenantContext";
import { useQueryClient } from "@tanstack/react-query";

interface BulkAssignClientsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedClientIds: string[];
  mode?: "assign" | "unassign";
}

interface SuperAgent {
  id: string;
  email: string;
  full_name: string | null;
}

export const BulkAssignClientsDialog = ({ 
  open, 
  onOpenChange, 
  selectedClientIds,
  mode = "assign",
}: BulkAssignClientsDialogProps) => {
  const isUnassign = mode === "unassign";
  const [superAgents, setSuperAgents] = useState<SuperAgent[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchSuperAgents = async () => {
      // Fetch SUPER_AGENT users only - filtered by tenant
      const { data: userRoles } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .eq("role", "SUPER_AGENT");

      if (userRoles) {
        const agentIds = userRoles.map(ur => ur.user_id);
        
        // Build query with tenant filter
        let profilesQuery = supabase
          .from("profiles")
          .select("id, email, full_name, admin_id")
          .in("id", agentIds);
        
        // Apply tenant filter if we have a tenant context
        if (effectiveTenantId) {
          profilesQuery = profilesQuery.eq("admin_id", effectiveTenantId);
        }
        
        const { data: profiles } = await profilesQuery;

        if (profiles) {
          setSuperAgents(profiles.map(p => ({
            id: p.id,
            email: p.email,
            full_name: p.full_name,
          })));
        }
      }
    };

    if (open) {
      fetchSuperAgents();
      setSelectedAgentId("");
    }
  }, [open, effectiveTenantId]);

  const handleAssign = async () => {
    if (!isUnassign && !selectedAgentId) {
      toast.error("Please select a super agent");
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from("clients")
        .update({ assigned_to: isUnassign ? null : selectedAgentId })
        .in("id", selectedClientIds);

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ["clients"] });
      toast.success(
        isUnassign
          ? `${selectedClientIds.length} clients unassigned successfully`
          : `${selectedClientIds.length} clients assigned successfully`
      );
      onOpenChange(false);
    } catch (error) {
      console.error("Error updating assignment:", error);
      toast.error(isUnassign ? "Failed to unassign clients" : "Failed to assign clients");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {isUnassign
              ? `Unassign ${selectedClientIds.length} Client(s)`
              : `Assign ${selectedClientIds.length} Client(s) to Super Agent`}
          </DialogTitle>
        </DialogHeader>

        {isUnassign ? (
          <div className="text-sm text-muted-foreground">
            This will remove the current super agent from {selectedClientIds.length} selected client(s). This action can be reversed by reassigning later.
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Select Super Agent</Label>
              <Select value={selectedAgentId} onValueChange={setSelectedAgentId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a super agent" />
                </SelectTrigger>
                <SelectContent>
                  {superAgents.map((agent) => (
                    <SelectItem key={agent.id} value={agent.id}>
                      {agent.full_name || agent.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {superAgents.length === 0 && (
                <p className="text-xs text-muted-foreground">
                  No super agents available in this tenant
                </p>
              )}
            </div>
          </div>
        )}

        <DialogFooter>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              variant={isUnassign ? "destructive" : "default"}
              onClick={handleAssign}
              disabled={isLoading || (!isUnassign && !selectedAgentId)}
            >
              {isLoading
                ? isUnassign ? "Unassigning..." : "Assigning..."
                : isUnassign ? "Unassign" : "Assign"}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
