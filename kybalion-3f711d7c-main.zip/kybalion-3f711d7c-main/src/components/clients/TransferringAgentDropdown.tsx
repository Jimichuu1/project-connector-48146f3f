import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { UserCombobox } from "@/components/ui/user-combobox";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";

interface TransferringAgentDropdownProps {
  clientId: string;
  currentTransferringAgent?: string | null;
  onAssignmentChange?: () => void;
}

export function TransferringAgentDropdown({
  clientId,
  currentTransferringAgent,
  onAssignmentChange,
}: TransferringAgentDropdownProps) {
  const { user } = useAuth();
  const { effectiveTenantId, isTenantOwner } = useTenant();
  const { isManager, isSuperAdmin } = useUserData();
  const queryClient = useQueryClient();
  const [isUpdating, setIsUpdating] = useState(false);

  // Check if user can assign transferring agent (super admin or tenant owner)
  const canAssign = isSuperAdmin || isTenantOwner;

  // Fetch all agents (AGENT and SUPER_AGENT) for the dropdown
  const { data: agents = [], isLoading } = useQuery({
    queryKey: ["all-tenant-agents", effectiveTenantId],
    queryFn: async () => {
      // First get all user IDs with AGENT or SUPER_AGENT roles
      const { data: roleData, error: roleError } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .in("role", ["AGENT", "SUPER_AGENT"]);

      if (roleError) throw roleError;

      const userIds = roleData?.map((r) => r.user_id) || [];
      if (userIds.length === 0) return [];

      // Then fetch profiles for those users, filtered by tenant
      let query = supabase
        .from("profiles")
        .select("id, full_name, avatar_url")
        .in("id", userIds);

      if (effectiveTenantId) {
        query = query.eq("admin_id", effectiveTenantId);
      }

      const { data, error } = await query;

      if (error) throw error;

      return data.map((agent) => ({
        id: agent.id,
        full_name: agent.full_name || agent.id,
        avatar: agent.avatar_url,
      }));
    },
    enabled: !!user?.id && canAssign,
  });

  const handleAssignmentChange = async (agentId: string) => {
    if (!agentId) return; // Don't allow unassigning
    
    setIsUpdating(true);
    try {
      // 1. Update client's transferring_agent
      const { error: updateError } = await supabase
        .from("clients")
        .update({ transferring_agent: agentId })
        .eq("id", clientId);

      if (updateError) throw updateError;

      // 2. Create activity log entry (conversion record)
      const { error: activityError } = await supabase
        .from("client_activities")
        .insert({
          client_id: clientId,
          user_id: user!.id,
          activity_type: "transferring_agent_assigned",
          description: `Transferring agent assigned manually by admin`,
        });

      if (activityError) {
        console.error("Error creating activity log:", activityError);
      }

      // 3. Send notification to the assigned agent
      const { error: notificationError } = await supabase
        .from("notifications")
        .insert({
          user_id: agentId,
          type: "LEAD_ASSIGNED",
          message: `You have been assigned as transferring agent for a client`,
          related_entity_type: "client",
          related_entity_id: clientId,
        });

      if (notificationError) {
        console.error("Error sending notification:", notificationError);
      }

      await queryClient.invalidateQueries({ queryKey: ["clients"] });
      toast.success("Transferring agent assigned successfully");
      onAssignmentChange?.();
    } catch (error) {
      console.error("Error updating transferring agent:", error);
      toast.error("Failed to update transferring agent");
    } finally {
      setIsUpdating(false);
    }
  };

  // Don't render if user can't assign
  if (!canAssign) {
    return null;
  }

  if (isLoading || isUpdating) {
    return <Skeleton className="h-10 w-full" />;
  }

  const options = [
    { value: "", label: "Unassigned", avatar: undefined },
    ...agents.map((agent) => ({
      value: agent.id,
      label: agent.full_name,
      avatar: agent.avatar,
    })),
  ];

  return (
    <UserCombobox
      options={options}
      value={currentTransferringAgent || ""}
      onValueChange={handleAssignmentChange}
      placeholder="Select transferring agent..."
      emptyText="No agents found"
      searchPlaceholder="Search agents..."
    />
  );
}
