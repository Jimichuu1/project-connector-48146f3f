import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Info } from "lucide-react";

const clientSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be less than 100 characters"),
  email: z.string().trim().email("Invalid email address").max(255, "Email must be less than 255 characters").optional().nullable().or(z.literal('')),
  home_phone: z.string().trim().min(1, "Phone is required").max(20, "Phone must be less than 20 characters"),
  country: z.string().trim().max(100, "Country must be less than 100 characters").optional().nullable(),
  balance: z.number().min(0, "Balance must be positive"),
  equity: z.number().min(0, "Initial amount must be positive"),
  status: z.enum(["ACTIVE", "FLIPPED", "FREELOADER", "NO_ANSWER"]),
});

// Partial schema for restricted mode (balance only)
const balanceOnlySchema = z.object({
  balance: z.number().min(0, "Balance must be positive"),
});

interface Client {
  id: string;
  name: string;
  email: string;
  home_phone?: string | null;
  country?: string | null;
  balance?: number | null;
  equity?: number | null;
  status: string;
}

interface EditClientDialogProps {
  client: Client;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  restrictedMode?: boolean;
  editableFields?: string[];
}

export function EditClientDialog({ 
  client, 
  open, 
  onOpenChange,
  restrictedMode = false,
  editableFields = []
}: EditClientDialogProps) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: client.name || "",
    email: client.email || "",
    home_phone: client.home_phone || "",
    country: client.country || "",
    balance: client.balance || 0,
    equity: client.equity || 0,
    status: client.status || "ACTIVE",
  });

  const isFieldEditable = (fieldName: string) => {
    if (!restrictedMode) return true;
    return editableFields.includes(fieldName);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (restrictedMode && editableFields.includes('balance')) {
        // Validate only balance in restricted mode
        const validatedData = balanceOnlySchema.parse({
          balance: formData.balance,
        });

        const { error } = await supabase
          .from("clients")
          .update({ balance: validatedData.balance })
          .eq("id", client.id);

        if (error) throw error;
      } else {
        // Full validation and update
        const validatedData = clientSchema.parse({
          ...formData,
          home_phone: formData.home_phone || null,
          country: formData.country || null,
        });

        const { error } = await supabase
          .from("clients")
          .update({
            name: validatedData.name,
            email: validatedData.email,
            home_phone: validatedData.home_phone,
            country: validatedData.country,
            balance: validatedData.balance,
            equity: validatedData.equity,
            status: validatedData.status,
          })
          .eq("id", client.id);

        if (error) throw error;
      }

      toast.success(restrictedMode ? "Balance updated successfully" : "Client updated successfully");
      queryClient.invalidateQueries({ queryKey: ["clients-paginated"] });
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      queryClient.invalidateQueries({ queryKey: ["client", client.id] });
      onOpenChange(false);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        console.error("Update error:", error);
        toast.error("Failed to update client");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{restrictedMode ? "Edit Initial Balance" : "Edit Client"}</DialogTitle>
          {restrictedMode && (
            <DialogDescription>
              Update the initial balance for this Live client
            </DialogDescription>
          )}
        </DialogHeader>

        {restrictedMode && (
          <Alert className="border-blue-500/50 bg-blue-500/10">
            <Info className="h-4 w-4 text-blue-500" />
            <AlertDescription className="text-blue-500">
              You can only edit the Initial Balance field for Live clients.
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required={!restrictedMode}
                maxLength={100}
                disabled={!isFieldEditable('name')}
                className={!isFieldEditable('name') ? "bg-muted" : ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                maxLength={255}
                disabled={!isFieldEditable('email')}
                className={!isFieldEditable('email') ? "bg-muted" : ""}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="home_phone">Phone *</Label>
              <Input
                id="home_phone"
                value={formData.home_phone}
                onChange={(e) => setFormData({ ...formData, home_phone: e.target.value })}
                required={!restrictedMode}
                maxLength={20}
                disabled={!isFieldEditable('home_phone')}
                className={!isFieldEditable('home_phone') ? "bg-muted" : ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                maxLength={100}
                disabled={!isFieldEditable('country')}
                className={!isFieldEditable('country') ? "bg-muted" : ""}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status *</Label>
            <Select 
              value={formData.status} 
              onValueChange={(value) => setFormData({ ...formData, status: value })}
              disabled={!isFieldEditable('status')}
            >
              <SelectTrigger className={!isFieldEditable('status') ? "bg-muted" : ""}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="FLIPPED">Flipped</SelectItem>
                <SelectItem value="FREELOADER">Freeloader</SelectItem>
                <SelectItem value="NO_ANSWER">No Answer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="balance">Initial Balance ($) *</Label>
              <Input
                id="balance"
                type="number"
                step="0.01"
                min="0"
                value={formData.balance}
                onChange={(e) => setFormData({ ...formData, balance: parseFloat(e.target.value) || 0 })}
                required
                disabled={!isFieldEditable('balance')}
                className={!isFieldEditable('balance') ? "bg-muted" : ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="equity">Initial Amount ($) *</Label>
              <Input
                id="equity"
                type="number"
                step="0.01"
                min="0"
                value={formData.equity}
                onChange={(e) => setFormData({ ...formData, equity: parseFloat(e.target.value) || 0 })}
                required={!restrictedMode}
                disabled={!isFieldEditable('equity')}
                className={!isFieldEditable('equity') ? "bg-muted" : ""}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : restrictedMode ? "Update Balance" : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}