import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";

interface ClientGroupDisplayProps {
  clientId: string;
}

export const ClientGroupDisplay = ({ clientId }: ClientGroupDisplayProps) => {
  const { data: groupName, isLoading } = useQuery({
    queryKey: ['client-group-name', clientId],
    queryFn: async () => {
      const { data: membership, error } = await supabase
        .from('client_group_members')
        .select('group_id')
        .eq('client_id', clientId)
        .maybeSingle();

      if (error || !membership) return null;

      const { data: group } = await supabase
        .from('client_groups')
        .select('name')
        .eq('id', membership.group_id)
        .single();

      return group?.name || null;
    },
    enabled: !!clientId,
  });

  if (isLoading) {
    return <span className="text-xs text-muted-foreground">Loading...</span>;
  }

  if (!groupName) {
    return <span className="text-xs text-muted-foreground">-</span>;
  }

  const isLiveTraffic = groupName === 'Live Traffic';
  const displayName = isLiveTraffic ? 'Live TR' : groupName;

  return (
    <Badge
      variant="outline"
      className={`text-xs ${
        groupName === 'Converted'
          ? 'border-purple-500 bg-purple-500/10 text-purple-500'
          : groupName === 'Live'
            ? 'border-red-500 bg-red-500/10 text-red-500'
            : isLiveTraffic
              ? 'border-yellow-500 bg-yellow-400/15 text-yellow-600 dark:text-yellow-400'
              : ''
      }`}
    >
      {displayName}
    </Badge>
  );
};
