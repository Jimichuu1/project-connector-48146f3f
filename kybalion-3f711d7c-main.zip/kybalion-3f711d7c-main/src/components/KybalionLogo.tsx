import { SVGProps } from "react";

export const KybalionLogo = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none" {...props}>
    {/* Outer circle */}
    <circle cx="50" cy="50" r="45" stroke="hsl(270, 70%, 60%)" strokeWidth="5" fill="none"/>
    
    {/* Triangle (equilateral, pointing up) */}
    <polygon points="50,12 10,78 90,78" stroke="hsl(270, 70%, 60%)" strokeWidth="5" fill="none" strokeLinejoin="round"/>
    
    {/* Square (centered inside triangle) */}
    <rect x="28" y="46" width="44" height="32" stroke="hsl(270, 70%, 60%)" strokeWidth="5" fill="none"/>
    
    {/* Inner circle (centered in square) */}
    <circle cx="50" cy="62" r="12" stroke="hsl(270, 70%, 60%)" strokeWidth="5" fill="none"/>
  </svg>
);