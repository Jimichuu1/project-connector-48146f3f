import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useDocuments } from "@/hooks/useDocuments";
import { Download, Trash2, File, FileText, FileSpreadsheet, Image as ImageIcon } from "lucide-react";
import { format } from "date-fns";
import { Document, DocumentType } from "@/types/documents";

interface DocumentListProps {
  entityId: string;
  entityType: 'lead' | 'client';
}

const getDocumentIcon = (type: DocumentType) => {
  switch (type) {
    case 'PDF':
      return <FileText className="h-5 w-5 text-destructive" />;
    case 'DOCX':
      return <File className="h-5 w-5 text-primary" />;
    case 'XLSX':
      return <FileSpreadsheet className="h-5 w-5 text-success" />;
    case 'IMAGE':
      return <ImageIcon className="h-5 w-5 text-chart-4" />;
    default:
      return <File className="h-5 w-5 text-muted-foreground" />;
  }
};

const formatFileSize = (bytes: number) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
};

export const DocumentList = ({ entityId, entityType }: DocumentListProps) => {
  const { documents, isLoading, deleteDocument, downloadDocument } = useDocuments(entityId, entityType);

  if (isLoading) {
    return <div>Loading documents...</div>;
  }

  if (!documents || documents.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          No documents uploaded yet
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Documents ({documents.length})</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {documents.map((doc) => (
          <div
            key={doc.id}
            className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
          >
            <div className="flex items-center gap-3 flex-1 min-w-0">
              {getDocumentIcon(doc.type)}
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{doc.name}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{formatFileSize(doc.size)}</span>
                  <span>•</span>
                  <span>{format(new Date(doc.created_at), 'MMM d, yyyy')}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => downloadDocument(doc.file_path, doc.name)}
              >
                <Download className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  if (confirm('Delete this document?')) {
                    deleteDocument.mutate(doc.id);
                  }
                }}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};
