import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Upload, X, File, FileText, FileSpreadsheet, Image as ImageIcon } from "lucide-react";
import { useDocuments } from "@/hooks/useDocuments";
import { DocumentType } from "@/types/documents";
import { validateFile } from "@/lib/fileValidation";
import { useToast } from "@/hooks/use-toast";

interface DocumentUploadProps {
  entityId: string;
  entityType: 'lead' | 'client';
  kycRecordId?: string;
}

export const DocumentUpload = ({ entityId, entityType, kycRecordId }: DocumentUploadProps) => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { uploadDocument } = useDocuments(entityId, entityType);
  const { toast } = useToast();

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    for (const file of acceptedFiles) {
      // SECURITY: Comprehensive file validation (size, signature, malicious content)
      const validation = await validateFile(file, 5); // 5MB limit (reduced from 10MB)
      
      if (!validation.valid) {
        toast({
          title: "File validation failed",
          description: validation.error,
          variant: "destructive",
        });
        continue;
      }

      if (validation.warnings && validation.warnings.length > 0) {
        toast({
          title: "File upload warning",
          description: validation.warnings.join('; '),
          variant: "destructive",
        });
      }

      setUploading(true);
      setUploadProgress(0);

      try {
        await uploadDocument.mutateAsync({
          file,
          entityId,
          entityType,
          kycRecordId,
        });
        setUploadProgress(100);
      } catch (error) {
        console.error('Upload error:', error);
      } finally {
        setTimeout(() => {
          setUploading(false);
          setUploadProgress(0);
        }, 500);
      }
    }
  }, [entityId, entityType, kycRecordId, uploadDocument, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp'],
    },
    multiple: true,
  });

  return (
    <Card className="border-dashed">
      <CardContent className="p-6">
        <div
          {...getRootProps()}
          className={`
            flex flex-col items-center justify-center p-6 cursor-pointer
            transition-colors rounded-lg border-2 border-dashed
            ${isDragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/25'}
            hover:border-primary hover:bg-primary/5
          `}
        >
          <input {...getInputProps()} />
          <Upload className={`h-10 w-10 mb-4 ${isDragActive ? 'text-primary' : 'text-muted-foreground'}`} />
          <p className="text-sm text-center">
            {isDragActive ? (
              <span className="text-primary font-medium">Drop files here...</span>
            ) : (
              <>
                <span className="font-medium">Click to upload</span> or drag and drop
                <br />
                <span className="text-xs text-muted-foreground">
                  PDF, DOCX, XLSX, or images (max 5MB)
                </span>
              </>
            )}
          </p>
        </div>

        {uploading && (
          <div className="mt-4 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Uploading...</span>
              <span>{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} />
          </div>
        )}
      </CardContent>
    </Card>
  );
};
