import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import React from 'react';
import { ErrorBoundary } from '../ErrorBoundary';

// Component that throws an error
const ThrowError = ({ shouldThrow }: { shouldThrow: boolean }) => {
  if (shouldThrow) {
    throw new Error('Test error');
  }
  return <div>No error</div>;
};

describe('ErrorBoundary', () => {
  // Suppress console.error for cleaner test output
  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  it('renders children when no error', () => {
    render(
      <ErrorBoundary>
        <div>Test content</div>
      </ErrorBoundary>
    );
    
    expect(screen.getByText('Test content')).toBeInTheDocument();
  });

  it('renders fallback UI when error occurs', () => {
    render(
      <ErrorBoundary>
        <ThrowError shouldThrow={true} />
      </ErrorBoundary>
    );
    
    // Should show error UI instead of crashing
    expect(screen.queryByText('No error')).not.toBeInTheDocument();
  });

  it('catches errors in child components', () => {
    const { container } = render(
      <ErrorBoundary>
        <ThrowError shouldThrow={true} />
      </ErrorBoundary>
    );
    
    // Component should render something (error UI)
    expect(container).toBeTruthy();
  });
});

describe('Error handling utilities', () => {
  it('should format error messages', () => {
    const formatError = (error: Error | string) => {
      if (typeof error === 'string') return error;
      return error.message || 'An unknown error occurred';
    };
    
    expect(formatError('Simple error')).toBe('Simple error');
    expect(formatError(new Error('Error object'))).toBe('Error object');
  });

  it('should categorize errors', () => {
    const categorizeError = (error: Error) => {
      if (error.message.includes('network')) return 'NETWORK_ERROR';
      if (error.message.includes('auth')) return 'AUTH_ERROR';
      if (error.message.includes('validation')) return 'VALIDATION_ERROR';
      return 'UNKNOWN_ERROR';
    };
    
    expect(categorizeError(new Error('network failure'))).toBe('NETWORK_ERROR');
    expect(categorizeError(new Error('auth token expired'))).toBe('AUTH_ERROR');
    expect(categorizeError(new Error('validation failed'))).toBe('VALIDATION_ERROR');
    expect(categorizeError(new Error('something else'))).toBe('UNKNOWN_ERROR');
  });

  it('should determine if error is retryable', () => {
    const isRetryable = (error: Error) => {
      const retryablePatterns = ['network', 'timeout', '503', '429'];
      return retryablePatterns.some(pattern => 
        error.message.toLowerCase().includes(pattern)
      );
    };
    
    expect(isRetryable(new Error('network error'))).toBe(true);
    expect(isRetryable(new Error('request timeout'))).toBe(true);
    expect(isRetryable(new Error('validation error'))).toBe(false);
  });

  it('should extract error details', () => {
    const extractDetails = (error: any) => ({
      message: error.message || 'Unknown error',
      code: error.code || null,
      status: error.status || null,
      stack: error.stack || null
    });
    
    const error = new Error('Test error');
    (error as any).code = 'ERR_001';
    (error as any).status = 400;
    
    const details = extractDetails(error);
    expect(details.message).toBe('Test error');
    expect(details.code).toBe('ERR_001');
    expect(details.status).toBe(400);
  });
});
