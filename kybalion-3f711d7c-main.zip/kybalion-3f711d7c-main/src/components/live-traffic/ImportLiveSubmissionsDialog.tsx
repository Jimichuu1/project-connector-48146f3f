import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Upload, Loader2 } from "lucide-react";
import { useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useQueryClient } from "@tanstack/react-query";
import { getCountryFromPhone } from "@/lib/phoneCountryCode";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ParsedRow {
  name?: string;
  email?: string;
  phone?: string | number;
  scam_type?: string;
  time_frame?: string;
  lost_amount?: string | number;
  description?: string;
  country?: string;
}



export function ImportLiveSubmissionsDialog({ open, onOpenChange }: Props) {
  const [downloading, setDownloading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [source, setSource] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { effectiveTenantId } = useTenant();
  const queryClient = useQueryClient();

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await fetch("/templates/live-rt-leads-import-template.xlsx");
      if (!response.ok) throw new Error("Failed to fetch template");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "live-rt-leads-import-template.xlsx";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      toast.error("Could not download template. Please try again.");
    } finally {
      setDownloading(false);
    }
  };

  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!effectiveTenantId) {
      toast.error("No active tenant selected");
      return;
    }

    setImporting(true);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const sheetName =
        wb.SheetNames.find((n) => n.toLowerCase().includes("live")) || wb.SheetNames[0];
      const sheet = wb.Sheets[sheetName];
      const rows = XLSX.utils.sheet_to_json<ParsedRow>(sheet, { defval: "" });

      if (!rows.length) {
        toast.error("No rows found in the file");
        return;
      }

      const records: Array<Record<string, unknown>> = [];
      const errors: string[] = [];

      rows.forEach((row, idx) => {
        const rowNum = idx + 2; // header is row 1
        const name = String(row.name ?? "").trim();
        if (!name) {
          errors.push(`Row ${rowNum}: missing name`);
          return;
        }
        const email = String(row.email ?? "").trim() || null;
        const phone = row.phone !== undefined && row.phone !== "" ? String(row.phone).trim() : null;
        const providedCountry = String(row.country ?? "").trim();
        const country = providedCountry || (phone ? getCountryFromPhone(phone) : null) || null;

        const scamType = String(row.scam_type ?? "").trim();
        const timeFrame = String(row.time_frame ?? "").trim();
        const lostAmountRaw = row.lost_amount;
        const description = String(row.description ?? "").trim();

        const trimmedSource = source.trim();
        const metadata: Record<string, unknown> = { imported: true };
        if (trimmedSource) metadata.source = trimmedSource;
        if (scamType) metadata.scam_type = scamType;
        if (timeFrame) metadata.time_frame = timeFrame;
        if (lostAmountRaw !== undefined && lostAmountRaw !== "") {
          const n = Number(lostAmountRaw);
          metadata.lost_amount = Number.isFinite(n) ? n : String(lostAmountRaw);
        }
        if (description) metadata.description = description;

        records.push({
          admin_id: effectiveTenantId,
          name,
          email,
          phone,
          phone_normalized: phone ? phone.replace(/\D/g, "") : null,
          country,
          metadata,
          source_url: trimmedSource || null,
          status: "new",
        });
      });

      if (!records.length) {
        toast.error(`No valid rows. ${errors.slice(0, 3).join("; ")}`);
        return;
      }

      // Insert in chunks of 500
      const chunkSize = 500;
      let inserted = 0;
      for (let i = 0; i < records.length; i += chunkSize) {
        const chunk = records.slice(i, i + chunkSize);
        const { error } = await supabase.from("live_traffic_submissions").insert(chunk as never);
        if (error) throw error;
        inserted += chunk.length;
      }

      queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });

      if (errors.length) {
        toast.success(`Imported ${inserted} leads. Skipped ${errors.length} invalid rows.`);
      } else {
        toast.success(`Imported ${inserted} leads`);
      }
      onOpenChange(false);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Import failed";
      toast.error(msg);
    } finally {
      setImporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Import Live Leads</DialogTitle>
          <DialogDescription>
            Bulk import will land directly into the Live Traffic inbox (not the Leads page).
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center justify-center gap-3 py-6 text-center">
          <div className="rounded-full bg-muted p-4">
            <Upload className="h-6 w-6 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground max-w-sm">
            Download the template, fill it with your leads, then upload it to import.
          </p>

          <div className="w-full text-left space-y-1.5">
            <Label htmlFor="import-source">Source</Label>
            <Input
              id="import-source"
              placeholder="e.g. Facebook Campaign Q2, Affiliate XYZ"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              disabled={importing}
            />
            <p className="text-xs text-muted-foreground">
              Applied to every row in this import.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 mt-2">
            <Button
              type="button"
              variant="secondary"
              onClick={handleDownload}
              disabled={downloading || importing}
            >
              <Download className="h-4 w-4 mr-2" />
              {downloading ? "Preparing..." : "Download template"}
            </Button>

            <Button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={importing || downloading}
            >
              {importing ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              {importing ? "Importing..." : "Upload file"}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={handleFileSelected}
            />
          </div>

          <p className="text-xs text-muted-foreground">
            Columns: name, email, phone, country, scam_type, time_frame, lost_amount, description
          </p>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={importing}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
