import { useState, useMemo, useCallback, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Shuffle, Users, Loader2 } from "lucide-react";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ShuffleLiveSubmissionsDialog({ open, onOpenChange }: Props) {
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [isShuffling, setIsShuffling] = useState(false);
  const [unassignedIds, setUnassignedIds] = useState<string[]>([]);
  const [loadingIds, setLoadingIds] = useState(false);
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();
  const { data: agents = [], isLoading: agentsLoading } = useAgentsCache();

  const superAgents = useMemo(
    () => agents.filter((a) => a.role === "SUPER_AGENT"),
    [agents]
  );

  // Fetch all unassigned submissions for this tenant when dialog opens
  useEffect(() => {
    if (!open || !effectiveTenantId) return;
    let cancelled = false;
    (async () => {
      setLoadingIds(true);
      const { data, error } = await supabase
        .from("live_traffic_submissions")
        .select("id")
        .eq("admin_id", effectiveTenantId)
        .is("assigned_to", null)
        .in("status", ["new"])
        .limit(5000);
      if (cancelled) return;
      if (error) {
        toast.error("Failed to load unassigned leads");
        setUnassignedIds([]);
      } else {
        setUnassignedIds((data || []).map((r) => r.id as string));
      }
      setLoadingIds(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [open, effectiveTenantId]);

  const distribution = useMemo(() => {
    const leadCount = unassignedIds.length;
    const memberCount = selectedMembers.length;
    if (memberCount === 0) return { perMember: {} as Record<string, number>, leadCount, memberCount: 0 };
    const base = Math.floor(leadCount / memberCount);
    const remainder = leadCount % memberCount;
    const perMember: Record<string, number> = {};
    selectedMembers.forEach((id, i) => {
      perMember[id] = i < remainder ? base + 1 : base;
    });
    return { perMember, leadCount, memberCount };
  }, [unassignedIds.length, selectedMembers]);

  const handleMemberToggle = useCallback((id: string, checked: boolean) => {
    setSelectedMembers((prev) =>
      checked ? [...prev, id] : prev.filter((x) => x !== id)
    );
  }, []);

  const handleSelectAll = useCallback(() => {
    if (selectedMembers.length === superAgents.length) {
      setSelectedMembers([]);
    } else {
      setSelectedMembers(superAgents.map((a) => a.id));
    }
  }, [superAgents, selectedMembers.length]);

  const handleShuffle = async () => {
    if (selectedMembers.length === 0) {
      toast.error("Please select at least one Super Agent");
      return;
    }
    if (unassignedIds.length === 0) {
      toast.error("No unassigned leads to shuffle");
      return;
    }

    setIsShuffling(true);
    try {
      const shuffled = [...unassignedIds].sort(() => Math.random() - 0.5);
      const assignments = shuffled.map((id, i) => ({
        submissionId: id,
        superAgentId: selectedMembers[i % selectedMembers.length],
      }));

      const chunkSize = 25;
      let done = 0;
      let failed = 0;
      for (let i = 0; i < assignments.length; i += chunkSize) {
        const chunk = assignments.slice(i, i + chunkSize);
        const results = await Promise.all(
          chunk.map((a) =>
            supabase.rpc("assign_live_submission", {
              p_submission_id: a.submissionId,
              p_super_agent_id: a.superAgentId,
            })
          )
        );
        results.forEach((r) => {
          if (r.error) failed++;
          else done++;
        });
      }

      await queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });

      if (failed > 0) {
        toast.warning(`Assigned ${done} leads. ${failed} failed.`);
      } else {
        toast.success(
          `Shuffled ${done} leads to ${selectedMembers.length} Super Agent${selectedMembers.length > 1 ? "s" : ""}`
        );
      }
      onOpenChange(false);
      setSelectedMembers([]);
    } catch (e) {
      toast.error((e as Error).message || "Failed to shuffle");
    } finally {
      setIsShuffling(false);
    }
  };

  const getInitials = (name: string) =>
    name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shuffle className="h-5 w-5" />
            Shuffle Unassigned Leads
          </DialogTitle>
          <DialogDescription>
            Distribute all unassigned live leads evenly among selected Super Agents.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
            <Users className="h-5 w-5 text-muted-foreground" />
            <span className="font-medium">
              {loadingIds ? "Loading…" : `Queue: ${unassignedIds.length} unassigned leads`}
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Select Super Agents:</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSelectAll}
                className="text-xs h-7"
                disabled={superAgents.length === 0}
              >
                {selectedMembers.length === superAgents.length && superAgents.length > 0
                  ? "Deselect All"
                  : "Select All"}
              </Button>
            </div>

            {agentsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : superAgents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                No Super Agents found
              </div>
            ) : (
              <div className="border rounded-lg divide-y max-h-64 overflow-y-auto">
                {superAgents.map((agent) => {
                  const isSelected = selectedMembers.includes(agent.id);
                  const count = distribution.perMember[agent.id] || 0;
                  return (
                    <div
                      key={agent.id}
                      className="flex items-center justify-between p-3 hover:bg-muted/50 cursor-pointer"
                      onClick={() => handleMemberToggle(agent.id, !isSelected)}
                    >
                      <div className="flex items-center gap-3">
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={(c) => handleMemberToggle(agent.id, c as boolean)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={agent.avatar || undefined} />
                          <AvatarFallback className="text-xs">
                            {getInitials(agent.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium">{agent.name}</span>
                          <span className="text-xs text-muted-foreground">{agent.email}</span>
                        </div>
                      </div>
                      {isSelected && (
                        <Badge variant="secondary" className="shrink-0">
                          → {count} leads
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {selectedMembers.length > 0 && (
            <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg space-y-1">
              <div className="text-sm font-medium text-primary">Distribution Preview</div>
              <div className="text-sm text-muted-foreground">
                <div>• Total leads: {distribution.leadCount}</div>
                <div>• Selected Super Agents: {distribution.memberCount}</div>
                <div>
                  • Each receives: ~
                  {distribution.memberCount > 0
                    ? Math.floor(distribution.leadCount / distribution.memberCount)
                    : 0}{" "}
                  leads
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isShuffling}>
            Cancel
          </Button>
          <Button
            onClick={handleShuffle}
            disabled={
              selectedMembers.length === 0 ||
              unassignedIds.length === 0 ||
              isShuffling ||
              loadingIds
            }
          >
            {isShuffling ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Shuffling...
              </>
            ) : (
              <>
                <Shuffle className="mr-2 h-4 w-4" />
                Shuffle
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
