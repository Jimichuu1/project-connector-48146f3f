import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { toast } from "sonner";
import { getCountryFromPhone } from "@/lib/phoneCountryCode";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const SCAM_TYPES = [
  "Crypto investment",
  "Romance scam",
  "Forex / trading platform",
  "Wire transfer fraud",
  "Phishing",
  "Tech support scam",
  "Real estate / rental",
  "Business email compromise",
  "Other",
];

const TIME_FRAMES = [
  "Within the last week",
  "1 month ago",
  "3 months ago",
  "6 months ago",
  "Within the last year",
  "Over a year ago",
];

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// Normalize to E.164-ish: keep leading +, strip other non-digits
function normalizePhone(value: string): string {
  const trimmed = value.trim();
  const hasPlus = trimmed.startsWith("+");
  const digits = trimmed.replace(/\D/g, "");
  return digits ? (hasPlus ? `+${digits}` : digits) : "";
}

export function CreateLiveSubmissionDialog({ open, onOpenChange }: Props) {
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [scamType, setScamType] = useState("");
  const [timeFrame, setTimeFrame] = useState("");
  const [lostAmount, setLostAmount] = useState("");
  const [description, setDescription] = useState("");

  const reset = () => {
    setName("");
    setEmail("");
    setPhone("");
    setScamType("");
    setTimeFrame("");
    setLostAmount("");
    setDescription("");
  };

  const wordCount = description.trim() ? description.trim().split(/\s+/).filter(Boolean).length : 0;
  

  const create = useMutation({
    mutationFn: async () => {
      if (!effectiveTenantId) throw new Error("No active tenant selected");
      if (!name.trim()) throw new Error("Full name is required");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) throw new Error("Valid email is required");
      const normalizedPhone = normalizePhone(phone);
      const phoneDigitsOnly = normalizedPhone.replace(/\D/g, "");
      if (phoneDigitsOnly.length < 7) throw new Error("Phone is required");
      if (!scamType) throw new Error("Type of scam is required");
      if (!timeFrame) throw new Error("Time frame is required");
      const amountNum = Number(lostAmount);
      if (!Number.isFinite(amountNum) || amountNum < 0) throw new Error("Amount lost must be a number");

      const country = getCountryFromPhone(normalizedPhone) || null;

      const { error } = await supabase.from("live_traffic_submissions").insert({
        admin_id: effectiveTenantId,
        api_key_id: null,
        name: name.trim(),
        email: email.trim(),
        phone: normalizedPhone,
        country,
        phone_normalized: phoneDigitsOnly,
        metadata: {
          scam_type: scamType,
          lost_amount: amountNum,
          time_frame: timeFrame,
          description: description.trim(),
          manual_entry: true,
        },
        source_url: null,
        ip_address: null,
        user_agent: "manual-entry",
        is_duplicate: false,
        duplicate_of_lead_id: null,
        status: "new",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Live lead created");
      queryClient.invalidateQueries({ queryKey: ["live-traffic-submissions"] });
      reset();
      onOpenChange(false);
    },
    onError: (e: Error) => {
      toast.error(e.message || "Failed to create live lead");
    },
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) reset();
        onOpenChange(o);
      }}
    >
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Live Lead</DialogTitle>
          <DialogDescription>
            Manually add a submission to the Live Traffic inbox. Mirrors the public landing form.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="ll-name">Full name</Label>
            <Input id="ll-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={200} />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ll-email">Email</Label>
            <Input
              id="ll-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              maxLength={255}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ll-phone">Phone</Label>
            <Input
              id="ll-phone"
              inputMode="tel"
              placeholder="+1 555 123 4567"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Country auto-detected: {getCountryFromPhone(normalizePhone(phone)) || "—"}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Type of scam</Label>
              <Select value={scamType} onValueChange={setScamType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select…" />
                </SelectTrigger>
                <SelectContent>
                  {SCAM_TYPES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>When</Label>
              <Select value={timeFrame} onValueChange={setTimeFrame}>
                <SelectTrigger>
                  <SelectValue placeholder="Select…" />
                </SelectTrigger>
                <SelectContent>
                  {TIME_FRAMES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ll-amount">Amount lost (USD)</Label>
            <Input
              id="ll-amount"
              type="number"
              min={0}
              step="0.01"
              value={lostAmount}
              onChange={(e) => setLostAmount(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ll-desc">What happened?</Label>
            <Textarea
              id="ll-desc"
              rows={5}
              maxLength={5000}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what happened…"
            />
            <p className="text-xs text-muted-foreground">
              {description.length}/5000 chars
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={create.isPending}>
            Cancel
          </Button>
          <Button onClick={() => create.mutate()} disabled={create.isPending}>
            {create.isPending ? "Creating…" : "Create Live Lead"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
