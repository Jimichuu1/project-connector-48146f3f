import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Info } from "lucide-react";

interface LiveSubmissionInfoPopoverProps {
  metadata: Record<string, unknown> | null | undefined;
}

export const LiveSubmissionInfoPopover = ({ metadata }: LiveSubmissionInfoPopoverProps) => {
  const meta = (metadata || {}) as Record<string, unknown>;
  const scamType = (meta.scam_type as string) || "";
  const lostAmount = meta.lost_amount as number | string | undefined;
  const timeFrame = (meta.time_frame as string) || "";
  const description = (meta.description as string) || "";

  const hasAny = !!(scamType || lostAmount || timeFrame || description);

  if (!hasAny) {
    return (
      <Button
        variant="ghost"
        size="icon"
        className="h-7 w-7 opacity-30 cursor-default"
        disabled
      >
        <Info className="h-4 w-4" />
      </Button>
    );
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="h-7 w-7">
          <Info className="h-4 w-4 text-primary" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="start">
        <div className="space-y-3 text-sm">
          {scamType && (
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Type of Scam</div>
              <div className="font-medium">{scamType}</div>
            </div>
          )}
          {lostAmount !== undefined && lostAmount !== "" && (
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Lost Amount</div>
              <div className="font-medium">{typeof lostAmount === "number" ? `$${lostAmount.toLocaleString()}` : String(lostAmount)}</div>
            </div>
          )}
          {timeFrame && (
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Time Frame</div>
              <div className="font-medium">{timeFrame}</div>
            </div>
          )}
          {description && (
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Description</div>
              <p className="text-sm whitespace-pre-wrap max-h-60 overflow-y-auto">{description}</p>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};
