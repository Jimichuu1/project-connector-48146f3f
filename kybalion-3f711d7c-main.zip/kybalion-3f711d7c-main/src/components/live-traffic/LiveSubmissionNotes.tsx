import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { StickyNote, Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface Props {
  submissionId: string;
  adminId: string;
}

interface Note {
  id: string;
  note: string;
  user_id: string;
  created_at: string;
}

export function LiveSubmissionNotes({ submissionId, adminId }: Props) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState("");

  const { data: notes, isLoading } = useQuery({
    queryKey: ["lts-notes", submissionId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("live_traffic_submission_notes" as never)
        .select("id, note, user_id, created_at")
        .eq("submission_id", submissionId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data || []) as unknown as Note[];
    },
  });

  const create = useMutation({
    mutationFn: async (note: string) => {
      const { error } = await supabase
        .from("live_traffic_submission_notes" as never)
        .insert({ submission_id: submissionId, admin_id: adminId, user_id: user!.id, note } as never);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Note added");
      setText("");
      setAdding(false);
      qc.invalidateQueries({ queryKey: ["lts-notes", submissionId] });
    },
    onError: (e: Error) => toast.error(e.message || "Failed to add note"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("live_traffic_submission_notes" as never)
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Note deleted");
      qc.invalidateQueries({ queryKey: ["lts-notes", submissionId] });
    },
    onError: (e: Error) => toast.error(e.message || "Failed to delete"),
  });

  return (
    <Card>
      <CardHeader className="pb-3 flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <StickyNote className="h-4 w-4" />
          Notes ({notes?.length || 0})
        </CardTitle>
        {!adding && (
          <Button size="sm" variant="ghost" onClick={() => setAdding(true)}>
            <Plus className="h-3.5 w-3.5" />
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {adding && (
          <div className="space-y-2">
            <Textarea
              placeholder="Write a note..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={3}
              autoFocus
            />
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" onClick={() => { setAdding(false); setText(""); }}>
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={() => create.mutate(text.trim())}
                disabled={!text.trim() || create.isPending}
              >
                {create.isPending ? "Adding..." : "Add"}
              </Button>
            </div>
          </div>
        )}

        {isLoading ? (
          <Skeleton className="h-16 w-full" />
        ) : !notes || notes.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No notes yet</p>
        ) : (
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {notes.map((n) => (
              <div key={n.id} className="p-3 rounded-lg border bg-muted/30">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-muted-foreground mb-1">
                      {format(new Date(n.created_at), "MMM d, yyyy h:mm a")}
                    </p>
                    <p className="text-sm whitespace-pre-wrap">{n.note}</p>
                  </div>
                  {n.user_id === user?.id && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 w-7 p-0"
                      onClick={() => {
                        if (confirm("Delete this note?")) remove.mutate(n.id);
                      }}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
