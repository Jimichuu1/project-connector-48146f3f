import { useEffect, useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { UserCombobox, UserOption } from "@/components/ui/user-combobox";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import {
  useLiveTrafficSubmissions,
  type LiveSubmission,
} from "@/hooks/useLiveTrafficSubmissions";
import { toast } from "sonner";

interface Props {
  submission: LiveSubmission | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

export function AssignToSuperAgentDialog({ submission, open, onOpenChange }: Props) {
  const { data: agents, isLoading: agentsLoading } = useAgentsCache();
  const { assignToSuperAgent } = useLiveTrafficSubmissions();
  const [selected, setSelected] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) setSelected(submission?.assigned_to ?? "");
  }, [open, submission?.assigned_to]);

  const superAgents = useMemo(
    () => (agents || []).filter((a) => a.role === "SUPER_AGENT"),
    [agents]
  );

  const options: UserOption[] = useMemo(
    () =>
      superAgents.map((sa) => ({
        value: sa.id,
        label: sa.name,
        avatar: sa.avatar,
        badge: (
          <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-blue-100 text-blue-700">
            Super Agent
          </span>
        ),
      })),
    [superAgents]
  );

  const handleAssign = async () => {
    if (!submission || !selected) return;
    setSubmitting(true);
    try {
      await assignToSuperAgent.mutateAsync({
        submissionId: submission.id,
        superAgentId: selected,
      });
      toast.success("Assigned to Super Agent");
      onOpenChange(false);
    } catch (e) {
      toast.error((e as Error).message || "Failed to assign");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {submission?.assigned_to ? "Reassign to Super Agent" : "Assign to Super Agent"}
          </DialogTitle>
          <DialogDescription>
            Pick the Super Agent who will work this Live Traffic lead.
          </DialogDescription>
        </DialogHeader>

        {submission && (
          <div className="rounded-md border bg-muted/30 p-3 text-sm space-y-1">
            <div><span className="text-muted-foreground">Name:</span> {submission.name}</div>
            {submission.phone && (
              <div><span className="text-muted-foreground">Phone:</span> {submission.phone}</div>
            )}
            {submission.email && (
              <div><span className="text-muted-foreground">Email:</span> {submission.email}</div>
            )}
            {submission.country && (
              <div><span className="text-muted-foreground">Country:</span> {submission.country}</div>
            )}
          </div>
        )}

        <div className="space-y-2">
          <Label>Super Agent</Label>
          <UserCombobox
            options={options}
            value={selected}
            onValueChange={setSelected}
            placeholder={agentsLoading ? "Loading..." : "Select a Super Agent"}
            searchPlaceholder="Search Super Agents..."
            emptyText="No Super Agent found"
          />
          {superAgents.length === 0 && !agentsLoading && (
            <p className="text-xs text-muted-foreground">
              No Super Agents found in this tenant.
            </p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={handleAssign} disabled={!selected || submitting}>
            {submitting ? "Assigning..." : "Assign"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
