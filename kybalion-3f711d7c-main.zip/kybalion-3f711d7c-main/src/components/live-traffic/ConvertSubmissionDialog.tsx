import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  useLiveTrafficSubmissions,
  type LiveSubmission,
} from "@/hooks/useLiveTrafficSubmissions";
import { toast } from "sonner";
import { clientHref } from "@/lib/idCipher";

interface Props {
  submission: LiveSubmission | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}

export function ConvertSubmissionDialog({ submission, open, onOpenChange }: Props) {
  const { convert } = useLiveTrafficSubmissions();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  const handleConvert = async () => {
    if (!submission) return;
    setSubmitting(true);
    try {
      const clientId = await convert.mutateAsync(submission.id);
      toast.success("Converted to client");
      onOpenChange(false);
      if (clientId) navigate(clientHref(clientId));
    } catch (e) {
      toast.error((e as Error).message || "Failed to convert");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Convert to client?</AlertDialogTitle>
          <AlertDialogDescription>
            A new client will be created and added to the <strong>Live Traffic</strong> group,
            owned by the assigned Super Agent. This is not counted as a Transfer.
          </AlertDialogDescription>
        </AlertDialogHeader>

        {submission && (
          <div className="rounded-md border bg-muted/30 p-3 text-sm space-y-1">
            <div><span className="text-muted-foreground">Name:</span> {submission.name}</div>
            {submission.phone && (
              <div><span className="text-muted-foreground">Phone:</span> {submission.phone}</div>
            )}
            {submission.email && (
              <div><span className="text-muted-foreground">Email:</span> {submission.email}</div>
            )}
            {submission.country && (
              <div><span className="text-muted-foreground">Country:</span> {submission.country}</div>
            )}
          </div>
        )}

        <AlertDialogFooter>
          <AlertDialogCancel disabled={submitting}>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={handleConvert} disabled={submitting}>
            {submitting ? "Converting..." : "Convert"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
