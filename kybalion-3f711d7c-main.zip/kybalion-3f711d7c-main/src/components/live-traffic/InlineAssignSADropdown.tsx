import { useMemo, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { UserCombobox, UserOption } from "@/components/ui/user-combobox";
import { useAgentsCache } from "@/hooks/useAgentsCache";
import { useLiveTrafficSubmissions } from "@/hooks/useLiveTrafficSubmissions";
import { toast } from "sonner";

interface Props {
  submissionId: string;
  currentAssignedTo: string | null;
  disabled?: boolean;
}

export function InlineAssignSADropdown({ submissionId, currentAssignedTo, disabled }: Props) {
  const { data: agents, isLoading } = useAgentsCache();
  const { assignToSuperAgent, unassign } = useLiveTrafficSubmissions();
  const [updating, setUpdating] = useState(false);
  const [optimistic, setOptimistic] = useState<string | null>(null);

  const options: UserOption[] = useMemo(() => {
    const sas = (agents || []).filter((a) => a.role === "SUPER_AGENT");
    return [
      { value: "unassigned", label: "Unassigned" },
      ...sas.map((sa) => ({
        value: sa.id,
        label: sa.name,
        avatar: sa.avatar,
        badge: (
          <span className="inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-medium bg-blue-100 text-blue-700">
            Super Agent
          </span>
        ),
      })),
    ];
  }, [agents]);

  const handleChange = async (value: string) => {
    setOptimistic(value);
    setUpdating(true);
    try {
      if (value === "unassigned") {
        await unassign.mutateAsync(submissionId);
      } else {
        await assignToSuperAgent.mutateAsync({
          submissionId,
          superAgentId: value,
        });
      }
    } catch (e) {
      setOptimistic(null);
      toast.error((e as Error).message || "Failed to update");
    } finally {
      setUpdating(false);
    }
  };

  if (isLoading) return <Skeleton className="h-8 w-32" />;

  const displayValue = optimistic ?? (currentAssignedTo || "unassigned");

  return updating ? (
    <Skeleton className="h-9 w-full max-w-[200px]" />
  ) : (
    <UserCombobox
      options={options}
      value={displayValue}
      onValueChange={handleChange}
      placeholder="Assign SA..."
      searchPlaceholder="Search Super Agents..."
      emptyText="No Super Agent found"
    />
  );
}
