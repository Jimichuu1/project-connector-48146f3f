import { useState, useRef, useCallback, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { FileText, X, ChevronLeft, ExternalLink, GripHorizontal } from "lucide-react";
import { format } from "date-fns";

interface Script {
  id: string;
  title: string;
  content: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export function ScriptsPopover() {
  const { effectiveTenantId } = useTenant();
  const [open, setOpen] = useState(false);
  const [viewing, setViewing] = useState<Script | null>(null);

  // Drag state
  const panelRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const dragState = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  const initPosition = useCallback(() => {
    if (triggerRef.current && !position) {
      const rect = triggerRef.current.getBoundingClientRect();
      setPosition({ x: rect.right - 384, y: rect.bottom + 8 });
    }
  }, [position]);

  const handleOpen = () => {
    if (!open) initPosition();
    setOpen(!open);
    if (open) setViewing(null);
  };

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if (!position) return;
    e.preventDefault();
    dragState.current = { startX: e.clientX, startY: e.clientY, origX: position.x, origY: position.y };
    const onMouseMove = (ev: MouseEvent) => {
      if (!dragState.current) return;
      const dx = ev.clientX - dragState.current.startX;
      const dy = ev.clientY - dragState.current.startY;
      setPosition({ x: dragState.current.origX + dx, y: dragState.current.origY + dy });
    };
    const onMouseUp = () => {
      dragState.current = null;
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
  }, [position]);

  // Clamp position on resize
  useEffect(() => {
    if (!open || !position) return;
    const onResize = () => {
      setPosition((prev) => {
        if (!prev) return prev;
        return {
          x: Math.min(Math.max(0, prev.x), window.innerWidth - 384),
          y: Math.min(Math.max(0, prev.y), window.innerHeight - 100),
        };
      });
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [open, position]);

  const popOutScript = (script: Script) => {
    const isDark = document.documentElement.classList.contains("dark");
    const win = window.open("", "_blank", "width=600,height=500,resizable=yes,scrollbars=yes");
    if (!win) return;
    win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${script.title}</title><style>
      body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 24px; line-height: 1.7; font-size: 14px; white-space: pre-wrap; word-wrap: break-word;
        background: ${isDark ? "#1a1a2e" : "#fff"}; color: ${isDark ? "#e2e8f0" : "#1a1a2e"}; }
      h1 { font-size: 18px; margin: 0 0 16px 0; padding-bottom: 12px; border-bottom: 1px solid ${isDark ? "#334155" : "#e2e8f0"}; }
    </style></head><body><h1>${script.title}</h1>${script.content || "No content"}</body></html>`);
    win.document.close();
  };

  const { data: scripts = [] } = useQuery({
    queryKey: ["scripts", effectiveTenantId, "active"],
    queryFn: async () => {
      let query = supabase
        .from("scripts")
        .select("*")
        .eq("is_active", true)
        .order("updated_at", { ascending: false });

      if (effectiveTenantId) {
        query = query.eq("admin_id", effectiveTenantId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Script[];
    },
  });

  return (
    <>
      <Button ref={triggerRef} size="icon" variant="ghost" className="relative h-8 w-8" onClick={handleOpen}>
        <FileText className="h-4 w-4" />
        {scripts.length > 0 && (
          <Badge variant="secondary" className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
            {scripts.length}
          </Badge>
        )}
      </Button>

      {open && position && (
        <div
          ref={panelRef}
          className="fixed z-50 w-96 max-h-[500px] flex flex-col rounded-md border bg-popover text-popover-foreground shadow-lg animate-scale-in"
          style={{ left: position.x, top: position.y }}
        >
          {/* Drag handle + header */}
          <div className="flex items-center justify-between p-3 border-b">
            <div className="flex items-center gap-2">
              <div
                onMouseDown={onMouseDown}
                className="cursor-grab active:cursor-grabbing p-0.5 rounded hover:bg-muted/50 text-muted-foreground"
                title="Drag to move"
              >
                <GripHorizontal className="h-4 w-4" />
              </div>
              {viewing && (
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setViewing(null)}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              )}
              <h4 className="font-semibold text-sm select-none">
                {viewing ? viewing.title : "Scripts"}
              </h4>
            </div>
            <div className="flex items-center gap-1">
              {viewing && (
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => popOutScript(viewing)}>
                  <ExternalLink className="h-3.5 w-3.5" />
                </Button>
              )}
              <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => { setOpen(false); setViewing(null); }}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {viewing ? (
            <ScrollArea className="flex-1 overflow-auto">
              <div className="p-4 whitespace-pre-wrap text-sm leading-relaxed">
                {viewing.content || "No content"}
              </div>
            </ScrollArea>
          ) : scripts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <FileText className="h-8 w-8 mb-2 opacity-40" />
              <p className="text-sm">No scripts available</p>
            </div>
          ) : (
            <ScrollArea className="flex-1 overflow-auto">
              <div className="divide-y">
                {scripts.map((script) => (
                  <button
                    key={script.id}
                    className="w-full text-left px-4 py-3 hover:bg-muted/50 transition-colors"
                    onClick={() => setViewing(script)}
                  >
                    <p className="font-medium text-sm line-clamp-1">{script.title}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                      {script.content || "No content"}
                    </p>
                    <Badge variant="outline" className="text-[10px] mt-1.5">
                      {format(new Date(script.updated_at), "MMM d, yyyy")}
                    </Badge>
                  </button>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      )}
    </>
  );
}
