import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2, Eye, ShieldOff } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface VisitRow {
  id: string;
  user_id: string;
  path: string;
  was_denied: boolean;
  created_at: string;
}

interface UserAgg {
  userId: string;
  name: string;
  reached: Set<string>;
  denied: Set<string>;
  visits: VisitRow[];
}

export function PageAccessByUser() {
  const { effectiveTenantId } = useTenant();
  const { role } = useUserData();
  const [openUser, setOpenUser] = useState<UserAgg | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["page-visits-by-user", effectiveTenantId, role],
    queryFn: async () => {
      const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
      let q = supabase
        .from("page_visits")
        .select("id, user_id, path, was_denied, created_at, admin_id")
        .gte("created_at", since)
        .order("created_at", { ascending: false })
        .limit(5000);
      if (effectiveTenantId) q = q.eq("admin_id", effectiveTenantId);
      const { data: visits, error } = await q;
      if (error) throw error;

      const userIds = [...new Set((visits || []).map((v) => v.user_id))];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name, email, admin_id")
        .in("id", userIds);

      // tenant filter: include all users with visits in tenant; also list users in tenant with no visits
      let tenantUsers: { id: string; full_name: string | null; email: string }[] = [];
      if (effectiveTenantId) {
        const { data: tu } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .eq("admin_id", effectiveTenantId);
        tenantUsers = tu || [];
      }

      const profileMap = new Map(profiles?.map((p) => [p.id, p]) || []);
      const aggMap = new Map<string, UserAgg>();

      // seed tenant users
      tenantUsers.forEach((u) => {
        aggMap.set(u.id, {
          userId: u.id,
          name: u.full_name || u.email,
          reached: new Set(),
          denied: new Set(),
          visits: [],
        });
      });

      (visits || []).forEach((v) => {
        const p = profileMap.get(v.user_id);
        const name = p?.full_name || p?.email || "Unknown";
        if (!aggMap.has(v.user_id)) {
          aggMap.set(v.user_id, {
            userId: v.user_id,
            name,
            reached: new Set(),
            denied: new Set(),
            visits: [],
          });
        }
        const agg = aggMap.get(v.user_id)!;
        if (v.was_denied) agg.denied.add(v.path);
        else agg.reached.add(v.path);
        agg.visits.push(v as VisitRow);
      });

      return Array.from(aggMap.values()).sort(
        (a, b) => b.reached.size + b.denied.size - (a.reached.size + a.denied.size)
      );
    },
    refetchInterval: 30000,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-center text-sm text-muted-foreground py-6">
        No page visit data yet
      </div>
    );
  }

  return (
    <>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {data.map((u) => (
          <Card
            key={u.userId}
            className="bg-muted/30 border-0 cursor-pointer hover:bg-muted/50 transition-colors"
            onClick={() => setOpenUser(u)}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-sm truncate">{u.name}</CardTitle>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <Eye className="h-4 w-4 text-muted-foreground" />
                  <span className="text-xl font-bold">{u.reached.size}</span>
                  <span className="text-xs text-muted-foreground">reached</span>
                </div>
                <Badge
                  variant={u.denied.size > 0 ? "destructive" : "secondary"}
                  className={u.denied.size > 0 ? "gap-1 text-destructive-foreground" : "gap-1"}
                >
                  <ShieldOff className="h-3 w-3" />
                  {u.denied.size} denied
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!openUser} onOpenChange={(o) => !o && setOpenUser(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{openUser?.name} — Page Access</DialogTitle>
          </DialogHeader>
          <ScrollArea className="h-[420px]">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-background">
                <tr className="text-left text-xs text-muted-foreground border-b">
                  <th className="py-2 pr-2">Path</th>
                  <th className="py-2 pr-2">Status</th>
                  <th className="py-2 pr-2">Attempts</th>
                  <th className="py-2">Last visit</th>
                </tr>
              </thead>
              <tbody>
                {openUser &&
                  Array.from(
                    openUser.visits.reduce((acc, v) => {
                      const k = v.path + "::" + v.was_denied;
                      const existing = acc.get(k);
                      if (existing) {
                        existing.count++;
                      } else {
                        acc.set(k, {
                          path: v.path,
                          denied: v.was_denied,
                          count: 1,
                          last: v.created_at,
                        });
                      }
                      return acc;
                    }, new Map<string, { path: string; denied: boolean; count: number; last: string }>())
                  )
                    .map(([, v]) => v)
                    .sort((a, b) => +new Date(b.last) - +new Date(a.last))
                    .map((row, i) => (
                      <tr key={i} className="border-b border-muted/40">
                        <td className="py-2 pr-2 font-mono text-xs truncate max-w-[240px]">
                          {row.path}
                        </td>
                        <td className="py-2 pr-2">
                          {row.denied ? (
                            <Badge variant="destructive" className="text-destructive-foreground">
                              Denied
                            </Badge>
                          ) : (
                            <Badge variant="secondary">Reached</Badge>
                          )}
                        </td>
                        <td className="py-2 pr-2">{row.count}</td>
                        <td className="py-2 text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(row.last), { addSuffix: true })}
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </>
  );
}
