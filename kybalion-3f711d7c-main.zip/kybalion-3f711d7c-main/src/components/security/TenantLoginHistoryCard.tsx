import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Building2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface LoginHistoryItem {
  id: string;
  user_id: string;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
  last_activity: string;
  expires_at: string;
  is_active: boolean;
  profile: {
    id: string;
    email: string;
    full_name: string | null;
    admin_id: string | null;
  } | null;
}

interface TenantLoginHistoryGroup {
  tenantId: string;
  tenantName: string;
  sessions: LoginHistoryItem[];
}

interface TenantLoginHistoryCardProps {
  tenantGroup: TenantLoginHistoryGroup;
}

export function TenantLoginHistoryCard({ tenantGroup }: TenantLoginHistoryCardProps) {
  return (
    <Card className="bg-muted/30 border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Building2 className="h-4 w-4" />
          {tenantGroup.tenantName} - Login History
          <Badge variant="default" className="text-xs ml-2">
            {tenantGroup.sessions.length} session{tenantGroup.sessions.length !== 1 ? "s" : ""}
          </Badge>
        </CardTitle>
        <CardDescription className="text-xs">Login history by IP and device</CardDescription>
      </CardHeader>
      <CardContent className="pb-3">
        <ScrollArea className="h-[280px]">
          <div className="space-y-1.5">
            {tenantGroup.sessions.map((session) => {
              const isExpired = new Date(session.expires_at) < new Date();
              const deviceInfo = session.user_agent 
                ? session.user_agent.includes('Mobile') 
                  ? 'Mobile' 
                  : session.user_agent.includes('Windows') 
                    ? 'Windows'
                    : session.user_agent.includes('Mac')
                      ? 'Mac'
                      : session.user_agent.includes('Linux')
                        ? 'Linux'
                        : 'Unknown'
                : 'Unknown';

              return (
                <div
                  key={session.id}
                  className="flex items-start justify-between p-2.5 bg-muted/50 rounded-md hover:bg-muted/70 transition-colors text-sm"
                >
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="font-medium truncate">
                        {session.profile?.full_name || session.profile?.email || 'Unknown User'}
                      </div>
                      {session.is_active && !isExpired && (
                        <Badge variant="default" className="text-[10px] h-4 px-1">Active</Badge>
                      )}
                      {isExpired && (
                        <Badge variant="destructive" className="text-[10px] h-4 px-1">Expired</Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <div className="truncate">
                        <span className="font-medium">IP:</span> {session.ip_address || 'Unknown'}
                      </div>
                      <div className="truncate">
                        <span className="font-medium">Device:</span> {deviceInfo}
                      </div>
                      <div className="truncate">
                        <span className="font-medium">Login:</span>{" "}
                        {formatDistanceToNow(new Date(session.created_at), { addSuffix: true })}
                      </div>
                      <div className="truncate">
                        <span className="font-medium">Activity:</span>{" "}
                        {formatDistanceToNow(new Date(session.last_activity), { addSuffix: true })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            {tenantGroup.sessions.length === 0 && (
              <div className="text-center text-sm text-muted-foreground py-6">
                No login history
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
