import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useTenant } from "@/contexts/TenantContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Users, LogOut, Loader2, Monitor, Smartphone, Globe } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface UserWithSessions {
  id: string;
  email: string;
  full_name: string | null;
  sessions: {
    id: string;
    ip_address: string | null;
    user_agent: string | null;
    last_activity: string;
    created_at: string;
  }[];
}

const parseDevice = (userAgent: string | null) => {
  if (!userAgent) return "Unknown";
  if (/Mobile|Android|iPhone|iPad/i.test(userAgent)) return "Mobile";
  return "Desktop";
};

export function ActiveUsersSessionsCard() {
  const [terminatingUser, setTerminatingUser] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const { effectiveTenantId } = useTenant();

  const { data: usersWithSessions, isLoading } = useQuery({
    queryKey: ["all-active-users-sessions", effectiveTenantId],
    queryFn: async () => {
      const { data: sessions, error: sessionsError } = await supabase
        .from("user_sessions")
        .select("*")
        .eq("is_active", true)
        .order("last_activity", { ascending: false });

      if (sessionsError) throw sessionsError;

      const userIds = [...new Set(sessions?.map((s) => s.user_id) || [])];

      let profileQuery = supabase
        .from("profiles")
        .select("id, email, full_name, admin_id")
        .in("id", userIds);

      const { data: profiles, error: profilesError } = await profileQuery;

      if (profilesError) throw profilesError;

      // Filter profiles by tenant
      const filteredProfiles = effectiveTenantId 
        ? profiles?.filter(p => p.admin_id === effectiveTenantId) 
        : profiles;

      const usersMap = new Map<string, UserWithSessions>();

      filteredProfiles?.forEach((profile) => {
        usersMap.set(profile.id, {
          id: profile.id,
          email: profile.email,
          full_name: profile.full_name,
          sessions: [],
        });
      });

      sessions?.forEach((session) => {
        const user = usersMap.get(session.user_id);
        if (user) {
          user.sessions.push({
            id: session.id,
            ip_address: session.ip_address,
            user_agent: session.user_agent,
            last_activity: session.last_activity,
            created_at: session.created_at,
          });
        }
      });

      return Array.from(usersMap.values());
    },
    refetchInterval: 15000,
  });

  const handleLogoutUser = async (userId: string, userName: string) => {
    setTerminatingUser(userId);
    try {
      const { error } = await supabase
        .from("user_sessions")
        .update({ is_active: false })
        .eq("user_id", userId);

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ["all-active-users-sessions"] });
      queryClient.invalidateQueries({ queryKey: ["security-active-sessions"] });
      queryClient.invalidateQueries({ queryKey: ["security-sessions-by-tenant"] });
      toast.success(`All sessions terminated for ${userName}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to terminate sessions";
      toast.error(message);
    } finally {
      setTerminatingUser(null);
    }
  };

  const getInitials = (name: string | null, email: string) => {
    if (name) {
      return name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);
    }
    return email.slice(0, 2).toUpperCase();
  };

  return (
    <Card className="bg-muted/30 border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Users className="h-4 w-4" />
          Active Users Sessions
          {usersWithSessions && (
            <Badge variant="default" className="text-xs ml-2">
              {usersWithSessions.length} user{usersWithSessions.length !== 1 ? "s" : ""}
            </Badge>
          )}
        </CardTitle>
        <CardDescription className="text-xs">
          Manage active user sessions. Terminate to log users out.
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-3">
        <ScrollArea className="h-[320px]">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : usersWithSessions?.length === 0 ? (
            <div className="text-center text-muted-foreground py-8 text-sm">
              No active users found
            </div>
          ) : (
            <div className="space-y-3">
              {usersWithSessions?.map((user) => (
                <div
                  key={user.id}
                  className="border border-border/50 rounded-lg p-3 bg-background/50"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {getInitials(user.full_name, user.email)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="font-medium text-sm truncate">
                          {user.full_name || user.email}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {user.email}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge className="text-[10px] bg-primary/20 text-primary border-primary/30">
                        {user.sessions.length} session{user.sessions.length !== 1 ? "s" : ""}
                      </Badge>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() =>
                          handleLogoutUser(user.id, user.full_name || user.email)
                        }
                        disabled={terminatingUser === user.id}
                      >
                        {terminatingUser === user.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <>
                            <LogOut className="h-3 w-3 mr-1" />
                            Logout
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-1 ml-10">
                    {user.sessions.map((session) => {
                      const device = parseDevice(session.user_agent);
                      return (
                        <div
                          key={session.id}
                          className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/30 rounded px-2 py-1.5"
                        >
                          {device === "Mobile" ? (
                            <Smartphone className="h-3 w-3 shrink-0" />
                          ) : (
                            <Monitor className="h-3 w-3 shrink-0" />
                          )}
                          <Globe className="h-3 w-3 shrink-0" />
                          <span className="truncate flex-1">{session.ip_address || "Unknown IP"}</span>
                          <span className="shrink-0">
                            {formatDistanceToNow(new Date(session.last_activity), { addSuffix: true })}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
