import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Users, LogOut, Loader2, Monitor, Smartphone, Globe, Building2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface UserSession {
  id: string;
  ip_address: string | null;
  user_agent: string | null;
  last_activity: string;
  created_at: string;
}

interface UserWithSessions {
  id: string;
  email: string;
  full_name: string | null;
  admin_id: string | null;
  sessions: UserSession[];
}

interface TenantSessionGroup {
  tenantId: string;
  tenantName: string;
  users: UserWithSessions[];
  totalSessions: number;
}

interface TenantSessionsCardProps {
  tenantGroup: TenantSessionGroup;
}

const parseDevice = (userAgent: string | null) => {
  if (!userAgent) return "Unknown";
  if (/Mobile|Android|iPhone|iPad/i.test(userAgent)) return "Mobile";
  return "Desktop";
};

export function TenantSessionsCard({ tenantGroup }: TenantSessionsCardProps) {
  const [terminatingUser, setTerminatingUser] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const handleLogoutUser = async (userId: string, userName: string) => {
    setTerminatingUser(userId);
    try {
      const { error } = await supabase
        .from("user_sessions")
        .update({ is_active: false })
        .eq("user_id", userId);

      if (error) throw error;

      queryClient.invalidateQueries({ queryKey: ["security-sessions-by-tenant"] });
      queryClient.invalidateQueries({ queryKey: ["security-active-sessions"] });
      toast.success(`All sessions terminated for ${userName}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Failed to terminate sessions";
      toast.error(message);
    } finally {
      setTerminatingUser(null);
    }
  };

  const getInitials = (name: string | null, email: string) => {
    if (name) {
      return name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);
    }
    return email.slice(0, 2).toUpperCase();
  };

  return (
    <Card className="bg-muted/30 border-0">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-sm">
          <Building2 className="h-4 w-4" />
          {tenantGroup.tenantName}
          <Badge variant="default" className="text-xs ml-2">
            {tenantGroup.users.length} user{tenantGroup.users.length !== 1 ? "s" : ""} • {tenantGroup.totalSessions} session{tenantGroup.totalSessions !== 1 ? "s" : ""}
          </Badge>
        </CardTitle>
        <CardDescription className="text-xs">
          Active sessions for this tenant
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-3">
        <ScrollArea className="h-[280px]">
          {tenantGroup.users.length === 0 ? (
            <div className="text-center text-muted-foreground py-8 text-sm">
              No active users
            </div>
          ) : (
            <div className="space-y-3">
              {tenantGroup.users.map((user) => (
                <div
                  key={user.id}
                  className="border border-border/50 rounded-lg p-3 bg-background/50"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {getInitials(user.full_name, user.email)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <div className="font-medium text-sm truncate">
                          {user.full_name || user.email}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {user.email}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge className="text-[10px] bg-primary/20 text-primary border-primary/30">
                        {user.sessions.length} session{user.sessions.length !== 1 ? "s" : ""}
                      </Badge>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="h-7 text-xs"
                        onClick={() => handleLogoutUser(user.id, user.full_name || user.email)}
                        disabled={terminatingUser === user.id}
                      >
                        {terminatingUser === user.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <>
                            <LogOut className="h-3 w-3 mr-1" />
                            Logout
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-1 ml-10">
                    {user.sessions.map((session) => {
                      const device = parseDevice(session.user_agent);
                      return (
                        <div
                          key={session.id}
                          className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/30 rounded px-2 py-1.5"
                        >
                          {device === "Mobile" ? (
                            <Smartphone className="h-3 w-3 shrink-0" />
                          ) : (
                            <Monitor className="h-3 w-3 shrink-0" />
                          )}
                          <Globe className="h-3 w-3 shrink-0" />
                          <span className="truncate flex-1">{session.ip_address || "Unknown IP"}</span>
                          <span className="shrink-0">
                            {formatDistanceToNow(new Date(session.last_activity), { addSuffix: true })}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
