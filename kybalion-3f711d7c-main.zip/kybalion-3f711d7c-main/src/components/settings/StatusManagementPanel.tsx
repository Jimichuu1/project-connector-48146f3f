import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, GripVertical, Check, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface Status {
  id: string;
  name: string;
  color: string;
  position: number;
  is_default: boolean;
  is_active: boolean;
}

const DEFAULT_COLORS = [
  "#22c55e", "#3b82f6", "#eab308", "#ef4444", "#8b5cf6", 
  "#06b6d4", "#ec4899", "#6b7280", "#84cc16", "#f97316"
];

export function StatusManagementPanel() {
  const [leadStatuses, setLeadStatuses] = useState<Status[]>([]);
  const [clientStatuses, setClientStatuses] = useState<Status[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingStatus, setEditingStatus] = useState<Status | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newStatusName, setNewStatusName] = useState("");
  const [newStatusColor, setNewStatusColor] = useState(DEFAULT_COLORS[0]);
  const [statusToDelete, setStatusToDelete] = useState<{ status: Status; type: "lead" | "client" } | null>(null);
  const [activeTab, setActiveTab] = useState<"leads" | "clients">("leads");

  useEffect(() => {
    fetchStatuses();
  }, []);

  const fetchStatuses = async () => {
    setLoading(true);
    try {
      const [leadRes, clientRes] = await Promise.all([
        supabase.from("lead_statuses").select("*").order("position"),
        supabase.from("client_statuses").select("*").order("position")
      ]);

      if (leadRes.error) throw leadRes.error;
      if (clientRes.error) throw clientRes.error;

      setLeadStatuses(leadRes.data || []);
      setClientStatuses(clientRes.data || []);
    } catch (error) {
      console.error("Error fetching statuses:", error);
      toast.error("Failed to load statuses");
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    if (!newStatusName.trim()) {
      toast.error("Status name is required");
      return;
    }

    const table = activeTab === "leads" ? "lead_statuses" : "client_statuses";
    const statuses = activeTab === "leads" ? leadStatuses : clientStatuses;
    const maxPosition = Math.max(...statuses.map(s => s.position), -1);

    try {
      const { error } = await supabase.from(table).insert({
        name: newStatusName.trim().toUpperCase(),
        color: newStatusColor,
        position: maxPosition + 1
      });

      if (error) throw error;

      toast.success("Status created successfully");
      setNewStatusName("");
      setNewStatusColor(DEFAULT_COLORS[0]);
      setIsCreating(false);
      fetchStatuses();
    } catch (error) {
      console.error("Error creating status:", error);
      const pgError = error as { code?: string };
      if (pgError.code === "23505") {
        toast.error("A status with this name already exists");
      } else {
        toast.error("Failed to create status");
      }
    }
  };

  const handleUpdate = async (status: Status, type: "lead" | "client") => {
    const table = type === "lead" ? "lead_statuses" : "client_statuses";

    try {
      const { error } = await supabase
        .from(table)
        .update({
          name: status.name,
          color: status.color,
          is_active: status.is_active,
          is_default: status.is_default
        })
        .eq("id", status.id);

      if (error) throw error;

      toast.success("Status updated successfully");
      setEditingStatus(null);
      fetchStatuses();
    } catch (error) {
      console.error("Error updating status:", error);
      const pgError = error as { code?: string };
      if (pgError.code === "23505") {
        toast.error("A status with this name already exists");
      } else {
        toast.error("Failed to update status");
      }
    }
  };

  const handleDelete = async () => {
    if (!statusToDelete) return;

    const { status, type } = statusToDelete;
    const statusTable = type === "lead" ? "lead_statuses" : "client_statuses";
    const entityTable = type === "lead" ? "leads" : "clients";
    const statuses = type === "lead" ? leadStatuses : clientStatuses;

    try {
      // Find the default status
      const defaultStatus = statuses.find(s => s.is_default);
      
      if (!defaultStatus) {
        toast.error("Please set a default status before deleting");
        return;
      }

      // Update all leads/clients with the deleted status to use default status
      // Using type assertion since status names match enum values
      const { error: updateError } = await supabase
        .from(entityTable)
        .update({ status: defaultStatus.name as any })
        .eq("status", status.name as any);

      if (updateError) {
        console.error("Error updating entities:", updateError);
        // Continue with deletion even if update fails (might be no matching records)
      }

      // Delete the status
      const { error: deleteError } = await supabase
        .from(statusTable)
        .delete()
        .eq("id", status.id);

      if (deleteError) throw deleteError;

      toast.success("Status deleted and records reassigned to default");
      setStatusToDelete(null);
      fetchStatuses();
    } catch (error) {
      console.error("Error deleting status:", error);
      toast.error("Failed to delete status");
    }
  };

  const handleSetDefault = async (status: Status, type: "lead" | "client") => {
    const table = type === "lead" ? "lead_statuses" : "client_statuses";

    try {
      // First, unset all defaults
      await supabase.from(table).update({ is_default: false }).neq("id", "");
      
      // Then set the new default
      const { error } = await supabase
        .from(table)
        .update({ is_default: true })
        .eq("id", status.id);

      if (error) throw error;

      toast.success("Default status updated");
      fetchStatuses();
    } catch (error) {
      console.error("Error setting default:", error);
      toast.error("Failed to set default status");
    }
  };

  const renderStatusList = (statuses: Status[], type: "lead" | "client") => (
    <div className="space-y-1.5">
      {statuses.map((status) => (
        <div
          key={status.id}
          className="flex items-center gap-2 p-2 bg-background/50 rounded-md"
        >
          <GripVertical className="h-3 w-3 text-muted-foreground cursor-grab" />
          
          {editingStatus?.id === status.id ? (
            <>
              <Input
                value={editingStatus.name}
                onChange={(e) => setEditingStatus({ ...editingStatus, name: e.target.value.toUpperCase() })}
                className="flex-1 h-7 text-xs"
              />
              <input
                type="color"
                value={editingStatus.color}
                onChange={(e) => setEditingStatus({ ...editingStatus, color: e.target.value })}
                className="w-6 h-6 rounded cursor-pointer border-0"
              />
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6"
                onClick={() => handleUpdate(editingStatus, type)}
              >
                <Check className="h-3 w-3 text-green-500" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6"
                onClick={() => setEditingStatus(null)}
              >
                <X className="h-3 w-3" />
              </Button>
            </>
          ) : (
            <>
              <div className="flex items-center gap-1">
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      className="w-5 h-5 rounded cursor-pointer border border-border/50 hover:scale-110 transition-transform"
                      style={{ backgroundColor: status.color }}
                    />
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-2" align="start">
                    <div className="grid grid-cols-5 gap-1.5">
                      {DEFAULT_COLORS.map((color) => (
                        <button
                          key={color}
                          className={`w-6 h-6 rounded cursor-pointer transition-transform hover:scale-110 ${status.color === color ? "ring-2 ring-offset-1 ring-primary" : ""}`}
                          style={{ backgroundColor: color }}
                          onClick={() => handleUpdate({ ...status, color }, type)}
                        />
                      ))}
                    </div>
                  </PopoverContent>
                </Popover>
              <Badge
                  style={{ backgroundColor: status.color, color: "#000" }}
                  className="min-w-[80px] justify-center text-xs py-0.5"
                >
                  {status.name}
                </Badge>
              </div>
              
              <div className="flex-1" />
              
              <div className="flex items-center gap-1.5">
                <Label className="text-[10px] text-muted-foreground">Active</Label>
                <Switch
                  checked={status.is_active}
                  onCheckedChange={(checked) => handleUpdate({ ...status, is_active: checked }, type)}
                  className="scale-75"
                />
              </div>

              <Button
                size="sm"
                variant={status.is_default ? "default" : "outline"}
                className="h-6 text-[10px] px-2"
                onClick={() => !status.is_default && handleSetDefault(status, type)}
              >
                {status.is_default ? "Default" : "Set Default"}
              </Button>

              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6"
                onClick={() => setEditingStatus(status)}
              >
                <Pencil className="h-3 w-3" />
              </Button>
              
              <Button
                size="icon"
                variant="ghost"
                className="h-6 w-6 text-destructive hover:text-destructive"
                onClick={() => setStatusToDelete({ status, type })}
                disabled={status.is_default}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </>
          )}
        </div>
      ))}
    </div>
  );

  return (
    <>
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "leads" | "clients")}>
        <TabsList className="grid w-full grid-cols-2 mb-3 h-9">
          <TabsTrigger value="leads" className="text-xs h-7">Lead Statuses</TabsTrigger>
          <TabsTrigger value="clients" className="text-xs h-7">Client Statuses</TabsTrigger>
        </TabsList>

        <TabsContent value="leads" className="space-y-2 mt-0">
          {isCreating && activeTab === "leads" ? (
            <div className="flex items-center gap-2 p-2 bg-background/50 rounded-md border-2 border-dashed border-primary">
              <Input
                placeholder="Status name"
                value={newStatusName}
                onChange={(e) => setNewStatusName(e.target.value.toUpperCase())}
                className="flex-1 h-7 text-xs"
                autoFocus
              />
              <div className="flex gap-1">
                {DEFAULT_COLORS.slice(0, 6).map((color) => (
                  <button
                    key={color}
                    className={`w-5 h-5 rounded-full transition-transform ${newStatusColor === color ? "ring-2 ring-offset-1 ring-primary scale-110" : ""}`}
                    style={{ backgroundColor: color }}
                    onClick={() => setNewStatusColor(color)}
                  />
                ))}
              </div>
              <Button size="sm" className="h-6 text-xs px-2" onClick={handleCreate}>
                <Check className="h-3 w-3 mr-1" />
                Add
              </Button>
              <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => { setIsCreating(false); setNewStatusName(""); }}>
                <X className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="border-dashed h-7 text-xs"
              onClick={() => setIsCreating(true)}
            >
              <Plus className="h-3 w-3 mr-1" />
              Add Lead Status
            </Button>
          )}
          
          {loading ? (
            <div className="text-center py-2 text-muted-foreground text-xs">Loading...</div>
          ) : (
            renderStatusList(leadStatuses, "lead")
          )}
        </TabsContent>

        <TabsContent value="clients" className="space-y-2 mt-0">
          {isCreating && activeTab === "clients" ? (
            <div className="flex items-center gap-2 p-2 bg-background/50 rounded-md border-2 border-dashed border-primary">
              <Input
                placeholder="Status name"
                value={newStatusName}
                onChange={(e) => setNewStatusName(e.target.value.toUpperCase())}
                className="flex-1 h-7 text-xs"
                autoFocus
              />
              <div className="flex gap-1">
                {DEFAULT_COLORS.slice(0, 6).map((color) => (
                  <button
                    key={color}
                    className={`w-5 h-5 rounded-full transition-transform ${newStatusColor === color ? "ring-2 ring-offset-1 ring-primary scale-110" : ""}`}
                    style={{ backgroundColor: color }}
                    onClick={() => setNewStatusColor(color)}
                  />
                ))}
              </div>
              <Button size="sm" className="h-6 text-xs px-2" onClick={handleCreate}>
                <Check className="h-3 w-3 mr-1" />
                Add
              </Button>
              <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => { setIsCreating(false); setNewStatusName(""); }}>
                <X className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="border-dashed h-7 text-xs"
              onClick={() => setIsCreating(true)}
            >
              <Plus className="h-3 w-3 mr-1" />
              Add Client Status
            </Button>
          )}
          
          {loading ? (
            <div className="text-center py-2 text-muted-foreground text-xs">Loading...</div>
          ) : (
            renderStatusList(clientStatuses, "client")
          )}
        </TabsContent>
      </Tabs>

      <AlertDialog open={!!statusToDelete} onOpenChange={() => setStatusToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Status</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the status "{statusToDelete?.status.name}"? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}