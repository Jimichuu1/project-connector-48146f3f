import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { TenantSettings } from "@/hooks/useTenantSettings";

interface PhoneVisibilitySettingsProps {
  settings: TenantSettings | null;
  onUpdate: (updates: Partial<TenantSettings>) => void;
  isLoading?: boolean;
}

export function PhoneVisibilitySettings({ 
  settings, 
  onUpdate,
  isLoading 
}: PhoneVisibilitySettingsProps) {
  const handleToggleAgents = async (checked: boolean) => {
    onUpdate({ show_phone_to_agents: checked });
    toast.success("Phone visibility for agents updated");
  };

  const handleToggleSuperAgents = async (checked: boolean) => {
    onUpdate({ show_phone_to_super_agents: checked });
    toast.success("Phone visibility for super agents updated");
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div className="space-y-0">
          <Label htmlFor="phone-visibility-agents" className="text-sm font-medium">
            Show Phone Numbers to Agents
          </Label>
          <p className="text-xs text-muted-foreground">
            Agents can see phone numbers
          </p>
        </div>
        <Switch
          id="phone-visibility-agents"
          checked={settings?.show_phone_to_agents ?? false}
          onCheckedChange={handleToggleAgents}
          disabled={isLoading || !settings}
          className="scale-90"
        />
      </div>
      <div className="flex items-center justify-between gap-3">
        <div className="space-y-0">
          <Label htmlFor="phone-visibility-super-agents" className="text-sm font-medium">
            Show Phone Numbers to Super Agents
          </Label>
          <p className="text-xs text-muted-foreground">
            Super Agents can see phone numbers
          </p>
        </div>
        <Switch
          id="phone-visibility-super-agents"
          checked={settings?.show_phone_to_super_agents ?? false}
          onCheckedChange={handleToggleSuperAgents}
          disabled={isLoading || !settings}
          className="scale-90"
        />
      </div>
    </div>
  );
}
