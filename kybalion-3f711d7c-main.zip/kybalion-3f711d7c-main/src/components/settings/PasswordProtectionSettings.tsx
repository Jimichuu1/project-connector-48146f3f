import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ShieldCheck, AlertTriangle, CheckCircle2, Info } from "lucide-react";
import { toast } from "sonner";
import { TenantSettings } from "@/hooks/useTenantSettings";

interface PasswordProtectionConfig {
  enable_leaked_password_check: boolean;
  min_password_length: number;
  require_uppercase: boolean;
  require_lowercase: boolean;
  require_numbers: boolean;
  require_special_chars: boolean;
}

interface PasswordProtectionSettingsProps {
  settings: TenantSettings | null;
  onUpdate: (updates: Partial<TenantSettings>) => void;
  isLoading?: boolean;
}

export function PasswordProtectionSettings({ 
  settings, 
  onUpdate,
  isLoading 
}: PasswordProtectionSettingsProps) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [config, setConfig] = useState<PasswordProtectionConfig>({
    enable_leaked_password_check: true,
    min_password_length: 8,
    require_uppercase: true,
    require_lowercase: true,
    require_numbers: true,
    require_special_chars: true,
  });

  useEffect(() => {
    if (open && settings?.password_protection_config) {
      const savedConfig = settings.password_protection_config as unknown as PasswordProtectionConfig;
      setConfig(savedConfig);
    }
  }, [open, settings]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const configJson = JSON.parse(JSON.stringify(config));
      onUpdate({ password_protection_config: configJson });
      toast.success("Password protection settings saved");
      setOpen(false);
    } catch (error) {
      toast.error("Failed to save settings");
    } finally {
      setSaving(false);
    }
  };

  const getSecurityScore = () => {
    let score = 0;
    if (config.enable_leaked_password_check) score += 2;
    if (config.min_password_length >= 8) score += 1;
    if (config.min_password_length >= 12) score += 1;
    if (config.require_uppercase) score += 1;
    if (config.require_lowercase) score += 1;
    if (config.require_numbers) score += 1;
    if (config.require_special_chars) score += 1;
    return score;
  };

  const score = getSecurityScore();
  const scoreLabel = score >= 7 ? "Strong" : score >= 4 ? "Medium" : "Weak";
  const scoreColor = score >= 7 ? "text-green-500" : score >= 4 ? "text-yellow-500" : "text-destructive";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full justify-start gap-2" disabled={isLoading || !settings}>
          <ShieldCheck className="h-4 w-4" />
          Password Protection
          <span className={`ml-auto text-xs ${scoreColor}`}>
            {scoreLabel}
          </span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            Password Protection Settings
          </DialogTitle>
          <DialogDescription>
            Configure password security requirements for user accounts
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Leaked Password Check */}
          <div className="rounded-lg border p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <Label className="flex items-center gap-2 font-medium">
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                  Leaked Password Protection
                </Label>
                <p className="text-xs text-muted-foreground">
                  Block passwords found in known data breaches (HaveIBeenPwned database)
                </p>
              </div>
              <Switch
                checked={config.enable_leaked_password_check}
                onCheckedChange={(checked) =>
                  setConfig((prev) => ({ ...prev, enable_leaked_password_check: checked }))
                }
              />
            </div>
            {config.enable_leaked_password_check && (
              <div className="flex items-center gap-2 text-xs text-green-600 bg-green-500/10 rounded-md p-2">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Compromised passwords will be blocked during signup and password changes
              </div>
            )}
          </div>

          {/* Password Requirements */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Password Requirements</Label>
            
            <div className="flex items-center gap-3">
              <Label className="text-xs text-muted-foreground w-32">Minimum Length</Label>
              <Input
                type="number"
                min={6}
                max={32}
                value={config.min_password_length}
                onChange={(e) =>
                  setConfig((prev) => ({
                    ...prev,
                    min_password_length: parseInt(e.target.value) || 8,
                  }))
                }
                className="w-20 h-8 text-sm"
              />
              <span className="text-xs text-muted-foreground">characters</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground">Uppercase (A-Z)</Label>
                <Switch
                  checked={config.require_uppercase}
                  onCheckedChange={(checked) =>
                    setConfig((prev) => ({ ...prev, require_uppercase: checked }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground">Lowercase (a-z)</Label>
                <Switch
                  checked={config.require_lowercase}
                  onCheckedChange={(checked) =>
                    setConfig((prev) => ({ ...prev, require_lowercase: checked }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground">Numbers (0-9)</Label>
                <Switch
                  checked={config.require_numbers}
                  onCheckedChange={(checked) =>
                    setConfig((prev) => ({ ...prev, require_numbers: checked }))
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-xs text-muted-foreground">Special (!@#$)</Label>
                <Switch
                  checked={config.require_special_chars}
                  onCheckedChange={(checked) =>
                    setConfig((prev) => ({ ...prev, require_special_chars: checked }))
                  }
                />
              </div>
            </div>
          </div>

          {/* Security Score */}
          <div className="rounded-lg bg-muted/50 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium">Security Score</span>
              <span className={`text-sm font-bold ${scoreColor}`}>
                {score}/8 - {scoreLabel}
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all ${
                  score >= 7 ? "bg-green-500" : score >= 4 ? "bg-yellow-500" : "bg-destructive"
                }`}
                style={{ width: `${(score / 8) * 100}%` }}
              />
            </div>
          </div>

          {/* Info Notice */}
          <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted/30 rounded-md p-2">
            <Info className="h-3.5 w-3.5 mt-0.5 shrink-0" />
            <span>
              These settings apply to new user creation and password resets. Existing passwords are not affected until changed.
            </span>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? "Saving..." : "Save Settings"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
