import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2 } from "lucide-react";

interface Tenant {
  id: string;
  full_name: string;
}

interface TenantSettingsSelectorProps {
  tenants: Tenant[];
  selectedTenantId: string | null;
  onTenantChange: (tenantId: string) => void;
}

export function TenantSettingsSelector({
  tenants,
  selectedTenantId,
  onTenantChange,
}: TenantSettingsSelectorProps) {
  if (tenants.length === 0) return null;

  return (
    <div className="flex items-center gap-2 p-3 bg-muted/30 rounded-lg border border-border/50">
      <Building2 className="h-4 w-4 text-muted-foreground" />
      <span className="text-sm text-muted-foreground">Managing settings for:</span>
      <Select value={selectedTenantId || ""} onValueChange={onTenantChange}>
        <SelectTrigger className="w-[200px] h-8">
          <SelectValue placeholder="Select tenant" />
        </SelectTrigger>
        <SelectContent>
          {tenants.map((tenant) => (
            <SelectItem key={tenant.id} value={tenant.id}>
              {tenant.full_name || "Unknown Tenant"}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
