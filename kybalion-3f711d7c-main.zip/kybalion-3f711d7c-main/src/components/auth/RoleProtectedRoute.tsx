import { ReactNode } from "react";
import { useUserData } from "@/contexts/UserDataContext";
import { useAuth } from "@/contexts/AuthContext";
import { queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import NotFound from "@/pages/NotFound";

type AllowedRole = "SUPER_ADMIN" | "TENANT_OWNER" | "MANAGER" | "TEAM_LEADER" | "SUPER_AGENT" | "AGENT";

interface RoleProtectedRouteProps {
  children: ReactNode;
  allowedRoles: AllowedRole[];
}

export const RoleProtectedRoute = ({ children, allowedRoles }: RoleProtectedRouteProps) => {
  const { role, loading } = useUserData();
  const { session } = useAuth();
  const userId = session?.user?.id;

  const hasCachedData = userId ? !!queryClient.getQueryData(["user-data", userId]) : false;

  if (loading && !hasCachedData) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Checking access...</p>
        </div>
      </div>
    );
  }

  if (!role || !allowedRoles.includes(role as AllowedRole)) {
    return <NotFound />;
  }

  return <>{children}</>;
};
