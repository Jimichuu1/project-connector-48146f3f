import { useEffect, useRef, useState } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ShieldCheck } from "lucide-react";

interface CaptchaVerificationProps {
  onVerify: (token: string) => void;
  onExpire?: () => void;
}

export const CaptchaVerification = ({ onVerify, onExpire }: CaptchaVerificationProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // For demo purposes, we'll use a simple checkbox verification
    // In production, integrate with hCaptcha or Google reCAPTCHA
    setIsLoading(false);
  }, []);

  const handleVerify = () => {
    // Generate a mock token for demo
    const mockToken = `captcha_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    onVerify(mockToken);
  };

  return (
    <div className="space-y-3">
      <Alert>
        <ShieldCheck className="h-4 w-4" />
        <AlertDescription>
          Additional verification required after multiple failed attempts
        </AlertDescription>
      </Alert>
      
      <div 
        ref={containerRef}
        className="flex items-center justify-center p-4 border border-border rounded-md bg-muted/50"
      >
        {isLoading ? (
          <div className="text-sm text-muted-foreground">Loading verification...</div>
        ) : (
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              className="w-4 h-4"
              onChange={(e) => e.target.checked && handleVerify()}
            />
            <span className="text-sm">I'm not a robot</span>
          </label>
        )}
      </div>
      
      <p className="text-xs text-muted-foreground text-center">
        This verification helps protect your account from unauthorized access
      </p>
    </div>
  );
};
