import { ReactNode, useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { Loader2, AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProtectedRouteProps {
  children: ReactNode;
}

export const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { user, loading: authLoading } = useAuth();
  const { loading: tenantLoading, error: tenantError, refetch, effectiveTenantId } = useTenant();
  const navigate = useNavigate();
  const [retrying, setRetrying] = useState(false);
  // Track if we've ever loaded successfully to prevent re-showing loading screen
  const hasLoadedOnce = useRef(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/", { replace: true });
    }
  }, [user, authLoading, navigate]);

  // Mark as loaded once we have valid data
  useEffect(() => {
    if (!authLoading && !tenantLoading && user && effectiveTenantId !== undefined) {
      hasLoadedOnce.current = true;
    }
  }, [authLoading, tenantLoading, user, effectiveTenantId]);

  const handleRetry = async () => {
    setRetrying(true);
    refetch();
    // Wait a bit for the refetch to complete
    setTimeout(() => setRetrying(false), 1000);
  };

  // Only block on auth loading. Tenant data has its own loading states in child components,
  // so we don't freeze the whole app on it. This prevents hangs if the tenant fetch stalls.
  if (authLoading && !hasLoadedOnce.current) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  // Show error state with retry option
  if (tenantError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center space-y-4 max-w-md px-4">
          <AlertCircle className="h-12 w-12 mx-auto text-destructive" />
          <h2 className="text-xl font-semibold">Unable to load page</h2>
          <p className="text-muted-foreground text-sm">
            There was an issue loading your data. This might be due to a session timeout.
          </p>
          <div className="flex gap-3 justify-center">
            <Button 
              onClick={handleRetry} 
              disabled={retrying}
              variant="default"
            >
              {retrying ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Try Again
            </Button>
            <Button 
              onClick={() => navigate("/", { replace: true })}
              variant="outline"
            >
              Sign In Again
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
