import { ReactNode } from "react";
import { useUserData } from "@/contexts/UserDataContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { useAuth } from "@/contexts/AuthContext";
import { queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";
import NotFound from "@/pages/NotFound";

interface ManagerTeamProtectedRouteProps {
  children: ReactNode;
  requiresSuperAgents?: boolean;
}

/**
 * Protects routes that require managers to have specific team members.
 * - For managers with only agents: can't access Clients/Pipeline
 * - For managers with super agents: full access
 * - Non-managers pass through (handled by other role checks)
 */
export const ManagerTeamProtectedRoute = ({ 
  children, 
  requiresSuperAgents = false,
}: ManagerTeamProtectedRouteProps) => {
  const { isManager, isTeamLeader, loading: roleLoading } = useUserData();
  const isManagerOrTL = isManager || isTeamLeader;
  const { canAccessClients, isLoading: teamLoading } = useManagerTeam();
  const { session } = useAuth();
  const userId = session?.user?.id;

  // Check if we have cached user data to avoid showing loading spinner
  const hasCachedUserData = userId ? !!queryClient.getQueryData(["user-data", userId]) : false;

  const isLoading = roleLoading || teamLoading;

  // Only show loading if actually loading AND no cached data exists
  if (isLoading && !hasCachedUserData) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Checking access...</p>
        </div>
      </div>
    );
  }

  // Non-managers/TLs pass through (other role checks handle their access)
  if (!isManagerOrTL) {
    return <>{children}</>;
  }

  // Manager/TL needs super agents to access routes requiring them
  if (requiresSuperAgents && !canAccessClients) {
    return <NotFound />;
  }

  return <>{children}</>;
};
