import { useState, useEffect, useCallback, useRef, lazy, Suspense, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

const AccessDenied = lazy(() => import("@/pages/AccessDenied"));

// Re-check IP every 5 minutes
const IP_RECHECK_INTERVAL_MS = 5 * 60 * 1000;
// Require 3 consecutive DEFINITIVE failures before blocking
const MAX_CONSECUTIVE_FAILURES = 3;

interface GeoAccessGuardProps {
  children: ReactNode;
}

export function GeoAccessGuard({ children }: GeoAccessGuardProps) {
  const [isChecking, setIsChecking] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);
  const [countryName, setCountryName] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isMounted = useRef(true);
  const consecutiveFailuresRef = useRef(0);

  const scrubMetadata = useCallback(() => {
    document.title = "403 Forbidden";
    const metaSelectors = [
      'meta[name="description"]',
      'meta[name="keywords"]',
      'meta[name="author"]',
      'meta[property="og:title"]',
      'meta[property="og:description"]',
      'meta[property="og:image"]',
      'meta[property="og:type"]',
      'meta[name="twitter:card"]',
      'meta[name="twitter:title"]',
      'meta[name="twitter:description"]',
      'meta[name="twitter:image"]',
    ];
    metaSelectors.forEach((sel) => {
      const el = document.querySelector(sel);
      if (el) el.remove();
    });
  }, []);

  const blockAccess = useCallback((country: string | null) => {
    if (!isMounted.current) return;
    setIsBlocked(true);
    setIsChecking(false);
    setCountryName(country);
    scrubMetadata();
    // Clear interval — no need to keep checking once blocked
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    // NOTE: We intentionally do NOT call supabase.auth.signOut() here.
    // Blocking the UI is sufficient; destroying the session causes
    // "Refresh Token Not Found" cascades when the block was caused by
    // transient edge-function errors rather than a real geo/IP block.
  }, [scrubMetadata]);

  const checkAccess = useCallback(async (isInitial = false) => {
    try {
      // Add a 5s timeout — never let a slow geo-check freeze the entire app on first paint.
      // Failure here is fail-open (matches existing behavior on network errors).
      const invokePromise = supabase.functions.invoke('check-geo-access', { body: {} });
      const timeoutPromise = new Promise<{ data: null; error: Error }>((resolve) =>
        setTimeout(() => resolve({ data: null, error: new Error('geo-check timeout') }), 5000),
      );
      const { data, error } = (await Promise.race([invokePromise, timeoutPromise])) as
        | Awaited<typeof invokePromise>
        | { data: null; error: Error };

      // Handle network-level errors (function unreachable, timeout, etc.)
      if (error || !data) {
        consecutiveFailuresRef.current += 1;
        console.warn(
          `Geo check failed (attempt ${consecutiveFailuresRef.current}/${MAX_CONSECUTIVE_FAILURES}):`,
          error?.message || 'No data returned'
        );

        // Transient network errors: never block, just allow through
        if (isInitial && isMounted.current) {
          setIsChecking(false);
        }
        return;
      }

      // Check for transient/internal_error responses — treat as success (fail-open)
      if (data.reason === 'internal_error' || data.error === 'transient') {
        console.warn('Geo check returned transient error, allowing access');
        consecutiveFailuresRef.current = 0; // Reset — server responded, just had an internal issue
        if (isInitial && isMounted.current) {
          setIsChecking(false);
        }
        return;
      }

      // Successful definitive response — reset failure counter
      consecutiveFailuresRef.current = 0;

      if (!data.allowed) {
        // Definitive block from the server (geo or IP whitelist)
        blockAccess(data.country || null);
        return;
      }

      // Access allowed
      if (isInitial && isMounted.current) {
        setIsChecking(false);
      }
    } catch {
      consecutiveFailuresRef.current += 1;
      console.warn(
        `Geo check network error (attempt ${consecutiveFailuresRef.current}/${MAX_CONSECUTIVE_FAILURES})`
      );

      // Network errors: never block, just allow through
      if (isInitial && isMounted.current) {
        setIsChecking(false);
      }
    }
  }, [blockAccess]);

  // Initial check
  useEffect(() => {
    isMounted.current = true;
    checkAccess(true);
    return () => {
      isMounted.current = false;
    };
  }, [checkAccess]);

  // Continuous re-check interval
  useEffect(() => {
    if (isBlocked) return;

    intervalRef.current = setInterval(() => {
      checkAccess(false);
    }, IP_RECHECK_INTERVAL_MS);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isBlocked, checkAccess]);

  // Re-check on visibility change (user switches tabs and comes back)
  useEffect(() => {
    if (isBlocked) return;

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        checkAccess(false);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [isBlocked, checkAccess]);

  // Re-check when network reconnects
  useEffect(() => {
    if (isBlocked) return;

    const handleOnline = () => {
      consecutiveFailuresRef.current = 0;
      checkAccess(false);
    };

    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [isBlocked, checkAccess]);

  if (isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (isBlocked) {
    return (
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center bg-black">
          <div className="text-green-500 font-mono animate-pulse">Initializing security protocols...</div>
        </div>
      }>
        <AccessDenied countryName={countryName} />
      </Suspense>
    );
  }

  return <>{children}</>;
}
