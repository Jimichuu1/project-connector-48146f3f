import { KybalionLogo } from "@/components/KybalionLogo";

const FloatingShape = ({ 
  className, 
  delay = "0s",
  duration = "6s",
  size = "w-16 h-16"
}: { 
  className?: string; 
  delay?: string;
  duration?: string;
  size?: string;
}) => (
  <div 
    className={`absolute rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20 ${size} ${className}`}
    style={{ 
      animation: `float ${duration} ease-in-out infinite`,
      animationDelay: delay
    }}
  />
);

const Diamond = ({ 
  className, 
  delay = "0s",
  size = "w-8 h-8"
}: { 
  className?: string; 
  delay?: string;
  size?: string;
}) => (
  <div 
    className={`absolute rotate-45 bg-accent/10 backdrop-blur-sm border border-accent/20 ${size} ${className}`}
    style={{ 
      animation: `float-reverse 8s ease-in-out infinite`,
      animationDelay: delay
    }}
  />
);

const AnimatedBackground = () => {
  return (
    <div className="relative w-full h-full overflow-hidden bg-gradient-to-br from-background via-primary/5 to-accent/10">
      {/* Animated gradient overlay */}
      <div 
        className="absolute inset-0 opacity-50"
        style={{
          background: "linear-gradient(135deg, hsl(var(--primary) / 0.1) 0%, hsl(var(--accent) / 0.1) 50%, hsl(var(--primary) / 0.05) 100%)",
          backgroundSize: "400% 400%",
          animation: "gradient-shift 15s ease infinite"
        }}
      />

      {/* Grid pattern overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(hsl(var(--foreground)) 1px, transparent 1px),
                           linear-gradient(90deg, hsl(var(--foreground)) 1px, transparent 1px)`,
          backgroundSize: "50px 50px"
        }}
      />

      {/* Floating shapes */}
      <FloatingShape className="top-[10%] left-[10%]" size="w-20 h-20" delay="0s" duration="7s" />
      <FloatingShape className="top-[20%] right-[15%]" size="w-12 h-12" delay="1s" duration="5s" />
      <FloatingShape className="top-[60%] left-[5%]" size="w-16 h-16" delay="2s" duration="8s" />
      <FloatingShape className="bottom-[15%] right-[10%]" size="w-24 h-24" delay="0.5s" duration="6s" />
      <FloatingShape className="top-[40%] left-[25%]" size="w-8 h-8" delay="3s" duration="9s" />
      
      {/* Diamond shapes */}
      <Diamond className="top-[30%] right-[25%]" size="w-10 h-10" delay="1.5s" />
      <Diamond className="bottom-[30%] left-[15%]" size="w-6 h-6" delay="2.5s" />
      <Diamond className="top-[70%] right-[30%]" size="w-8 h-8" delay="0.5s" />

      {/* Center content */}
      <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
        {/* Logo with glow effect */}
        <div 
          className="relative mb-8"
          style={{ animation: "pulse-glow 3s ease-in-out infinite" }}
        >
          <div className="absolute inset-0 blur-2xl bg-primary/30 rounded-full scale-150" />
          <div className="relative h-28 w-28 rounded-2xl bg-card flex items-center justify-center shadow-2xl border border-primary/20">
            <KybalionLogo className="h-20 w-20" />
          </div>
        </div>

        {/* Brand name */}
        <h1 className="text-4xl font-bold text-foreground mb-4 tracking-tight">
          Kybalion CRM
        </h1>
        
        {/* Tagline */}
        <p className="text-muted-foreground text-lg mb-8 text-center max-w-sm">
          Transform your sales pipeline with intelligent lead management
        </p>

        {/* Feature pills */}
        <div className="flex flex-wrap gap-3 justify-center max-w-md">
          {["Lead Tracking", "Pipeline Management", "Team Analytics", "Real-time Reports"].map((feature, i) => (
            <span 
              key={feature}
              className="px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-sm text-foreground/80 backdrop-blur-sm"
              style={{ 
                animation: "fade-in 0.5s ease-out forwards",
                animationDelay: `${i * 0.1}s`,
                opacity: 0
              }}
            >
              {feature}
            </span>
          ))}
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background/50 to-transparent" />
    </div>
  );
};

export default AnimatedBackground;
