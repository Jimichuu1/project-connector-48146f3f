import { Navigate, useLocation } from "react-router-dom";
import { toHashedPath } from "@/lib/routeMap";

/** Redirects any readable route to its hashed equivalent, preserving search/hash. */
export const ReadableRedirect = () => {
  const location = useLocation();
  const hashed = toHashedPath(location.pathname);
  if (!hashed) return <Navigate to="/" replace />;
  return <Navigate to={hashed + location.search + location.hash} replace />;
};
