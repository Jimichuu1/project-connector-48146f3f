interface TokenRotationProviderProps {
  children: React.ReactNode;
}

export function TokenRotationProvider({ children }: TokenRotationProviderProps) {
  // Rely on built-in auth token refresh to avoid cross-tab refresh storms
  return <>{children}</>;
}
