import { usePageVisitLogger } from "@/hooks/usePageVisitLogger";

export function PageVisitTracker() {
  usePageVisitLogger();
  return null;
}
