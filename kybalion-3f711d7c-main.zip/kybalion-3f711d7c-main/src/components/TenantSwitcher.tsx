import { Building2, Check, ChevronsUpDown, Eye } from "lucide-react";
import { useTenant } from "@/contexts/TenantContext";
import { useSidebar } from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

export function TenantSwitcher() {
  const { tenants, selectedTenantId, setSelectedTenantId, isSuperAdmin, selectedTenantName } = useTenant();
  const { state } = useSidebar();
  const isCollapsed = state === "collapsed";

  if (!isSuperAdmin || tenants.length === 0) {
    return null;
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            "flex items-center gap-2 w-full rounded-lg border border-border/50 bg-accent/30 hover:bg-accent/50 transition-colors",
            isCollapsed ? "justify-center p-2" : "px-3 py-2"
          )}
        >
          <div className="flex items-center justify-center h-6 w-6 rounded bg-primary/10 flex-shrink-0">
            {selectedTenantId ? (
              <Eye className="h-3.5 w-3.5 text-primary" />
            ) : (
              <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
            )}
          </div>
          {!isCollapsed && (
            <>
              <div className="flex flex-col items-start flex-1 min-w-0">
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider">
                  Viewing As
                </span>
                <span className="text-xs font-medium truncate w-full text-left">
                  {selectedTenantName || "All Tenants"}
                </span>
              </div>
              <ChevronsUpDown className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            </>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56">
        <DropdownMenuItem
          onClick={() => setSelectedTenantId(null)}
          className="cursor-pointer"
        >
          <div className="flex items-center justify-between w-full">
            <span>All Tenants</span>
            {!selectedTenantId && <Check className="h-4 w-4 text-primary" />}
          </div>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        {tenants.map((tenant) => (
          <DropdownMenuItem
            key={tenant.id}
            onClick={() => setSelectedTenantId(tenant.id)}
            className="cursor-pointer"
          >
            <div className="flex items-center justify-between w-full">
              <span className="truncate">{tenant.full_name}</span>
              {selectedTenantId === tenant.id && (
                <Check className="h-4 w-4 text-primary flex-shrink-0" />
              )}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
