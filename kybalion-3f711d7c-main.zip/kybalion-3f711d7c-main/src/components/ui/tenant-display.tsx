import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Building2 } from "lucide-react";

interface TenantDisplayProps {
  adminId: string | null | undefined;
  showIcon?: boolean;
}

export function TenantDisplay({ adminId, showIcon = false }: TenantDisplayProps) {
  const { data: tenant, isLoading } = useQuery({
    queryKey: ['tenant-profile', adminId],
    queryFn: async () => {
      if (!adminId) return null;
      
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email, username')
        .eq('id', adminId)
        .single();
      
      if (error) return null;
      return data;
    },
    enabled: !!adminId,
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
  });

  if (!adminId) {
    return (
      <Badge variant="outline" className="text-xs text-muted-foreground">
        No Tenant
      </Badge>
    );
  }

  if (isLoading) {
    return <Skeleton className="h-5 w-20" />;
  }

  const displayName = tenant?.full_name || tenant?.username || tenant?.email || 'Unknown';

  return (
    <Badge variant="outline" className="text-xs gap-1 bg-primary/10 text-primary border-primary/30">
      {showIcon && <Building2 className="h-3 w-3" />}
      {displayName}
    </Badge>
  );
}
