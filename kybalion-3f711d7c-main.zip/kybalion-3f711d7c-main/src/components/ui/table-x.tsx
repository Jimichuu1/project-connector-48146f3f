import { ReactNode } from "react";

interface TableXProps {
  toolbar: ReactNode;
  filters?: ReactNode;
  children: ReactNode;
}

/**
 * TableX - A structured table container with toolbar, filters, and content areas
 * Provides consistent layout for data tables with search, filters, and view switching
 */
export function TableX({ toolbar, filters, children }: TableXProps) {
  return (
    <div className="bg-background">
      {/* Toolbar Section - Search, Actions, View Switcher */}
      {toolbar}

      {/* Filters Section - Status, Advanced Filters */}
      {filters}

      {/* Content Section - Table/Board/Groups View */}
      <div className="animate-fade-in">
        {children}
      </div>
    </div>
  );
}
