import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface UserDisplayProps {
  name: string;
  avatar?: string | null;
  className?: string;
}

export function UserDisplay({ name, avatar, className }: UserDisplayProps) {
  const getInitials = (name: string) => {
    return name.charAt(0).toUpperCase();
  };

  return (
    <div className={`flex items-center gap-2 ${className || ''}`}>
      <Avatar className="h-6 w-6">
        <AvatarImage src={avatar || undefined} />
        <AvatarFallback className="text-xs">
          {getInitials(name)}
        </AvatarFallback>
      </Avatar>
      <span className="truncate">{name}</span>
    </div>
  );
}
