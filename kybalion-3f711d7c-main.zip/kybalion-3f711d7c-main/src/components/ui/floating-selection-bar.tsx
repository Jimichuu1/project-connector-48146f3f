import { X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface FloatingSelectionBarAction {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost";
}

interface FloatingSelectionBarDropdownAction {
  label: string;
  icon?: React.ReactNode;
  options: Array<{
    label: string;
    value: string;
    onClick: () => void;
  }>;
}

interface FloatingSelectionBarProps {
  selectedCount: number;
  onClear: () => void;
  actions?: FloatingSelectionBarAction[];
  dropdownActions?: FloatingSelectionBarDropdownAction[];
  className?: string;
}

export function FloatingSelectionBar({
  selectedCount,
  onClear,
  actions = [],
  dropdownActions = [],
  className,
}: FloatingSelectionBarProps) {
  if (selectedCount === 0) return null;

  return (
    <div
      className={cn(
        "fixed bottom-6 left-1/2 -translate-x-1/2 z-50",
        "flex items-center gap-3 px-4 py-3 rounded-xl",
        "bg-secondary text-secondary-foreground shadow-2xl",
        "animate-in slide-in-from-bottom-4 fade-in duration-300",
        className
      )}
    >
      <div className="flex items-center gap-2 pr-3 border-r border-secondary-foreground/20">
        <span className="text-sm font-medium">
          {selectedCount} selected
        </span>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 hover:bg-secondary-foreground/20 text-secondary-foreground"
          onClick={onClear}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex items-center gap-2">
        {/* Dropdown Actions */}
        {dropdownActions.map((dropdown, index) => (
          <DropdownMenu key={`dropdown-${index}`}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="secondary"
                size="sm"
                className="bg-secondary-foreground/20 hover:bg-secondary-foreground/30 text-secondary-foreground"
              >
                {dropdown.icon}
                <span className="ml-1.5">{dropdown.label}</span>
                <ChevronDown className="ml-1 h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="center" className="bg-popover">
              {dropdown.options.map((option) => (
                <DropdownMenuItem
                  key={option.value}
                  onClick={option.onClick}
                >
                  {option.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        ))}

        {/* Regular Actions */}
        {actions.map((action, index) => (
          <Button
            key={index}
            variant={action.variant || "secondary"}
            size="sm"
            className={cn(
              action.variant === "destructive" 
                ? "bg-destructive/90 hover:bg-destructive text-destructive-foreground" 
                : "bg-secondary-foreground/20 hover:bg-secondary-foreground/30 text-secondary-foreground"
            )}
            onClick={action.onClick}
          >
            {action.icon}
            <span className="ml-1.5">{action.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}
