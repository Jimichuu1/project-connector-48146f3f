import { useState } from "react";
import { TableHead } from "@/components/ui/table";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { cn } from "@/lib/utils";

export type SortDirection = "asc" | "desc" | null;
export type SortState = { key: string; direction: SortDirection };

interface SortableTableHeadProps {
  children: React.ReactNode;
  sortKey: string;
  currentSort: { key: string; direction: SortDirection };
  onSort: (key: string) => void;
  className?: string;
  icon?: React.ReactNode;
}

export function SortableTableHead({
  children,
  sortKey,
  currentSort,
  onSort,
  className,
  icon,
}: SortableTableHeadProps) {
  const isActive = currentSort.key === sortKey;
  const direction = isActive ? currentSort.direction : null;

  return (
    <TableHead
      className={cn("cursor-pointer select-none hover:bg-muted/50 transition-colors", className)}
      onClick={() => onSort(sortKey)}
    >
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-muted-foreground">{children}</span>
        <span className="ml-auto">
          {direction === "asc" ? (
            <ArrowUp className="h-3 w-3 text-primary" />
          ) : direction === "desc" ? (
            <ArrowDown className="h-3 w-3 text-primary" />
          ) : (
            <ArrowUpDown className="h-3 w-3 text-muted-foreground/50" />
          )}
        </span>
      </div>
    </TableHead>
  );
}

// Helper function to sort data
export function sortData<T>(
  data: T[],
  sortKey: string,
  direction: SortDirection
): T[] {
  if (!direction || !sortKey) return data;

  return [...data].sort((a, b) => {
    const aVal = (a as any)[sortKey];
    const bVal = (b as any)[sortKey];

    // Handle null/undefined
    if (aVal == null && bVal == null) return 0;
    if (aVal == null) return direction === "asc" ? 1 : -1;
    if (bVal == null) return direction === "asc" ? -1 : 1;

    // Handle dates
    if (aVal instanceof Date && bVal instanceof Date) {
      return direction === "asc"
        ? aVal.getTime() - bVal.getTime()
        : bVal.getTime() - aVal.getTime();
    }

    // Handle strings that look like dates
    if (typeof aVal === "string" && typeof bVal === "string") {
      const dateA = Date.parse(aVal);
      const dateB = Date.parse(bVal);
      if (!isNaN(dateA) && !isNaN(dateB)) {
        return direction === "asc" ? dateA - dateB : dateB - dateA;
      }
    }

    // Handle numbers
    if (typeof aVal === "number" && typeof bVal === "number") {
      return direction === "asc" ? aVal - bVal : bVal - aVal;
    }

    // Handle strings
    const strA = String(aVal).toLowerCase();
    const strB = String(bVal).toLowerCase();
    if (direction === "asc") {
      return strA.localeCompare(strB);
    }
    return strB.localeCompare(strA);
  });
}

// Hook for managing sort state
export function useTableSort(defaultKey = "", defaultDirection: SortDirection = null) {
  const [sort, setSort] = useState<{ key: string; direction: SortDirection }>({
    key: defaultKey,
    direction: defaultDirection,
  });

  const handleSort = (key: string) => {
    setSort((prev) => {
      if (prev.key !== key) {
        return { key, direction: "asc" };
      }
      if (prev.direction === "asc") {
        return { key, direction: "desc" };
      }
      if (prev.direction === "desc") {
        return { key: "", direction: null };
      }
      return { key, direction: "asc" };
    });
  };

  return { sort, handleSort };
}