import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary/10 text-primary ring-1 ring-primary/20 hover:bg-primary/20",
        secondary: "border-transparent bg-secondary/10 text-secondary-foreground ring-1 ring-secondary/20 hover:bg-secondary/20",
        destructive: "border-transparent bg-destructive/10 text-destructive ring-1 ring-destructive/20 hover:bg-destructive/20",
        outline: "border-border/50 bg-background/50 text-foreground hover:bg-accent/50",
        success: "border-transparent bg-success/10 text-success ring-1 ring-success/20 hover:bg-success/20",
        warning: "border-transparent bg-warning/10 text-warning ring-1 ring-warning/20 hover:bg-warning/20",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
