import * as React from "react";
import { cn } from "@/lib/utils";

const Table = React.forwardRef<HTMLTableElement, React.HTMLAttributes<HTMLTableElement>>(
  ({ className, ...props }, ref) => {
    const containerRef = React.useRef<HTMLDivElement>(null);
    const isDragging = React.useRef(false);
    const hasDragged = React.useRef(false);
    const startX = React.useRef(0);
    const scrollLeft = React.useRef(0);

    React.useEffect(() => {
      const element = containerRef.current;
      if (!element) return;

      const onMouseDown = (e: MouseEvent) => {
        // Don't initiate drag on interactive elements
        const target = e.target as HTMLElement;
        if (target.closest('button, a, input, select, [role="button"], [role="checkbox"]')) return;
        
        isDragging.current = true;
        hasDragged.current = false;
        startX.current = e.pageX - element.offsetLeft;
        scrollLeft.current = element.scrollLeft;
        element.style.cursor = "grabbing";
      };

      const onMouseMove = (e: MouseEvent) => {
        if (!isDragging.current) return;
        
        const x = e.pageX - element.offsetLeft;
        const distance = Math.abs(x - startX.current);
        
        // Only consider it a drag if moved more than 5px
        if (distance > 5) {
          hasDragged.current = true;
          e.preventDefault();
          const walk = (x - startX.current) * 1.5;
          element.scrollLeft = scrollLeft.current - walk;
        }
      };

      const onMouseUp = () => {
        isDragging.current = false;
        element.style.cursor = "grab";
        
        // Reset hasDragged after a short delay to allow click events to check it
        setTimeout(() => {
          hasDragged.current = false;
        }, 50);
      };

      const onMouseLeave = () => {
        isDragging.current = false;
        hasDragged.current = false;
        element.style.cursor = "grab";
      };

      const onClick = (e: MouseEvent) => {
        // Prevent click if we just dragged
        if (hasDragged.current) {
          e.preventDefault();
          e.stopPropagation();
        }
      };

      element.style.cursor = "grab";
      element.addEventListener("mousedown", onMouseDown);
      element.addEventListener("mousemove", onMouseMove);
      element.addEventListener("mouseup", onMouseUp);
      element.addEventListener("mouseleave", onMouseLeave);
      element.addEventListener("click", onClick, true);

      return () => {
        element.removeEventListener("mousedown", onMouseDown);
        element.removeEventListener("mousemove", onMouseMove);
        element.removeEventListener("mouseup", onMouseUp);
        element.removeEventListener("mouseleave", onMouseLeave);
        element.removeEventListener("click", onClick, true);
      };
    }, []);

    return (
      <div ref={containerRef} className="relative w-full overflow-auto select-none">
        <table ref={ref} className={cn("w-full caption-bottom text-sm", className)} {...props} />
      </div>
    );
  },
);
Table.displayName = "Table";

const TableHeader = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>(
  ({ className, ...props }, ref) => <thead ref={ref} className={cn("[&_tr]:border-b", className)} {...props} />,
);
TableHeader.displayName = "TableHeader";

const TableBody = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>(
  ({ className, ...props }, ref) => (
    <tbody ref={ref} className={cn("[&_tr:last-child]:border-0", className)} {...props} />
  ),
);
TableBody.displayName = "TableBody";

const TableFooter = React.forwardRef<HTMLTableSectionElement, React.HTMLAttributes<HTMLTableSectionElement>>(
  ({ className, ...props }, ref) => (
    <tfoot ref={ref} className={cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className)} {...props} />
  ),
);
TableFooter.displayName = "TableFooter";

const TableRow = React.forwardRef<HTMLTableRowElement, React.HTMLAttributes<HTMLTableRowElement>>(
  ({ className, ...props }, ref) => (
    <tr
      ref={ref}
      className={cn("border-b border-border/50 transition-all duration-200 data-[state=selected]:bg-muted hover:bg-muted/30", className)}
      {...props}
    />
  ),
);
TableRow.displayName = "TableRow";

const TableHead = React.forwardRef<HTMLTableCellElement, React.ThHTMLAttributes<HTMLTableCellElement>>(
  ({ className, ...props }, ref) => (
    <th
      ref={ref}
      className={cn(
        "h-12 px-4 text-left align-middle font-semibold text-sm text-foreground/80 [&:has([role=checkbox])]:pr-0 bg-muted/30",
        className,
      )}
      {...props}
    />
  ),
);
TableHead.displayName = "TableHead";

const TableCell = React.forwardRef<HTMLTableCellElement, React.TdHTMLAttributes<HTMLTableCellElement>>(
  ({ className, ...props }, ref) => (
    <td ref={ref} className={cn("p-4 align-middle [&:has([role=checkbox])]:pr-0", className)} {...props} />
  ),
);
TableCell.displayName = "TableCell";

const TableCaption = React.forwardRef<HTMLTableCaptionElement, React.HTMLAttributes<HTMLTableCaptionElement>>(
  ({ className, ...props }, ref) => (
    <caption ref={ref} className={cn("mt-4 text-sm text-muted-foreground", className)} {...props} />
  ),
);
TableCaption.displayName = "TableCaption";

export { Table, TableHeader, TableBody, TableFooter, TableHead, TableRow, TableCell, TableCaption };
