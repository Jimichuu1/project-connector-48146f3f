import { useState, useEffect } from 'react';
import { getLocalTimeFromPhone } from '@/lib/phoneTimezone';

interface LocalTimeDisplayProps {
  phone: string | null | undefined;
  className?: string;
}

export function LocalTimeDisplay({ phone, className }: LocalTimeDisplayProps) {
  const [time, setTime] = useState<string | null>(() => getLocalTimeFromPhone(phone));

  useEffect(() => {
    // Initial time
    setTime(getLocalTimeFromPhone(phone));

    // Update every minute
    const interval = setInterval(() => {
      setTime(getLocalTimeFromPhone(phone));
    }, 60000);

    return () => clearInterval(interval);
  }, [phone]);

  if (!time) {
    return <span className={`text-muted-foreground ${className || ''}`}>—</span>;
  }

  return (
    <span className={`font-mono text-xs tabular-nums ${className || ''}`}>
      {time}
    </span>
  );
}
