import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Building2, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface ClientKYCBanksProps {
  entityId: string;
  entityType: 'lead' | 'client';
  onAddBank?: () => void;
}

export const ClientKYCBanks = ({ entityId, entityType, onAddBank }: ClientKYCBanksProps) => {
  const queryClient = useQueryClient();
  
  const { data: banks, isLoading } = useQuery({
    queryKey: ['kyc-records', entityId, entityType, 'banks'],
    queryFn: async () => {
      const query = supabase
        .from('kyc_records')
        .select('id, bank_name, created_at')
        .not('bank_name', 'is', null)
        .order('created_at', { ascending: false });
      
      if (entityType === 'lead') {
        query.eq('lead_id', entityId);
      } else {
        query.eq('client_id', entityId);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this bank record?')) return;
    
    const { error } = await supabase
      .from('kyc_records')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast.error('Failed to delete bank record');
      return;
    }
    
    toast.success('Bank record deleted');
    queryClient.invalidateQueries({ queryKey: ['kyc-records'] });
  };

  if (isLoading) {
    return (
      <div>
        <div className="pb-3">
          <Skeleton className="h-5 w-24" />
        </div>
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between pb-3">
        <h3 className="text-sm font-medium flex items-center gap-2">
          <Building2 className="h-4 w-4 text-muted-foreground" />
          Banks ({banks?.length || 0})
        </h3>
        {onAddBank && (
          <Button variant="ghost" size="sm" onClick={onAddBank} className="h-7 px-2">
            <Plus className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
      <div className="space-y-2">
        {!banks || banks.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No banks added</p>
        ) : (
          banks.map((bank) => (
            <div
              key={bank.id}
              className="flex items-center justify-between p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm">{bank.bank_name}</p>
                <p className="text-xs text-muted-foreground">
                  {format(new Date(bank.created_at), 'MMM d, yyyy')}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0"
                onClick={() => handleDelete(bank.id)}
              >
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
