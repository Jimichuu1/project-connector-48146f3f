import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useKYC } from "@/hooks/useKYC";

interface CreateNoteDialogProps {
  entityId: string;
  entityType: 'lead' | 'client';
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateNoteDialog = ({ entityId, entityType, open, onOpenChange }: CreateNoteDialogProps) => {
  const [notes, setNotes] = useState("");
  const { createKYCRecord } = useKYC(entityId, entityType);

  const handleCreate = () => {
    createKYCRecord.mutate(
      {
        entityId,
        entityType,
        bankName: undefined,
        notes,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          setNotes("");
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Note</DialogTitle>
          <DialogDescription>
            Add a new note record
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="notes">Note *</Label>
            <Textarea
              id="notes"
              placeholder="Add your note..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </div>
        </div>
        <DialogFooter>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleCreate}
              disabled={!notes || createKYCRecord.isPending}
            >
              {createKYCRecord.isPending ? "Adding..." : "Add Note"}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
