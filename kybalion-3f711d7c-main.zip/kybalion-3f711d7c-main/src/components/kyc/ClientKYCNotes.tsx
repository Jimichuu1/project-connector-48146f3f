import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, StickyNote, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface ClientKYCNotesProps {
  entityId: string;
  entityType: 'lead' | 'client';
  onAddNote?: () => void;
}

export const ClientKYCNotes = ({ entityId, entityType, onAddNote }: ClientKYCNotesProps) => {
  const queryClient = useQueryClient();
  
  const { data: notes, isLoading } = useQuery({
    queryKey: ['kyc-records', entityId, entityType, 'notes'],
    queryFn: async () => {
      const query = supabase
        .from('kyc_records')
        .select('id, notes, created_at')
        .not('notes', 'is', null)
        .order('created_at', { ascending: false });
      
      if (entityType === 'lead') {
        query.eq('lead_id', entityId);
      } else {
        query.eq('client_id', entityId);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this note?')) return;
    
    const { error } = await supabase
      .from('kyc_records')
      .delete()
      .eq('id', id);
    
    if (error) {
      toast.error('Failed to delete note');
      return;
    }
    
    toast.success('Note deleted');
    queryClient.invalidateQueries({ queryKey: ['kyc-records'] });
  };

  if (isLoading) {
    return (
      <div>
        <div className="pb-3">
          <Skeleton className="h-5 w-24" />
        </div>
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between pb-3">
        <h3 className="text-sm font-medium flex items-center gap-2">
          <StickyNote className="h-4 w-4 text-muted-foreground" />
          Notes ({notes?.length || 0})
        </h3>
        {onAddNote && (
          <Button variant="ghost" size="sm" onClick={onAddNote} className="h-7 px-2">
            <Plus className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
      <div className="space-y-2 max-h-[400px] overflow-y-auto">
        {!notes || notes.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No notes added</p>
        ) : (
          notes.map((note) => (
            <div
              key={note.id}
              className="p-3 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-muted-foreground mb-1">
                    {format(new Date(note.created_at), 'MMM d, yyyy h:mm a')}
                  </p>
                  <p className="text-sm whitespace-pre-wrap">{note.notes}</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 w-7 p-0 flex-shrink-0"
                  onClick={() => handleDelete(note.id)}
                >
                  <Trash2 className="h-3.5 w-3.5 text-destructive" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
