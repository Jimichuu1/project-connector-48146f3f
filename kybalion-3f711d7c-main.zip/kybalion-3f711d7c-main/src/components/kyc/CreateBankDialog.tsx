import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useKYC } from "@/hooks/useKYC";

interface CreateBankDialogProps {
  entityId: string;
  entityType: 'lead' | 'client';
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateBankDialog = ({ entityId, entityType, open, onOpenChange }: CreateBankDialogProps) => {
  const [bankName, setBankName] = useState("");
  const { createKYCRecord } = useKYC(entityId, entityType);

  const handleCreate = () => {
    createKYCRecord.mutate(
      {
        entityId,
        entityType,
        bankName,
        notes: undefined,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          setBankName("");
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Bank</DialogTitle>
          <DialogDescription>
            Add a new bank record
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="bankName">Bank Name *</Label>
            <Input
              id="bankName"
              placeholder="e.g., Chase Bank"
              value={bankName}
              onChange={(e) => setBankName(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleCreate}
              disabled={!bankName || createKYCRecord.isPending}
            >
              {createKYCRecord.isPending ? "Adding..." : "Add Bank"}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
