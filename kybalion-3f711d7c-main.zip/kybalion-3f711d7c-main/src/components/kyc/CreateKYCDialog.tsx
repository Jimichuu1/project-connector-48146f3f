import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ButtonGroup } from "@/components/ui/button-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useKYC } from "@/hooks/useKYC";

interface CreateKYCDialogProps {
  entityId: string;
  entityType: 'lead' | 'client';
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const CreateKYCDialog = ({ entityId, entityType, open, onOpenChange }: CreateKYCDialogProps) => {
  const [bankName, setBankName] = useState("");
  const [notes, setNotes] = useState("");
  const { createKYCRecord } = useKYC(entityId, entityType);

  const handleCreate = () => {
    createKYCRecord.mutate(
      {
        entityId,
        entityType,
        bankName,
        notes: notes || undefined,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          setBankName("");
          setNotes("");
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add KYC Record</DialogTitle>
          <DialogDescription>
            Create a new KYC verification record
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="bankName">Bank Name *</Label>
            <Input
              id="bankName"
              placeholder="e.g., Chase Bank"
              value={bankName}
              onChange={(e) => setBankName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="Add any additional notes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </div>
        </div>
        <DialogFooter>
          <ButtonGroup>
            <Button size="sm" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleCreate}
              disabled={!bankName || createKYCRecord.isPending}
            >
              {createKYCRecord.isPending ? "Creating..." : "Create KYC Record"}
            </Button>
          </ButtonGroup>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
