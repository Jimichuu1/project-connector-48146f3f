import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useKYC } from "@/hooks/useKYC";
import { format } from "date-fns";
import { Trash2, FileText, X } from "lucide-react";

interface KYCRecordListProps {
  entityId: string;
  entityType: 'lead' | 'client';
}

export const KYCRecordList = ({ entityId, entityType }: KYCRecordListProps) => {
  const { kycRecords, isLoading, deleteKYCRecord } = useKYC(entityId, entityType);

  if (isLoading) {
    return <div>Loading KYC records...</div>;
  }

  if (!kycRecords || kycRecords.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground">
          No KYC records yet
        </CardContent>
      </Card>
    );
  }

  const bankRecords = kycRecords.filter(r => r.bank_name);
  const noteRecords = kycRecords.filter(r => !r.bank_name && r.notes);

  return (
    <div className="space-y-6">
      {/* Banks Section */}
      {bankRecords.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Banks</h3>
          <div className="flex flex-wrap gap-2">
            {bankRecords.map((record) => (
              <Badge 
                key={record.id} 
                variant="secondary"
                className="pl-3 pr-2 py-1.5 h-auto gap-2 text-sm"
              >
                <span>{record.bank_name}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-4 w-4 p-0 hover:bg-transparent"
                  onClick={() => {
                    if (confirm('Delete this bank record?')) {
                      deleteKYCRecord.mutate(record.id);
                    }
                  }}
                >
                  <X className="h-3 w-3 text-muted-foreground hover:text-destructive transition-colors" />
                </Button>
              </Badge>
            ))}
          </div>
        </div>
      )}

      {/* Notes Section */}
      {noteRecords.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Notes</h3>
          <div className="space-y-4">
            {noteRecords.map((record) => (
              <Card key={record.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(record.created_at), 'MMM d, yyyy')}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (confirm('Delete this note?')) {
                          deleteKYCRecord.mutate(record.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">{record.notes}</p>
                  {record.verified_date && record.verified_profile && (
                    <div className="text-sm text-muted-foreground">
                      Verified by {record.verified_profile.full_name || record.verified_profile.email} on{' '}
                      {format(new Date(record.verified_date), 'MMM d, yyyy')}
                    </div>
                  )}
                  {record.documents && record.documents.length > 0 && (
                    <div>
                      <p className="text-sm font-medium mb-2 flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Documents ({record.documents.length})
                      </p>
                      <div className="space-y-1">
                        {record.documents.map((doc) => (
                          <div key={doc.id} className="text-xs text-muted-foreground pl-6">
                            • {doc.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
