import { useState, useEffect } from "react";
import { format } from "date-fns";
import { toZonedTime } from "date-fns-tz";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
const WORLD_CLOCKS = [{
  label: "UK",
  city: "London",
  timezone: "Europe/London",
  flag: "🇬🇧"
}, {
  label: "AU",
  city: "Sydney",
  timezone: "Australia/Sydney",
  flag: "🇦🇺"
}, {
  label: "CA",
  city: "Toronto",
  timezone: "America/Toronto",
  flag: "🇨🇦"
}];
export function WorldClock() {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  return <TooltipProvider>
      <div className="flex items-center gap-1 py-[1px] px-[3px] rounded-lg bg-muted/50 border border-border/50">
        
        {WORLD_CLOCKS.map((clock, index) => {
        const zonedTime = toZonedTime(currentTime, clock.timezone);
        const hours = parseInt(format(zonedTime, "H"));
        const isNight = hours < 6 || hours >= 20;
        return <Tooltip key={clock.timezone}>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-1 cursor-default">
                  {index > 0 && <div className="w-px h-4 bg-border/50 mx-1" />}
                  <div className="flex flex-col items-center min-w-[44px]">
                    <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">
                      {clock.label}
                    </span>
                    <span className={`font-mono text-xs font-bold tabular-nums ${isNight ? "text-indigo-400" : "text-foreground"}`}>
                      {format(zonedTime, "HH:mm")}
                    </span>
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">
                <p className="font-medium">{clock.city}</p>
                <p className="text-muted-foreground">
                  {format(zonedTime, "EEEE, MMM d")}
                </p>
                <p className="font-mono">{format(zonedTime, "HH:mm:ss")}</p>
              </TooltipContent>
            </Tooltip>;
      })}
      </div>
    </TooltipProvider>;
}