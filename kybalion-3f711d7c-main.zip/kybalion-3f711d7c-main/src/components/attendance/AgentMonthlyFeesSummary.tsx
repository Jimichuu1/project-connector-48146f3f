import { useMemo } from "react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, User, Gift } from "lucide-react";
import type { AttendanceWithProfile } from "@/types/attendance";

interface DateRange {
  from: Date;
  to: Date;
}

interface AgentMonthlyFeesSummaryProps {
  attendance: AttendanceWithProfile[];
  dateRange?: DateRange;
  monthlyHonorableAbsences?: number;
}

interface AgentFees {
  userId: string;
  fullName: string;
  email: string;
  totalFees: number;
  lateFees: number;
  breakFees: number;
  dayOffFees: number;
  daysWorked: number;
  totalMinutes: number;
  dayOffCount: number;
  honorableDayOffCount: number;
}

export function AgentMonthlyFeesSummary({ attendance, dateRange, monthlyHonorableAbsences = 0 }: AgentMonthlyFeesSummaryProps) {
  const getTitle = () => {
    if (!dateRange) return "Fees Summary";
    
    const fromMonth = format(dateRange.from, "MMMM yyyy");
    const toMonth = format(dateRange.to, "MMMM yyyy");
    
    if (fromMonth === toMonth) {
      return `${fromMonth} Fees`;
    }
    
    return `Fees (${format(dateRange.from, "MMM d")} - ${format(dateRange.to, "MMM d, yyyy")})`;
  };

  const agentFees = useMemo(() => {
    const feesMap = new Map<string, AgentFees>();

    attendance.forEach((record) => {
      const userId = record.user_id;
      
      let recordMinutes = 0;
      if (record.clock_in && record.clock_out) {
        const diff = new Date(record.clock_out).getTime() - new Date(record.clock_in).getTime();
        recordMinutes = Math.max(0, diff / (1000 * 60));
      }

      const isDayOff = record.notes === "Day off" || record.notes === "Day off (Honorable)";
      const isHonorable = record.notes === "Day off (Honorable)";

      const existing = feesMap.get(userId);

      if (existing) {
        existing.totalFees += record.total_fees || 0;
        existing.lateFees += record.late_start_fee || 0;
        existing.breakFees += record.break_time_fee || 0;
        if (isDayOff) {
          existing.dayOffFees += record.total_fees || 0;
          existing.dayOffCount += 1;
        }
        if (isHonorable) {
          existing.honorableDayOffCount += 1;
        }
        existing.daysWorked += 1;
        existing.totalMinutes += recordMinutes;
      } else {
        feesMap.set(userId, {
          userId,
          fullName: record.profiles.full_name || "Unknown",
          email: record.profiles.email,
          totalFees: record.total_fees || 0,
          lateFees: record.late_start_fee || 0,
          breakFees: record.break_time_fee || 0,
          dayOffFees: isDayOff ? (record.total_fees || 0) : 0,
          daysWorked: 1,
          totalMinutes: recordMinutes,
          dayOffCount: isDayOff ? 1 : 0,
          honorableDayOffCount: isHonorable ? 1 : 0,
        });
      }
    });

    return Array.from(feesMap.values())
      .sort((a, b) => b.totalFees - a.totalFees);
  }, [attendance]);

  const totalAllFees = useMemo(() => 
    agentFees.reduce((sum, agent) => sum + agent.totalFees, 0), 
    [agentFees]
  );

  if (agentFees.length === 0) return null;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
        <CardTitle className="text-base flex items-center gap-2">
            <DollarSign className="h-4 w-4" />
            {getTitle()}
          </CardTitle>
          <Badge variant={totalAllFees > 0 ? "destructive" : "secondary"} className="text-sm">
            Total: ${totalAllFees.toFixed(2)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {agentFees.map((agent) => {
            const honorableRemaining = Math.max(0, monthlyHonorableAbsences - agent.honorableDayOffCount);
            
            return (
              <div
                key={agent.userId}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border"
              >
              <div className="flex items-center gap-2 min-w-0">
                  <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{agent.fullName}</p>
                    <p className="text-xs text-muted-foreground">
                      {agent.daysWorked} days · {Math.floor(agent.totalMinutes / 60)}h {Math.round(agent.totalMinutes % 60)}m
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                  {monthlyHonorableAbsences > 0 && (
                    <span className={`text-xs font-semibold ${honorableRemaining >= 2 ? "text-emerald-600 dark:text-emerald-400" : honorableRemaining === 1 ? "text-orange-500 dark:text-orange-400" : "text-muted-foreground"}`} title={`${honorableRemaining} honorable day-offs remaining`}>
                      ({honorableRemaining})
                    </span>
                  )}
                  <span className={`text-sm font-semibold ${agent.totalFees > 0 ? 'text-destructive' : 'text-muted-foreground'}`}>
                    ${agent.totalFees.toFixed(2)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
