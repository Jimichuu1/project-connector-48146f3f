import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Building2, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface TenantDeposits {
  tenantId: string;
  tenantName: string;
  totalDeposits: number;
  depositCount: number;
}

export function TopTenantsBanner() {
  const { data: topTenants, isLoading } = useQuery({
    queryKey: ['top-tenants-deposits'],
    queryFn: async () => {
      // Get all approved deposits with super agent and tenant info for the current month
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: deposits, error } = await supabase
        .from('deposits')
        .select(`
          amount,
          status,
          admin_id,
          super_agent_id
        `)
        .eq('status', 'approved')
        .gte('created_at', startOfMonth.toISOString())
        .not('super_agent_id', 'is', null)
        .not('admin_id', 'is', null);

      if (error) throw error;

      // Get unique tenant IDs
      const tenantIds = [...new Set(deposits?.map(d => d.admin_id).filter(Boolean))] as string[];

      // Fetch tenant names
      const { data: tenantProfiles } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .in('id', tenantIds);

      const tenantNameMap = new Map<string, string>();
      tenantProfiles?.forEach(t => {
        tenantNameMap.set(t.id, t.full_name || t.email);
      });

      // Aggregate deposits by tenant
      const tenantTotals = deposits?.reduce((acc: Record<string, TenantDeposits>, deposit) => {
        const tenantId = deposit.admin_id;
        if (!tenantId) return acc;

        if (!acc[tenantId]) {
          acc[tenantId] = {
            tenantId,
            tenantName: tenantNameMap.get(tenantId) || 'Unknown Tenant',
            totalDeposits: 0,
            depositCount: 0,
          };
        }

        acc[tenantId].totalDeposits += Number(deposit.amount);
        acc[tenantId].depositCount += 1;

        return acc;
      }, {}) || {};

      // Sort by total deposits and return top 5
      return Object.values(tenantTotals)
        .sort((a, b) => b.totalDeposits - a.totalDeposits)
        .slice(0, 5);
    },
    refetchInterval: 30000,
  });

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20">
        <CardContent className="py-4">
          <div className="flex items-center gap-4">
            <Skeleton className="h-8 w-8 rounded-lg" />
            <Skeleton className="h-6 w-48" />
            <div className="flex-1 flex gap-4 overflow-hidden">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-12 w-48 rounded-lg flex-shrink-0" />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!topTenants || topTenants.length === 0) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20">
      <CardContent className="py-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="p-2 bg-primary/20 rounded-lg">
              <Trophy className="h-5 w-5 text-primary" />
            </div>
            <span className="font-semibold text-sm whitespace-nowrap">Top Tenants This Month</span>
          </div>
          
          <div className="flex-1 flex items-center gap-3 overflow-x-auto pb-1">
            {topTenants.map((tenant, index) => (
              <div
                key={tenant.tenantId}
                className="flex items-center gap-3 px-4 py-2 bg-card/80 rounded-lg border border-border/50 flex-shrink-0 hover:border-primary/30 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Badge 
                    variant={index === 0 ? "default" : "secondary"} 
                    className={`h-6 w-6 rounded-full p-0 flex items-center justify-center text-xs ${
                      index === 0 ? 'bg-amber-500 text-amber-950' : ''
                    }`}
                  >
                    {index + 1}
                  </Badge>
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex flex-col">
                  <span className="font-medium text-sm truncate max-w-[120px]">{tenant.tenantName}</span>
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className="h-3 w-3 text-primary" />
                    <span className="text-sm font-bold text-primary">
                      ${tenant.totalDeposits.toLocaleString()}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      ({tenant.depositCount})
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}