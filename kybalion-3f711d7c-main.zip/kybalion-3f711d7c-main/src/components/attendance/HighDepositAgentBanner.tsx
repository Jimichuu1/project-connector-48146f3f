import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, TrendingUp, Sparkles, Users } from "lucide-react";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";

interface TopPerformer {
  id: string;
  full_name: string;
  value: number;
  label: string;
  metric: string;
}

interface HighDepositAgentBannerProps {
  variant?: "header" | "sidebar";
}

export function HighDepositAgentBanner({ variant = "header" }: HighDepositAgentBannerProps) {
  const [topAgent, setTopAgent] = useState<TopPerformer | null>(null);
  const [topSuperAgent, setTopSuperAgent] = useState<TopPerformer | null>(null);
  const { effectiveTenantId } = useTenant();
  const { role, isTeamLeader } = useUserData();

  useEffect(() => {
    const fetchTopPerformers = async () => {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      if (role === 'AGENT') {
        // For agents: show top agent with most transfers
        await fetchTopAgentByTransfers(startOfMonth);
      } else if (role === 'SUPER_AGENT') {
        // For super agents: show top super agent with most deposit earnings
        await fetchTopSuperAgentByDeposits(startOfMonth);
      } else {
        // For admins/managers/tenant owners: fetch both
        await Promise.all([
          fetchTopAgentByTransfers(startOfMonth),
          fetchTopSuperAgentByDeposits(startOfMonth)
        ]);
      }
    };

    const fetchTopAgentByTransfers = async (startOfMonth: Date) => {
      const { data, error } = await supabase.rpc('get_top_agent_by_transfers', {
        p_admin_id: effectiveTenantId,
        p_start_date: startOfMonth.toISOString()
      });

      if (error || !data || data.length === 0) {
        setTopAgent(null);
        return;
      }

      const top = data[0];
      if (top.transfer_count > 0) {
        setTopAgent({
          id: top.agent_id,
          full_name: top.agent_name || "Unknown",
          value: Number(top.transfer_count),
          label: "Top Agent",
          metric: "transfers"
        });
      } else {
        setTopAgent(null);
      }
    };

    const fetchTopSuperAgentByDeposits = async (startOfMonth: Date) => {
      // Use RPC function (SECURITY DEFINER) to bypass RLS and get the actual top super agent
      const { data, error } = await supabase.rpc('get_top_super_agent_by_deposits', {
        p_admin_id: effectiveTenantId || null,
        p_start_date: startOfMonth.toISOString()
      });

      if (error || !data || data.length === 0) {
        setTopSuperAgent(null);
        return;
      }

      const top = data[0];
      if (Number(top.total_earnings) > 0) {
        setTopSuperAgent({
          id: top.super_agent_id,
          full_name: top.super_agent_name || "Unknown",
          value: Number(top.total_earnings),
          label: "Top Super Agent",
          metric: "deposits"
        });
      } else {
        setTopSuperAgent(null);
      }
    };

    if (role) {
      fetchTopPerformers();
    }

    // Subscribe to deposit changes
    const channel = supabase
      .channel("deposit_changes_banner")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "deposits",
        },
        () => {
          if (role) fetchTopPerformers();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [effectiveTenantId, role]);

  // Determine which performers to show based on role
  const performers: TopPerformer[] = [];
  if (role === 'AGENT') {
    if (topAgent) performers.push(topAgent);
  } else if (role === 'SUPER_AGENT') {
    if (topSuperAgent) performers.push(topSuperAgent);
  } else if (isTeamLeader) {
    if (topAgent) performers.push(topAgent);
  } else {
    // Admins/managers see both
    if (topAgent) performers.push(topAgent);
    if (topSuperAgent) performers.push(topSuperAgent);
  }

  if (performers.length === 0) return null;

  const formatValue = (performer: TopPerformer) => {
    if (performer.metric === "transfers") {
      return `${performer.value}`;
    }
    return `$${performer.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  };

  const getIcon = (performer: TopPerformer) => {
    if (performer.metric === "transfers") {
      return <Users className="w-4 h-4 text-white" />;
    }
    return <Trophy className="w-4 h-4 text-white" />;
  };

  const renderBanner = (performer: TopPerformer, index: number) => {
    // Sidebar variant - vertical compact design
    if (variant === "sidebar") {
      return (
        <div key={performer.id + index} className="group relative overflow-hidden rounded-xl bg-gradient-to-br from-amber-500/20 via-yellow-500/10 to-orange-500/20 border border-amber-500/30 p-3 animate-fade-in transition-all duration-300 hover:border-amber-500/50 hover:shadow-xl hover:shadow-amber-500/20">
          {/* Animated background shimmer */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
          
          {/* Sparkle decorations */}
          <Sparkles className="absolute top-2 right-2 w-3 h-3 text-amber-400/60 animate-pulse" />
          
          {/* Header with trophy */}
          <div className="flex items-center gap-2 mb-2">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 shadow-lg shadow-amber-500/40">
              {getIcon(performer)}
              <div className="absolute inset-0 rounded-lg bg-white/30 animate-pulse" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-amber-400 font-bold">
                {performer.label}
              </span>
              <span className="text-[9px] text-muted-foreground">This Month</span>
            </div>
          </div>

          {/* Agent name */}
          <div className="relative z-10 mb-1.5">
            <span className="text-sm font-bold text-foreground truncate block">
              {performer.full_name}
            </span>
          </div>

          {/* Amount with trend */}
          <div className="flex items-center gap-1.5 relative z-10">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-lg font-extrabold bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-400 bg-clip-text text-transparent">
              {formatValue(performer)}
            </span>
          </div>
        </div>
      );
    }

    // Header variant - horizontal compact design
    return (
      <div key={performer.id + index} className="group relative flex items-center gap-3 py-[1px] pl-[3px] pr-4 bg-gradient-to-r from-amber-500/10 via-yellow-500/15 to-orange-500/10 rounded-lg border border-amber-500/30 backdrop-blur-sm animate-fade-in transition-all duration-300 hover:border-amber-500/50 hover:shadow-lg hover:shadow-amber-500/10">
        {/* Animated glow effect */}
        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-amber-500/0 via-amber-500/5 to-amber-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Trophy icon with pulse */}
        <div className="relative flex items-center justify-center w-7 h-7 rounded-md bg-gradient-to-br from-amber-500 to-orange-500 shadow-md shadow-amber-500/30">
          {getIcon(performer)}
          <div className="absolute inset-0 rounded-lg bg-white/20 animate-pulse" />
        </div>

        {/* Content */}
        <div className="flex items-center gap-2.5 relative z-10">
          <div className="flex flex-col leading-tight">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">
              {performer.label}
            </span>
            <span className="text-sm font-semibold text-foreground truncate max-w-[120px]">
              {performer.full_name}
            </span>
          </div>

          {/* Separator */}
          <div className="w-px h-6 bg-border/50" />

          {/* Amount with trend indicator */}
          <div className="flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-sm font-bold bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
              {formatValue(performer)}
            </span>
          </div>
        </div>
      </div>
    );
  };

  if (variant === "sidebar") {
    return (
      <div className="flex flex-col gap-2">
        {performers.map((p, i) => renderBanner(p, i))}
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      {performers.map((p, i) => renderBanner(p, i))}
    </div>
  );
}
