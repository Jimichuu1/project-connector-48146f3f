import { useState, useEffect } from "react";
import { Clock } from "lucide-react";
import type { Json } from "@/integrations/supabase/types";
import { useServerNow } from "@/hooks/useServerNow";

interface WorkingPeriod {
  started_at: string;
  ended_at: string;
}

interface BreakTimeCounterProps {
  clockIn: string;
  clockOut: string | null;
  workingStartedAt: string | null;
  workingPeriods: Json | null;
  breakMinutes: number;
  isDayOff: boolean;
  maxBreakMinutes?: number;
}

// Maximum reasonable break time to display (24 hours) - sanity check
const MAX_REASONABLE_BREAK_MINUTES = 24 * 60;

export function BreakTimeCounter({
  clockIn,
  clockOut,
  workingStartedAt,
  workingPeriods,
  breakMinutes,
  isDayOff,
  maxBreakMinutes = 60
}: BreakTimeCounterProps) {
  const [currentBreakTime, setCurrentBreakTime] = useState<number>(0);
  const { serverNow } = useServerNow();

  useEffect(() => {
    // If day off or clocked out, just show stored break_minutes
    if (isDayOff || clockOut) {
      setCurrentBreakTime(breakMinutes || 0);
      return;
    }

    // Parse working periods
    const periods: WorkingPeriod[] = Array.isArray(workingPeriods) 
      ? (workingPeriods as unknown as WorkingPeriod[]) 
      : [];

    // Determine if user is actually on break:
    // - Not clocked out
    // - working_started_at is null (stopped working)
    // - MUST have at least one working period (otherwise they just clocked in)
    const hasWorkedBefore = periods.length > 0;
    const isOnBreak = !clockOut && !workingStartedAt && hasWorkedBefore;

    if (!isOnBreak) {
      // Not on break, show accumulated break_minutes
      setCurrentBreakTime(breakMinutes || 0);
      return;
    }

    // Calculate current break time
    const calculateBreakTime = () => {
      // Get the last working period's end time (when break started)
      const lastPeriod = periods[periods.length - 1];
      const breakStartTime = new Date(lastPeriod.ended_at);

      // Use server time if available, otherwise fall back to local time
      const now = serverNow || new Date();
      const currentBreakMins = Math.max(0, Math.floor((now.getTime() - breakStartTime.getTime()) / (1000 * 60)));
      
      // Add any previously accumulated break time
      const totalBreakMins = (breakMinutes || 0) + currentBreakMins;
      
      // Apply sanity check - cap at maximum reasonable value
      const cappedBreakMins = Math.min(totalBreakMins, MAX_REASONABLE_BREAK_MINUTES);
      setCurrentBreakTime(cappedBreakMins);
    };

    // Calculate immediately
    calculateBreakTime();

    // Update every second for live counter
    const interval = setInterval(calculateBreakTime, 1000);

    return () => clearInterval(interval);
  }, [clockIn, clockOut, workingStartedAt, workingPeriods, breakMinutes, isDayOff, serverNow]);

  if (isDayOff) {
    return <span className="text-muted-foreground">-</span>;
  }

  // Not clocked in yet
  if (!clockIn) {
    return <span className="text-muted-foreground">-</span>;
  }

  // Parse working periods to check if user has worked before
  const periods: WorkingPeriod[] = Array.isArray(workingPeriods) 
    ? (workingPeriods as unknown as WorkingPeriod[]) 
    : [];
  const hasWorkedBefore = periods.length > 0;
  const isOnBreak = !clockOut && !workingStartedAt && hasWorkedBefore;

  const hours = Math.floor(currentBreakTime / 60);
  const mins = currentBreakTime % 60;
  const display = hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;

  const isOverLimit = currentBreakTime > maxBreakMinutes;

  if (isOnBreak) {
    return (
      <span className={`flex items-center gap-1 font-medium ${isOverLimit ? 'text-destructive' : 'text-amber-600'}`}>
        <Clock className="h-3 w-3 animate-pulse" />
        {display}
      </span>
    );
  }

  if (isOverLimit) {
    return <span className="text-destructive font-medium">{display}</span>;
  }

  return <span>{display}</span>;
}