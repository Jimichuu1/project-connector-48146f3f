import { useState } from "react";
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { getServerToday } from "@/hooks/useServerNow";

export interface DateRange {
  from: Date;
  to: Date;
}

interface AttendanceDateFilterProps {
  value: DateRange;
  onChange: (range: DateRange) => void;
  /** Server time to use as base for "Today" calculations (optional, uses device time if not provided) */
  serverNow?: Date | null;
  /** User's timezone preference for consistent day boundaries */
  timezone?: string;
}

export function AttendanceDateFilter({ value, onChange, serverNow, timezone }: AttendanceDateFilterProps) {
  const [open, setOpen] = useState(false);
  
  // Use server time + timezone if available for accurate "today" calculation
  const getBaseToday = () => {
    return getServerToday(serverNow, timezone);
  };

  const presets = [
    {
      label: "Today",
      getValue: () => {
        const today = getBaseToday();
        return { from: today, to: today };
      },
    },
    {
      label: "Yesterday",
      getValue: () => {
        const today = getBaseToday();
        const yesterday = subDays(today, 1);
        return { from: yesterday, to: yesterday };
      },
    },
    {
      label: "This Week",
      getValue: () => {
        const today = getBaseToday();
        return {
          from: startOfWeek(today, { weekStartsOn: 1 }),
          to: endOfWeek(today, { weekStartsOn: 1 }),
        };
      },
    },
    {
      label: "This Month",
      getValue: () => {
        const today = getBaseToday();
        return {
          from: startOfMonth(today),
          to: endOfMonth(today),
        };
      },
    },
  ];

  const formatDateRange = () => {
    if (value.from.toDateString() === value.to.toDateString()) {
      return format(value.from, "MMM dd, yyyy");
    }
    return `${format(value.from, "MMM dd")} - ${format(value.to, "MMM dd, yyyy")}`;
  };

  return (
    <div className="flex gap-2">
      <div className="flex gap-1">
        {presets.map((preset) => (
          <Button
            key={preset.label}
            variant="outline"
            size="sm"
            onClick={() => onChange(preset.getValue())}
          >
            {preset.label}
          </Button>
        ))}
      </div>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className={cn("justify-start text-left font-normal min-w-[200px]")}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {formatDateRange()}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0 border-0 shadow-none" align="start">
          <Calendar
            mode="range"
            selected={{ from: value.from, to: value.to }}
            onSelect={(range) => {
              if (range?.from) {
                onChange({ from: range.from, to: range.to || range.from });
                if (range.to) {
                  setOpen(false);
                }
              }
            }}
            initialFocus
            className={cn("p-3 pointer-events-auto border-0")}
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}
