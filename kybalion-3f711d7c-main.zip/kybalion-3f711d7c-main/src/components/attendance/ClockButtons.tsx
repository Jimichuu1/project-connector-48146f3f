import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { toast } from "sonner";
import { LogIn, LogOut } from "lucide-react";
import { localTimeToUTC } from "@/lib/timezoneUtils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

// Helper to get server time as YYYY-MM-DD
async function fetchServerDateKey(): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_server_time') as { data: string | null; error: Error | null };
    if (error || !data) return new Date().toISOString().split("T")[0];
    return new Date(data).toISOString().split("T")[0];
  } catch {
    return new Date().toISOString().split("T")[0];
  }
}

// Helper to get server timestamp
async function fetchServerTimestamp(): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_server_time') as { data: string | null; error: Error | null };
    if (error || !data) return new Date().toISOString();
    return data;
  } catch {
    return new Date().toISOString();
  }
}

export function ClockButtons() {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const [hasClockedIn, setHasClockedIn] = useState(false);
  const [loading, setLoading] = useState(false);
  const [canUseButtons, setCanUseButtons] = useState(false);
  const [showClockOutDialog, setShowClockOutDialog] = useState(false);

  const checkUserRole = useCallback(async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["AGENT", "SUPER_AGENT", "TEAM_LEADER"])
      .maybeSingle();

    setCanUseButtons(!!data);
  }, [user]);

  const checkTodayStatus = useCallback(async () => {
    if (!user) return;

    const today = await fetchServerDateKey();
    const { data } = await supabase
      .from("attendance")
      .select("id, clock_out")
      .eq("user_id", user.id)
      .eq("date", today)
      .order("clock_in", { ascending: false })
      .limit(1);

    const activeSession = data?.[0] && !data[0].clock_out;
    setHasClockedIn(!!activeSession);
  }, [user]);

  useEffect(() => {
    checkUserRole();
    checkTodayStatus();
  }, [checkUserRole, checkTodayStatus]);

  // Realtime subscription to keep state in sync across tabs
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel("clock_buttons_sync")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "attendance",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          checkTodayStatus();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, checkTodayStatus]);

  const handleClockIn = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const today = await fetchServerDateKey();
      const clockInTimestamp = await fetchServerTimestamp();
      const clockInTime = new Date(clockInTimestamp);

      // Get user's admin_id from their profile
      const { data: profile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .maybeSingle();

      const userAdminId = profile?.admin_id || effectiveTenantId;

      // Fresh query to prevent stale state across tabs
      const { data: existingRecords } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .order("clock_in", { ascending: false })
        .limit(1);

      const existingRecord = existingRecords?.[0];

      if (existingRecord && !existingRecord.clock_out) {
        // Already clocked in (possibly from another tab)
        toast.error("You are already clocked in");
        setHasClockedIn(true);
        setLoading(false);
        return;
      }

      if (existingRecord && existingRecord.clock_out) {
        // Resume session
        const lastClockOut = new Date(existingRecord.clock_out);
        const gapMinutes = Math.round((clockInTime.getTime() - lastClockOut.getTime()) / (1000 * 60));
        const newBreakMinutes = (existingRecord.break_minutes || 0) + gapMinutes;

      // Skip fee calculations on weekends (Saturday=6, Sunday=0) - use UTC to match server time
        const resumeDayOfWeek = clockInTime.getUTCDay();
        const isResumeWeekend = resumeDayOfWeek === 0 || resumeDayOfWeek === 6;

        let breakFee = 0;
        let settingsQuery = supabase.from("admin_settings").select("*");
        if (userAdminId) {
          settingsQuery = settingsQuery.eq("admin_id", userAdminId);
        }
        const { data: settings } = await settingsQuery.maybeSingle();

        if (!isResumeWeekend && settings && newBreakMinutes > settings.max_break_minutes) {
          const excessMinutes = newBreakMinutes - settings.max_break_minutes;
          breakFee = parseFloat(settings.excessive_break_fee.toString());
          toast.warning(`Break time exceeded by ${excessMinutes} minutes! Fee: $${breakFee}`);
        }

        // Build rule_snapshot if not already present
        const ruleSnapshot = existingRecord.rule_snapshot || (settings ? {
          work_start_time: settings.work_start_time,
          work_end_time: settings.work_end_time,
          late_start_fee: parseFloat(settings.late_start_fee.toString()),
          excessive_break_fee: parseFloat(settings.excessive_break_fee.toString()),
          day_off_fee: parseFloat(settings.day_off_fee.toString()),
          max_break_minutes: settings.max_break_minutes,
          timezone: (settings as Record<string, unknown>).timezone as string || 'Asia/Yerevan',
          late_grace_minutes: (settings as Record<string, unknown>).late_grace_minutes as number ?? 0,
        } : null);

        const { error } = await supabase
          .from("attendance")
          .update({
            clock_out: null,
            working_started_at: clockInTimestamp,
            break_minutes: newBreakMinutes,
            break_time_fee: breakFee,
            total_fees: (existingRecord.late_start_fee || 0) + breakFee,
            ...(ruleSnapshot && !existingRecord.rule_snapshot ? { rule_snapshot: ruleSnapshot } : {}),
          })
          .eq("id", existingRecord.id);

        if (error) throw error;
        toast.success(`Resumed session. Break: ${gapMinutes} min`);
        setHasClockedIn(true);
      } else {
        // First clock-in of the day
        let settingsQuery = supabase.from("admin_settings").select("*");
        if (userAdminId) {
          settingsQuery = settingsQuery.eq("admin_id", userAdminId);
        }
        const { data: settings } = await settingsQuery.maybeSingle();

        // Skip fee calculations on weekends (Saturday=6, Sunday=0) - use UTC to match server time
        const dayOfWeek = clockInTime.getUTCDay();
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

        let isLate = false;
        let lateFee = 0;

        if (!isWeekend && settings) {
          const timezone = (settings as Record<string, unknown>).timezone as string || 'Asia/Yerevan';
          const workStartTime = localTimeToUTC(settings.work_start_time, timezone, clockInTime);

          const minutesLate = (clockInTime.getTime() - workStartTime.getTime()) / (1000 * 60);

          if (minutesLate > 0) {
            isLate = true;
            lateFee = parseFloat(settings.late_start_fee.toString());
            toast.warning(`You are late by ${Math.round(minutesLate)} minutes! Fee: $${lateFee}`);
          }
        }

        // Build rule_snapshot from current settings
        const ruleSnapshot = settings ? {
          work_start_time: settings.work_start_time,
          work_end_time: settings.work_end_time,
          late_start_fee: parseFloat(settings.late_start_fee.toString()),
          excessive_break_fee: parseFloat(settings.excessive_break_fee.toString()),
          day_off_fee: parseFloat(settings.day_off_fee.toString()),
          max_break_minutes: settings.max_break_minutes,
          timezone: (settings as Record<string, unknown>).timezone as string || 'Asia/Yerevan',
          late_grace_minutes: (settings as Record<string, unknown>).late_grace_minutes as number ?? 0,
        } : null;

        const { error } = await supabase
          .from("attendance")
          .insert({
            user_id: user.id,
            date: today,
            clock_in: clockInTimestamp,
            working_started_at: clockInTimestamp,
            is_late: isLate,
            late_start_fee: lateFee,
            total_fees: lateFee,
            admin_id: userAdminId,
            ...(ruleSnapshot ? { rule_snapshot: ruleSnapshot } : {}),
          });

        if (error) throw error;
        toast.success("Clocked in successfully");
        setHasClockedIn(true);
      }
    } catch (error: unknown) {
      console.error("Error clocking in:", error);
      toast.error("Failed to clock in");
    } finally {
      setLoading(false);
    }
  };

  const handleClockOut = async () => {
    if (!user) return;

    setLoading(true);
    setShowClockOutDialog(false);
    try {
      const today = await fetchServerDateKey();
      const clockOutTimestamp = await fetchServerTimestamp();

      // Fresh query to get active session
      const { data: records } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .is("clock_out", null)
        .order("clock_in", { ascending: false })
        .limit(1);

      const activeRecord = records?.[0];

      if (!activeRecord) {
        toast.error("No active clock-in session found");
        setHasClockedIn(false);
        setLoading(false);
        return;
      }

      // Get user's admin_id for tenant settings
      const { data: profile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .maybeSingle();

      const userAdminId = profile?.admin_id || effectiveTenantId;

      // Evaluate break fee at clock-out if not already applied
      let breakFee = activeRecord.break_time_fee || 0;
      const snapshot = activeRecord.rule_snapshot as { max_break_minutes?: number; excessive_break_fee?: number } | null;
      let maxBreakMinutes = snapshot?.max_break_minutes;
      let excessiveBreakFee = snapshot?.excessive_break_fee;

      if (maxBreakMinutes == null || excessiveBreakFee == null) {
        let settingsQuery = supabase.from("admin_settings").select("max_break_minutes, excessive_break_fee");
        if (userAdminId) settingsQuery = settingsQuery.eq("admin_id", userAdminId);
        const { data: settings } = await settingsQuery.maybeSingle();
        maxBreakMinutes = maxBreakMinutes ?? settings?.max_break_minutes ?? 120;
        excessiveBreakFee = excessiveBreakFee ?? (settings ? parseFloat(settings.excessive_break_fee.toString()) : 0);
      }

      const totalBreakMinutes = activeRecord.break_minutes || 0;
      if (totalBreakMinutes > maxBreakMinutes && breakFee === 0 && excessiveBreakFee > 0) {
        breakFee = excessiveBreakFee;
        toast.warning(`Break time exceeded: ${totalBreakMinutes} min (limit: ${maxBreakMinutes}). Fee: $${breakFee}`);
      }

      const newTotalFees = (activeRecord.late_start_fee || 0) + breakFee;

      const { error } = await supabase
        .from("attendance")
        .update({
          clock_out: clockOutTimestamp,
          break_time_fee: breakFee,
          total_fees: newTotalFees,
        })
        .eq("id", activeRecord.id);

      if (error) throw error;
      toast.success("Clocked out successfully");
      setHasClockedIn(false);
    } catch (error: unknown) {
      console.error("Error clocking out:", error);
      toast.error("Failed to clock out");
    } finally {
      setLoading(false);
    }
  };

  if (!canUseButtons) return null;

  return (
    <div className="flex items-center gap-2">
      {!hasClockedIn && (
        <Button
          size="sm"
          variant="default"
          onClick={handleClockIn}
          disabled={loading}
          className="gap-2"
        >
          <LogIn className="h-4 w-4" />
          Clock In
        </Button>
      )}
      
      {hasClockedIn && (
        <AlertDialog open={showClockOutDialog} onOpenChange={setShowClockOutDialog}>
          <AlertDialogTrigger asChild>
            <Button
              size="sm"
              variant="outline"
              disabled={loading}
              className="gap-2"
            >
              <LogOut className="h-4 w-4" />
              Clock Out
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Clock Out</AlertDialogTitle>
              <AlertDialogDescription>
                Do you really want to clock out?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel asChild>
                <Button variant="default">No</Button>
              </AlertDialogCancel>
              <AlertDialogAction asChild>
                <Button variant="outline" onClick={handleClockOut}>Yes</Button>
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
