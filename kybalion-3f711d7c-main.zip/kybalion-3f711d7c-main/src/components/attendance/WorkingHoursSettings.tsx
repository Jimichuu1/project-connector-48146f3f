import { useState, useEffect } from "react";
import { Clock, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTenant } from "@/contexts/TenantContext";

interface WorkingHoursSettingsData {
  id: string;
  work_start_time: string;
  work_end_time: string;
  late_start_fee: number;
  excessive_break_fee: number;
  day_off_fee: number;
  max_break_minutes: number;
  late_grace_minutes: number;
  monthly_honorable_absences: number;
}

export function WorkingHoursSettings() {
  const { effectiveTenantId, isSuperAdmin } = useTenant();
  const [settings, setSettings] = useState<WorkingHoursSettingsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [formData, setFormData] = useState({
    work_start_time: "09:00",
    work_end_time: "18:00",
    late_start_fee: "10.00",
    excessive_break_fee: "5.00",
    day_off_fee: "0.00",
    max_break_minutes: "60",
    late_grace_minutes: "15",
    monthly_honorable_absences: "0"
  });

  useEffect(() => {
    fetchSettings();
  }, [effectiveTenantId]);

  const fetchSettings = async () => {
    setLoading(true);
    try {
      // First try tenant-specific settings from admin_settings
      if (effectiveTenantId) {
        const { data: tenantData, error: tenantError } = await supabase
          .from("admin_settings")
          .select("id, work_start_time, work_end_time, late_start_fee, excessive_break_fee, day_off_fee, max_break_minutes, late_grace_minutes, monthly_honorable_absences")
          .eq("admin_id", effectiveTenantId)
          .maybeSingle();

        if (tenantData) {
          setSettings(tenantData as WorkingHoursSettingsData);
          setFormData({
            work_start_time: tenantData.work_start_time.substring(0, 5),
            work_end_time: tenantData.work_end_time.substring(0, 5),
            late_start_fee: tenantData.late_start_fee.toString(),
            excessive_break_fee: tenantData.excessive_break_fee.toString(),
            day_off_fee: tenantData.day_off_fee.toString(),
            max_break_minutes: tenantData.max_break_minutes.toString(),
            late_grace_minutes: ((tenantData as any).late_grace_minutes ?? 15).toString(),
            monthly_honorable_absences: ((tenantData as any).monthly_honorable_absences ?? 0).toString()
          });
          setLoading(false);
          return;
        }

        // If no tenant settings exist, create them with defaults
        const { data: newSettings, error: createError } = await supabase
          .from("admin_settings")
          .insert({
            admin_id: effectiveTenantId,
            work_start_time: "09:00:00",
            work_end_time: "18:00:00",
            late_start_fee: 10,
            excessive_break_fee: 5,
            day_off_fee: 0,
            max_break_minutes: 60
          })
          .select()
          .single();

        if (newSettings) {
          setSettings(newSettings as unknown as WorkingHoursSettingsData);
          setFormData({
            work_start_time: newSettings.work_start_time.substring(0, 5),
            work_end_time: newSettings.work_end_time.substring(0, 5),
            late_start_fee: newSettings.late_start_fee.toString(),
            excessive_break_fee: newSettings.excessive_break_fee.toString(),
            day_off_fee: newSettings.day_off_fee.toString(),
            max_break_minutes: newSettings.max_break_minutes.toString(),
            late_grace_minutes: ((newSettings as any).late_grace_minutes ?? 15).toString(),
            monthly_honorable_absences: ((newSettings as any).monthly_honorable_absences ?? 0).toString()
          });
          setLoading(false);
          return;
        }
      }

      // No tenant selected (Super Admin without active tenant) — nothing to load.
      // Settings live in admin_settings only; user must select a tenant first.
    } catch (error) {
      console.error("Error fetching settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!settings) return;
    try {
      if (!effectiveTenantId) {
        toast.error("Select a tenant first to edit its settings");
        return;
      }
      const { error } = await supabase
        .from("admin_settings")
        .update({
          work_start_time: formData.work_start_time + ":00",
          work_end_time: formData.work_end_time + ":00",
          late_start_fee: parseFloat(formData.late_start_fee),
          excessive_break_fee: parseFloat(formData.excessive_break_fee),
          day_off_fee: parseFloat(formData.day_off_fee),
          max_break_minutes: parseInt(formData.max_break_minutes),
          late_grace_minutes: parseInt(formData.late_grace_minutes),
          monthly_honorable_absences: parseInt(formData.monthly_honorable_absences)
        })
        .eq("id", settings.id);

      if (error) throw error;

      toast.success("Settings updated successfully");
      setShowDialog(false);
      fetchSettings();
    } catch (error) {
      console.error("Error updating settings:", error);
      toast.error("Failed to update settings");
    }
  };

  if (loading || !settings) return null;

  return (
    <>
      <div className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm font-medium">Working Hours:</span>
          <span className="text-sm">{settings.work_start_time.substring(0, 5)} - {settings.work_end_time.substring(0, 5)}</span>
        </div>
        <div className="h-4 w-px bg-border" />
        <div className="flex items-center gap-4 text-sm">
          <span>
            <span className="text-muted-foreground">Late:</span>{" "}
            <span className="text-destructive font-medium">${settings.late_start_fee}</span>
          </span>
          <span>
            <span className="text-muted-foreground">Break:</span>{" "}
            <span className="text-destructive font-medium">${settings.excessive_break_fee}</span>
          </span>
          <span>
            <span className="text-muted-foreground">Day Off:</span>{" "}
            <span className="text-destructive font-medium">${settings.day_off_fee}</span>
          </span>
          <span>
            <span className="text-muted-foreground">Grace:</span>{" "}
            <span className="font-medium">{settings.late_grace_minutes}min</span>
          </span>
          <span>
            <span className="text-muted-foreground">Honorable:</span>{" "}
            <span className="font-medium">{settings.monthly_honorable_absences} days</span>
          </span>
        </div>
        <Button size="sm" variant="ghost" onClick={() => setShowDialog(true)} className="h-7 ml-auto">
          <Settings className="h-3.5 w-3.5 mr-1" />
          Edit
        </Button>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Working Hours & Fees</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Work Start Time</Label>
                <Input
                  type="time"
                  value={formData.work_start_time}
                  onChange={(e) => setFormData({ ...formData, work_start_time: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Work End Time</Label>
                <Input
                  type="time"
                  value={formData.work_end_time}
                  onChange={(e) => setFormData({ ...formData, work_end_time: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Late Start Fee ($)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.late_start_fee}
                onChange={(e) => setFormData({ ...formData, late_start_fee: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Excessive Break Fee ($)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.excessive_break_fee}
                onChange={(e) => setFormData({ ...formData, excessive_break_fee: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Day Off Fee ($)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.day_off_fee}
                onChange={(e) => setFormData({ ...formData, day_off_fee: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Max Break Minutes</Label>
              <Input
                type="number"
                value={formData.max_break_minutes}
                onChange={(e) => setFormData({ ...formData, max_break_minutes: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Late Grace Minutes</Label>
              <Input
                type="number"
                min="0"
                value={formData.late_grace_minutes}
                onChange={(e) => setFormData({ ...formData, late_grace_minutes: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Minutes after start time before late fee applies. Set to 0 for no grace period.
              </p>
            </div>

            <div className="space-y-2">
              <Label>Monthly Honorable Absences</Label>
              <Input
                type="number"
                min="0"
                value={formData.monthly_honorable_absences}
                onChange={(e) => setFormData({ ...formData, monthly_honorable_absences: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Number of day-offs per month that won't incur a fee. Set to 0 to charge all day-offs.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button size="sm" variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleSave}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
