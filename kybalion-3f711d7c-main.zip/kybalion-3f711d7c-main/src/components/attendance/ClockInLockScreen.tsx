import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Clock, LogIn } from "lucide-react";
import { useAttendance } from "@/hooks/useAttendance";
import { format } from "date-fns";

export function ClockInLockScreen() {
  const { clockIn } = useAttendance();
  const [isClockingIn, setIsClockingIn] = useState(false);

  const handleClockIn = async () => {
    setIsClockingIn(true);
    await clockIn();
    setIsClockingIn(false);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center p-4">
      <div className="flex flex-col items-center gap-8 p-12 rounded-2xl border-2 border-primary/20 bg-card/95 backdrop-blur-xl shadow-2xl max-w-lg w-full">
        <div className="flex flex-col items-center gap-6">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/20 rounded-full blur-2xl animate-pulse" />
            <Clock className="relative h-32 w-32 text-primary" />
          </div>
          <div className="text-center space-y-3">
            <h1 className="text-4xl font-bold text-foreground">Welcome Back!</h1>
            <p className="text-lg text-muted-foreground">
              {format(new Date(), "EEEE, MMMM d, yyyy")}
            </p>
            <p className="text-muted-foreground">
              Please clock in to continue your workday
            </p>
          </div>
        </div>

        <div className="w-full space-y-4">
          <Button 
            size="lg" 
            onClick={handleClockIn}
            disabled={isClockingIn}
            className="w-full text-lg h-14 gap-2"
          >
            <LogIn className="h-5 w-5" />
            {isClockingIn ? "Clocking In..." : "Clock In Now"}
          </Button>

          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Your attendance will be recorded once you clock in
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 pt-4 border-t border-border w-full">
          <div className="flex-1 text-center">
            <p className="text-xs text-muted-foreground mb-1">Current Time</p>
            <p className="text-lg font-semibold text-foreground">
              {format(new Date(), "h:mm a")}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
