import { useState, useEffect, useCallback } from "react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useTenant } from "@/contexts/TenantContext";
import { toast } from "sonner";
import { getErrorMessage } from "@/types/errors";
import type { WorkingPeriod } from "@/types/attendance";
import type { Json } from "@/integrations/supabase/types";
import { localTimeToUTC } from "@/lib/timezoneUtils";

// Helper to get server time as YYYY-MM-DD
async function fetchServerDateKey(): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_server_time') as { data: string | null; error: Error | null };
    if (error || !data) return new Date().toISOString().split("T")[0];
    return new Date(data).toISOString().split("T")[0];
  } catch {
    return new Date().toISOString().split("T")[0];
  }
}

// Helper to get server timestamp
async function fetchServerTimestamp(): Promise<string> {
  try {
    const { data, error } = await supabase.rpc('get_server_time') as { data: string | null; error: Error | null };
    if (error || !data) return new Date().toISOString();
    return data;
  } catch {
    return new Date().toISOString();
  }
}

export function WorkingToggle() {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const [isWorking, setIsWorking] = useState(false);
  const [loading, setLoading] = useState(false);
  const [canUseToggle, setCanUseToggle] = useState(false);

  const checkUserRole = useCallback(async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["AGENT", "SUPER_AGENT", "TEAM_LEADER"])
      .maybeSingle();

    setCanUseToggle(!!data);
  }, [user]);

  const checkWorkingStatus = useCallback(async () => {
    if (!user) return;

    const today = await fetchServerDateKey();
    const { data: records } = await supabase
      .from("attendance")
      .select("id, working_started_at, clock_out")
      .eq("user_id", user.id)
      .eq("date", today)
      .is("clock_out", null)
      .order("clock_in", { ascending: false })
      .limit(1);

    const activeRecord = records?.[0];
    // Derive state from DB: working if active session with working_started_at set
    setIsWorking(!!activeRecord?.working_started_at);
  }, [user]);

  useEffect(() => {
    checkUserRole();
    checkWorkingStatus();
  }, [checkUserRole, checkWorkingStatus]);

  // Realtime subscription to keep toggle in sync across tabs
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel("working_toggle_updates")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "attendance",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          checkWorkingStatus();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, checkWorkingStatus]);

  const handleToggle = async (checked: boolean) => {
    if (!user) return;

    setLoading(true);

    try {
      const today = await fetchServerDateKey();
      const now = await fetchServerTimestamp();

      // Fresh query to get active session
      const { data: records } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .is("clock_out", null)
        .order("clock_in", { ascending: false })
        .limit(1);

      const todayRecord = records?.[0];

      if (!todayRecord) {
        toast.error("Please clock in first");
        setLoading(false);
        return;
      }

      if (checked) {
        // Start working
        const updatePayload: Record<string, unknown> = { working_started_at: now };

        // Safety-net late fee check: first work start of the day
        const existingPeriods = (todayRecord.working_periods as unknown as WorkingPeriod[]) || [];
        const alreadyHasLateFee = (todayRecord.late_start_fee || 0) > 0;

        if (existingPeriods.length === 0 && !alreadyHasLateFee) {
          const snapshot = todayRecord.rule_snapshot as { work_start_time?: string; late_start_fee?: number; late_grace_minutes?: number } | null;
          const workStartTimeStr = snapshot?.work_start_time;
          const snapshotLateFee = snapshot?.late_start_fee;

          if (workStartTimeStr && snapshotLateFee != null) {
            // Weekend check (no fees on Sat/Sun)
            const nowDate = new Date(now);
            const dayOfWeek = nowDate.getUTCDay();
            const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

            if (!isWeekend) {
              const snapshotTimezone = (snapshot as Record<string, unknown>)?.timezone as string || 'Asia/Yerevan';
              const workStartDate = localTimeToUTC(workStartTimeStr, snapshotTimezone, nowDate);

              // Apply grace period if available
              const graceMinutes = snapshot?.late_grace_minutes ?? 0;
              const graceMs = graceMinutes * 60 * 1000;

              const minutesLate = (nowDate.getTime() - workStartDate.getTime() - graceMs) / (1000 * 60);

              if (minutesLate > 0) {
                updatePayload.is_late = true;
                updatePayload.late_start_fee = snapshotLateFee;
                updatePayload.total_fees = snapshotLateFee + (todayRecord.break_time_fee || 0);
                toast.warning(`You are late by ${Math.round(minutesLate)} minutes! Fee: $${snapshotLateFee}`);
              }
            }
          }
        }

        const { error } = await supabase
          .from("attendance")
          .update(updatePayload)
          .eq("id", todayRecord.id);

        if (error) throw error;
        toast.success("Work started");
        setIsWorking(true);
      } else {
        // Stop working (start break)
        if (!todayRecord.working_started_at) {
          toast.error("Working period not found");
          setLoading(false);
          return;
        }

        const existingPeriods = (todayRecord.working_periods as unknown as WorkingPeriod[]) || [];
        const periods: WorkingPeriod[] = [...existingPeriods, {
          started_at: todayRecord.working_started_at as string,
          ended_at: now,
        }];

        // Calculate total break minutes
        const totalWorkMinutes = periods.reduce((sum: number, period: WorkingPeriod) => {
          const start = new Date(period.started_at);
          const end = new Date(period.ended_at);
          return sum + (end.getTime() - start.getTime()) / (1000 * 60);
        }, 0);

        const clockInTime = new Date(todayRecord.clock_in);
        const totalMinutes = (new Date(now).getTime() - clockInTime.getTime()) / (1000 * 60);
        const breakMinutes = Math.round(totalMinutes - totalWorkMinutes);

        // Get break settings from rule_snapshot if available, otherwise fetch from admin_settings
        const snapshot = todayRecord.rule_snapshot as { max_break_minutes?: number; excessive_break_fee?: number } | null;
        let maxBreakMinutes = snapshot?.max_break_minutes;
        let excessiveBreakFee = snapshot?.excessive_break_fee;

        if (maxBreakMinutes == null || excessiveBreakFee == null) {
          let settingsQuery = supabase.from("admin_settings").select("*");
          if (effectiveTenantId) {
            settingsQuery = settingsQuery.eq("admin_id", effectiveTenantId);
          }
          const { data: settings } = await settingsQuery.maybeSingle();
          maxBreakMinutes = settings?.max_break_minutes ?? 60;
          excessiveBreakFee = settings ? parseFloat(settings.excessive_break_fee.toString()) : 0;
        }

        let breakFee = 0;
        if (breakMinutes > maxBreakMinutes) {
          breakFee = excessiveBreakFee;
        }

        const { error } = await supabase
          .from("attendance")
          .update({
            working_started_at: null,
            working_periods: periods as unknown as Json,
            break_minutes: breakMinutes,
            break_time_fee: breakFee,
            total_fees: (todayRecord.late_start_fee || 0) + breakFee,
          })
          .eq("id", todayRecord.id);

        if (error) throw error;
        toast.success("Break started");
        setIsWorking(false);
      }
    } catch (error) {
      console.error("Error toggling work status:", error);
      toast.error(getErrorMessage(error, "Failed to update work status"));
      // Re-fetch actual state instead of guessing
      checkWorkingStatus();
    } finally {
      setLoading(false);
    }
  };

  if (!canUseToggle) return null;

  return (
    <div className="flex items-center gap-2">
      <Switch
        id="working-toggle"
        checked={isWorking}
        onCheckedChange={handleToggle}
        disabled={loading}
      />
      <Label htmlFor="working-toggle" className="cursor-pointer text-sm font-medium">
        Working
      </Label>
    </div>
  );
}
