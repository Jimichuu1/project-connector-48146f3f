import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Clock, Coffee, AlertTriangle } from "lucide-react";
import { useTenant } from "@/contexts/TenantContext";

interface LockScreenProps {
  onBackToWork: () => void;
}

export function LockScreen({ onBackToWork }: LockScreenProps) {
  const { user } = useAuth();
  const { effectiveTenantId } = useTenant();
  const [breakStartTime, setBreakStartTime] = useState<Date | null>(null);
  const [elapsedTime, setElapsedTime] = useState<string>("00:00");
  const [elapsedMinutes, setElapsedMinutes] = useState<number>(0);
  const [accumulatedBreakMinutes, setAccumulatedBreakMinutes] = useState<number>(0);
  const [maxBreakMinutes, setMaxBreakMinutes] = useState<number>(60);

  // Fetch settings for max break minutes
  useEffect(() => {
    const fetchSettings = async () => {
      if (!user) return;
      
      // Get user's admin_id
      const { data: profile } = await supabase
        .from("profiles")
        .select("admin_id")
        .eq("id", user.id)
        .maybeSingle();
      
      const adminId = profile?.admin_id || effectiveTenantId;
      
      if (adminId) {
        const { data: tenantSettings } = await supabase
          .from("admin_settings")
          .select("max_break_minutes")
          .eq("admin_id", adminId)
          .maybeSingle();
        
        if (tenantSettings?.max_break_minutes) {
          setMaxBreakMinutes(tenantSettings.max_break_minutes);
          return;
        }
      }
      
      // No tenant settings — keep current default; settings live in admin_settings only.
    };
    
    fetchSettings();
  }, [user, effectiveTenantId]);

  useEffect(() => {
    const checkBreakStart = async () => {
      if (!user) return;

      const today = new Date().toISOString().split("T")[0];
      const { data: records } = await supabase
        .from("attendance")
        .select("*")
        .eq("user_id", user.id)
        .eq("date", today)
        .is("clock_out", null)
        .order("clock_in", { ascending: false })
        .limit(1);

      const activeRecord = records?.[0];
      if (activeRecord) {
        // Set accumulated break minutes from the record
        setAccumulatedBreakMinutes(activeRecord.break_minutes || 0);
        
        if (activeRecord.working_periods) {
          const periods = activeRecord.working_periods as any[];
          const lastPeriod = periods[periods.length - 1];
          if (lastPeriod?.ended_at) {
            setBreakStartTime(new Date(lastPeriod.ended_at));
          }
        }
      }
    };

    checkBreakStart();
  }, [user]);

  useEffect(() => {
    if (!breakStartTime) return;

    const interval = setInterval(() => {
      const now = new Date();
      const diff = now.getTime() - breakStartTime.getTime();
      const minutes = Math.floor(diff / 60000);
      const seconds = Math.floor((diff % 60000) / 1000);
      setElapsedTime(`${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`);
      setElapsedMinutes(minutes);
    }, 1000);

    return () => clearInterval(interval);
  }, [breakStartTime]);

  // Calculate total break time and remaining
  const totalBreakMinutes = accumulatedBreakMinutes + elapsedMinutes;
  const remainingBreakMinutes = Math.max(0, maxBreakMinutes - totalBreakMinutes);
  const isOverLimit = totalBreakMinutes >= maxBreakMinutes;
  
  // Format remaining time
  const formatRemainingTime = (minutes: number) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hrs > 0) {
      return `${hrs}h ${mins}m`;
    }
    return `${mins}m`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex items-center justify-center">
      <div className="flex flex-col items-center gap-8 p-12 rounded-lg border-2 border-border bg-card shadow-2xl max-w-md w-full mx-4">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <Coffee className="h-24 w-24 text-primary animate-pulse" />
            <div className="absolute -bottom-2 -right-2 bg-primary/20 rounded-full p-2">
              <Clock className="h-6 w-6 text-primary" />
            </div>
          </div>
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold text-foreground">On Break</h2>
            <p className="text-muted-foreground text-lg">You're currently taking a break</p>
          </div>
        </div>

        <div className="flex flex-col items-center gap-2">
          <p className="text-sm text-muted-foreground">Current break time</p>
          <p className="text-4xl font-mono font-bold text-primary">{elapsedTime}</p>
        </div>

        {/* Available break time indicator */}
        <div className={`flex flex-col items-center gap-1 p-4 rounded-lg w-full ${
          isOverLimit 
            ? "bg-destructive/10 border border-destructive/30" 
            : "bg-muted/50"
        }`}>
          {isOverLimit ? (
            <>
              <div className="flex items-center gap-2 text-destructive">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Break time exceeded!</span>
              </div>
              <p className="text-sm text-destructive/80">
                Fee will be applied ({totalBreakMinutes - maxBreakMinutes}m over limit)
              </p>
            </>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">Available break time remaining</p>
              <p className="text-2xl font-semibold text-foreground">
                {formatRemainingTime(remainingBreakMinutes)}
              </p>
              <p className="text-xs text-muted-foreground">
                Total today: {totalBreakMinutes}m / {maxBreakMinutes}m allowed
              </p>
            </>
          )}
        </div>

        <Button 
          size="lg" 
          onClick={onBackToWork}
          className="w-full text-lg h-12"
        >
          Back to Work
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Click the button above when you're ready to resume working
        </p>
      </div>
    </div>
  );
}
