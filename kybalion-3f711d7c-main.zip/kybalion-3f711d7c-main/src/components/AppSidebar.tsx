import { LayoutDashboard, Users, UserPlus, TrendingUp, BarChart3, Shield, ListChecks, Clock, Settings, ChevronDown, LogOut, User, UsersRound, Building2, Wallet, FileText, Star, Target, History as HistoryIcon, Radio, Plug } from "lucide-react";
import { KybalionLogo } from "@/components/KybalionLogo";
import { HighDepositAgentBanner } from "@/components/attendance/HighDepositAgentBanner";
import { NavLink } from "@/components/NavLink";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useManagerTeam } from "@/hooks/useManagerTeam";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarFooter, SidebarHeader, useSidebar } from "@/components/ui/sidebar";
import { toHashedPath, HASH_TO_ROUTE } from "@/lib/routeMap";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { TenantSwitcher } from "@/components/TenantSwitcher";
import { useTenant } from "@/contexts/TenantContext";
import { useUserData } from "@/contexts/UserDataContext";
const dashboardItems = [{
  title: "Dashboard",
  url: "/dashboard",
  icon: LayoutDashboard,
  adminOnly: true // SUPER_ADMIN and TENANT_OWNER
}, {
  title: "Targets",
  url: "/targets",
  icon: Target,
  adminOnly: true
}, {
  title: "Salary",
  url: "/salary",
  icon: Wallet,
  adminOnly: true // SUPER_ADMIN and TENANT_OWNER
}, {
  title: "Reports",
  url: "/reports",
  icon: BarChart3
}, {
  title: "Scripts",
  url: "/scripts",
  icon: FileText
}];
const workspaceItems = [{
  title: "Live RT",
  url: "/live-traffic",
  icon: Radio,
  adminOnly: true,
  superAgentAllowed: true,
  liveBadge: true
}, {
  title: "Leads",
  url: "/leads",
  icon: UserPlus
}, {
  title: "Clients",
  url: "/clients",
  icon: Users
}, {
  title: "Favourite Clients",
  url: "/favourite-clients",
  icon: Star,
  adminOnly: true
}, {
  title: "Pipeline",
  url: "/pipeline",
  icon: TrendingUp
}, {
  title: "Convert Queue",
  url: "/convert-queue",
  icon: ListChecks
}];
const managementItems = [{
  title: "Tenant Management",
  url: "/tenant-management",
  icon: Building2,
  superAdminOnly: true
}, {
  title: "User Management",
  url: "/user-management",
  icon: Shield,
  adminOnly: true
}, {
  title: "Team Management",
  url: "/team-management",
  icon: UsersRound,
  adminOnly: true
}, {
  title: "Attendance",
  url: "/attendance",
  icon: Clock
}, {
  title: "Session Monitoring",
  url: "/security-monitoring",
  icon: Shield,
  adminOnly: true
}];
const settingsItems = [{
  title: "General Settings",
  url: "/settings",
  icon: Settings
}, {
  title: "Live Settings",
  url: "/settings/live",
  icon: Radio
}, {
  title: "App Integration",
  url: "/settings/app-integration",
  icon: Plug
}];
export function AppSidebar() {
  const {
    state
  } = useSidebar();
  const {
    user
  } = useAuth();
  const {
    effectiveTenantId,
    isSuperAdmin
  } = useTenant();
  const { isManager, isTeamLeader, isAgent, isSuperAgent, hasTenantOwnerAccess } = useUserData();
  const { canAccessClients, canAccessPipeline, isLoading: managerTeamLoading } = useManagerTeam();
  const location = useLocation();
  const currentPath = location.pathname;
  const [hasAdminAccess, setHasAdminAccess] = useState(false);
  const [hasManagerAccess, setHasManagerAccess] = useState(false);
  const [isAgentOnly, setIsAgentOnly] = useState(false);
  const isManagerOrTL = isManager || isTeamLeader;

  // Collapsible state
  const [workspaceOpen, setWorkspaceOpen] = useState(true);
  const [managementOpen, setManagementOpen] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(true);
  // Simplified counts - use React Query for caching instead of realtime subscriptions
  const { data: counts = { leads: 0, clients: 0, opportunities: 0, conversions: 0, users: 0 } } = useQuery({
    queryKey: ['sidebar-counts', effectiveTenantId],
    staleTime: 2 * 60 * 1000, // 2 minutes - reduced polling
    gcTime: 5 * 60 * 1000, // 5 minutes cache
    refetchOnWindowFocus: false,
    enabled: !!user && effectiveTenantId !== undefined,
    queryFn: async () => {
      // Build queries with tenant filter
      let leadsQuery = supabase.from("leads").select("id", { count: "exact", head: true });
      let clientsQuery = supabase.from("clients").select("id", { count: "exact", head: true });
      let branchesQuery = supabase.from("sale_branches").select("id", { count: "exact", head: true });
      let conversionsQuery = supabase.from("leads").select("id", { count: "exact", head: true }).eq("pending_conversion", true);

      // Apply tenant filter
      if (effectiveTenantId) {
        leadsQuery = leadsQuery.eq("admin_id", effectiveTenantId);
        clientsQuery = clientsQuery.eq("admin_id", effectiveTenantId);
        branchesQuery = branchesQuery.eq("admin_id", effectiveTenantId);
        conversionsQuery = conversionsQuery.eq("admin_id", effectiveTenantId);
      }

      // Get users count
      const { data: userRolesData } = await supabase
        .from("user_roles")
        .select("user_id")
        .not("role", "in", "(SUPER_ADMIN,TENANT_OWNER)");
      
      let usersCount = 0;
      if (userRolesData && userRolesData.length > 0) {
        const userIds = userRolesData.map(r => r.user_id);
        let profilesQuery = supabase
          .from("profiles")
          .select("id", { count: "exact", head: true })
          .in("id", userIds);

        if (effectiveTenantId) {
          profilesQuery = profilesQuery.eq("admin_id", effectiveTenantId);
        }
        const { count } = await profilesQuery;
        usersCount = count || 0;
      }

      const [leadsRes, clientsRes, opportunitiesRes, conversionsRes] = await Promise.all([
        leadsQuery, clientsQuery, branchesQuery, conversionsQuery
      ]);

      return {
        leads: leadsRes.count || 0,
        clients: clientsRes.count || 0,
        opportunities: opportunitiesRes.count || 0,
        conversions: conversionsRes.count || 0,
        users: usersCount
      };
    },
  });

  // Live Traffic "new" count — drives the pulsing LIVE badge in sidebar
  const queryClient = useQueryClient();
  const { data: liveNewCount = 0 } = useQuery({
    queryKey: ['sidebar-live-traffic-new', effectiveTenantId],
    enabled: !!user && !!effectiveTenantId,
    staleTime: 30 * 1000,
    queryFn: async () => {
      let q = supabase
        .from("live_traffic_submissions")
        .select("id", { count: "exact", head: true })
        .eq("status", "new");
      if (effectiveTenantId) q = q.eq("admin_id", effectiveTenantId);
      const { count } = await q;
      return count || 0;
    },
  });

  useEffect(() => {
    if (!effectiveTenantId) return;
    const ch = supabase
      .channel(`sidebar-live-traffic-${effectiveTenantId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "live_traffic_submissions",
          filter: `admin_id=eq.${effectiveTenantId}`,
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ["sidebar-live-traffic-new"] });
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [effectiveTenantId, queryClient]);

  useEffect(() => {
    if (user) {
      setHasAdminAccess(hasTenantOwnerAccess);
      setHasManagerAccess(hasTenantOwnerAccess || isManagerOrTL);
      setIsAgentOnly(isAgent && !isSuperAgent && !isManagerOrTL && !hasTenantOwnerAccess);
    }
  }, [user, hasTenantOwnerAccess, isManagerOrTL, isAgent, isSuperAgent]);
  const isActive = (path: string) => {
    // Map current hashed path back to readable for comparison
    const readableCurrent = HASH_TO_ROUTE[currentPath]
      ?? (currentPath.startsWith("/p/")
          ? Object.entries(HASH_TO_ROUTE).find(([h]) => currentPath.startsWith(h + "/"))?.[1]
            ? Object.entries(HASH_TO_ROUTE).find(([h]) => currentPath.startsWith(h + "/"))![1]
              + currentPath.slice(Object.entries(HASH_TO_ROUTE).find(([h]) => currentPath.startsWith(h + "/"))![0].length)
            : currentPath
          : currentPath);
    if (path === "/clients" && readableCurrent.startsWith("/clients/")) return true;
    if (path === "/leads" && readableCurrent.startsWith("/leads/")) return true;
    if (path === "/settings" && readableCurrent !== "/settings") return false;
    return readableCurrent === path;
  };
  const getCount = (title: string) => {
    switch (title) {
      case "Leads":
        return counts.leads;
      case "Clients":
        return counts.clients;
      case "Pipeline":
        return counts.opportunities;
      case "Convert Queue":
        return counts.conversions;
      case "User Management":
        return counts.users;
      default:
        return null;
    }
  };
  const isCollapsed = state === "collapsed";
  const sidebarWidth = isCollapsed ? "w-16" : "w-64";
  const renderMenuItem = (item: {
    title: string;
    url: string;
    icon: React.ElementType;
    liveBadge?: boolean;
  }, showCount = false) => {
    const count = showCount ? getCount(item.title) : null;
    const isPendingConversions = item.title === "Convert Queue" && count !== null && count > 0;
    return <SidebarMenuItem key={item.title}>
        <SidebarMenuButton asChild isActive={isActive(item.url)} tooltip={isCollapsed ? item.title + (isPendingConversions ? ` (${count})` : "") : undefined}>
          <NavLink to={toHashedPath(item.url) ?? item.url} end={item.url === "/settings"} className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-all hover:bg-accent/50 ${isCollapsed ? "justify-center" : ""}`} activeClassName="bg-accent text-accent-foreground font-medium">
            <div className="relative">
              <item.icon className="h-4 w-4 flex-shrink-0" />
              {isCollapsed && isPendingConversions && <span className="absolute -top-1.5 -right-1.5 h-4 w-4 flex items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                  {count > 9 ? "9+" : count}
                </span>}
              {isCollapsed && item.liveBadge && (
                <span className={`absolute -top-1 -right-1 h-2 w-2 rounded-full ring-2 ring-background ${liveNewCount > 0 ? "bg-yellow-400 animate-pulse" : "bg-muted-foreground/40"}`} />
              )}
            </div>
            {!isCollapsed && <div className="flex items-center justify-between flex-1 gap-2">
                <div className="flex items-center gap-1.5">
                  <span>{item.title}</span>
                  {item.liveBadge && (
                    <Badge
                      className={`h-4 px-1.5 text-[9px] font-bold tracking-wider border-0 ${
                        liveNewCount > 0
                          ? "bg-yellow-400 text-yellow-950 hover:bg-yellow-400 animate-pulse"
                          : "bg-muted text-muted-foreground hover:bg-muted"
                      }`}
                    >
                      LIVE
                    </Badge>
                  )}
                </div>
                {count !== null && count > 0 && <Badge variant={isPendingConversions ? "default" : "secondary"} className={`ml-auto text-xs h-5 px-1.5 ${isPendingConversions ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                    {count}
                  </Badge>}
              </div>}
          </NavLink>
        </SidebarMenuButton>
      </SidebarMenuItem>;
  };
  return <Sidebar className={`${sidebarWidth} transition-all duration-200 ease-in-out`} collapsible="icon">
      {/* Sidebar Header with Logo */}
      <SidebarHeader className="pt-0">
        <div className={`flex items-center h-16 transition-all duration-200 ${isCollapsed ? "justify-center" : "gap-3 px-4"}`}>
          <div className="h-8 w-8 rounded-lg overflow-hidden flex items-center justify-center flex-shrink-0">
            <KybalionLogo className="h-8 w-8 text-foreground" />
          </div>
          {!isCollapsed && <div className="flex flex-col">
              <span className="text-sm text-foreground tracking-[0.3em] font-extrabold">K Y B A L I O N</span>
              <span className="text-[9px] text-muted-foreground whitespace-nowrap">Customer Relationship Management</span>
            </div>}
        </div>
        {/* Tenant Switcher for Super Admins */}
        <div className={`${isCollapsed ? "px-1" : "px-3"} pb-2`}>
          <TenantSwitcher />
        </div>
      </SidebarHeader>

      <SidebarContent className={`${isCollapsed ? "pt-0" : "pt-4"} [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]`}>
        {/* Top Agent Banner */}
        {!isCollapsed}

        {/* Dashboard Section - No collapsible */}
        <SidebarGroup className="py-0">
          <SidebarGroupContent>
            <SidebarMenu className={`${isCollapsed ? "gap-0 px-1" : "gap-0.5 px-2"}`}>
              {dashboardItems.filter(item => {
              if (item.adminOnly && !hasAdminAccess && !isSuperAdmin) return false;
              if (isAgentOnly && !["Reports", "Scripts"].includes(item.title)) return false;
              return true;
            }).map(item => renderMenuItem(item))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Work Space Section - Collapsible */}
        <SidebarGroup className="py-0">
          <Collapsible open={workspaceOpen} onOpenChange={setWorkspaceOpen}>
            <CollapsibleTrigger asChild>
              <button type="button" className={`flex items-center w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer ${isCollapsed ? "justify-center py-3" : "justify-between px-3 py-2"}`}>
                {!isCollapsed && <span className="uppercase tracking-wider">Work Space</span>}
                {isCollapsed && <span className="text-[10px]">WO</span>}
                {!isCollapsed && <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${workspaceOpen ? "" : "-rotate-90"}`} />}
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <SidebarGroupContent>
                <SidebarMenu className={`${isCollapsed ? "gap-0 px-1" : "gap-0.5 px-2 ml-2 border-l border-border/50"}`}>
                  {workspaceItems.filter(item => {
                  // Super Agent allowance: items flagged superAgentAllowed bypass admin gating for SAs
                  const saBypass = (item as any).superAgentAllowed && isSuperAgent;
                  // Admin-only items hidden from non-admins (unless SA bypass)
                  if (item.adminOnly && !hasAdminAccess && !isSuperAdmin && !saBypass) return false;
                  // Agent-only restrictions
                  if (isAgentOnly && !["Leads", "Convert Queue"].includes(item.title)) return false;
                  // Team Leader restrictions: no Clients page, no Pipeline
                  if (isTeamLeader) {
                    if (item.title === "Clients") return false;
                    if (item.title === "Pipeline") return false;
                  }
                  // Manager restrictions based on team composition
                  // Don't hide items while still loading to prevent flickering
                  if (isManager && !managerTeamLoading) {
                    if (item.title === "Clients" && !canAccessClients) return false;
                    if (item.title === "Pipeline" && !canAccessPipeline) return false;
                  }
                  return true;
                }).map(item => renderMenuItem(item, true))}
                </SidebarMenu>
              </SidebarGroupContent>
            </CollapsibleContent>
          </Collapsible>
        </SidebarGroup>

        {/* Management Section - Collapsible (visible to MANAGER and above) */}
        {hasManagerAccess && <SidebarGroup className="py-0">
          <Collapsible open={managementOpen} onOpenChange={setManagementOpen}>
              <CollapsibleTrigger asChild>
                <button type="button" className={`flex items-center w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer ${isCollapsed ? "justify-center py-3" : "justify-between px-3 py-2"}`}>
                  {!isCollapsed && <span className="uppercase tracking-wider">Management</span>}
                  {isCollapsed && <span className="text-[10px]">MA</span>}
                  {!isCollapsed && <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${managementOpen ? "" : "-rotate-90"}`} />}
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <SidebarGroupContent>
                  <SidebarMenu className={`${isCollapsed ? "gap-0 px-1" : "gap-0.5 px-2 ml-2 border-l border-border/50"}`}>
                    {managementItems.filter(item => {
                  if (item.superAdminOnly && !isSuperAdmin) return false;
                  if (item.adminOnly && !hasAdminAccess) return false;
                  return true;
                }).map(item => renderMenuItem(item, item.title === "User Management"))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </Collapsible>
          </SidebarGroup>}

        {/* Settings Section - Collapsible (ADMIN and SUPER_ADMIN only) */}
        {(hasAdminAccess || isSuperAdmin) && <SidebarGroup className="py-0">
            <Collapsible open={settingsOpen} onOpenChange={setSettingsOpen}>
              <CollapsibleTrigger asChild>
                <button type="button" className={`flex items-center w-full text-xs font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer ${isCollapsed ? "justify-center py-3" : "justify-between px-3 py-2"}`}>
                  {!isCollapsed && <span className="uppercase tracking-wider">Settings</span>}
                  {isCollapsed && <span className="text-[10px]">SE</span>}
                  {!isCollapsed && <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${settingsOpen ? "" : "-rotate-90"}`} />}
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <SidebarGroupContent>
                  <SidebarMenu className={`${isCollapsed ? "gap-0 px-1" : "gap-0.5 px-2 ml-2 border-l border-border/50"}`}>
                    {settingsItems.map(item => renderMenuItem(item))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </Collapsible>
          </SidebarGroup>}
      </SidebarContent>

      <SidebarFooter className="mt-auto p-2">
        <SidebarUserProfile isCollapsed={isCollapsed} />
      </SidebarFooter>
    </Sidebar>;
}
function SidebarUserProfile({
  isCollapsed
}: {
  isCollapsed: boolean;
}) {
  const {
    user,
    signOut
  } = useAuth();
  const navigate = useNavigate();
  const {
    data: profile
  } = useQuery({
    queryKey: ['sidebar-user-profile', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const {
        data,
        error
      } = await supabase.from('profiles').select('username, full_name, avatar_url').eq('id', user.id).single();
      if (error) throw error;
      return data;
    },
    enabled: !!user
  });
  const getInitials = (name: string) => name.substring(0, 2).toUpperCase();
  const displayName = profile?.full_name || profile?.username || user?.email || "User";
  return <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className={`flex items-center gap-3 w-full rounded-xl p-2 bg-accent/40 hover:bg-accent/60 transition-colors ${isCollapsed ? "justify-center" : ""}`}>
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarImage src={profile?.avatar_url || ""} alt={displayName} />
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              {getInitials(displayName)}
            </AvatarFallback>
          </Avatar>
          {!isCollapsed && <div className="flex flex-col items-start flex-1 min-w-0">
              <span className="text-sm font-medium truncate w-full text-left">{displayName}</span>
              <span className="text-xs text-muted-foreground truncate w-full text-left">
                {profile?.username || "View profile"}
              </span>
            </div>}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align={isCollapsed ? "center" : "start"} side="top" className="w-56">
        <DropdownMenuItem onClick={() => navigate(toHashedPath("/settings/profile") ?? "/settings/profile")} className="cursor-pointer">
          <User className="mr-2 h-4 w-4" />
          Profile
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={signOut} className="cursor-pointer text-destructive focus:text-destructive">
          <LogOut className="mr-2 h-4 w-4" />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>;
}